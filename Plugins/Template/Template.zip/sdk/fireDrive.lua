fireDrive = require("delayedLoad.dlua").new("fireDriveCore.dlua");
FireDrive = fireDrive;
return fireDrive;
