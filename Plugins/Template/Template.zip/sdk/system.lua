﻿system = require("delayedLoad.dlua").new("systemCore.dlua");
System = system;
return system;
