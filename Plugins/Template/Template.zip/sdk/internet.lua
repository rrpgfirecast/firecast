internet = require("delayedLoad.dlua").new("internetCore.dlua");
Internet = internet;
return internet;
