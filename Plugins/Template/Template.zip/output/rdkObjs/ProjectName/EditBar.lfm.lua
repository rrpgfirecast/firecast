require("firecast.lua");
local __o_rrpgObjs = require("rrpgObjs.lua");
require("rrpgGUI.lua");
require("rrpgDialogs.lua");
require("rrpgLFM.lua");
require("ndb.lua");
require("locale.lua");
local __o_Utils = require("utils.lua");

local function constructNew_frmEditBar()
    local obj = GUI.fromHandle(_obj_newObject("form"));
    local self = obj;
    local sheet = nil;

    rawset(obj, "_oldSetNodeObjectFunction", rawget(obj, "setNodeObject"));

    function obj:setNodeObject(nodeObject)
        sheet = nodeObject;
        self.sheet = nodeObject;
        self:_oldSetNodeObjectFunction(nodeObject);
    end;

    function obj:setNodeDatabase(nodeObject)
        self:setNodeObject(nodeObject);
    end;

    _gui_assignInitialParentForForm(obj.handle);
    obj:beginUpdate();
    obj:setName("frmEditBar");
    obj:setAlign("client");

    obj.BarPopup = GUI.fromHandle(_obj_newObject("popup"));
    obj.BarPopup:setParent(obj);
    obj.BarPopup:setName("BarPopup");
    obj.BarPopup:setWidth(140);
    obj.BarPopup:setHeight(66);
    obj.BarPopup:setBackOpacity(0);
    obj.BarPopup:setMargins({left=4, right=4, top=4, bottom=4});
    lfm_setPropAsString(obj.BarPopup, "autoScopeNode",  "false");

    obj.rectangle1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle1:setParent(obj.BarPopup);
    obj.rectangle1:setAlign("client");
    obj.rectangle1:setColor("white");
    obj.rectangle1:setXradius(5);
    obj.rectangle1:setYradius(5);
    obj.rectangle1:setName("rectangle1");

    obj.PopupBarColor = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.PopupBarColor:setParent(obj.rectangle1);
    obj.PopupBarColor:setAlign("client");
    obj.PopupBarColor:setName("PopupBarColor");
    obj.PopupBarColor:setColor("#808080");
    obj.PopupBarColor:setXradius(5);
    obj.PopupBarColor:setYradius(5);
    obj.PopupBarColor:setOpacity(0.9);

    obj.label1 = GUI.fromHandle(_obj_newObject("label"));
    obj.label1:setParent(obj.PopupBarColor);
    obj.label1:setFontColor("black");
    obj.label1:setMargins({left=6, top=2});
    obj.label1:setAlign("top");
    obj.label1:setText("Valor");
    obj.label1:setField("AtributoBarrinha");
    obj.label1:setFontSize(12);
    lfm_setPropAsString(obj.label1, "fontStyle",  "bold");
    obj.label1:setTextTrimming("character");
    obj.label1:setName("label1");

    obj.layout1 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout1:setParent(obj.PopupBarColor);
    obj.layout1:setAlign("client");
    obj.layout1:setMargins({top=2, left=4});
    obj.layout1:setName("layout1");

    obj.layout2 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout2:setParent(obj.layout1);
    obj.layout2:setAlign("top");
    obj.layout2:setHeight(18);
    obj.layout2:setName("layout2");

    obj.label2 = GUI.fromHandle(_obj_newObject("label"));
    obj.label2:setParent(obj.layout2);
    obj.label2:setFontColor("black");
    obj.label2:setAlign("left");
    obj.label2:setText("Atual:  ");
    obj.label2:setHorzTextAlign("trailing");
    obj.label2:setWidth(34);
    obj.label2:setMargins({right=2});
    obj.label2:setFontSize(12);
    obj.label2:setName("label2");

    obj.comboBox1 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox1:setParent(obj.layout2);
    obj.comboBox1:setFontColor("white");
    obj.comboBox1:setMargins({left=2});
    obj.comboBox1:setAlign("left");
    obj.comboBox1:setTransparent(false);
    obj.comboBox1:setWidth(40);
    obj.comboBox1:setField("ModificadorBarrinha");
    obj.comboBox1:setItems({'=', '+', '-'});
    obj.comboBox1:setValues({'igual', 'mais', 'menos'});
    obj.comboBox1:setValue("igual");
    obj.comboBox1:setName("comboBox1");

    obj.currentBarValue = GUI.fromHandle(_obj_newObject("edit"));
    obj.currentBarValue:setParent(obj.layout2);
    obj.currentBarValue:setFontColor("white");
    obj.currentBarValue:setMargins({left=2, right=4});
    obj.currentBarValue:setType("number");
    obj.currentBarValue:setAlign("client");
    obj.currentBarValue:setField("ValorMudadoAtualBarrinha");
    obj.currentBarValue:setName("currentBarValue");

    obj.layout3 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout3:setParent(obj.layout1);
    obj.layout3:setAlign("top");
    obj.layout3:setHeight(18);
    obj.layout3:setName("layout3");

    obj.label3 = GUI.fromHandle(_obj_newObject("label"));
    obj.label3:setParent(obj.layout3);
    obj.label3:setFontColor("black");
    obj.label3:setAlign("left");
    obj.label3:setText("Max:  ");
    obj.label3:setHorzTextAlign("trailing");
    obj.label3:setWidth(34);
    obj.label3:setMargins({right=2});
    obj.label3:setFontSize(12);
    obj.label3:setName("label3");

    obj.comboBox2 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox2:setParent(obj.layout3);
    obj.comboBox2:setFontColor("white");
    obj.comboBox2:setMargins({left=2});
    obj.comboBox2:setAlign("left");
    obj.comboBox2:setTransparent(false);
    obj.comboBox2:setWidth(40);
    obj.comboBox2:setField("ModificadorBarrinhaMax");
    obj.comboBox2:setItems({'=', '+', '-'});
    obj.comboBox2:setValues({'igual', 'mais', 'menos'});
    obj.comboBox2:setValue("igual");
    obj.comboBox2:setName("comboBox2");

    obj.maxBarValue = GUI.fromHandle(_obj_newObject("edit"));
    obj.maxBarValue:setParent(obj.layout3);
    obj.maxBarValue:setFontColor("white");
    obj.maxBarValue:setMargins({left=2, right=4});
    obj.maxBarValue:setType("number");
    obj.maxBarValue:setAlign("client");
    obj.maxBarValue:setField("ValorMudadoMaxBarrinha");
    obj.maxBarValue:setName("maxBarValue");

    obj.scrollBox1 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox1:setParent(obj);
    obj.scrollBox1:setAlign("client");
    obj.scrollBox1:setName("scrollBox1");

    obj.layout4 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout4:setParent(obj.scrollBox1);
    obj.layout4:setAlign("top");
    obj.layout4:setHeight(25);
    obj.layout4:setName("layout4");

    obj.layout5 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout5:setParent(obj.layout4);
    obj.layout5:setAlign("left");
    obj.layout5:setWidth(125);
    obj.layout5:setName("layout5");

    obj.edit1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit1:setParent(obj.layout5);
    obj.edit1:setAlign("left");
    obj.edit1:setWidth(50);
    obj.edit1:setField("AtributoBarrinha1");
    obj.edit1:setName("edit1");

    obj.layout6 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout6:setParent(obj.layout5);
    obj.layout6:setAlign("left");
    obj.layout6:setWidth(45);
    obj.layout6:setMargins({top=5,bottom=5});
    obj.layout6:setName("layout6");

    obj.imageCheckBox1 = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.imageCheckBox1:setParent(obj.layout6);
    obj.imageCheckBox1:setAlign("client");
    obj.imageCheckBox1:setName("imageCheckBox1");

    obj.Barrinha1 = GUI.fromHandle(_obj_newObject("progressBar"));
    obj.Barrinha1:setParent(obj.imageCheckBox1);
    obj.Barrinha1:setColorMode("hl");
    obj.Barrinha1:setWidth(45);
    obj.Barrinha1:setHeight(15);
    obj.Barrinha1:setMargins({top=5,bottom=5});
    obj.Barrinha1:setHitTest(true);
    obj.Barrinha1:setMouseGlow(true);
    obj.Barrinha1:setColor("Red");
    obj.Barrinha1:setName("Barrinha1");
    obj.Barrinha1:setField("Barrinha1Valor");
    obj.Barrinha1:setFieldMax("Barrinha1ValorMax");

    obj.ValoresBarrinha1 = GUI.fromHandle(_obj_newObject("layout"));
    obj.ValoresBarrinha1:setParent(obj.layout5);
    obj.ValoresBarrinha1:setAlign("left");
    obj.ValoresBarrinha1:setWidth(30);
    obj.ValoresBarrinha1:setMargins({top=5,bottom=5});
    obj.ValoresBarrinha1:setVisible(false);
    obj.ValoresBarrinha1:setName("ValoresBarrinha1");

    obj.CorBarrinha1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.CorBarrinha1:setParent(obj.ValoresBarrinha1);
    obj.CorBarrinha1:setAlign("client");
    obj.CorBarrinha1:setXradius(2);
    obj.CorBarrinha1:setYradius(2);
    obj.CorBarrinha1:setName("CorBarrinha1");
    obj.CorBarrinha1:setColor("Green");

    obj.InfoBarrinha1 = GUI.fromHandle(_obj_newObject("label"));
    obj.InfoBarrinha1:setParent(obj.CorBarrinha1);
    obj.InfoBarrinha1:setAlign("left");
    obj.InfoBarrinha1:setFontColor("white");
    obj.InfoBarrinha1:setFontSize(10);
    obj.InfoBarrinha1:setAutoSize(true);
    obj.InfoBarrinha1:setTextTrimming("none");
    obj.InfoBarrinha1:setWordWrap(false);
    obj.InfoBarrinha1:setName("InfoBarrinha1");
    obj.InfoBarrinha1:setField("InfoBarrinha1");
    obj.InfoBarrinha1:setHorzTextAlign("center");
    obj.InfoBarrinha1:setText("0/0");

    obj.dataLink1 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink1:setParent(obj.layout5);
    obj.dataLink1:setField("CorBarrinha1");
    obj.dataLink1:setDefaultValue("Green");
    obj.dataLink1:setName("dataLink1");

    obj.dataLink2 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink2:setParent(obj.layout5);
    obj.dataLink2:setField("Barrinha1Valor");
    obj.dataLink2:setName("dataLink2");

    obj.layout7 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout7:setParent(obj.layout4);
    obj.layout7:setAlign("left");
    obj.layout7:setWidth(125);
    obj.layout7:setName("layout7");

    obj.edit2 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit2:setParent(obj.layout7);
    obj.edit2:setAlign("left");
    obj.edit2:setWidth(50);
    obj.edit2:setField("AtributoBarrinha2");
    obj.edit2:setName("edit2");

    obj.layout8 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout8:setParent(obj.layout7);
    obj.layout8:setAlign("left");
    obj.layout8:setWidth(45);
    obj.layout8:setMargins({top=5,bottom=5});
    obj.layout8:setName("layout8");

    obj.imageCheckBox2 = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.imageCheckBox2:setParent(obj.layout8);
    obj.imageCheckBox2:setAlign("client");
    obj.imageCheckBox2:setName("imageCheckBox2");

    obj.Barrinha2 = GUI.fromHandle(_obj_newObject("progressBar"));
    obj.Barrinha2:setParent(obj.imageCheckBox2);
    obj.Barrinha2:setColorMode("hl");
    obj.Barrinha2:setWidth(45);
    obj.Barrinha2:setHeight(15);
    obj.Barrinha2:setMargins({top=5,bottom=5});
    obj.Barrinha2:setHitTest(true);
    obj.Barrinha2:setMouseGlow(true);
    obj.Barrinha2:setColor("Red");
    obj.Barrinha2:setName("Barrinha2");
    obj.Barrinha2:setField("Barrinha2Valor");
    obj.Barrinha2:setFieldMax("Barrinha2ValorMax");

    obj.ValoresBarrinha2 = GUI.fromHandle(_obj_newObject("layout"));
    obj.ValoresBarrinha2:setParent(obj.layout7);
    obj.ValoresBarrinha2:setAlign("left");
    obj.ValoresBarrinha2:setWidth(30);
    obj.ValoresBarrinha2:setMargins({top=5,bottom=5});
    obj.ValoresBarrinha2:setVisible(false);
    obj.ValoresBarrinha2:setName("ValoresBarrinha2");

    obj.CorBarrinha2 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.CorBarrinha2:setParent(obj.ValoresBarrinha2);
    obj.CorBarrinha2:setAlign("client");
    obj.CorBarrinha2:setXradius(2);
    obj.CorBarrinha2:setYradius(2);
    obj.CorBarrinha2:setName("CorBarrinha2");
    obj.CorBarrinha2:setColor("Green");

    obj.InfoBarrinha2 = GUI.fromHandle(_obj_newObject("label"));
    obj.InfoBarrinha2:setParent(obj.CorBarrinha2);
    obj.InfoBarrinha2:setAlign("left");
    obj.InfoBarrinha2:setFontColor("white");
    obj.InfoBarrinha2:setFontSize(10);
    obj.InfoBarrinha2:setAutoSize(true);
    obj.InfoBarrinha2:setTextTrimming("none");
    obj.InfoBarrinha2:setWordWrap(false);
    obj.InfoBarrinha2:setName("InfoBarrinha2");
    obj.InfoBarrinha2:setField("InfoBarrinha2");
    obj.InfoBarrinha2:setHorzTextAlign("center");
    obj.InfoBarrinha2:setText("0/0");

    obj.dataLink3 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink3:setParent(obj.layout7);
    obj.dataLink3:setField("CorBarrinha2");
    obj.dataLink3:setDefaultValue("Green");
    obj.dataLink3:setName("dataLink3");

    obj.dataLink4 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink4:setParent(obj.layout7);
    obj.dataLink4:setField("Barrinha2Valor");
    obj.dataLink4:setName("dataLink4");

    obj.layout9 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout9:setParent(obj.layout4);
    obj.layout9:setAlign("left");
    obj.layout9:setWidth(125);
    obj.layout9:setName("layout9");

    obj.edit3 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit3:setParent(obj.layout9);
    obj.edit3:setAlign("left");
    obj.edit3:setWidth(50);
    obj.edit3:setField("AtributoBarrinha3");
    obj.edit3:setName("edit3");

    obj.layout10 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout10:setParent(obj.layout9);
    obj.layout10:setAlign("left");
    obj.layout10:setWidth(45);
    obj.layout10:setMargins({top=5,bottom=5});
    obj.layout10:setName("layout10");

    obj.imageCheckBox3 = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.imageCheckBox3:setParent(obj.layout10);
    obj.imageCheckBox3:setAlign("client");
    obj.imageCheckBox3:setName("imageCheckBox3");

    obj.Barrinha3 = GUI.fromHandle(_obj_newObject("progressBar"));
    obj.Barrinha3:setParent(obj.imageCheckBox3);
    obj.Barrinha3:setColorMode("hl");
    obj.Barrinha3:setWidth(45);
    obj.Barrinha3:setHeight(15);
    obj.Barrinha3:setMargins({top=5,bottom=5});
    obj.Barrinha3:setHitTest(true);
    obj.Barrinha3:setMouseGlow(true);
    obj.Barrinha3:setColor("Red");
    obj.Barrinha3:setName("Barrinha3");
    obj.Barrinha3:setField("Barrinha3Valor");
    obj.Barrinha3:setFieldMax("Barrinha3ValorMax");

    obj.ValoresBarrinha3 = GUI.fromHandle(_obj_newObject("layout"));
    obj.ValoresBarrinha3:setParent(obj.layout9);
    obj.ValoresBarrinha3:setAlign("left");
    obj.ValoresBarrinha3:setWidth(30);
    obj.ValoresBarrinha3:setMargins({top=5,bottom=5});
    obj.ValoresBarrinha3:setVisible(false);
    obj.ValoresBarrinha3:setName("ValoresBarrinha3");

    obj.CorBarrinha3 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.CorBarrinha3:setParent(obj.ValoresBarrinha3);
    obj.CorBarrinha3:setAlign("client");
    obj.CorBarrinha3:setXradius(2);
    obj.CorBarrinha3:setYradius(2);
    obj.CorBarrinha3:setName("CorBarrinha3");
    obj.CorBarrinha3:setColor("Green");

    obj.InfoBarrinha3 = GUI.fromHandle(_obj_newObject("label"));
    obj.InfoBarrinha3:setParent(obj.CorBarrinha3);
    obj.InfoBarrinha3:setAlign("left");
    obj.InfoBarrinha3:setFontColor("white");
    obj.InfoBarrinha3:setFontSize(10);
    obj.InfoBarrinha3:setAutoSize(true);
    obj.InfoBarrinha3:setTextTrimming("none");
    obj.InfoBarrinha3:setWordWrap(false);
    obj.InfoBarrinha3:setName("InfoBarrinha3");
    obj.InfoBarrinha3:setField("InfoBarrinha3");
    obj.InfoBarrinha3:setHorzTextAlign("center");
    obj.InfoBarrinha3:setText("0/0");

    obj.dataLink5 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink5:setParent(obj.layout9);
    obj.dataLink5:setField("CorBarrinha3");
    obj.dataLink5:setDefaultValue("Green");
    obj.dataLink5:setName("dataLink5");

    obj.dataLink6 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink6:setParent(obj.layout9);
    obj.dataLink6:setField("Barrinha3Valor");
    obj.dataLink6:setName("dataLink6");

    obj._e_event0 = obj.BarPopup:addEventListener("onNodeReady",
        function (_)
            local node = self.BarPopup.scopeNode
            			if node == nil then return end
            			
            			local selectedBar = node.selectedBar
            
            			node.AtributoBarrinha = node["Atributo"..selectedBar]
            			node.ValorMudadoAtualBarrinha = node["ValorMudadoAtual"..selectedBar]
            			node.ValorMudadoMaxBarrinha = node["ValorMudadoMax"..selectedBar]
        end, obj);

    obj._e_event1 = obj.BarPopup:addEventListener("onClose",
        function (_, canceled)
            setTimeout( function()
            				local node = self.BarPopup.scopeNode
            				if node == nil then return end
            
            				local selectedBar = node.selectedBar
            
            				if (node.ModificadorBarrinha == "igual") then
            					node["ValorTempAtual"..selectedBar] = tonumber(node.ValorMudadoAtualBarrinha or 0);
            				elseif (node.ModificadorBarrinha == "mais") then
            					node["ValorTempAtual"..selectedBar] = tonumber(node["ValorTempAtual"..selectedBar] or 0) + tonumber(node.ValorMudadoAtualBarrinha or 0);
            				elseif (node.ModificadorBarrinha == "menos") then
            					node["ValorTempAtual"..selectedBar] = tonumber(node["ValorTempAtual"..selectedBar] or 0) - tonumber(node.ValorMudadoAtualBarrinha or 0);
            				end;
            				
            				if (node.ModificadorBarrinhaMax == "igual") then
            					node["ValorTempMax"..selectedBar] = tonumber(node.ValorMudadoMaxBarrinha or 0);
            				elseif (node.ModificadorBarrinhaMax == "mais") then
            					node["ValorTempMax"..selectedBar] = tonumber(node["ValorTempMax"..selectedBar] or 0) + tonumber(node.ValorMudadoMaxBarrinha or 0);
            				elseif (node.ModificadorBarrinhaMax == "menos") then
            					node["ValorTempMax"..selectedBar] = tonumber(node["ValorTempMax"..selectedBar] or 0) - tonumber(node.ValorMudadoMaxBarrinha or 0);
            				end;
            				
            				local barrinhapc = 0
            				local barrinhapcmax = 0
            				local porcentagem = 0
            				local porcentagemmax = 0
            
            				barrinhapc = (node["ValorTempAtual"..selectedBar] - (node[selectedBar.."Valor"] or 0));
            				barrinhapcmax = (node["ValorTempMax"..selectedBar] - (node[selectedBar.."ValorMax"] or 0));
            				node[selectedBar.."Valor"] = node["ValorTempAtual"..selectedBar];
            				node[selectedBar.."ValorMax"] = node["ValorTempMax"..selectedBar];
            				
            				if ((barrinhapc ~= 0) or (barrinhapcmax ~= 0)) then
            					local nome = node.AtributoBarrinha or "Barrinha";
            					local personagem = sheet.nome or "personagem";
            					local text = "[§K2]" .. nome .. "[§K3] de [§K2]" .. personagem.. "[§K3]: ";
            					local valor = barrinhapc;
            					local valormax = barrinhapcmax;
            					
            					if tonumber(barrinhapc) >= 0 then
            						valor = "+" .. tostring(barrinhapc);
            					end;
            					if tonumber(barrinhapcmax) >= 0 then
            						valormax = "+" .. tostring(barrinhapcmax);
            					end;
            					
            					if tonumber(valormax) == 0 then
            						text = text .. valor;
            					else
            						text = text .. valor .. "/" .. valormax;
            					end;
            					
            					local mesaDoPersonagem = Firecast.getMesaDe(sheet);
            					if mesaDoPersonagem ~= nil then
            						   mesaDoPersonagem.activeChat:enviarMensagem(text);
            					end;
            				end;
            			end, 100);
        end, obj);

    obj._e_event2 = obj.currentBarValue:addEventListener("onKeyDown",
        function (_, event)
            local oenter = (event.keyCode == 13)
            								if oenter then
            									self.BarPopup:close();
            								end;
        end, obj);

    obj._e_event3 = obj.maxBarValue:addEventListener("onKeyDown",
        function (_, event)
            local oenter = (event.keyCode == 13);
            								if oenter then
            									self.BarPopup:close();
            								end;
        end, obj);

    obj._e_event4 = obj.Barrinha1:addEventListener("onMouseEnter",
        function (_)
            self.CorBarrinha1.color = "Green";
            							self.ValoresBarrinha1.visible = true;
            							sheet.InfoBarrinha1 = (sheet.Barrinha1Valor or 0) .. "/"	.. (sheet.Barrinha1ValorMax or 0);
        end, obj);

    obj._e_event5 = obj.Barrinha1:addEventListener("onMouseLeave",
        function (_)
            self.ValoresBarrinha1.visible = false;
        end, obj);

    obj._e_event6 = obj.Barrinha1:addEventListener("onDblClick",
        function (_)
            sheet.Barrinha1ID = sheet.index;
            							
            							sheet.ModificadorBarrinha1 = "igual";
            							sheet.ModificadorBarrinha1Max = "igual";
            							sheet.ValorTempAtualBarrinha1 = sheet.Barrinha1Valor;
            							sheet.ValorTempMaxBarrinha1 = sheet.Barrinha1ValorMax;
            							sheet.ValorMudadoAtualBarrinha1 = sheet.Barrinha1Valor;
            							sheet.ValorMudadoMaxBarrinha1 = sheet.Barrinha1ValorMax;
            
            							local rec = self:findControlByName("PopupBarColor");
            							if rec~=nil then rec.color = "Green" end;
            							
            							local pop = self:findControlByName("BarPopup");
            							if pop~= nil then
            								pop.scopeNode = sheet
            								pop.scopeNode.selectedBar = "Barrinha1"
            								pop:show("top", self.Barrinha1)
            								pop.top = (pop.top + 29 + 10)
            							end;
        end, obj);

    obj._e_event7 = obj.InfoBarrinha1:addEventListener("onResize",
        function (_)
            self.InfoBarrinha1.width = (self.ValoresBarrinha1.width - 4);
        end, obj);

    obj._e_event8 = obj.dataLink1:addEventListener("onUserChange",
        function (_, field, oldValue, newValue)
            self.Barrinha1.color = "Green";
        end, obj);

    obj._e_event9 = obj.dataLink2:addEventListener("onChange",
        function (_, field, oldValue, newValue)
            if sheet.Barrinha1Valor==nil then return end;
            					if sheet.Barrinha1Valor==0 then 
            						self.Barrinha1.color = "Yellow";
            					else
            						self.Barrinha1.color = "Green";
            					end;
        end, obj);

    obj._e_event10 = obj.Barrinha2:addEventListener("onMouseEnter",
        function (_)
            self.CorBarrinha2.color = "Green";
            							self.ValoresBarrinha2.visible = true;
            							sheet.InfoBarrinha2 = (sheet.Barrinha2Valor or 0) .. "/"	.. (sheet.Barrinha2ValorMax or 0);
        end, obj);

    obj._e_event11 = obj.Barrinha2:addEventListener("onMouseLeave",
        function (_)
            self.ValoresBarrinha2.visible = false;
        end, obj);

    obj._e_event12 = obj.Barrinha2:addEventListener("onDblClick",
        function (_)
            sheet.Barrinha2ID = sheet.index;
            							
            							sheet.ModificadorBarrinha2 = "igual";
            							sheet.ModificadorBarrinha2Max = "igual";
            							sheet.ValorTempAtualBarrinha2 = sheet.Barrinha2Valor;
            							sheet.ValorTempMaxBarrinha2 = sheet.Barrinha2ValorMax;
            							sheet.ValorMudadoAtualBarrinha2 = sheet.Barrinha2Valor;
            							sheet.ValorMudadoMaxBarrinha2 = sheet.Barrinha2ValorMax;
            
            							local rec = self:findControlByName("PopupBarColor");
            							if rec~=nil then rec.color = "Green" end;
            							
            							local pop = self:findControlByName("BarPopup");
            							if pop~= nil then
            								pop.scopeNode = sheet
            								pop.scopeNode.selectedBar = "Barrinha2"
            								pop:show("top", self.Barrinha2)
            								pop.top = (pop.top + 29 + 10)
            							end;
        end, obj);

    obj._e_event13 = obj.InfoBarrinha2:addEventListener("onResize",
        function (_)
            self.InfoBarrinha2.width = (self.ValoresBarrinha2.width - 4);
        end, obj);

    obj._e_event14 = obj.dataLink3:addEventListener("onUserChange",
        function (_, field, oldValue, newValue)
            self.Barrinha2.color = "Green";
        end, obj);

    obj._e_event15 = obj.dataLink4:addEventListener("onChange",
        function (_, field, oldValue, newValue)
            if sheet.Barrinha2Valor==nil then return end;
            					if sheet.Barrinha2Valor==0 then 
            						self.Barrinha2.color = "Yellow";
            					else
            						self.Barrinha2.color = "Green";
            					end;
        end, obj);

    obj._e_event16 = obj.Barrinha3:addEventListener("onMouseEnter",
        function (_)
            self.CorBarrinha3.color = "Green";
            							self.ValoresBarrinha3.visible = true;
            							sheet.InfoBarrinha3 = (sheet.Barrinha3Valor or 0) .. "/"	.. (sheet.Barrinha3ValorMax or 0);
        end, obj);

    obj._e_event17 = obj.Barrinha3:addEventListener("onMouseLeave",
        function (_)
            self.ValoresBarrinha3.visible = false;
        end, obj);

    obj._e_event18 = obj.Barrinha3:addEventListener("onDblClick",
        function (_)
            sheet.Barrinha3ID = sheet.index;
            							
            							sheet.ModificadorBarrinha3 = "igual";
            							sheet.ModificadorBarrinha3Max = "igual";
            							sheet.ValorTempAtualBarrinha3 = sheet.Barrinha3Valor;
            							sheet.ValorTempMaxBarrinha3 = sheet.Barrinha3ValorMax;
            							sheet.ValorMudadoAtualBarrinha3 = sheet.Barrinha3Valor;
            							sheet.ValorMudadoMaxBarrinha3 = sheet.Barrinha3ValorMax;
            
            							local rec = self:findControlByName("PopupBarColor");
            							if rec~=nil then rec.color = "Green" end;
            							
            							local pop = self:findControlByName("BarPopup");
            							if pop~= nil then
            								pop.scopeNode = sheet
            								pop.scopeNode.selectedBar = "Barrinha3"
            								pop:show("top", self.Barrinha3)
            								pop.top = (pop.top + 29 + 10)
            							end;
        end, obj);

    obj._e_event19 = obj.InfoBarrinha3:addEventListener("onResize",
        function (_)
            self.InfoBarrinha3.width = (self.ValoresBarrinha3.width - 4);
        end, obj);

    obj._e_event20 = obj.dataLink5:addEventListener("onUserChange",
        function (_, field, oldValue, newValue)
            self.Barrinha3.color = "Green";
        end, obj);

    obj._e_event21 = obj.dataLink6:addEventListener("onChange",
        function (_, field, oldValue, newValue)
            if sheet.Barrinha3Valor==nil then return end;
            					if sheet.Barrinha3Valor==0 then 
            						self.Barrinha3.color = "Yellow";
            					else
            						self.Barrinha3.color = "Green";
            					end;
        end, obj);

    function obj:_releaseEvents()
        __o_rrpgObjs.removeEventListenerById(self._e_event21);
        __o_rrpgObjs.removeEventListenerById(self._e_event20);
        __o_rrpgObjs.removeEventListenerById(self._e_event19);
        __o_rrpgObjs.removeEventListenerById(self._e_event18);
        __o_rrpgObjs.removeEventListenerById(self._e_event17);
        __o_rrpgObjs.removeEventListenerById(self._e_event16);
        __o_rrpgObjs.removeEventListenerById(self._e_event15);
        __o_rrpgObjs.removeEventListenerById(self._e_event14);
        __o_rrpgObjs.removeEventListenerById(self._e_event13);
        __o_rrpgObjs.removeEventListenerById(self._e_event12);
        __o_rrpgObjs.removeEventListenerById(self._e_event11);
        __o_rrpgObjs.removeEventListenerById(self._e_event10);
        __o_rrpgObjs.removeEventListenerById(self._e_event9);
        __o_rrpgObjs.removeEventListenerById(self._e_event8);
        __o_rrpgObjs.removeEventListenerById(self._e_event7);
        __o_rrpgObjs.removeEventListenerById(self._e_event6);
        __o_rrpgObjs.removeEventListenerById(self._e_event5);
        __o_rrpgObjs.removeEventListenerById(self._e_event4);
        __o_rrpgObjs.removeEventListenerById(self._e_event3);
        __o_rrpgObjs.removeEventListenerById(self._e_event2);
        __o_rrpgObjs.removeEventListenerById(self._e_event1);
        __o_rrpgObjs.removeEventListenerById(self._e_event0);
    end;

    obj._oldLFMDestroy = obj.destroy;

    function obj:destroy() 
        self:_releaseEvents();

        if (self.handle ~= 0) and (self.setNodeDatabase ~= nil) then
          self:setNodeDatabase(nil);
        end;

        if self.CorBarrinha2 ~= nil then self.CorBarrinha2:destroy(); self.CorBarrinha2 = nil; end;
        if self.InfoBarrinha2 ~= nil then self.InfoBarrinha2:destroy(); self.InfoBarrinha2 = nil; end;
        if self.imageCheckBox3 ~= nil then self.imageCheckBox3:destroy(); self.imageCheckBox3 = nil; end;
        if self.Barrinha1 ~= nil then self.Barrinha1:destroy(); self.Barrinha1 = nil; end;
        if self.Barrinha2 ~= nil then self.Barrinha2:destroy(); self.Barrinha2 = nil; end;
        if self.Barrinha3 ~= nil then self.Barrinha3:destroy(); self.Barrinha3 = nil; end;
        if self.InfoBarrinha3 ~= nil then self.InfoBarrinha3:destroy(); self.InfoBarrinha3 = nil; end;
        if self.label1 ~= nil then self.label1:destroy(); self.label1 = nil; end;
        if self.layout4 ~= nil then self.layout4:destroy(); self.layout4 = nil; end;
        if self.label3 ~= nil then self.label3:destroy(); self.label3 = nil; end;
        if self.layout9 ~= nil then self.layout9:destroy(); self.layout9 = nil; end;
        if self.layout10 ~= nil then self.layout10:destroy(); self.layout10 = nil; end;
        if self.ValoresBarrinha3 ~= nil then self.ValoresBarrinha3:destroy(); self.ValoresBarrinha3 = nil; end;
        if self.CorBarrinha1 ~= nil then self.CorBarrinha1:destroy(); self.CorBarrinha1 = nil; end;
        if self.dataLink4 ~= nil then self.dataLink4:destroy(); self.dataLink4 = nil; end;
        if self.comboBox1 ~= nil then self.comboBox1:destroy(); self.comboBox1 = nil; end;
        if self.ValoresBarrinha1 ~= nil then self.ValoresBarrinha1:destroy(); self.ValoresBarrinha1 = nil; end;
        if self.InfoBarrinha1 ~= nil then self.InfoBarrinha1:destroy(); self.InfoBarrinha1 = nil; end;
        if self.ValoresBarrinha2 ~= nil then self.ValoresBarrinha2:destroy(); self.ValoresBarrinha2 = nil; end;
        if self.layout5 ~= nil then self.layout5:destroy(); self.layout5 = nil; end;
        if self.CorBarrinha3 ~= nil then self.CorBarrinha3:destroy(); self.CorBarrinha3 = nil; end;
        if self.dataLink1 ~= nil then self.dataLink1:destroy(); self.dataLink1 = nil; end;
        if self.label2 ~= nil then self.label2:destroy(); self.label2 = nil; end;
        if self.edit3 ~= nil then self.edit3:destroy(); self.edit3 = nil; end;
        if self.PopupBarColor ~= nil then self.PopupBarColor:destroy(); self.PopupBarColor = nil; end;
        if self.BarPopup ~= nil then self.BarPopup:destroy(); self.BarPopup = nil; end;
        if self.currentBarValue ~= nil then self.currentBarValue:destroy(); self.currentBarValue = nil; end;
        if self.maxBarValue ~= nil then self.maxBarValue:destroy(); self.maxBarValue = nil; end;
        if self.layout6 ~= nil then self.layout6:destroy(); self.layout6 = nil; end;
        if self.dataLink3 ~= nil then self.dataLink3:destroy(); self.dataLink3 = nil; end;
        if self.imageCheckBox1 ~= nil then self.imageCheckBox1:destroy(); self.imageCheckBox1 = nil; end;
        if self.dataLink6 ~= nil then self.dataLink6:destroy(); self.dataLink6 = nil; end;
        if self.layout3 ~= nil then self.layout3:destroy(); self.layout3 = nil; end;
        if self.dataLink5 ~= nil then self.dataLink5:destroy(); self.dataLink5 = nil; end;
        if self.dataLink2 ~= nil then self.dataLink2:destroy(); self.dataLink2 = nil; end;
        if self.edit2 ~= nil then self.edit2:destroy(); self.edit2 = nil; end;
        if self.layout8 ~= nil then self.layout8:destroy(); self.layout8 = nil; end;
        if self.layout1 ~= nil then self.layout1:destroy(); self.layout1 = nil; end;
        if self.scrollBox1 ~= nil then self.scrollBox1:destroy(); self.scrollBox1 = nil; end;
        if self.rectangle1 ~= nil then self.rectangle1:destroy(); self.rectangle1 = nil; end;
        if self.layout2 ~= nil then self.layout2:destroy(); self.layout2 = nil; end;
        if self.comboBox2 ~= nil then self.comboBox2:destroy(); self.comboBox2 = nil; end;
        if self.edit1 ~= nil then self.edit1:destroy(); self.edit1 = nil; end;
        if self.layout7 ~= nil then self.layout7:destroy(); self.layout7 = nil; end;
        if self.imageCheckBox2 ~= nil then self.imageCheckBox2:destroy(); self.imageCheckBox2 = nil; end;
        self:_oldLFMDestroy();
    end;

    obj:endUpdate();

    return obj;
end;

function newfrmEditBar()
    local retObj = nil;
    __o_rrpgObjs.beginObjectsLoading();

    __o_Utils.tryFinally(
      function()
        retObj = constructNew_frmEditBar();
      end,
      function()
        __o_rrpgObjs.endObjectsLoading();
      end);

    assert(retObj ~= nil);
    return retObj;
end;

local _frmEditBar = {
    newEditor = newfrmEditBar, 
    new = newfrmEditBar, 
    name = "frmEditBar", 
    dataType = "", 
    formType = "undefined", 
    formComponentName = "form", 
    title = "", 
    description=""};

frmEditBar = _frmEditBar;
Firecast.registrarForm(_frmEditBar);

return _frmEditBar;
