require("firecast.lua");
local __o_rrpgObjs = require("rrpgObjs.lua");
require("rrpgGUI.lua");
require("rrpgDialogs.lua");
require("rrpgLFM.lua");
require("ndb.lua");
require("locale.lua");
local __o_Utils = require("utils.lua");

local function constructNew_templateVinculo_2()
    local obj = GUI.fromHandle(_obj_newObject("form"));
    local self = obj;
    local sheet = nil;

    rawset(obj, "_oldSetNodeObjectFunction", obj.setNodeObject);

    function obj:setNodeObject(nodeObject)
        sheet = nodeObject;
        self.sheet = nodeObject;
        self:_oldSetNodeObjectFunction(nodeObject);
    end;

    function obj:setNodeDatabase(nodeObject)
        self:setNodeObject(nodeObject);
    end;

    _gui_assignInitialParentForForm(obj.handle);
    obj:beginUpdate();
    obj:setName("templateVinculo_2");
    obj:setHeight(140);
    obj.grid.role = "col";
    obj.grid.width = 6;
    obj.grid["cnt-gutter"] = 0;

    obj.indicador_corVinculo_2 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.indicador_corVinculo_2:setParent(obj);
    obj.indicador_corVinculo_2:setName("indicador_corVinculo_2");
    obj.indicador_corVinculo_2:setColor("#150e16");
    obj.indicador_corVinculo_2:setStrokeSize(1);
    obj.indicador_corVinculo_2:setStrokeColor("white");
    obj.indicador_corVinculo_2:setCornerType("round");
    obj.indicador_corVinculo_2:setXradius(5);
    obj.indicador_corVinculo_2:setYradius(5);
    obj.indicador_corVinculo_2.grid.role = "col";
    obj.indicador_corVinculo_2.grid.width = 12;
    obj.indicador_corVinculo_2:setHeight(140);

    obj.dataLink1 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink1:setParent(obj.indicador_corVinculo_2);
    obj.dataLink1:setField("corVinculo_2");
    obj.dataLink1:setName("dataLink1");

    obj.imgVinculo_2 = GUI.fromHandle(_obj_newObject("image"));
    obj.imgVinculo_2:setParent(obj.indicador_corVinculo_2);
    obj.imgVinculo_2:setName("imgVinculo_2");
    obj.imgVinculo_2:setField("imagemVinculo_2");
    obj.imgVinculo_2.grid.role = "col";
    obj.imgVinculo_2.grid.width = 12;
    obj.imgVinculo_2:setHeight(134);
    obj.imgVinculo_2:setStyle("proportional");
    obj.imgVinculo_2:setEditable(true);
    obj.imgVinculo_2.animate = true;
    obj.imgVinculo_2:setMargins({top=3,left=3,right=3,bottom=3});

    obj.dataLink2 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink2:setParent(obj.imgVinculo_2);
    obj.dataLink2:setField("imagemVinculo_2");
    obj.dataLink2:setDefaultValue("https://blob.firecast.com.br/blobs/GQNCNVTE_4313075/info.png");
    obj.dataLink2:setName("dataLink2");

    obj.label1 = GUI.fromHandle(_obj_newObject("label"));
    obj.label1:setParent(obj.imgVinculo_2);
    obj.label1.grid.role = "col";
    obj.label1.grid.width = 10;
    obj.label1:setName("label1");

    obj.btnExcluirVinculo_2 = GUI.fromHandle(_obj_newObject("button"));
    obj.btnExcluirVinculo_2:setParent(obj.imgVinculo_2);
    obj.btnExcluirVinculo_2:setName("btnExcluirVinculo_2");
    obj.btnExcluirVinculo_2:setText("✖");
    obj.btnExcluirVinculo_2.grid.role = "col";
    obj.btnExcluirVinculo_2.grid.width = 2;
    obj.btnExcluirVinculo_2:setFontSize(6);
    obj.btnExcluirVinculo_2:setHeight(21);
    obj.btnExcluirVinculo_2:setMargins({top=3,right=3});

    obj.rectangle1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle1:setParent(obj.imgVinculo_2);
    obj.rectangle1:setHeight(20);
    obj.rectangle1:setColor("black");
    obj.rectangle1:setCornerType("round");
    obj.rectangle1.grid.role = "col";
    obj.rectangle1.grid.width = 12;
    obj.rectangle1:setStrokeSize(1);
    obj.rectangle1:setStrokeColor("white");
    obj.rectangle1:setXradius(5);
    obj.rectangle1:setYradius(5);
    obj.rectangle1:setMargins({top=90,right=2,left=2});
    obj.rectangle1:setName("rectangle1");

    obj.edit1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit1:setParent(obj.rectangle1);
    obj.edit1:setField("nomeVinculo_2");
    obj.edit1.grid.role = "col";
    obj.edit1.grid.width = 12;
    obj.edit1:setTransparent(true);
    obj.edit1:setFontSize(15);
    obj.edit1:setHeight(21);
    obj.edit1:setVertTextAlign("center");
    obj.edit1:setHorzTextAlign("center");
    obj.edit1:setFontFamily("Wishes Script Caps Display");
    obj.edit1:setName("edit1");


        self.btnExcluirVinculo_2.onClick = function (_)
            local node = sheet
            if self.observer ~= nil then
                self.observer.enabled = false
                self.observer = nil
            end
            if node ~= nil then
                NDB.deleteNode(node)
            end
        end;
    


    obj._e_event0 = obj.dataLink1:addEventListener("onChange",
        function (field, oldValue, newValue)
            local cor = sheet.corVinculo_2 or "#ffffff"
                            self.indicador_corVinculo_2.color = cor
        end);

    obj._e_event1 = obj.dataLink2:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet == nil then return end
                                    pcall(function()
                                        if sheet.imagemVinculo_2 == nil then 
                                            sheet.imagemVinculo_2 = "https://blob.firecast.com.br/blobs/GQNCNVTE_4313075/info.png"
                                        end
                                    end)
        end);

    function obj:_releaseEvents()
        __o_rrpgObjs.removeEventListenerById(self._e_event1);
        __o_rrpgObjs.removeEventListenerById(self._e_event0);
    end;

    obj._oldLFMDestroy = obj.destroy;

    function obj:destroy() 
        self:_releaseEvents();

        if (self.handle ~= 0) and (self.setNodeDatabase ~= nil) then
          self:setNodeDatabase(nil);
        end;

        if self.dataLink2 ~= nil then self.dataLink2:destroy(); self.dataLink2 = nil; end;
        if self.indicador_corVinculo_2 ~= nil then self.indicador_corVinculo_2:destroy(); self.indicador_corVinculo_2 = nil; end;
        if self.dataLink1 ~= nil then self.dataLink1:destroy(); self.dataLink1 = nil; end;
        if self.rectangle1 ~= nil then self.rectangle1:destroy(); self.rectangle1 = nil; end;
        if self.imgVinculo_2 ~= nil then self.imgVinculo_2:destroy(); self.imgVinculo_2 = nil; end;
        if self.btnExcluirVinculo_2 ~= nil then self.btnExcluirVinculo_2:destroy(); self.btnExcluirVinculo_2 = nil; end;
        if self.edit1 ~= nil then self.edit1:destroy(); self.edit1 = nil; end;
        if self.label1 ~= nil then self.label1:destroy(); self.label1 = nil; end;
        self:_oldLFMDestroy();
    end;

    obj:endUpdate();

    return obj;
end;

function newtemplateVinculo_2()
    local retObj = nil;
    __o_rrpgObjs.beginObjectsLoading();

    __o_Utils.tryFinally(
      function()
        retObj = constructNew_templateVinculo_2();
      end,
      function()
        __o_rrpgObjs.endObjectsLoading();
      end);

    assert(retObj ~= nil);
    return retObj;
end;

local _templateVinculo_2 = {
    newEditor = newtemplateVinculo_2, 
    new = newtemplateVinculo_2, 
    name = "templateVinculo_2", 
    dataType = "", 
    formType = "undefined", 
    formComponentName = "form", 
    cacheMode = "none", 
    title = "", 
    description=""};

templateVinculo_2 = _templateVinculo_2;
Firecast.registrarForm(_templateVinculo_2);

return _templateVinculo_2;
