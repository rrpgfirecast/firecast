require("firecast.lua");
local __o_rrpgObjs = require("rrpgObjs.lua");
require("rrpgGUI.lua");
require("rrpgDialogs.lua");
require("rrpgLFM.lua");
require("ndb.lua");
require("locale.lua");
local __o_Utils = require("utils.lua");

local function constructNew_frmPickMeUp()
    local obj = GUI.fromHandle(_obj_newObject("form"));
    local self = obj;
    local sheet = nil;

    rawset(obj, "_oldSetNodeObjectFunction", obj.setNodeObject);

    function obj:setNodeObject(nodeObject)
        sheet = nodeObject;
        self.sheet = nodeObject;
        self:_oldSetNodeObjectFunction(nodeObject);
    end;

    function obj:setNodeDatabase(nodeObject)
        self:setNodeObject(nodeObject);
    end;

    _gui_assignInitialParentForForm(obj.handle);
    obj:beginUpdate();
    obj:setFormType("sheetTemplate");
    obj:setDataType("Pick_Me_Up_Geral");
    obj:setTitle("Pick Me Up");
    obj:setName("frmPickMeUp");

    obj.rectangle1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle1:setParent(obj);
    obj.rectangle1:setAlign("client");
    obj.rectangle1:setColor("black");
    obj.rectangle1:setName("rectangle1");

    obj.image1 = GUI.fromHandle(_obj_newObject("image"));
    obj.image1:setParent(obj.rectangle1);
    obj.image1.grid.role = "col";
    obj.image1.grid.width = 12;
    obj.image1:setStyle("proportional");
    obj.image1:setHeight(85);
    obj.image1:setSRC("http://blob.firecast.com.br/blobs/FCMWSWEU_3185381/Novo_Projeto__3_.png");
    obj.image1:setName("image1");

    obj.tipo_de_arquivo = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.tipo_de_arquivo:setParent(obj.image1);
    obj.tipo_de_arquivo:setField("tipo_de_arquivo");
    obj.tipo_de_arquivo:setName("tipo_de_arquivo");
    obj.tipo_de_arquivo:setItems({'Ficha', 'Texto', 'Inventário'});
    obj.tipo_de_arquivo.grid.role = "col";
    obj.tipo_de_arquivo.grid["max-width"] = 60;
    obj.tipo_de_arquivo:setHeight(30);
    obj.tipo_de_arquivo:setMargins({top=15});

    obj.dataLink1 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink1:setParent(obj.tipo_de_arquivo);
    obj.dataLink1:setField("tipo_de_arquivo");
    obj.dataLink1:setDefaultValue("Ficha");
    obj.dataLink1:setName("dataLink1");

    obj.scrollBox1 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox1:setParent(obj);
    obj.scrollBox1:setAlign("client");
    obj.scrollBox1:setMargins({left=10,right=10,top=80});
    obj.scrollBox1:setName("scrollBox1");

    obj.ficha = GUI.fromHandle(_obj_newObject("tabControl"));
    obj.ficha:setParent(obj.scrollBox1);
    obj.ficha:setAlign("client");
    obj.ficha:setName("ficha");
    obj.ficha:setVisible(false);
    obj.ficha.grid["cnt-gutter"] = 10;

    obj.aba_perfil = GUI.fromHandle(_obj_newObject("tab"));
    obj.aba_perfil:setParent(obj.ficha);
    obj.aba_perfil:setName("aba_perfil");
    obj.aba_perfil:setTitle("Perfil");

    obj.rectangle2 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle2:setParent(obj.aba_perfil);
    obj.rectangle2:setAlign("client");
    obj.rectangle2:setColor("black");
    obj.rectangle2:setName("rectangle2");

    obj.scrollBox2 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox2:setParent(obj.rectangle2);
    obj.scrollBox2:setAlign("client");
    obj.scrollBox2:setMargins({left=5,right=5});
    obj.scrollBox2:setName("scrollBox2");

    obj.rectangle3 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle3:setParent(obj.scrollBox2);
    obj.rectangle3:setColor("#150e16");
    obj.rectangle3:setStrokeSize(2);
    obj.rectangle3:setStrokeColor("white");
    obj.rectangle3.grid.role = "col";
    obj.rectangle3.grid.width = 4;
    obj.rectangle3.grid["max-width"] = 1080;
    obj.rectangle3.grid["min-width"] = 400;
    obj.rectangle3.grid["min-height"] = 550;
    obj.rectangle3.grid["max-height"] = 1080;
    obj.rectangle3:setMargins({top=15});
    obj.rectangle3:setName("rectangle3");

    obj.label1 = GUI.fromHandle(_obj_newObject("label"));
    obj.label1:setParent(obj.rectangle3);
    obj.label1:setHeight(25);
    obj.label1:setText("Perfil");
    obj.label1:setFontSize(50);
    obj.label1.grid.role = "col";
    obj.label1.grid.width = 12;
    obj.label1:setFontFamily("Wishes Script Caps Display");
    obj.label1:setHorzTextAlign("center");
    obj.label1:setMargins({top=15});
    obj.label1:setName("label1");

    obj.image2 = GUI.fromHandle(_obj_newObject("image"));
    obj.image2:setParent(obj.rectangle3);
    obj.image2:setField("personagem");
    obj.image2:setEditable(true);
    obj.image2.animate = true;
    obj.image2:setStyle("proportional");
    obj.image2.grid.role = "col";
    obj.image2.grid.width = 12;
    obj.image2:setHeight(280);
    obj.image2:setMargins({left=10, top=5, right=10});
    obj.image2:setName("image2");

    obj.dataLink2 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink2:setParent(obj.rectangle3);
    obj.dataLink2:setFields({'personagem', 'nome'});
    obj.dataLink2:setDefaultValues({'https://images.vexels.com/media/users/3/220516/isolated/preview/7e7c120c190ae032e068975586d25279-silhueta-de-soldado-guerreiro-medieval.png', 'Nome do Personagem'});
    obj.dataLink2:setName("dataLink2");

    obj.label2 = GUI.fromHandle(_obj_newObject("label"));
    obj.label2:setParent(obj.rectangle3);
    obj.label2:setHeight(15);
    obj.label2:setText("Nome:");
    obj.label2:setFontSize(18);
    obj.label2.grid.role = "col";
    obj.label2.grid.width = 12;
    obj.label2:setFontFamily("Wishes Script Caps Display");
    obj.label2:setHorzTextAlign("leading");
    obj.label2:setVertTextAlign("leading");
    obj.label2:setMargins({top=5,left=10});
    obj.label2:setName("label2");

    obj.rectangle4 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle4:setParent(obj.rectangle3);
    obj.rectangle4:setHeight(40);
    obj.rectangle4:setColor("black");
    obj.rectangle4:setCornerType("round");
    obj.rectangle4.grid.role = "col";
    obj.rectangle4.grid.width = 12;
    obj.rectangle4:setStrokeSize(1);
    obj.rectangle4:setStrokeColor("white");
    obj.rectangle4:setXradius(5);
    obj.rectangle4:setYradius(5);
    obj.rectangle4:setMargins({top=5,right=10,left=10});
    obj.rectangle4:setName("rectangle4");

    obj.edit_nome = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit_nome:setParent(obj.rectangle4);
    obj.edit_nome:setHeight(40);
    obj.edit_nome:setName("edit_nome");
    obj.edit_nome:setField("nome");
    obj.edit_nome:setFontColor("white");
    obj.edit_nome:setFontSize(30);
    obj.edit_nome.grid.role = "col";
    obj.edit_nome.grid.width = 12;
    obj.edit_nome:setFontFamily("Wishes Script Caps Display");
    obj.edit_nome:setTransparent(true);
    obj.edit_nome:setVertTextAlign("leading");
    obj.edit_nome:setHorzTextAlign("center");

    obj.label3 = GUI.fromHandle(_obj_newObject("label"));
    obj.label3:setParent(obj.rectangle3);
    obj.label3:setHeight(25);
    obj.label3:setText("Estrela Origem:");
    obj.label3:setFontSize(10);
    obj.label3.grid.role = "col";
    obj.label3.grid.width = 3;
    obj.label3:setFontFamily("Wishes Script Caps Display");
    obj.label3:setHorzTextAlign("center");
    obj.label3:setMargins({top=5,left=10});
    obj.label3:setName("label3");

    obj.rectangle5 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle5:setParent(obj.rectangle3);
    obj.rectangle5:setHeight(25);
    obj.rectangle5:setColor("black");
    obj.rectangle5:setCornerType("round");
    obj.rectangle5.grid.role = "col";
    obj.rectangle5.grid.width = 2;
    obj.rectangle5:setStrokeSize(1);
    obj.rectangle5:setStrokeColor("white");
    obj.rectangle5:setXradius(5);
    obj.rectangle5:setYradius(5);
    obj.rectangle5:setMargins({top=5});
    obj.rectangle5:setName("rectangle5");

    obj.comboBox1 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox1:setParent(obj.rectangle5);
    obj.comboBox1:setField("estrela_origem");
    obj.comboBox1.grid.role = "col";
    obj.comboBox1.grid.width = 12;
    obj.comboBox1:setHeight(30);
    obj.comboBox1:setHorzTextAlign("center");
    obj.comboBox1:setFontFamily("Wishes Script Caps Display");
    obj.comboBox1:setTransparent(true);
    obj.comboBox1:setFontSize(25);
    obj.comboBox1:setItems({'1', '2', '3', '4', '5'});
    obj.comboBox1:setMargins({left=3,right=3});
    obj.comboBox1:setName("comboBox1");

    obj.label4 = GUI.fromHandle(_obj_newObject("label"));
    obj.label4:setParent(obj.comboBox1);
    obj.label4:setHeight(25);
    obj.label4:setText("☆");
    obj.label4:setFontSize(16);
    obj.label4.grid.role = "col";
    obj.label4.grid.width = 11;
    obj.label4:setFontFamily("Wishes Script Caps Display");
    obj.label4:setHorzTextAlign("trailing");
    obj.label4:setVertTextAlign("leading");
    obj.label4:setMargins({right=7});
    obj.label4:setName("label4");

    obj.label5 = GUI.fromHandle(_obj_newObject("label"));
    obj.label5:setParent(obj.rectangle3);
    obj.label5:setHeight(25);
    obj.label5:setFontSize(15);
    obj.label5.grid.role = "col";
    obj.label5.grid.width = 1;
    obj.label5:setName("label5");

    obj.label6 = GUI.fromHandle(_obj_newObject("label"));
    obj.label6:setParent(obj.rectangle3);
    obj.label6:setHeight(25);
    obj.label6:setText("Nivel:");
    obj.label6:setFontSize(18);
    obj.label6.grid.role = "col";
    obj.label6.grid.width = 2;
    obj.label6:setFontFamily("Wishes Script Caps Display");
    obj.label6:setHorzTextAlign("trailing");
    obj.label6:setMargins({top=5});
    obj.label6:setName("label6");

    obj.rectangle6 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle6:setParent(obj.rectangle3);
    obj.rectangle6:setHeight(25);
    obj.rectangle6:setColor("black");
    obj.rectangle6:setCornerType("round");
    obj.rectangle6.grid.role = "col";
    obj.rectangle6.grid.width = 4;
    obj.rectangle6:setStrokeSize(1);
    obj.rectangle6:setStrokeColor("white");
    obj.rectangle6:setXradius(5);
    obj.rectangle6:setYradius(5);
    obj.rectangle6:setMargins({top=5,right=10});
    obj.rectangle6:setName("rectangle6");

    obj.edit1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit1:setParent(obj.rectangle6);
    obj.edit1:setHeight(30);
    obj.edit1:setField("nv");
    obj.edit1:setFontSize(25);
    obj.edit1.grid.role = "col";
    obj.edit1.grid.width = 12;
    obj.edit1:setFontFamily("Wishes Script Caps Display");
    obj.edit1:setTransparent(true);
    obj.edit1:setHorzTextAlign("center");
    obj.edit1:setName("edit1");

    obj.label7 = GUI.fromHandle(_obj_newObject("label"));
    obj.label7:setParent(obj.rectangle3);
    obj.label7:setHeight(25);
    obj.label7:setText("Estrela Atual:");
    obj.label7:setFontSize(15);
    obj.label7.grid.role = "col";
    obj.label7.grid.width = 3;
    obj.label7:setFontFamily("Wishes Script Caps Display");
    obj.label7:setHorzTextAlign("center");
    obj.label7:setMargins({top=5,left=10});
    obj.label7:setName("label7");

    obj.rectangle7 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle7:setParent(obj.rectangle3);
    obj.rectangle7:setHeight(25);
    obj.rectangle7:setColor("black");
    obj.rectangle7:setCornerType("round");
    obj.rectangle7.grid.role = "col";
    obj.rectangle7.grid.width = 2;
    obj.rectangle7:setStrokeSize(1);
    obj.rectangle7:setStrokeColor("white");
    obj.rectangle7:setXradius(5);
    obj.rectangle7:setYradius(5);
    obj.rectangle7:setMargins({top=5});
    obj.rectangle7:setName("rectangle7");

    obj.comboBox2 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox2:setParent(obj.rectangle7);
    obj.comboBox2:setField("estrela_atual");
    obj.comboBox2.grid.role = "col";
    obj.comboBox2.grid.width = 12;
    obj.comboBox2:setHeight(30);
    obj.comboBox2:setHorzTextAlign("center");
    obj.comboBox2:setFontFamily("Wishes Script Caps Display");
    obj.comboBox2:setTransparent(true);
    obj.comboBox2:setFontSize(25);
    obj.comboBox2:setItems({'1', '2', '3', '4', '5', '6', '7'});
    obj.comboBox2:setMargins({left=3,right=3});
    obj.comboBox2:setName("comboBox2");

    obj.label8 = GUI.fromHandle(_obj_newObject("label"));
    obj.label8:setParent(obj.comboBox2);
    obj.label8:setHeight(25);
    obj.label8:setText("☆");
    obj.label8:setFontSize(16);
    obj.label8.grid.role = "col";
    obj.label8.grid.width = 11;
    obj.label8:setFontFamily("Wishes Script Caps Display");
    obj.label8:setHorzTextAlign("trailing");
    obj.label8:setVertTextAlign("leading");
    obj.label8:setMargins({right=7});
    obj.label8:setName("label8");

    obj.label9 = GUI.fromHandle(_obj_newObject("label"));
    obj.label9:setParent(obj.rectangle3);
    obj.label9:setHeight(25);
    obj.label9:setFontSize(15);
    obj.label9.grid.role = "col";
    obj.label9.grid.width = 1;
    obj.label9:setName("label9");

    obj.dataLink3 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink3:setParent(obj.rectangle3);
    obj.dataLink3:setFields({'estrela_origem', 'estrela_atual', 'xpmax', 'nv'});
    obj.dataLink3:setDefaultValues({'1', '1', '10', '1'});
    obj.dataLink3:setName("dataLink3");

    obj.label10 = GUI.fromHandle(_obj_newObject("label"));
    obj.label10:setParent(obj.rectangle3);
    obj.label10:setHeight(25);
    obj.label10:setText("XP:");
    obj.label10:setFontSize(18);
    obj.label10.grid.role = "col";
    obj.label10.grid.width = 2;
    obj.label10:setFontFamily("Wishes Script Caps Display");
    obj.label10:setHorzTextAlign("trailing");
    obj.label10:setMargins({top=5});
    obj.label10:setName("label10");

    obj.rectangle8 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle8:setParent(obj.rectangle3);
    obj.rectangle8.grid.role = "col";
    obj.rectangle8.grid.width = 4;
    obj.rectangle8:setHeight(25);
    obj.rectangle8:setStrokeSize(1);
    obj.rectangle8:setStrokeColor("white");
    obj.rectangle8:setMargins({top=5,right=10});
    obj.rectangle8.grid["cnt-gutter"] = 0;
    obj.rectangle8:setColor("black");
    obj.rectangle8:setCornerType("round");
    obj.rectangle8:setXradius(5);
    obj.rectangle8:setYradius(5);
    obj.rectangle8:setName("rectangle8");

    obj.edit2 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit2:setParent(obj.rectangle8);
    obj.edit2:setHeight(30);
    obj.edit2:setField("xp");
    obj.edit2:setFontSize(25);
    obj.edit2.grid.role = "col";
    obj.edit2.grid.width = 5;
    obj.edit2:setFontFamily("Wishes Script Caps Display");
    obj.edit2:setTransparent(true);
    obj.edit2:setHorzTextAlign("center");
    obj.edit2:setName("edit2");

    obj.edit3 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit3:setParent(obj.rectangle8);
    obj.edit3:setHeight(25);
    obj.edit3:setText("/");
    obj.edit3:setFontSize(30);
    obj.edit3.grid.role = "col";
    obj.edit3.grid.width = 2;
    obj.edit3:setFontFamily("Wishes Script Caps Display");
    obj.edit3:setTransparent(true);
    obj.edit3:setHorzTextAlign("center");
    obj.edit3:setReadOnly(true);
    obj.edit3:setName("edit3");

    obj.edit4 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit4:setParent(obj.rectangle8);
    obj.edit4:setHeight(30);
    obj.edit4:setField("xpmax");
    obj.edit4:setFontSize(25);
    obj.edit4.grid.role = "col";
    obj.edit4.grid.width = 5;
    obj.edit4:setFontFamily("Wishes Script Caps Display");
    obj.edit4:setTransparent(true);
    obj.edit4:setHorzTextAlign("center");
    obj.edit4:setName("edit4");

    obj.dataLink4 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink4:setParent(obj.rectangle8);
    obj.dataLink4:setFields({'nv', 'estrela_origem'});
    obj.dataLink4:setName("dataLink4");

    obj.dataLink5 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink5:setParent(obj.rectangle8);
    obj.dataLink5:setFields({'xp','xpmax'});
    obj.dataLink5:setDefaultValues({'0','0'});
    obj.dataLink5:setName("dataLink5");

    obj.label11 = GUI.fromHandle(_obj_newObject("label"));
    obj.label11:setParent(obj.rectangle3);
    obj.label11:setHeight(25);
    obj.label11:setText("Classe:");
    obj.label11:setFontSize(15);
    obj.label11.grid.role = "col";
    obj.label11.grid.width = 3;
    obj.label11:setFontFamily("Wishes Script Caps Display");
    obj.label11:setHorzTextAlign("center");
    obj.label11:setMargins({top=5,left=10});
    obj.label11:setName("label11");

    obj.rectangle9 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle9:setParent(obj.rectangle3);
    obj.rectangle9:setHeight(25);
    obj.rectangle9:setColor("black");
    obj.rectangle9:setCornerType("round");
    obj.rectangle9.grid.role = "col";
    obj.rectangle9.grid.width = 9;
    obj.rectangle9:setStrokeSize(1);
    obj.rectangle9:setStrokeColor("white");
    obj.rectangle9:setXradius(5);
    obj.rectangle9:setYradius(5);
    obj.rectangle9:setMargins({top=5,right=10});
    obj.rectangle9:setName("rectangle9");

    obj.edit5 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit5:setParent(obj.rectangle9);
    obj.edit5:setHeight(30);
    obj.edit5:setField("classe");
    obj.edit5:setFontColor("gray");
    obj.edit5:setFontSize(18);
    obj.edit5.grid.role = "col";
    obj.edit5.grid.width = 12;
    obj.edit5:setFontFamily("Wishes Script Caps Display");
    obj.edit5:setTransparent(true);
    obj.edit5:setHorzTextAlign("center");
    obj.edit5:setName("edit5");

    obj.dataLink6 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink6:setParent(obj.rectangle9);
    obj.dataLink6:setFields({'classe'});
    obj.dataLink6:setDefaultValues({'Novato'});
    obj.dataLink6:setName("dataLink6");

    obj.label12 = GUI.fromHandle(_obj_newObject("label"));
    obj.label12:setParent(obj.rectangle3);
    obj.label12:setHeight(25);
    obj.label12:setText("Função:");
    obj.label12:setFontSize(15);
    obj.label12.grid.role = "col";
    obj.label12.grid.width = 3;
    obj.label12:setFontFamily("Wishes Script Caps Display");
    obj.label12:setHorzTextAlign("center");
    obj.label12:setMargins({top=5,left=10});
    obj.label12:setName("label12");

    obj.rectangle10 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle10:setParent(obj.rectangle3);
    obj.rectangle10:setHeight(25);
    obj.rectangle10:setColor("black");
    obj.rectangle10:setCornerType("round");
    obj.rectangle10.grid.role = "col";
    obj.rectangle10.grid.width = 9;
    obj.rectangle10:setStrokeSize(1);
    obj.rectangle10:setStrokeColor("white");
    obj.rectangle10:setXradius(5);
    obj.rectangle10:setYradius(5);
    obj.rectangle10:setMargins({top=5,right=10});
    obj.rectangle10:setName("rectangle10");

    obj.edit6 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit6:setParent(obj.rectangle10);
    obj.edit6:setHeight(30);
    obj.edit6:setField("funcao");
    obj.edit6:setFontColor("gray");
    obj.edit6:setFontSize(18);
    obj.edit6.grid.role = "col";
    obj.edit6.grid.width = 12;
    obj.edit6:setFontFamily("Wishes Script Caps Display");
    obj.edit6:setTransparent(true);
    obj.edit6:setHorzTextAlign("center");
    obj.edit6:setName("edit6");

    obj.dataLink7 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink7:setParent(obj.rectangle10);
    obj.dataLink7:setFields({'funcao'});
    obj.dataLink7:setDefaultValues({'Não Atribuída'});
    obj.dataLink7:setName("dataLink7");

    obj.rectangle11 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle11:setParent(obj.rectangle3);
    obj.rectangle11:setHeight(25);
    obj.rectangle11:setColor("black");
    obj.rectangle11:setCornerType("round");
    obj.rectangle11.grid.role = "col";
    obj.rectangle11.grid.width = 12;
    obj.rectangle11:setStrokeSize(1);
    obj.rectangle11:setStrokeColor("white");
    obj.rectangle11:setXradius(5);
    obj.rectangle11:setYradius(5);
    obj.rectangle11:setMargins({top=5,right=10,left=10});
    obj.rectangle11:setName("rectangle11");

    obj.tipo_de_energia = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.tipo_de_energia:setParent(obj.rectangle11);
    obj.tipo_de_energia:setField("tipo_de_energia");
    obj.tipo_de_energia:setName("tipo_de_energia");
    obj.tipo_de_energia:setFontColor("gray");
    obj.tipo_de_energia:setFontSize(18);
    obj.tipo_de_energia:setFontFamily("Wishes Script Caps Display");
    obj.tipo_de_energia:setTransparent(true);
    obj.tipo_de_energia:setHorzTextAlign("center");
    obj.tipo_de_energia:setItems({'Ainda a procura do seu caminho', 'Caminho da Aura', 'Caminho da Magia'});
    obj.tipo_de_energia.grid.role = "col";
    obj.tipo_de_energia.grid.width = 12;
    obj.tipo_de_energia:setHeight(30);

    obj.dataLink8 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink8:setParent(obj.tipo_de_energia);
    obj.dataLink8:setField("tipo_de_energia");
    obj.dataLink8:setDefaultValue("Ainda a procura do seu caminho");
    obj.dataLink8:setName("dataLink8");

    obj.rectangle12 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle12:setParent(obj.scrollBox2);
    obj.rectangle12:setColor("#150e16");
    obj.rectangle12:setStrokeSize(2);
    obj.rectangle12:setStrokeColor("white");
    obj.rectangle12.grid.role = "col";
    obj.rectangle12.grid.width = 4;
    obj.rectangle12.grid["max-width"] = 1080;
    obj.rectangle12.grid["min-width"] = 400;
    obj.rectangle12.grid["min-height"] = 550;
    obj.rectangle12.grid["max-height"] = 1080;
    obj.rectangle12:setMargins({top=15});
    obj.rectangle12:setName("rectangle12");

    obj.tabela_atributos = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.tabela_atributos:setParent(obj.rectangle12);
    obj.tabela_atributos:setAlign("client");
    obj.tabela_atributos:setColor("none");
    obj.tabela_atributos:setName("tabela_atributos");
    obj.tabela_atributos:setVisible(true);
    obj.tabela_atributos.grid["cnt-gutter"] = 4;

    obj.label13 = GUI.fromHandle(_obj_newObject("label"));
    obj.label13:setParent(obj.tabela_atributos);
    obj.label13:setHeight(25);
    obj.label13:setText("Atributos");
    obj.label13:setFontSize(50);
    obj.label13.grid.role = "col";
    obj.label13.grid.width = 12;
    obj.label13:setFontFamily("Wishes Script Caps Display");
    obj.label13:setHorzTextAlign("center");
    obj.label13:setMargins({top=15});
    obj.label13:setName("label13");

    obj.label14 = GUI.fromHandle(_obj_newObject("label"));
    obj.label14:setParent(obj.label13);
    obj.label14.grid.role = "col";
    obj.label14.grid.width = 11;
    obj.label14:setName("label14");

    obj.button1 = GUI.fromHandle(_obj_newObject("button"));
    obj.button1:setParent(obj.label13);
    obj.button1.grid.role = "col";
    obj.button1.grid.width = 1;
    obj.button1:setText("?");
    obj.button1:setMargins({right=5});
    obj.button1:setName("button1");

    obj.explicacao_att = GUI.fromHandle(_obj_newObject("popup"));
    obj.explicacao_att:setParent(obj.tabela_atributos);
    obj.explicacao_att:setName("explicacao_att");
    obj.explicacao_att:setWidth(700);
    obj.explicacao_att:setHeight(600);
    obj.explicacao_att:setBackOpacity(0.5);

    obj.rectangle13 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle13:setParent(obj.explicacao_att);
    obj.rectangle13:setColor("black");
    obj.rectangle13:setLeft(-5);
    obj.rectangle13:setTop(-5);
    obj.rectangle13:setWidth(410);
    obj.rectangle13:setHeight(610);
    obj.rectangle13:setName("rectangle13");

    obj.rectangle14 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle14:setParent(obj.explicacao_att);
    obj.rectangle14:setColor("#150e16");
    obj.rectangle14:setStrokeSize(2);
    obj.rectangle14:setStrokeColor("white");
    obj.rectangle14:setLeft(5);
    obj.rectangle14:setTop(5);
    obj.rectangle14:setWidth(690);
    obj.rectangle14:setHeight(590);
    obj.rectangle14:setCornerType("round");
    obj.rectangle14:setXradius(5);
    obj.rectangle14:setYradius(5);
    obj.rectangle14:setName("rectangle14");

    obj.scrollBox3 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox3:setParent(obj.rectangle14);
    obj.scrollBox3:setAlign("client");
    obj.scrollBox3:setMargins({top=5,bottom=5});
    obj.scrollBox3:setName("scrollBox3");

    obj.label15 = GUI.fromHandle(_obj_newObject("label"));
    obj.label15:setParent(obj.scrollBox3);
    obj.label15:setText("Modificadores e Usos dos Atributos");
    obj.label15:setHeight(30);
    obj.label15:setFontSize(25);
    obj.label15.grid.role = "col";
    obj.label15.grid.width = 12;
    obj.label15:setFontFamily("Wishes Script Caps Display");
    obj.label15:setHorzTextAlign("center");
    obj.label15:setVertTextAlign("center");
    obj.label15:setMargins({top=10});
    obj.label15:setName("label15");

    obj.label16 = GUI.fromHandle(_obj_newObject("label"));
    obj.label16:setParent(obj.scrollBox3);
    obj.label16:setText("Modificadores:");
    obj.label16.grid.role = "col";
    obj.label16.grid.width = 12;
    obj.label16:setHeight(20);
    obj.label16:setFontSize(20);
    obj.label16:setFontFamily("Wishes Script Caps Display");
    obj.label16:setMargins({left=0,top=10});
    obj.label16:setName("label16");

    obj.rectangle15 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle15:setParent(obj.scrollBox3);
    obj.rectangle15:setHeight(90);
    obj.rectangle15:setColor("black");
    obj.rectangle15.grid.role = "col";
    obj.rectangle15.grid.width = 12;
    obj.rectangle15:setStrokeSize(1);
    obj.rectangle15:setStrokeColor("white");
    obj.rectangle15:setCornerType("round");
    obj.rectangle15:setXradius(5);
    obj.rectangle15:setYradius(5);
    obj.rectangle15:setMargins({left=0,right=0});
    obj.rectangle15:setName("rectangle15");

    obj.textEditor1 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor1:setParent(obj.rectangle15);
    obj.textEditor1:setReadOnly(true);
    obj.textEditor1:setText("Os modificadores de todas as ações são definidas por skills. \nCada skill utiliza um ou mais atributos, sendo esses sempre especificados nela. \nAs skills são divididas em niveis de Maestrias e cada nivel de maestria é dividido do nv 1 ao 10; \nOs modificadorers para cada ação são definidos a partir das skills, sua maestria e nivel, além dos atributos utilizados por elas.");
    obj.textEditor1:setFontSize(12);
    obj.textEditor1:setAlign("client");
    obj.textEditor1:setTransparent(true);
    obj.textEditor1:setName("textEditor1");

    obj.image3 = GUI.fromHandle(_obj_newObject("image"));
    obj.image3:setParent(obj.scrollBox3);
    obj.image3:setSRC("https://blob.firecast.com.br/blobs/TKDUMLFR_4353758/69de43230884980d0063d0c3.jpg");
    obj.image3:setStyle("proportional");
    obj.image3:setHeight(180);
    obj.image3.grid.role = "col";
    obj.image3.grid.width = 12;
    obj.image3:setMargins({left=0,top=10});
    obj.image3:setName("image3");

    obj.label17 = GUI.fromHandle(_obj_newObject("label"));
    obj.label17:setParent(obj.scrollBox3);
    obj.label17:setText("Alguns usos de Força:");
    obj.label17.grid.role = "col";
    obj.label17.grid.width = 12;
    obj.label17:setHeight(20);
    obj.label17:setFontSize(20);
    obj.label17:setFontFamily("Wishes Script Caps Display");
    obj.label17:setMargins({left=0,top=10});
    obj.label17:setName("label17");

    obj.rectangle16 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle16:setParent(obj.scrollBox3);
    obj.rectangle16:setHeight(60);
    obj.rectangle16:setColor("black");
    obj.rectangle16.grid.role = "col";
    obj.rectangle16.grid.width = 12;
    obj.rectangle16:setStrokeSize(1);
    obj.rectangle16:setStrokeColor("white");
    obj.rectangle16:setCornerType("round");
    obj.rectangle16:setXradius(5);
    obj.rectangle16:setYradius(5);
    obj.rectangle16:setMargins({left=0,right=0});
    obj.rectangle16:setName("rectangle16");

    obj.textEditor2 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor2:setParent(obj.rectangle16);
    obj.textEditor2:setReadOnly(true);
    obj.textEditor2:setText("• Testes de proezas fisicas, como levantar grandes pesos ou saltar grandes distâncias. \n• Influência o modificador de treino de skills de Força. \n• Influência o cálculo de dano de skills de Força, onde é usado o valor total.");
    obj.textEditor2:setFontSize(12);
    obj.textEditor2:setAlign("client");
    obj.textEditor2:setTransparent(true);
    obj.textEditor2:setName("textEditor2");

    obj.label18 = GUI.fromHandle(_obj_newObject("label"));
    obj.label18:setParent(obj.scrollBox3);
    obj.label18:setText("Alguns usos de Destreza:");
    obj.label18.grid.role = "col";
    obj.label18.grid.width = 12;
    obj.label18:setHeight(20);
    obj.label18:setFontSize(20);
    obj.label18:setFontFamily("Wishes Script Caps Display");
    obj.label18:setMargins({left=0,top=10});
    obj.label18:setName("label18");

    obj.rectangle17 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle17:setParent(obj.scrollBox3);
    obj.rectangle17:setHeight(90);
    obj.rectangle17:setColor("black");
    obj.rectangle17.grid.role = "col";
    obj.rectangle17.grid.width = 12;
    obj.rectangle17:setStrokeSize(1);
    obj.rectangle17:setStrokeColor("white");
    obj.rectangle17:setCornerType("round");
    obj.rectangle17:setXradius(5);
    obj.rectangle17:setYradius(5);
    obj.rectangle17:setMargins({left=0,right=0});
    obj.rectangle17:setName("rectangle17");

    obj.textEditor3 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor3:setParent(obj.rectangle17);
    obj.textEditor3:setReadOnly(true);
    obj.textEditor3:setText("• Testes de esquiva \n• Cálculo de deslocamento \n• Testes de movimentos acrobaticos e semelhantes \n• Influência o modificador de treino de skills de Destreza. \n• Influência o cálculo de dano de skills de Destreza, onde é usado a metade do valor total.");
    obj.textEditor3:setFontSize(12);
    obj.textEditor3:setAlign("client");
    obj.textEditor3:setTransparent(true);
    obj.textEditor3:setName("textEditor3");

    obj.label19 = GUI.fromHandle(_obj_newObject("label"));
    obj.label19:setParent(obj.scrollBox3);
    obj.label19:setText("Alguns usos de Vigor:");
    obj.label19.grid.role = "col";
    obj.label19.grid.width = 12;
    obj.label19:setHeight(20);
    obj.label19:setFontSize(20);
    obj.label19:setFontFamily("Wishes Script Caps Display");
    obj.label19:setMargins({left=0,top=10});
    obj.label19:setName("label19");

    obj.rectangle18 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle18:setParent(obj.scrollBox3);
    obj.rectangle18:setHeight(110);
    obj.rectangle18:setColor("black");
    obj.rectangle18.grid.role = "col";
    obj.rectangle18.grid.width = 12;
    obj.rectangle18:setStrokeSize(1);
    obj.rectangle18:setStrokeColor("white");
    obj.rectangle18:setCornerType("round");
    obj.rectangle18:setXradius(5);
    obj.rectangle18:setYradius(5);
    obj.rectangle18:setMargins({left=0,right=0});
    obj.rectangle18:setName("rectangle18");

    obj.textEditor4 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor4:setParent(obj.rectangle18);
    obj.textEditor4:setReadOnly(true);
    obj.textEditor4:setText("• Testes de Defesa, onde é usado a metade do valor total \n• Cálculo de pontos de Aura \n• Resistência a venenos e outras condições fisicas \n• Cálculo de Pontos de Vida Máximos \n• Cálculo de Pontos de Energia Máximos \n• Influência o modificador de treino de skills de Vigor.");
    obj.textEditor4:setFontSize(12);
    obj.textEditor4:setAlign("client");
    obj.textEditor4:setTransparent(true);
    obj.textEditor4:setName("textEditor4");

    obj.label20 = GUI.fromHandle(_obj_newObject("label"));
    obj.label20:setParent(obj.scrollBox3);
    obj.label20:setText("Alguns usos de Inteligência:");
    obj.label20.grid.role = "col";
    obj.label20.grid.width = 12;
    obj.label20:setHeight(20);
    obj.label20:setFontSize(20);
    obj.label20:setFontFamily("Wishes Script Caps Display");
    obj.label20:setMargins({left=0,top=10});
    obj.label20:setName("label20");

    obj.rectangle19 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle19:setParent(obj.scrollBox3);
    obj.rectangle19:setHeight(90);
    obj.rectangle19:setColor("black");
    obj.rectangle19.grid.role = "col";
    obj.rectangle19.grid.width = 12;
    obj.rectangle19:setStrokeSize(1);
    obj.rectangle19:setStrokeColor("white");
    obj.rectangle19:setCornerType("round");
    obj.rectangle19:setXradius(5);
    obj.rectangle19:setYradius(5);
    obj.rectangle19:setMargins({left=0,right=0});
    obj.rectangle19:setName("rectangle19");

    obj.textEditor5 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor5:setParent(obj.rectangle19);
    obj.textEditor5:setReadOnly(true);
    obj.textEditor5:setText("• Testes de inteligência, Intuição e similares \n• Cálculo de pontos de Mana \n• Magias \n• Influência o modificador de treino de skills de Inteligência. \n• Influência o cálculo de dano de skills de Inteligência, onde é usado a metade do valor total.");
    obj.textEditor5:setFontSize(12);
    obj.textEditor5:setAlign("client");
    obj.textEditor5:setTransparent(true);
    obj.textEditor5:setName("textEditor5");

    obj.label21 = GUI.fromHandle(_obj_newObject("label"));
    obj.label21:setParent(obj.scrollBox3);
    obj.label21:setText("Alguns usos de Consciência:");
    obj.label21.grid.role = "col";
    obj.label21.grid.width = 12;
    obj.label21:setHeight(20);
    obj.label21:setFontSize(20);
    obj.label21:setFontFamily("Wishes Script Caps Display");
    obj.label21:setMargins({left=0,top=10});
    obj.label21:setName("label21");

    obj.rectangle20 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle20:setParent(obj.scrollBox3);
    obj.rectangle20:setHeight(110);
    obj.rectangle20:setColor("black");
    obj.rectangle20.grid.role = "col";
    obj.rectangle20.grid.width = 12;
    obj.rectangle20:setStrokeSize(1);
    obj.rectangle20:setStrokeColor("white");
    obj.rectangle20:setCornerType("round");
    obj.rectangle20:setXradius(5);
    obj.rectangle20:setYradius(5);
    obj.rectangle20:setMargins({left=0,right=0});
    obj.rectangle20:setName("rectangle20");

    obj.textEditor6 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor6:setParent(obj.rectangle20);
    obj.textEditor6:setReadOnly(true);
    obj.textEditor6:setText("• Testes de Sanidade \n• Cálculo de pontos de Sanidade \n• Cálculo de pontos de Mana \n• Cálculo de pontos de Aura \n• Testes de Percepção e resistência mental \n• Influência o modificador de treino de skills de Consciência. ");
    obj.textEditor6:setFontSize(12);
    obj.textEditor6:setAlign("client");
    obj.textEditor6:setTransparent(true);
    obj.textEditor6:setName("textEditor6");

    obj.label22 = GUI.fromHandle(_obj_newObject("label"));
    obj.label22:setParent(obj.scrollBox3);
    obj.label22:setText("Alguns usos de Carisma:");
    obj.label22.grid.role = "col";
    obj.label22.grid.width = 12;
    obj.label22:setHeight(20);
    obj.label22:setFontSize(20);
    obj.label22:setFontFamily("Wishes Script Caps Display");
    obj.label22:setMargins({left=0,top=10});
    obj.label22:setName("label22");

    obj.rectangle21 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle21:setParent(obj.scrollBox3);
    obj.rectangle21:setHeight(60);
    obj.rectangle21:setColor("black");
    obj.rectangle21.grid.role = "col";
    obj.rectangle21.grid.width = 12;
    obj.rectangle21:setStrokeSize(1);
    obj.rectangle21:setStrokeColor("white");
    obj.rectangle21:setCornerType("round");
    obj.rectangle21:setXradius(5);
    obj.rectangle21:setYradius(5);
    obj.rectangle21:setMargins({left=0,right=0});
    obj.rectangle21:setName("rectangle21");

    obj.textEditor7 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor7:setParent(obj.rectangle21);
    obj.textEditor7:setReadOnly(true);
    obj.textEditor7:setText("• Testes de atuação, enganação, persuasão e similares \n• Influência como seu personagem é visto pelos outros \n• Influência o modificador de treino de skills de Carisma. ");
    obj.textEditor7:setFontSize(12);
    obj.textEditor7:setAlign("client");
    obj.textEditor7:setTransparent(true);
    obj.textEditor7:setName("textEditor7");

    obj.label23 = GUI.fromHandle(_obj_newObject("label"));
    obj.label23:setParent(obj.scrollBox3);
    obj.label23:setText("Alguns usos de Combate:");
    obj.label23.grid.role = "col";
    obj.label23.grid.width = 12;
    obj.label23:setHeight(20);
    obj.label23:setFontSize(20);
    obj.label23:setFontFamily("Wishes Script Caps Display");
    obj.label23:setMargins({left=0,top=10});
    obj.label23:setName("label23");

    obj.rectangle22 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle22:setParent(obj.scrollBox3);
    obj.rectangle22:setHeight(50);
    obj.rectangle22:setColor("black");
    obj.rectangle22.grid.role = "col";
    obj.rectangle22.grid.width = 12;
    obj.rectangle22:setStrokeSize(1);
    obj.rectangle22:setStrokeColor("white");
    obj.rectangle22:setCornerType("round");
    obj.rectangle22:setXradius(5);
    obj.rectangle22:setYradius(5);
    obj.rectangle22:setMargins({left=0,right=0});
    obj.rectangle22:setName("rectangle22");

    obj.textEditor8 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor8:setParent(obj.rectangle22);
    obj.textEditor8:setReadOnly(true);
    obj.textEditor8:setText("• Testes de acerto corpo a corpo, podendo ser usado a distância dependendo de skills especificas \n• Influência o modificador de treino de skills de Combate corpo a corpo. ");
    obj.textEditor8:setFontSize(12);
    obj.textEditor8:setAlign("client");
    obj.textEditor8:setTransparent(true);
    obj.textEditor8:setName("textEditor8");

    obj.label24 = GUI.fromHandle(_obj_newObject("label"));
    obj.label24:setParent(obj.scrollBox3);
    obj.label24:setText("Alguns usos de Precisão:");
    obj.label24.grid.role = "col";
    obj.label24.grid.width = 12;
    obj.label24:setHeight(20);
    obj.label24:setFontSize(20);
    obj.label24:setFontFamily("Wishes Script Caps Display");
    obj.label24:setMargins({left=0,top=10});
    obj.label24:setName("label24");

    obj.rectangle23 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle23:setParent(obj.scrollBox3);
    obj.rectangle23:setHeight(50);
    obj.rectangle23:setColor("black");
    obj.rectangle23.grid.role = "col";
    obj.rectangle23.grid.width = 12;
    obj.rectangle23:setStrokeSize(1);
    obj.rectangle23:setStrokeColor("white");
    obj.rectangle23:setCornerType("round");
    obj.rectangle23:setXradius(5);
    obj.rectangle23:setYradius(5);
    obj.rectangle23:setMargins({left=0,right=0});
    obj.rectangle23:setName("rectangle23");

    obj.textEditor9 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor9:setParent(obj.rectangle23);
    obj.textEditor9:setReadOnly(true);
    obj.textEditor9:setText("• Testes de acerto a distância, normalmente impondo demetiros quando usado corpo a corpo \n• Influência o modificador de treino de skills de longo alcance. ");
    obj.textEditor9:setFontSize(12);
    obj.textEditor9:setAlign("client");
    obj.textEditor9:setTransparent(true);
    obj.textEditor9:setName("textEditor9");

    obj.label25 = GUI.fromHandle(_obj_newObject("label"));
    obj.label25:setParent(obj.tabela_atributos);
    obj.label25:setHeight(20);
    obj.label25:setFontSize(15);
    obj.label25.grid.role = "col";
    obj.label25.grid.width = 4;
    obj.label25:setFontFamily("Wishes Script Caps Display");
    obj.label25:setHorzTextAlign("center");
    obj.label25:setVertTextAlign("center");
    obj.label25:setMargins({top=10,});
    obj.label25:setName("label25");

    obj.rectangle24 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle24:setParent(obj.tabela_atributos);
    obj.rectangle24:setHeight(20);
    obj.rectangle24:setColor("none");
    obj.rectangle24:setCornerType("round");
    obj.rectangle24.grid.role = "col";
    obj.rectangle24.grid.width = 6;
    obj.rectangle24:setMargins({top=10});
    obj.rectangle24.grid["cnt-gutter"] = 4;
    obj.rectangle24:setName("rectangle24");

    obj.label26 = GUI.fromHandle(_obj_newObject("label"));
    obj.label26:setParent(obj.rectangle24);
    obj.label26:setHeight(20);
    obj.label26:setText("Base");
    obj.label26:setFontSize(15);
    obj.label26.grid.role = "col";
    obj.label26.grid.width = 3;
    obj.label26:setFontFamily("Wishes Script Caps Display");
    obj.label26:setHorzTextAlign("center");
    obj.label26:setVertTextAlign("center");
    obj.label26:setName("label26");

    obj.label27 = GUI.fromHandle(_obj_newObject("label"));
    obj.label27:setParent(obj.rectangle24);
    obj.label27:setHeight(20);
    obj.label27:setText("Sintese");
    obj.label27:setFontSize(15);
    obj.label27.grid.role = "col";
    obj.label27.grid.width = 3;
    obj.label27:setFontFamily("Wishes Script Caps Display");
    obj.label27:setHorzTextAlign("center");
    obj.label27:setVertTextAlign("center");
    obj.label27:setName("label27");

    obj.label28 = GUI.fromHandle(_obj_newObject("label"));
    obj.label28:setParent(obj.rectangle24);
    obj.label28:setHeight(20);
    obj.label28:setText("Equips");
    obj.label28:setFontSize(15);
    obj.label28.grid.role = "col";
    obj.label28.grid.width = 3;
    obj.label28:setFontFamily("Wishes Script Caps Display");
    obj.label28:setHorzTextAlign("center");
    obj.label28:setVertTextAlign("center");
    obj.label28:setName("label28");

    obj.label29 = GUI.fromHandle(_obj_newObject("label"));
    obj.label29:setParent(obj.rectangle24);
    obj.label29:setHeight(20);
    obj.label29:setText("Buffs");
    obj.label29:setFontSize(15);
    obj.label29.grid.role = "col";
    obj.label29.grid.width = 3;
    obj.label29:setFontFamily("Wishes Script Caps Display");
    obj.label29:setHorzTextAlign("center");
    obj.label29:setVertTextAlign("center");
    obj.label29:setName("label29");

    obj.label30 = GUI.fromHandle(_obj_newObject("label"));
    obj.label30:setParent(obj.tabela_atributos);
    obj.label30:setHeight(20);
    obj.label30:setText("Total");
    obj.label30:setFontSize(15);
    obj.label30.grid.role = "col";
    obj.label30.grid.width = 2;
    obj.label30:setFontFamily("Wishes Script Caps Display");
    obj.label30:setHorzTextAlign("center");
    obj.label30:setVertTextAlign("center");
    obj.label30:setMargins({top=10,right=10});
    obj.label30:setName("label30");

    obj.rectangle25 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle25:setParent(obj.tabela_atributos);
    obj.rectangle25:setHeight(280);
    obj.rectangle25:setColor("none");
    obj.rectangle25:setCornerType("round");
    obj.rectangle25.grid.role = "col";
    obj.rectangle25.grid.width = 4;
    obj.rectangle25:setStrokeColor("white");
    obj.rectangle25:setXradius(5);
    obj.rectangle25:setYradius(5);
    obj.rectangle25:setMargins({top=10,left=5});
    obj.rectangle25:setName("rectangle25");

    obj.label31 = GUI.fromHandle(_obj_newObject("label"));
    obj.label31:setParent(obj.rectangle25);
    obj.label31:setHeight(30);
    obj.label31:setText("FORÇA");
    obj.label31:setFontSize(18);
    obj.label31.grid.role = "col";
    obj.label31.grid.width = 12;
    obj.label31:setFontFamily("Wishes Script Caps Display");
    obj.label31:setHorzTextAlign("center");
    obj.label31:setVertTextAlign("center");
    obj.label31:setMargins({top=5});
    obj.label31:setHint("Usado para proezas de força, dano e treino de skills de força.");
    obj.label31:setName("label31");

    obj.label32 = GUI.fromHandle(_obj_newObject("label"));
    obj.label32:setParent(obj.rectangle25);
    obj.label32:setHeight(30);
    obj.label32:setText("DESTREZA");
    obj.label32:setFontSize(18);
    obj.label32.grid.role = "col";
    obj.label32.grid.width = 12;
    obj.label32:setFontFamily("Wishes Script Caps Display");
    obj.label32:setHorzTextAlign("center");
    obj.label32:setVertTextAlign("center");
    obj.label32:setMargins({top=5});
    obj.label32:setName("label32");

    obj.label33 = GUI.fromHandle(_obj_newObject("label"));
    obj.label33:setParent(obj.rectangle25);
    obj.label33:setHeight(30);
    obj.label33:setText("VIGOR");
    obj.label33:setFontSize(18);
    obj.label33.grid.role = "col";
    obj.label33.grid.width = 12;
    obj.label33:setFontFamily("Wishes Script Caps Display");
    obj.label33:setHorzTextAlign("center");
    obj.label33:setVertTextAlign("center");
    obj.label33:setMargins({top=5});
    obj.label33:setName("label33");

    obj.label34 = GUI.fromHandle(_obj_newObject("label"));
    obj.label34:setParent(obj.rectangle25);
    obj.label34:setHeight(30);
    obj.label34:setText("INTELIGÊNCIA");
    obj.label34:setFontSize(16);
    obj.label34.grid.role = "col";
    obj.label34.grid.width = 12;
    obj.label34:setFontFamily("Wishes Script Caps Display");
    obj.label34:setHorzTextAlign("center");
    obj.label34:setVertTextAlign("center");
    obj.label34:setMargins({top=5});
    obj.label34:setName("label34");

    obj.label35 = GUI.fromHandle(_obj_newObject("label"));
    obj.label35:setParent(obj.rectangle25);
    obj.label35:setHeight(30);
    obj.label35:setText("CONSCIÊNCIA");
    obj.label35:setFontSize(16);
    obj.label35.grid.role = "col";
    obj.label35.grid.width = 12;
    obj.label35:setFontFamily("Wishes Script Caps Display");
    obj.label35:setHorzTextAlign("center");
    obj.label35:setVertTextAlign("center");
    obj.label35:setMargins({top=5});
    obj.label35:setName("label35");

    obj.label36 = GUI.fromHandle(_obj_newObject("label"));
    obj.label36:setParent(obj.rectangle25);
    obj.label36:setHeight(30);
    obj.label36:setText("CARISMA");
    obj.label36:setFontSize(18);
    obj.label36.grid.role = "col";
    obj.label36.grid.width = 12;
    obj.label36:setFontFamily("Wishes Script Caps Display");
    obj.label36:setHorzTextAlign("center");
    obj.label36:setVertTextAlign("center");
    obj.label36:setMargins({top=5});
    obj.label36:setName("label36");

    obj.label37 = GUI.fromHandle(_obj_newObject("label"));
    obj.label37:setParent(obj.rectangle25);
    obj.label37:setHeight(30);
    obj.label37:setText("COMBATE");
    obj.label37:setFontSize(18);
    obj.label37.grid.role = "col";
    obj.label37.grid.width = 12;
    obj.label37:setFontFamily("Wishes Script Caps Display");
    obj.label37:setHorzTextAlign("center");
    obj.label37:setVertTextAlign("center");
    obj.label37:setMargins({top=5});
    obj.label37:setName("label37");

    obj.label38 = GUI.fromHandle(_obj_newObject("label"));
    obj.label38:setParent(obj.rectangle25);
    obj.label38:setHeight(30);
    obj.label38:setText("PRECISÃO");
    obj.label38:setFontSize(18);
    obj.label38.grid.role = "col";
    obj.label38.grid.width = 12;
    obj.label38:setFontFamily("Wishes Script Caps Display");
    obj.label38:setHorzTextAlign("center");
    obj.label38:setVertTextAlign("center");
    obj.label38:setMargins({top=5});
    obj.label38:setName("label38");

    obj.rectangle26 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle26:setParent(obj.tabela_atributos);
    obj.rectangle26:setHeight(280);
    obj.rectangle26:setColor("none");
    obj.rectangle26:setCornerType("round");
    obj.rectangle26.grid.role = "col";
    obj.rectangle26.grid.width = 6;
    obj.rectangle26:setMargins({top=10});
    obj.rectangle26.grid["cnt-gutter"] = 4;
    obj.rectangle26:setName("rectangle26");

    obj.rectangle27 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle27:setParent(obj.rectangle26);
    obj.rectangle27:setHeight(280);
    obj.rectangle27:setColor("black");
    obj.rectangle27:setCornerType("round");
    obj.rectangle27.grid.role = "col";
    obj.rectangle27.grid.width = 3;
    obj.rectangle27:setStrokeSize(1);
    obj.rectangle27:setStrokeColor("white");
    obj.rectangle27:setXradius(5);
    obj.rectangle27:setYradius(5);
    obj.rectangle27:setName("rectangle27");

    obj.edit7 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit7:setParent(obj.rectangle27);
    obj.edit7:setHeight(30);
    obj.edit7:setField("forcabase");
    obj.edit7:setFontSize(40);
    obj.edit7.grid.role = "col";
    obj.edit7.grid.width = 12;
    obj.edit7:setFontFamily("Wishes Script Caps Display");
    obj.edit7:setHorzTextAlign("center");
    obj.edit7:setTransparent(true);
    obj.edit7:setMargins({top=5});
    obj.edit7:setName("edit7");

    obj.edit8 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit8:setParent(obj.rectangle27);
    obj.edit8:setHeight(30);
    obj.edit8:setField("destrezabase");
    obj.edit8:setFontSize(40);
    obj.edit8.grid.role = "col";
    obj.edit8.grid.width = 12;
    obj.edit8:setFontFamily("Wishes Script Caps Display");
    obj.edit8:setHorzTextAlign("center");
    obj.edit8:setTransparent(true);
    obj.edit8:setMargins({top=5});
    obj.edit8:setName("edit8");

    obj.edit9 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit9:setParent(obj.rectangle27);
    obj.edit9:setHeight(30);
    obj.edit9:setField("vigorbase");
    obj.edit9:setFontSize(40);
    obj.edit9.grid.role = "col";
    obj.edit9.grid.width = 12;
    obj.edit9:setFontFamily("Wishes Script Caps Display");
    obj.edit9:setHorzTextAlign("center");
    obj.edit9:setTransparent(true);
    obj.edit9:setMargins({top=5});
    obj.edit9:setName("edit9");

    obj.edit10 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit10:setParent(obj.rectangle27);
    obj.edit10:setHeight(30);
    obj.edit10:setField("inteligenciabase");
    obj.edit10:setFontSize(40);
    obj.edit10.grid.role = "col";
    obj.edit10.grid.width = 12;
    obj.edit10:setFontFamily("Wishes Script Caps Display");
    obj.edit10:setHorzTextAlign("center");
    obj.edit10:setTransparent(true);
    obj.edit10:setMargins({top=5});
    obj.edit10:setName("edit10");

    obj.edit11 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit11:setParent(obj.rectangle27);
    obj.edit11:setHeight(30);
    obj.edit11:setField("conscienciabase");
    obj.edit11:setFontSize(40);
    obj.edit11.grid.role = "col";
    obj.edit11.grid.width = 12;
    obj.edit11:setFontFamily("Wishes Script Caps Display");
    obj.edit11:setHorzTextAlign("center");
    obj.edit11:setTransparent(true);
    obj.edit11:setMargins({top=5});
    obj.edit11:setName("edit11");

    obj.edit12 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit12:setParent(obj.rectangle27);
    obj.edit12:setHeight(30);
    obj.edit12:setField("carismabase");
    obj.edit12:setFontSize(40);
    obj.edit12.grid.role = "col";
    obj.edit12.grid.width = 12;
    obj.edit12:setFontFamily("Wishes Script Caps Display");
    obj.edit12:setHorzTextAlign("center");
    obj.edit12:setTransparent(true);
    obj.edit12:setMargins({top=5});
    obj.edit12:setName("edit12");

    obj.edit13 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit13:setParent(obj.rectangle27);
    obj.edit13:setHeight(30);
    obj.edit13:setField("combatebase");
    obj.edit13:setFontSize(40);
    obj.edit13.grid.role = "col";
    obj.edit13.grid.width = 12;
    obj.edit13:setFontFamily("Wishes Script Caps Display");
    obj.edit13:setHorzTextAlign("center");
    obj.edit13:setTransparent(true);
    obj.edit13:setMargins({top=5});
    obj.edit13:setName("edit13");

    obj.edit14 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit14:setParent(obj.rectangle27);
    obj.edit14:setHeight(30);
    obj.edit14:setField("precisaobase");
    obj.edit14:setFontSize(40);
    obj.edit14.grid.role = "col";
    obj.edit14.grid.width = 12;
    obj.edit14:setFontFamily("Wishes Script Caps Display");
    obj.edit14:setHorzTextAlign("center");
    obj.edit14:setTransparent(true);
    obj.edit14:setMargins({top=5});
    obj.edit14:setName("edit14");

    obj.rectangle28 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle28:setParent(obj.rectangle26);
    obj.rectangle28:setHeight(280);
    obj.rectangle28:setColor("black");
    obj.rectangle28:setCornerType("round");
    obj.rectangle28.grid.role = "col";
    obj.rectangle28.grid.width = 3;
    obj.rectangle28:setStrokeSize(1);
    obj.rectangle28:setStrokeColor("white");
    obj.rectangle28:setXradius(5);
    obj.rectangle28:setYradius(5);
    obj.rectangle28:setName("rectangle28");

    obj.edit15 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit15:setParent(obj.rectangle28);
    obj.edit15:setHeight(30);
    obj.edit15:setField("forcasintese");
    obj.edit15:setFontSize(25);
    obj.edit15.grid.role = "col";
    obj.edit15.grid.width = 12;
    obj.edit15:setFontFamily("Wishes Script Caps Display");
    obj.edit15:setHorzTextAlign("center");
    obj.edit15:setTransparent(true);
    obj.edit15:setMargins({top=5});
    obj.edit15:setName("edit15");

    obj.edit16 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit16:setParent(obj.rectangle28);
    obj.edit16:setHeight(30);
    obj.edit16:setField("destrezasintese");
    obj.edit16:setFontSize(25);
    obj.edit16.grid.role = "col";
    obj.edit16.grid.width = 12;
    obj.edit16:setFontFamily("Wishes Script Caps Display");
    obj.edit16:setHorzTextAlign("center");
    obj.edit16:setTransparent(true);
    obj.edit16:setMargins({top=5});
    obj.edit16:setName("edit16");

    obj.edit17 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit17:setParent(obj.rectangle28);
    obj.edit17:setHeight(30);
    obj.edit17:setField("vigorsintese");
    obj.edit17:setFontSize(25);
    obj.edit17.grid.role = "col";
    obj.edit17.grid.width = 12;
    obj.edit17:setFontFamily("Wishes Script Caps Display");
    obj.edit17:setHorzTextAlign("center");
    obj.edit17:setTransparent(true);
    obj.edit17:setMargins({top=5});
    obj.edit17:setName("edit17");

    obj.edit18 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit18:setParent(obj.rectangle28);
    obj.edit18:setHeight(30);
    obj.edit18:setField("inteligenciasintese");
    obj.edit18:setFontSize(25);
    obj.edit18.grid.role = "col";
    obj.edit18.grid.width = 12;
    obj.edit18:setFontFamily("Wishes Script Caps Display");
    obj.edit18:setHorzTextAlign("center");
    obj.edit18:setTransparent(true);
    obj.edit18:setMargins({top=5});
    obj.edit18:setName("edit18");

    obj.edit19 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit19:setParent(obj.rectangle28);
    obj.edit19:setHeight(30);
    obj.edit19:setField("conscienciasintese");
    obj.edit19:setFontSize(25);
    obj.edit19.grid.role = "col";
    obj.edit19.grid.width = 12;
    obj.edit19:setFontFamily("Wishes Script Caps Display");
    obj.edit19:setHorzTextAlign("center");
    obj.edit19:setTransparent(true);
    obj.edit19:setMargins({top=5});
    obj.edit19:setName("edit19");

    obj.edit20 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit20:setParent(obj.rectangle28);
    obj.edit20:setHeight(30);
    obj.edit20:setField("carismasintese");
    obj.edit20:setFontSize(25);
    obj.edit20.grid.role = "col";
    obj.edit20.grid.width = 12;
    obj.edit20:setFontFamily("Wishes Script Caps Display");
    obj.edit20:setHorzTextAlign("center");
    obj.edit20:setTransparent(true);
    obj.edit20:setMargins({top=5});
    obj.edit20:setName("edit20");

    obj.edit21 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit21:setParent(obj.rectangle28);
    obj.edit21:setHeight(30);
    obj.edit21:setField("combatesintese");
    obj.edit21:setFontSize(25);
    obj.edit21.grid.role = "col";
    obj.edit21.grid.width = 12;
    obj.edit21:setFontFamily("Wishes Script Caps Display");
    obj.edit21:setHorzTextAlign("center");
    obj.edit21:setTransparent(true);
    obj.edit21:setMargins({top=5});
    obj.edit21:setName("edit21");

    obj.edit22 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit22:setParent(obj.rectangle28);
    obj.edit22:setHeight(30);
    obj.edit22:setField("precisaosintese");
    obj.edit22:setFontSize(25);
    obj.edit22.grid.role = "col";
    obj.edit22.grid.width = 12;
    obj.edit22:setFontFamily("Wishes Script Caps Display");
    obj.edit22:setHorzTextAlign("center");
    obj.edit22:setTransparent(true);
    obj.edit22:setMargins({top=5});
    obj.edit22:setName("edit22");

    obj.rectangle29 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle29:setParent(obj.rectangle26);
    obj.rectangle29:setHeight(280);
    obj.rectangle29:setColor("black");
    obj.rectangle29:setCornerType("round");
    obj.rectangle29.grid.role = "col";
    obj.rectangle29.grid.width = 3;
    obj.rectangle29:setStrokeSize(1);
    obj.rectangle29:setStrokeColor("white");
    obj.rectangle29:setXradius(5);
    obj.rectangle29:setYradius(5);
    obj.rectangle29:setName("rectangle29");

    obj.edit23 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit23:setParent(obj.rectangle29);
    obj.edit23:setHeight(30);
    obj.edit23:setField("forcaequips");
    obj.edit23:setFontSize(40);
    obj.edit23.grid.role = "col";
    obj.edit23.grid.width = 12;
    obj.edit23:setFontFamily("Wishes Script Caps Display");
    obj.edit23:setHorzTextAlign("center");
    obj.edit23:setTransparent(true);
    obj.edit23:setMargins({top=5});
    obj.edit23:setName("edit23");

    obj.edit24 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit24:setParent(obj.rectangle29);
    obj.edit24:setHeight(30);
    obj.edit24:setField("destrezaequips");
    obj.edit24:setFontSize(40);
    obj.edit24.grid.role = "col";
    obj.edit24.grid.width = 12;
    obj.edit24:setFontFamily("Wishes Script Caps Display");
    obj.edit24:setHorzTextAlign("center");
    obj.edit24:setTransparent(true);
    obj.edit24:setMargins({top=5});
    obj.edit24:setName("edit24");

    obj.edit25 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit25:setParent(obj.rectangle29);
    obj.edit25:setHeight(30);
    obj.edit25:setField("vigorequips");
    obj.edit25:setFontSize(40);
    obj.edit25.grid.role = "col";
    obj.edit25.grid.width = 12;
    obj.edit25:setFontFamily("Wishes Script Caps Display");
    obj.edit25:setHorzTextAlign("center");
    obj.edit25:setTransparent(true);
    obj.edit25:setMargins({top=5});
    obj.edit25:setName("edit25");

    obj.edit26 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit26:setParent(obj.rectangle29);
    obj.edit26:setHeight(30);
    obj.edit26:setField("inteligenciaequips");
    obj.edit26:setFontSize(40);
    obj.edit26.grid.role = "col";
    obj.edit26.grid.width = 12;
    obj.edit26:setFontFamily("Wishes Script Caps Display");
    obj.edit26:setHorzTextAlign("center");
    obj.edit26:setTransparent(true);
    obj.edit26:setMargins({top=5});
    obj.edit26:setName("edit26");

    obj.edit27 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit27:setParent(obj.rectangle29);
    obj.edit27:setHeight(30);
    obj.edit27:setField("conscienciaequips");
    obj.edit27:setFontSize(40);
    obj.edit27.grid.role = "col";
    obj.edit27.grid.width = 12;
    obj.edit27:setFontFamily("Wishes Script Caps Display");
    obj.edit27:setHorzTextAlign("center");
    obj.edit27:setTransparent(true);
    obj.edit27:setMargins({top=5});
    obj.edit27:setName("edit27");

    obj.edit28 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit28:setParent(obj.rectangle29);
    obj.edit28:setHeight(30);
    obj.edit28:setField("carismaequips");
    obj.edit28:setFontSize(40);
    obj.edit28.grid.role = "col";
    obj.edit28.grid.width = 12;
    obj.edit28:setFontFamily("Wishes Script Caps Display");
    obj.edit28:setHorzTextAlign("center");
    obj.edit28:setTransparent(true);
    obj.edit28:setMargins({top=5});
    obj.edit28:setName("edit28");

    obj.edit29 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit29:setParent(obj.rectangle29);
    obj.edit29:setHeight(30);
    obj.edit29:setField("combateequips");
    obj.edit29:setFontSize(40);
    obj.edit29.grid.role = "col";
    obj.edit29.grid.width = 12;
    obj.edit29:setFontFamily("Wishes Script Caps Display");
    obj.edit29:setHorzTextAlign("center");
    obj.edit29:setTransparent(true);
    obj.edit29:setMargins({top=5});
    obj.edit29:setName("edit29");

    obj.edit30 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit30:setParent(obj.rectangle29);
    obj.edit30:setHeight(30);
    obj.edit30:setField("precisaoequips");
    obj.edit30:setFontSize(40);
    obj.edit30.grid.role = "col";
    obj.edit30.grid.width = 12;
    obj.edit30:setFontFamily("Wishes Script Caps Display");
    obj.edit30:setHorzTextAlign("center");
    obj.edit30:setTransparent(true);
    obj.edit30:setMargins({top=5});
    obj.edit30:setName("edit30");

    obj.rectangle30 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle30:setParent(obj.rectangle26);
    obj.rectangle30:setHeight(280);
    obj.rectangle30:setColor("black");
    obj.rectangle30:setCornerType("round");
    obj.rectangle30.grid.role = "col";
    obj.rectangle30.grid.width = 3;
    obj.rectangle30:setStrokeSize(1);
    obj.rectangle30:setStrokeColor("white");
    obj.rectangle30:setXradius(5);
    obj.rectangle30:setYradius(5);
    obj.rectangle30:setName("rectangle30");

    obj.edit31 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit31:setParent(obj.rectangle30);
    obj.edit31:setHeight(30);
    obj.edit31:setField("forcabuffs");
    obj.edit31:setFontSize(40);
    obj.edit31.grid.role = "col";
    obj.edit31.grid.width = 12;
    obj.edit31:setFontFamily("Wishes Script Caps Display");
    obj.edit31:setHorzTextAlign("center");
    obj.edit31:setTransparent(true);
    obj.edit31:setMargins({top=5});
    obj.edit31:setName("edit31");

    obj.edit32 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit32:setParent(obj.rectangle30);
    obj.edit32:setHeight(30);
    obj.edit32:setField("destrezabuffs");
    obj.edit32:setFontSize(40);
    obj.edit32.grid.role = "col";
    obj.edit32.grid.width = 12;
    obj.edit32:setFontFamily("Wishes Script Caps Display");
    obj.edit32:setHorzTextAlign("center");
    obj.edit32:setTransparent(true);
    obj.edit32:setMargins({top=5});
    obj.edit32:setName("edit32");

    obj.edit33 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit33:setParent(obj.rectangle30);
    obj.edit33:setHeight(30);
    obj.edit33:setField("vigorbuffs");
    obj.edit33:setFontSize(40);
    obj.edit33.grid.role = "col";
    obj.edit33.grid.width = 12;
    obj.edit33:setFontFamily("Wishes Script Caps Display");
    obj.edit33:setHorzTextAlign("center");
    obj.edit33:setTransparent(true);
    obj.edit33:setMargins({top=5});
    obj.edit33:setName("edit33");

    obj.edit34 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit34:setParent(obj.rectangle30);
    obj.edit34:setHeight(30);
    obj.edit34:setField("inteligenciabuffs");
    obj.edit34:setFontSize(40);
    obj.edit34.grid.role = "col";
    obj.edit34.grid.width = 12;
    obj.edit34:setFontFamily("Wishes Script Caps Display");
    obj.edit34:setHorzTextAlign("center");
    obj.edit34:setTransparent(true);
    obj.edit34:setMargins({top=5});
    obj.edit34:setName("edit34");

    obj.edit35 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit35:setParent(obj.rectangle30);
    obj.edit35:setHeight(30);
    obj.edit35:setField("conscienciabuffs");
    obj.edit35:setFontSize(40);
    obj.edit35.grid.role = "col";
    obj.edit35.grid.width = 12;
    obj.edit35:setFontFamily("Wishes Script Caps Display");
    obj.edit35:setHorzTextAlign("center");
    obj.edit35:setTransparent(true);
    obj.edit35:setMargins({top=5});
    obj.edit35:setName("edit35");

    obj.edit36 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit36:setParent(obj.rectangle30);
    obj.edit36:setHeight(30);
    obj.edit36:setField("carismabuffs");
    obj.edit36:setFontSize(40);
    obj.edit36.grid.role = "col";
    obj.edit36.grid.width = 12;
    obj.edit36:setFontFamily("Wishes Script Caps Display");
    obj.edit36:setHorzTextAlign("center");
    obj.edit36:setTransparent(true);
    obj.edit36:setMargins({top=5});
    obj.edit36:setName("edit36");

    obj.edit37 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit37:setParent(obj.rectangle30);
    obj.edit37:setHeight(30);
    obj.edit37:setField("combatebuffs");
    obj.edit37:setFontSize(40);
    obj.edit37.grid.role = "col";
    obj.edit37.grid.width = 12;
    obj.edit37:setFontFamily("Wishes Script Caps Display");
    obj.edit37:setHorzTextAlign("center");
    obj.edit37:setTransparent(true);
    obj.edit37:setMargins({top=5});
    obj.edit37:setName("edit37");

    obj.edit38 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit38:setParent(obj.rectangle30);
    obj.edit38:setHeight(30);
    obj.edit38:setField("precisaobuffs");
    obj.edit38:setFontSize(40);
    obj.edit38.grid.role = "col";
    obj.edit38.grid.width = 12;
    obj.edit38:setFontFamily("Wishes Script Caps Display");
    obj.edit38:setHorzTextAlign("center");
    obj.edit38:setTransparent(true);
    obj.edit38:setMargins({top=5});
    obj.edit38:setName("edit38");

    obj.rectangle31 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle31:setParent(obj.tabela_atributos);
    obj.rectangle31:setHeight(280);
    obj.rectangle31:setColor("black");
    obj.rectangle31:setCornerType("round");
    obj.rectangle31.grid.role = "col";
    obj.rectangle31.grid.width = 2;
    obj.rectangle31:setStrokeSize(1);
    obj.rectangle31:setStrokeColor("white");
    obj.rectangle31:setXradius(5);
    obj.rectangle31:setYradius(5);
    obj.rectangle31:setMargins({top=10,right=10});
    obj.rectangle31.grid["cnt-gutter"] = 4;
    obj.rectangle31:setName("rectangle31");

    obj.edit39 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit39:setParent(obj.rectangle31);
    obj.edit39:setHeight(30);
    obj.edit39:setField("forca");
    obj.edit39:setFontSize(40);
    obj.edit39.grid.role = "col";
    obj.edit39.grid.width = 12;
    obj.edit39:setFontFamily("Wishes Script Caps Display");
    obj.edit39:setHorzTextAlign("center");
    obj.edit39:setTransparent(true);
    obj.edit39:setMargins({top=5});
    obj.edit39:setName("edit39");

    obj.edit40 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit40:setParent(obj.rectangle31);
    obj.edit40:setHeight(30);
    obj.edit40:setField("destreza");
    obj.edit40:setFontSize(40);
    obj.edit40.grid.role = "col";
    obj.edit40.grid.width = 12;
    obj.edit40:setFontFamily("Wishes Script Caps Display");
    obj.edit40:setHorzTextAlign("center");
    obj.edit40:setTransparent(true);
    obj.edit40:setMargins({top=5});
    obj.edit40:setName("edit40");

    obj.edit41 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit41:setParent(obj.rectangle31);
    obj.edit41:setHeight(30);
    obj.edit41:setField("vigor");
    obj.edit41:setFontSize(40);
    obj.edit41.grid.role = "col";
    obj.edit41.grid.width = 12;
    obj.edit41:setFontFamily("Wishes Script Caps Display");
    obj.edit41:setHorzTextAlign("center");
    obj.edit41:setTransparent(true);
    obj.edit41:setMargins({top=5});
    obj.edit41:setName("edit41");

    obj.edit42 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit42:setParent(obj.rectangle31);
    obj.edit42:setHeight(30);
    obj.edit42:setField("inteligencia");
    obj.edit42:setFontSize(40);
    obj.edit42.grid.role = "col";
    obj.edit42.grid.width = 12;
    obj.edit42:setFontFamily("Wishes Script Caps Display");
    obj.edit42:setHorzTextAlign("center");
    obj.edit42:setTransparent(true);
    obj.edit42:setMargins({top=5});
    obj.edit42:setName("edit42");

    obj.edit43 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit43:setParent(obj.rectangle31);
    obj.edit43:setHeight(30);
    obj.edit43:setField("consciencia");
    obj.edit43:setFontSize(40);
    obj.edit43.grid.role = "col";
    obj.edit43.grid.width = 12;
    obj.edit43:setFontFamily("Wishes Script Caps Display");
    obj.edit43:setHorzTextAlign("center");
    obj.edit43:setTransparent(true);
    obj.edit43:setMargins({top=5});
    obj.edit43:setName("edit43");

    obj.edit44 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit44:setParent(obj.rectangle31);
    obj.edit44:setHeight(30);
    obj.edit44:setField("carisma");
    obj.edit44:setFontSize(40);
    obj.edit44.grid.role = "col";
    obj.edit44.grid.width = 12;
    obj.edit44:setFontFamily("Wishes Script Caps Display");
    obj.edit44:setHorzTextAlign("center");
    obj.edit44:setTransparent(true);
    obj.edit44:setMargins({top=5});
    obj.edit44:setName("edit44");

    obj.edit45 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit45:setParent(obj.rectangle31);
    obj.edit45:setHeight(30);
    obj.edit45:setField("combate");
    obj.edit45:setFontSize(40);
    obj.edit45.grid.role = "col";
    obj.edit45.grid.width = 12;
    obj.edit45:setFontFamily("Wishes Script Caps Display");
    obj.edit45:setHorzTextAlign("center");
    obj.edit45:setTransparent(true);
    obj.edit45:setMargins({top=5});
    obj.edit45:setName("edit45");

    obj.edit46 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit46:setParent(obj.rectangle31);
    obj.edit46:setHeight(30);
    obj.edit46:setField("precisao");
    obj.edit46:setFontSize(40);
    obj.edit46.grid.role = "col";
    obj.edit46.grid.width = 12;
    obj.edit46:setFontFamily("Wishes Script Caps Display");
    obj.edit46:setHorzTextAlign("center");
    obj.edit46:setTransparent(true);
    obj.edit46:setMargins({top=5});
    obj.edit46:setName("edit46");

    obj.dataLink9 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink9:setParent(obj.tabela_atributos);
    obj.dataLink9:setFields({'forcabase', 'forcasintese', 'forcaequips', 'forcabuffs', 'destrezabase', 'destrezasintese', 'destrezaequips', 'destrezabuffs', 'vigorbase', 'vigorsintese', 'vigorequips', 'vigorbuffs', 'inteligenciabase', 'inteligenciasintese', 'inteligenciaequips', 'inteligenciabuffs', 'conscienciabase', 'conscienciasintese', 'conscienciaequips', 'conscienciabuffs', 'carismabase', 'carismasintese', 'carismaequips', 'carismabuffs', 'combatebase', 'combatesintese', 'combateequips', 'combatebuffs', 'precisaobase', 'precisaosintese', 'precisaoequips', 'precisaobuffs', 'condicao'});
    obj.dataLink9:setDefaultValues({'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','Nenhum'});
    obj.dataLink9:setName("dataLink9");

    obj.rectangle32 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle32:setParent(obj.tabela_atributos);
    obj.rectangle32:setHeight(30);
    obj.rectangle32:setColor("black");
    obj.rectangle32:setCornerType("round");
    obj.rectangle32.grid.role = "col";
    obj.rectangle32.grid.width = 12;
    obj.rectangle32:setStrokeSize(1);
    obj.rectangle32:setStrokeColor("white");
    obj.rectangle32:setXradius(5);
    obj.rectangle32:setYradius(5);
    obj.rectangle32:setMargins({top=10,right=10,left=10});
    obj.rectangle32:setName("rectangle32");

    obj.label39 = GUI.fromHandle(_obj_newObject("label"));
    obj.label39:setParent(obj.rectangle32);
    obj.label39:setHeight(25);
    obj.label39:setText("Disponível:");
    obj.label39:setFontSize(12);
    obj.label39.grid.role = "col";
    obj.label39.grid.width = 2;
    obj.label39:setFontFamily("Wishes Script Caps Display");
    obj.label39:setHorzTextAlign("trailing");
    obj.label39:setVertTextAlign("center");
    obj.label39:setMargins({top=3});
    obj.label39:setName("label39");

    obj.rectangle33 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle33:setParent(obj.rectangle32);
    obj.rectangle33:setHeight(23);
    obj.rectangle33:setColor("black");
    obj.rectangle33:setCornerType("round");
    obj.rectangle33.grid.role = "col";
    obj.rectangle33.grid.width = 1;
    obj.rectangle33:setStrokeSize(1);
    obj.rectangle33:setStrokeColor("white");
    obj.rectangle33:setXradius(5);
    obj.rectangle33:setYradius(5);
    obj.rectangle33:setMargins({top=3});
    obj.rectangle33:setName("rectangle33");

    obj.edit47 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit47:setParent(obj.rectangle33);
    obj.edit47:setHeight(23);
    obj.edit47:setField("distribuir");
    obj.edit47:setFontSize(15);
    obj.edit47.grid.role = "col";
    obj.edit47.grid.width = 12;
    obj.edit47:setHorzTextAlign("center");
    obj.edit47:setVertTextAlign("center");
    obj.edit47:setTransparent(true);
    obj.edit47:setReadOnly(true);
    obj.edit47:setName("edit47");

    obj.dataLink10 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink10:setParent(obj.rectangle33);
    obj.dataLink10:setFields({'estrela_origem','total','nv','forcabase','destrezabase','vigorbase','inteligenciabase', 'conscienciabase', 'carismabase'});
    obj.dataLink10:setName("dataLink10");

    obj.label40 = GUI.fromHandle(_obj_newObject("label"));
    obj.label40:setParent(obj.rectangle32);
    obj.label40:setHeight(25);
    obj.label40:setText("Totais:");
    obj.label40:setFontSize(8);
    obj.label40.grid.role = "col";
    obj.label40.grid.width = 1;
    obj.label40:setFontFamily("Wishes Script Caps Display");
    obj.label40:setHorzTextAlign("trailing");
    obj.label40:setVertTextAlign("center");
    obj.label40:setMargins({top=3});
    obj.label40:setName("label40");

    obj.rectangle34 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle34:setParent(obj.rectangle32);
    obj.rectangle34:setHeight(23);
    obj.rectangle34:setColor("black");
    obj.rectangle34:setCornerType("round");
    obj.rectangle34.grid.role = "col";
    obj.rectangle34.grid.width = 2;
    obj.rectangle34:setStrokeSize(1);
    obj.rectangle34:setStrokeColor("white");
    obj.rectangle34:setXradius(5);
    obj.rectangle34:setYradius(5);
    obj.rectangle34:setMargins({top=3});
    obj.rectangle34:setName("rectangle34");

    obj.edit48 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit48:setParent(obj.rectangle34);
    obj.edit48:setHeight(23);
    obj.edit48:setField("basetotal");
    obj.edit48:setFontSize(15);
    obj.edit48.grid.role = "col";
    obj.edit48.grid.width = 12;
    obj.edit48:setHorzTextAlign("center");
    obj.edit48:setVertTextAlign("center");
    obj.edit48:setTransparent(true);
    obj.edit48:setReadOnly(true);
    obj.edit48:setName("edit48");

    obj.dataLink11 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink11:setParent(obj.rectangle32);
    obj.dataLink11:setFields({'forcabase', 'destrezabase','vigorbase','inteligenciabase', 'conscienciabase', 'carismabase', 'combatebase', 'precisaobase'});
    obj.dataLink11:setName("dataLink11");

    obj.rectangle35 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle35:setParent(obj.rectangle32);
    obj.rectangle35:setHeight(23);
    obj.rectangle35:setColor("black");
    obj.rectangle35:setCornerType("round");
    obj.rectangle35.grid.role = "col";
    obj.rectangle35.grid.width = 2;
    obj.rectangle35:setStrokeSize(1);
    obj.rectangle35:setStrokeColor("white");
    obj.rectangle35:setXradius(5);
    obj.rectangle35:setYradius(5);
    obj.rectangle35:setMargins({top=3});
    obj.rectangle35:setName("rectangle35");

    obj.edit49 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit49:setParent(obj.rectangle35);
    obj.edit49:setHeight(23);
    obj.edit49:setField("sintesetotal");
    obj.edit49:setFontSize(15);
    obj.edit49.grid.role = "col";
    obj.edit49.grid.width = 12;
    obj.edit49:setHorzTextAlign("center");
    obj.edit49:setVertTextAlign("center");
    obj.edit49:setTransparent(true);
    obj.edit49:setReadOnly(true);
    obj.edit49:setName("edit49");

    obj.dataLink12 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink12:setParent(obj.rectangle32);
    obj.dataLink12:setFields({'forcasintese', 'destrezasintese','vigorsintese','inteligenciasintese', 'conscienciasintese', 'carismasintese', 'combatesintese', 'precisaosintese'});
    obj.dataLink12:setName("dataLink12");

    obj.rectangle36 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle36:setParent(obj.rectangle32);
    obj.rectangle36:setHeight(23);
    obj.rectangle36:setColor("black");
    obj.rectangle36:setCornerType("round");
    obj.rectangle36.grid.role = "col";
    obj.rectangle36.grid.width = 2;
    obj.rectangle36:setStrokeSize(1);
    obj.rectangle36:setStrokeColor("white");
    obj.rectangle36:setXradius(5);
    obj.rectangle36:setYradius(5);
    obj.rectangle36:setMargins({top=3});
    obj.rectangle36:setName("rectangle36");

    obj.edit50 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit50:setParent(obj.rectangle36);
    obj.edit50:setHeight(23);
    obj.edit50:setField("equipstotal");
    obj.edit50:setFontSize(15);
    obj.edit50.grid.role = "col";
    obj.edit50.grid.width = 12;
    obj.edit50:setHorzTextAlign("center");
    obj.edit50:setVertTextAlign("center");
    obj.edit50:setTransparent(true);
    obj.edit50:setReadOnly(true);
    obj.edit50:setName("edit50");

    obj.dataLink13 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink13:setParent(obj.rectangle32);
    obj.dataLink13:setFields({'forcaequips', 'destrezaequips', 'vigorequips', 'inteligenciaequips', 'conscienciaequips', 'carismaequips', 'combateequips', 'precisaoequips'});
    obj.dataLink13:setName("dataLink13");

    obj.rectangle37 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle37:setParent(obj.rectangle32);
    obj.rectangle37:setHeight(23);
    obj.rectangle37:setColor("black");
    obj.rectangle37:setCornerType("round");
    obj.rectangle37.grid.role = "col";
    obj.rectangle37.grid.width = 2;
    obj.rectangle37:setStrokeSize(1);
    obj.rectangle37:setStrokeColor("white");
    obj.rectangle37:setXradius(5);
    obj.rectangle37:setYradius(5);
    obj.rectangle37:setMargins({top=3,right=3});
    obj.rectangle37:setName("rectangle37");

    obj.edit51 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit51:setParent(obj.rectangle37);
    obj.edit51:setHeight(23);
    obj.edit51:setField("total");
    obj.edit51:setFontSize(15);
    obj.edit51.grid.role = "col";
    obj.edit51.grid.width = 12;
    obj.edit51:setHorzTextAlign("center");
    obj.edit51:setVertTextAlign("center");
    obj.edit51:setTransparent(true);
    obj.edit51:setReadOnly(true);
    obj.edit51:setName("edit51");

    obj.dataLink14 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink14:setParent(obj.rectangle32);
    obj.dataLink14:setFields({'forca', 'destreza', 'vigor', 'inteligencia', 'consciencia', 'carisma', 'combate', 'precisao'});
    obj.dataLink14:setName("dataLink14");

    obj.label41 = GUI.fromHandle(_obj_newObject("label"));
    obj.label41:setParent(obj.tabela_atributos);
    obj.label41:setHeight(25);
    obj.label41:setText("Condição:");
    obj.label41:setFontSize(15);
    obj.label41.grid.role = "col";
    obj.label41.grid.width = 3;
    obj.label41:setFontFamily("Wishes Script Caps Display");
    obj.label41:setHorzTextAlign("center");
    obj.label41:setMargins({top=5,left=10});
    obj.label41:setName("label41");

    obj.rectangle38 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle38:setParent(obj.tabela_atributos);
    obj.rectangle38:setHeight(25);
    obj.rectangle38:setColor("black");
    obj.rectangle38:setCornerType("round");
    obj.rectangle38.grid.role = "col";
    obj.rectangle38.grid.width = 9;
    obj.rectangle38:setStrokeSize(1);
    obj.rectangle38:setStrokeColor("white");
    obj.rectangle38:setXradius(5);
    obj.rectangle38:setYradius(5);
    obj.rectangle38:setMargins({top=5,right=10});
    obj.rectangle38:setName("rectangle38");

    obj.comboBox3 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox3:setParent(obj.rectangle38);
    obj.comboBox3:setField("condicao");
    obj.comboBox3.grid.role = "col";
    obj.comboBox3.grid.width = 12;
    obj.comboBox3:setHeight(30);
    obj.comboBox3:setHorzTextAlign("center");
    obj.comboBox3:setFontFamily("Wishes Script Caps Display");
    obj.comboBox3:setTransparent(true);
    obj.comboBox3:setFontSize(20);
    obj.comboBox3:setItems({'Nenhum', 'Medo', 'Pavor', 'Terror'});
    obj.comboBox3:setMargins({left=3,right=3});
    obj.comboBox3:setName("comboBox3");

    obj.label42 = GUI.fromHandle(_obj_newObject("label"));
    obj.label42:setParent(obj.tabela_atributos);
    obj.label42:setHeight(25);
    obj.label42:setText("Vida:");
    obj.label42:setFontSize(25);
    obj.label42.grid.role = "col";
    obj.label42.grid.width = 3;
    obj.label42:setFontFamily("Wishes Script Caps Display");
    obj.label42:setHorzTextAlign("center");
    obj.label42:setFontColor("red");
    obj.label42:setVertTextAlign("center");
    obj.label42:setMargins({top=25,left=10});
    obj.label42:setName("label42");

    obj.rectangle39 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle39:setParent(obj.tabela_atributos);
    obj.rectangle39:setHeight(25);
    obj.rectangle39:setColor("black");
    obj.rectangle39:setCornerType("round");
    obj.rectangle39.grid.role = "col";
    obj.rectangle39.grid.width = 3;
    obj.rectangle39:setStrokeSize(1);
    obj.rectangle39:setStrokeColor("white");
    obj.rectangle39:setXradius(5);
    obj.rectangle39:setYradius(5);
    obj.rectangle39:setMargins({top=25});
    obj.rectangle39:setName("rectangle39");

    obj.edit52 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit52:setParent(obj.rectangle39);
    obj.edit52:setHeight(30);
    obj.edit52:setField("hptotal");
    obj.edit52:setFontSize(25);
    obj.edit52.grid.role = "col";
    obj.edit52.grid.width = 12;
    obj.edit52:setFontFamily("Wishes Script Caps Display");
    obj.edit52:setHorzTextAlign("center");
    obj.edit52:setVertTextAlign("center");
    obj.edit52:setTransparent(true);
    obj.edit52:setReadOnly(true);
    obj.edit52:setName("edit52");

    obj.dataLink15 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink15:setParent(obj.rectangle39);
    obj.dataLink15:setFields({'vigorbase','vigorsintese','vigorequips', 'nv'});
    obj.dataLink15:setName("dataLink15");

    obj.label43 = GUI.fromHandle(_obj_newObject("label"));
    obj.label43:setParent(obj.tabela_atributos);
    obj.label43:setHeight(25);
    obj.label43:setText("Energia:");
    obj.label43:setFontSize(25);
    obj.label43.grid.role = "col";
    obj.label43.grid.width = 3;
    obj.label43:setFontFamily("Wishes Script Caps Display");
    obj.label43:setHorzTextAlign("center");
    obj.label43:setFontColor("green");
    obj.label43:setVertTextAlign("center");
    obj.label43:setMargins({top=25});
    obj.label43:setName("label43");

    obj.rectangle40 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle40:setParent(obj.tabela_atributos);
    obj.rectangle40:setHeight(25);
    obj.rectangle40:setColor("black");
    obj.rectangle40:setCornerType("round");
    obj.rectangle40.grid.role = "col";
    obj.rectangle40.grid.width = 3;
    obj.rectangle40:setStrokeSize(1);
    obj.rectangle40:setStrokeColor("white");
    obj.rectangle40:setXradius(5);
    obj.rectangle40:setYradius(5);
    obj.rectangle40:setMargins({top=25, right=10});
    obj.rectangle40:setName("rectangle40");

    obj.edit53 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit53:setParent(obj.rectangle40);
    obj.edit53:setHeight(30);
    obj.edit53:setField("sptotal");
    obj.edit53:setFontSize(25);
    obj.edit53.grid.role = "col";
    obj.edit53.grid.width = 12;
    obj.edit53:setFontFamily("Wishes Script Caps Display");
    obj.edit53:setHorzTextAlign("center");
    obj.edit53:setVertTextAlign("center");
    obj.edit53:setTransparent(true);
    obj.edit53:setReadOnly(true);
    obj.edit53:setName("edit53");

    obj.dataLink16 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink16:setParent(obj.rectangle40);
    obj.dataLink16:setFields({'vigorbase','vigorsintese','vigorequips','nv'});
    obj.dataLink16:setName("dataLink16");

    obj.label44 = GUI.fromHandle(_obj_newObject("label"));
    obj.label44:setParent(obj.tabela_atributos);
    obj.label44:setHeight(25);
    obj.label44:setText("Sanidade:");
    obj.label44:setFontSize(20);
    obj.label44.grid.role = "col";
    obj.label44.grid.width = 3;
    obj.label44:setFontFamily("Wishes Script Caps Display");
    obj.label44:setHorzTextAlign("center");
    obj.label44:setFontColor("purple");
    obj.label44:setVertTextAlign("center");
    obj.label44:setMargins({top=5,left=10});
    obj.label44:setName("label44");

    obj.rectangle41 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle41:setParent(obj.tabela_atributos);
    obj.rectangle41:setHeight(25);
    obj.rectangle41:setColor("black");
    obj.rectangle41:setCornerType("round");
    obj.rectangle41.grid.role = "col";
    obj.rectangle41.grid.width = 3;
    obj.rectangle41:setStrokeSize(1);
    obj.rectangle41:setStrokeColor("white");
    obj.rectangle41:setXradius(5);
    obj.rectangle41:setYradius(5);
    obj.rectangle41:setMargins({top=5});
    obj.rectangle41:setName("rectangle41");

    obj.edit54 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit54:setParent(obj.rectangle41);
    obj.edit54:setHeight(30);
    obj.edit54:setField("sancidadetotal");
    obj.edit54:setFontSize(25);
    obj.edit54.grid.role = "col";
    obj.edit54.grid.width = 12;
    obj.edit54:setFontFamily("Wishes Script Caps Display");
    obj.edit54:setHorzTextAlign("center");
    obj.edit54:setVertTextAlign("center");
    obj.edit54:setTransparent(true);
    obj.edit54:setReadOnly(true);
    obj.edit54:setName("edit54");

    obj.dataLink17 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink17:setParent(obj.rectangle41);
    obj.dataLink17:setFields({'conscienciabase','conscienciasintese','conscienciaequips','nv'});
    obj.dataLink17:setName("dataLink17");

    obj.label_magia = GUI.fromHandle(_obj_newObject("label"));
    obj.label_magia:setParent(obj.tabela_atributos);
    obj.label_magia:setHeight(25);
    obj.label_magia:setText("Mana:");
    obj.label_magia:setName("label_magia");
    obj.label_magia:setFontSize(25);
    obj.label_magia.grid.role = "col";
    obj.label_magia.grid.width = 3;
    obj.label_magia:setFontFamily("Wishes Script Caps Display");
    obj.label_magia:setHorzTextAlign("center");
    obj.label_magia:setFontColor("blue");
    obj.label_magia:setVertTextAlign("center");
    obj.label_magia:setMargins({top=5});
    obj.label_magia:setVisible(false);

    obj.retangulo_magia = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.retangulo_magia:setParent(obj.tabela_atributos);
    obj.retangulo_magia:setHeight(25);
    obj.retangulo_magia:setName("retangulo_magia");
    obj.retangulo_magia:setColor("black");
    obj.retangulo_magia:setCornerType("round");
    obj.retangulo_magia.grid.role = "col";
    obj.retangulo_magia.grid.width = 3;
    obj.retangulo_magia:setStrokeSize(1);
    obj.retangulo_magia:setStrokeColor("white");
    obj.retangulo_magia:setXradius(5);
    obj.retangulo_magia:setYradius(5);
    obj.retangulo_magia:setMargins({top=5,right=10});
    obj.retangulo_magia:setVisible(false);

    obj.edit55 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit55:setParent(obj.retangulo_magia);
    obj.edit55:setHeight(30);
    obj.edit55:setField("mptotal");
    obj.edit55:setFontSize(25);
    obj.edit55.grid.role = "col";
    obj.edit55.grid.width = 12;
    obj.edit55:setFontFamily("Wishes Script Caps Display");
    obj.edit55:setHorzTextAlign("center");
    obj.edit55:setVertTextAlign("center");
    obj.edit55:setTransparent(true);
    obj.edit55:setReadOnly(true);
    obj.edit55:setName("edit55");

    obj.dataLink18 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink18:setParent(obj.retangulo_magia);
    obj.dataLink18:setFields({'inteligenciabase', 'inteligenciasintese','inteligenciaequips', 'conscienciabase','conscienciasintese','conscienciaequips','nv', 'tipo_de_energia'});
    obj.dataLink18:setName("dataLink18");

    obj.label_aura = GUI.fromHandle(_obj_newObject("label"));
    obj.label_aura:setParent(obj.tabela_atributos);
    obj.label_aura:setHeight(25);
    obj.label_aura:setText("Aura:");
    obj.label_aura:setName("label_aura");
    obj.label_aura:setFontSize(25);
    obj.label_aura.grid.role = "col";
    obj.label_aura.grid.width = 3;
    obj.label_aura:setFontFamily("Wishes Script Caps Display");
    obj.label_aura:setHorzTextAlign("center");
    obj.label_aura:setFontColor("yellow");
    obj.label_aura:setVertTextAlign("center");
    obj.label_aura:setMargins({top=5});
    obj.label_aura:setVisible(false);

    obj.retangulo_aura = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.retangulo_aura:setParent(obj.tabela_atributos);
    obj.retangulo_aura:setHeight(25);
    obj.retangulo_aura:setName("retangulo_aura");
    obj.retangulo_aura:setColor("black");
    obj.retangulo_aura:setCornerType("round");
    obj.retangulo_aura.grid.role = "col";
    obj.retangulo_aura.grid.width = 3;
    obj.retangulo_aura:setStrokeSize(1);
    obj.retangulo_aura:setStrokeColor("white");
    obj.retangulo_aura:setXradius(5);
    obj.retangulo_aura:setYradius(5);
    obj.retangulo_aura:setMargins({top=5, right=10});
    obj.retangulo_aura:setVisible(false);

    obj.edit56 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit56:setParent(obj.retangulo_aura);
    obj.edit56:setHeight(30);
    obj.edit56:setField("auratotal");
    obj.edit56:setFontSize(25);
    obj.edit56.grid.role = "col";
    obj.edit56.grid.width = 12;
    obj.edit56:setFontFamily("Wishes Script Caps Display");
    obj.edit56:setHorzTextAlign("center");
    obj.edit56:setVertTextAlign("center");
    obj.edit56:setTransparent(true);
    obj.edit56:setReadOnly(true);
    obj.edit56:setName("edit56");

    obj.dataLink19 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink19:setParent(obj.retangulo_aura);
    obj.dataLink19:setFields({'vigorbase', 'vigorsintese','vigorequips','conscienciabase','conscienciasintese','conscienciaequips','nv', 'tipo_de_energia'});
    obj.dataLink19:setName("dataLink19");

    obj.tabela_mods_fabricacao = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.tabela_mods_fabricacao:setParent(obj.rectangle12);
    obj.tabela_mods_fabricacao.grid.role = "col";
    obj.tabela_mods_fabricacao.grid.width = 12;
    obj.tabela_mods_fabricacao:setHeight(510);
    obj.tabela_mods_fabricacao:setColor("none");
    obj.tabela_mods_fabricacao:setName("tabela_mods_fabricacao");
    obj.tabela_mods_fabricacao:setVisible(false);
    obj.tabela_mods_fabricacao:setMargins({left=10});

    obj.label45 = GUI.fromHandle(_obj_newObject("label"));
    obj.label45:setParent(obj.tabela_mods_fabricacao);
    obj.label45:setHeight(25);
    obj.label45:setText("Modificadores de Fabricação");
    obj.label45:setFontSize(30);
    obj.label45.grid.role = "col";
    obj.label45.grid.width = 12;
    obj.label45:setFontFamily("Wishes Script Caps Display");
    obj.label45:setHorzTextAlign("center");
    obj.label45:setMargins({top=15});
    obj.label45:setName("label45");

    obj.scrollBox4 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox4:setParent(obj.tabela_mods_fabricacao);
    obj.scrollBox4:setAlign("client");
    obj.scrollBox4:setMargins({top=60});
    obj.scrollBox4:setName("scrollBox4");

    obj.dataLink20 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink20:setParent(obj.scrollBox4);
    obj.dataLink20:setFields({'nv_forja', 'maestria_forja', 'extra_forja',
                                            'nv_carpintaria', 'maestria_carpintaria', 'extra_carpintaria',
                                            'nv_alquimia', 'maestria_alquimia', 'extra_alquimia',
                                            'nv_alfaiataria', 'maestria_alfaiataria', 'extra_alfaiataria',
                                            'nv_culinaria', 'maestria_culinaria', 'extra_culinaria',
                                            'nv_joalheria', 'maestria_joalheria', 'extra_joalheria',
                                            'nv_ecomorfia', 'maestria_ecomorfia', 'extra_ecomorfia',
                                            'nv_insetocultura', 'maestria_insetocultura', 'extra_insetocultura',
                                            'nv_agricultura', 'maestria_agricultura', 'extra_agricultura',
                                            'nv_pesca', 'maestria_pesca', 'extra_pesca',
                                            'nv_mineracao', 'maestria_mineracao', 'extra_mineracao',
                                            'nv_criacao_animal', 'maestria_criacao_animal', 'extra_criacao_animal',
                                            'nv_pesquisa', 'maestria_pesquisa', 'extra_pesquisa',
                                            'forca', 'destreza', 'vigor', 'inteligencia', 'consciencia', 'carisma'});
    obj.dataLink20:setDefaultValues({'0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', '0','Sem Skill','0', });
    obj.dataLink20:setName("dataLink20");

    obj.rec_agricultura = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_agricultura:setParent(obj.scrollBox4);
    obj.rec_agricultura:setName("rec_agricultura");
    obj.rec_agricultura:setHeight(50);
    obj.rec_agricultura:setColor("black");
    obj.rec_agricultura:setStrokeSize(2);
    obj.rec_agricultura:setStrokeColor("white");
    obj.rec_agricultura.grid.role = "col";
    obj.rec_agricultura.grid.width = 6;
    obj.rec_agricultura:setCornerType("round");
    obj.rec_agricultura:setXradius(5);
    obj.rec_agricultura:setYradius(5);
    obj.rec_agricultura:setMargins({top=10});

    obj.label46 = GUI.fromHandle(_obj_newObject("label"));
    obj.label46:setParent(obj.rec_agricultura);
    obj.label46:setText("Agricultura");
    obj.label46:setHeight(50);
    obj.label46:setFontSize(18);
    obj.label46.grid.role = "col";
    obj.label46.grid.width = 8;
    obj.label46:setFontFamily("Wishes Script Caps Display");
    obj.label46:setHorzTextAlign("leading");
    obj.label46:setVertTextAlign("center");
    obj.label46:setMargins({left=10});
    obj.label46:setName("label46");

    obj.label47 = GUI.fromHandle(_obj_newObject("label"));
    obj.label47:setParent(obj.rec_agricultura);
    obj.label47:setField("nvt_agricultura");
    obj.label47.grid.role = "col";
    obj.label47.grid.width = 1;
    obj.label47:setHeight(50);
    obj.label47:setFontSize(12);
    obj.label47:setFontFamily("Wishes Script Caps Display");
    obj.label47:setHorzTextAlign("center");
    obj.label47:setVertTextAlign("center");
    obj.label47:setName("label47");

    obj.dataLink21 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink21:setParent(obj.rec_agricultura);
    obj.dataLink21:setField("nv_agricultura");
    obj.dataLink21:setName("dataLink21");

    obj.rectangle42 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle42:setParent(obj.rec_agricultura);
    obj.rectangle42:setHeight(40);
    obj.rectangle42:setColor("black");
    obj.rectangle42:setStrokeSize(2);
    obj.rectangle42:setStrokeColor("white");
    obj.rectangle42.grid.role = "col";
    obj.rectangle42.grid.width = 3;
    obj.rectangle42:setCornerType("round");
    obj.rectangle42:setXradius(5);
    obj.rectangle42:setYradius(5);
    obj.rectangle42:setMargins({top=4,right=4,bottom=4});
    obj.rectangle42:setName("rectangle42");

    obj.label48 = GUI.fromHandle(_obj_newObject("label"));
    obj.label48:setParent(obj.rectangle42);
    obj.label48:setField("mod_agricultura");
    obj.label48.grid.role = "col";
    obj.label48.grid.width = 12;
    obj.label48:setHeight(22);
    obj.label48:setFontSize(20);
    obj.label48:setFontFamily("Wishes Script Caps Display");
    obj.label48:setHorzTextAlign("center");
    obj.label48:setVertTextAlign("leading");
    obj.label48:setName("label48");

    obj.dataLink22 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink22:setParent(obj.rectangle42);
    obj.dataLink22:setField("mod_agricultura");
    obj.dataLink22:setDefaultValue("+0");
    obj.dataLink22:setName("dataLink22");

    obj.button2 = GUI.fromHandle(_obj_newObject("button"));
    obj.button2:setParent(obj.rectangle42);
    obj.button2:setText("Mais");
    obj.button2.grid.role = "col";
    obj.button2.grid.width = 12;
    obj.button2:setHeight(15);
    obj.button2:setFontSize(11);
    obj.button2:setFontFamily("Wishes Script Caps Display");
    obj.button2:setHorzTextAlign("center");
    obj.button2:setVertTextAlign("center");
    obj.button2:setMargins({left=3,right=3});
    obj.button2:setName("button2");

    obj.dataLink23 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink23:setParent(obj.scrollBox4);
    obj.dataLink23:setField("maestria_agricultura");
    obj.dataLink23:setName("dataLink23");

    obj.detalhes_agricultura = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_agricultura:setParent(obj.scrollBox4);
    obj.detalhes_agricultura:setName("detalhes_agricultura");
    obj.detalhes_agricultura:setWidth(400);
    obj.detalhes_agricultura:setHeight(600);
    obj.detalhes_agricultura:setLeft(0);
    obj.detalhes_agricultura:setBackOpacity(0.4);

    obj.rectangle43 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle43:setParent(obj.detalhes_agricultura);
    obj.rectangle43:setColor("black");
    obj.rectangle43:setLeft(-5);
    obj.rectangle43:setTop(-5);
    obj.rectangle43:setWidth(410);
    obj.rectangle43:setHeight(610);
    obj.rectangle43:setName("rectangle43");

    obj.rectangle44 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle44:setParent(obj.detalhes_agricultura);
    obj.rectangle44:setColor("#150e16");
    obj.rectangle44:setStrokeSize(2);
    obj.rectangle44:setStrokeColor("white");
    obj.rectangle44:setLeft(5);
    obj.rectangle44:setTop(5);
    obj.rectangle44:setWidth(390);
    obj.rectangle44:setHeight(590);
    obj.rectangle44:setCornerType("round");
    obj.rectangle44:setXradius(5);
    obj.rectangle44:setYradius(5);
    obj.rectangle44:setName("rectangle44");

    obj.label49 = GUI.fromHandle(_obj_newObject("label"));
    obj.label49:setParent(obj.detalhes_agricultura);
    obj.label49:setText("Agricultura");
    obj.label49:setHeight(30);
    obj.label49:setFontSize(25);
    obj.label49.grid.role = "col";
    obj.label49.grid.width = 12;
    obj.label49:setFontFamily("Wishes Script Caps Display");
    obj.label49:setHorzTextAlign("center");
    obj.label49:setVertTextAlign("center");
    obj.label49:setMargins({top=10});
    obj.label49:setName("label49");

    obj.image4 = GUI.fromHandle(_obj_newObject("image"));
    obj.image4:setParent(obj.detalhes_agricultura);
    obj.image4.animate = true;
    obj.image4:setField("icone_agricultura");
    obj.image4:setStyle("proportional");
    obj.image4.grid.role = "col";
    obj.image4.grid.width = 12;
    obj.image4:setHeight(200);
    obj.image4:setMargins({top=10});
    obj.image4:setURL("https://64.media.tumblr.com/6f1726e3295fa5783016857264a72196/tumblr_otlgprArnA1wvwhrpo1_500.gifv");
    obj.image4:setName("image4");

    obj.label50 = GUI.fromHandle(_obj_newObject("label"));
    obj.label50:setParent(obj.detalhes_agricultura);
    obj.label50:setText("Maestria:");
    obj.label50.grid.role = "col";
    obj.label50.grid.width = 6;
    obj.label50:setHeight(20);
    obj.label50:setFontSize(12);
    obj.label50:setFontFamily("Wishes Script Caps Display");
    obj.label50:setMargins({top=5});
    obj.label50:setName("label50");

    obj.label51 = GUI.fromHandle(_obj_newObject("label"));
    obj.label51:setParent(obj.detalhes_agricultura);
    obj.label51:setText("Nível:");
    obj.label51.grid.role = "col";
    obj.label51.grid.width = 3;
    obj.label51:setHeight(20);
    obj.label51:setFontSize(12);
    obj.label51:setFontFamily("Wishes Script Caps Display");
    obj.label51:setMargins({top=5});
    obj.label51:setName("label51");

    obj.label52 = GUI.fromHandle(_obj_newObject("label"));
    obj.label52:setParent(obj.detalhes_agricultura);
    obj.label52:setText("Mod:");
    obj.label52.grid.role = "col";
    obj.label52.grid.width = 3;
    obj.label52:setHeight(20);
    obj.label52:setFontSize(12);
    obj.label52:setFontFamily("Wishes Script Caps Display");
    obj.label52:setMargins({top=5});
    obj.label52:setName("label52");

    obj.rectangle45 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle45:setParent(obj.detalhes_agricultura);
    obj.rectangle45:setHeight(25);
    obj.rectangle45:setColor("black");
    obj.rectangle45.grid.role = "col";
    obj.rectangle45.grid.width = 6;
    obj.rectangle45:setStrokeSize(1);
    obj.rectangle45:setStrokeColor("white");
    obj.rectangle45:setCornerType("round");
    obj.rectangle45:setXradius(5);
    obj.rectangle45:setYradius(5);
    obj.rectangle45:setName("rectangle45");

    obj.comboBox4 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox4:setParent(obj.rectangle45);
    obj.comboBox4:setField("maestria_agricultura");
    obj.comboBox4.grid.role = "col";
    obj.comboBox4.grid.width = 12;
    obj.comboBox4:setHeight(30);
    obj.comboBox4:setFontFamily("Wishes Script Caps Display");
    obj.comboBox4:setTransparent(true);
    obj.comboBox4:setFontSize(20);
    obj.comboBox4:setHorzTextAlign("center");
    obj.comboBox4:setVertTextAlign("center");
    obj.comboBox4:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox4:setName("comboBox4");

    obj.rectangle46 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle46:setParent(obj.detalhes_agricultura);
    obj.rectangle46:setHeight(25);
    obj.rectangle46:setColor("black");
    obj.rectangle46.grid.role = "col";
    obj.rectangle46.grid.width = 3;
    obj.rectangle46:setStrokeSize(1);
    obj.rectangle46:setStrokeColor("white");
    obj.rectangle46:setCornerType("round");
    obj.rectangle46:setXradius(5);
    obj.rectangle46:setYradius(5);
    obj.rectangle46:setName("rectangle46");

    obj.edit57 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit57:setParent(obj.rectangle46);
    obj.edit57:setField("nv_agricultura");
    obj.edit57.grid.role = "col";
    obj.edit57.grid.width = 12;
    obj.edit57:setHeight(30);
    obj.edit57:setFontFamily("Wishes Script Caps Display");
    obj.edit57:setTransparent(true);
    obj.edit57:setFontSize(20);
    obj.edit57:setHorzTextAlign("center");
    obj.edit57:setVertTextAlign("center");
    obj.edit57:setName("edit57");

    obj.rectangle47 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle47:setParent(obj.detalhes_agricultura);
    obj.rectangle47:setHeight(25);
    obj.rectangle47:setColor("black");
    obj.rectangle47.grid.role = "col";
    obj.rectangle47.grid.width = 3;
    obj.rectangle47:setStrokeSize(1);
    obj.rectangle47:setStrokeColor("white");
    obj.rectangle47:setCornerType("round");
    obj.rectangle47:setXradius(5);
    obj.rectangle47:setYradius(5);
    obj.rectangle47:setName("rectangle47");

    obj.edit58 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit58:setParent(obj.rectangle47);
    obj.edit58:setField("mod_agricultura");
    obj.edit58.grid.role = "col";
    obj.edit58.grid.width = 12;
    obj.edit58:setHeight(30);
    obj.edit58:setFontFamily("Wishes Script Caps Display");
    obj.edit58:setTransparent(true);
    obj.edit58:setFontSize(20);
    obj.edit58:setHorzTextAlign("center");
    obj.edit58:setVertTextAlign("center");
    obj.edit58:setName("edit58");

    obj.label53 = GUI.fromHandle(_obj_newObject("label"));
    obj.label53:setParent(obj.detalhes_agricultura);
    obj.label53:setText("Limite:");
    obj.label53.grid.role = "col";
    obj.label53.grid.width = 9;
    obj.label53:setHeight(20);
    obj.label53:setFontSize(12);
    obj.label53:setFontFamily("Wishes Script Caps Display");
    obj.label53:setMargins({top=5});
    obj.label53:setName("label53");

    obj.label54 = GUI.fromHandle(_obj_newObject("label"));
    obj.label54:setParent(obj.detalhes_agricultura);
    obj.label54:setText("Extra:");
    obj.label54.grid.role = "col";
    obj.label54.grid.width = 3;
    obj.label54:setHeight(20);
    obj.label54:setFontSize(12);
    obj.label54:setFontFamily("Wishes Script Caps Display");
    obj.label54:setMargins({top=5});
    obj.label54:setName("label54");

    obj.rectangle48 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle48:setParent(obj.detalhes_agricultura);
    obj.rectangle48:setHeight(25);
    obj.rectangle48:setColor("black");
    obj.rectangle48.grid.role = "col";
    obj.rectangle48.grid.width = 9;
    obj.rectangle48:setStrokeSize(1);
    obj.rectangle48:setStrokeColor("white");
    obj.rectangle48:setCornerType("round");
    obj.rectangle48:setName("rectangle48");

    obj.edit59 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit59:setParent(obj.rectangle48);
    obj.edit59:setField("limite_agricultura");
    obj.edit59.grid.role = "col";
    obj.edit59.grid.width = 12;
    obj.edit59:setHeight(30);
    obj.edit59:setFontFamily("Wishes Script Caps Display");
    obj.edit59:setReadOnly(true);
    obj.edit59:setTransparent(true);
    obj.edit59:setFontSize(20);
    obj.edit59:setHorzTextAlign("center");
    obj.edit59:setVertTextAlign("center");
    obj.edit59:setName("edit59");

    obj.rectangle49 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle49:setParent(obj.detalhes_agricultura);
    obj.rectangle49:setHeight(25);
    obj.rectangle49:setColor("black");
    obj.rectangle49.grid.role = "col";
    obj.rectangle49.grid.width = 3;
    obj.rectangle49:setStrokeSize(1);
    obj.rectangle49:setStrokeColor("white");
    obj.rectangle49:setCornerType("round");
    obj.rectangle49:setName("rectangle49");

    obj.edit60 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit60:setParent(obj.rectangle49);
    obj.edit60:setField("extra_agricultura");
    obj.edit60.grid.role = "col";
    obj.edit60.grid.width = 12;
    obj.edit60:setHeight(30);
    obj.edit60:setFontFamily("Wishes Script Caps Display");
    obj.edit60:setTransparent(true);
    obj.edit60:setFontSize(20);
    obj.edit60:setHorzTextAlign("center");
    obj.edit60:setVertTextAlign("center");
    obj.edit60:setName("edit60");

    obj.label55 = GUI.fromHandle(_obj_newObject("label"));
    obj.label55:setParent(obj.detalhes_agricultura);
    obj.label55:setText("Descrição:");
    obj.label55.grid.role = "col";
    obj.label55.grid.width = 12;
    obj.label55:setHeight(20);
    obj.label55:setFontSize(12);
    obj.label55:setFontFamily("Wishes Script Caps Display");
    obj.label55:setMargins({top=5});
    obj.label55:setName("label55");

    obj.rectangle50 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle50:setParent(obj.detalhes_agricultura);
    obj.rectangle50:setHeight(100);
    obj.rectangle50:setColor("black");
    obj.rectangle50.grid.role = "col";
    obj.rectangle50.grid.width = 12;
    obj.rectangle50:setStrokeSize(1);
    obj.rectangle50:setStrokeColor("white");
    obj.rectangle50:setCornerType("round");
    obj.rectangle50:setName("rectangle50");

    obj.textEditor10 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor10:setParent(obj.rectangle50);
    obj.textEditor10:setAlign("client");
    obj.textEditor10:setField("descricao_agricultura");
    obj.textEditor10:setTransparent(true);
    obj.textEditor10:setReadOnly(true);
    obj.textEditor10:setName("textEditor10");

    obj.label56 = GUI.fromHandle(_obj_newObject("label"));
    obj.label56:setParent(obj.detalhes_agricultura);
    obj.label56:setText("Progressão:");
    obj.label56.grid.role = "col";
    obj.label56.grid.width = 12;
    obj.label56:setHeight(20);
    obj.label56:setFontSize(12);
    obj.label56:setFontFamily("Wishes Script Caps Display");
    obj.label56:setMargins({top=5});
    obj.label56:setName("label56");

    obj.rectangle51 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle51:setParent(obj.detalhes_agricultura);
    obj.rectangle51:setHeight(80);
    obj.rectangle51:setColor("black");
    obj.rectangle51.grid.role = "col";
    obj.rectangle51.grid.width = 12;
    obj.rectangle51:setStrokeSize(1);
    obj.rectangle51:setStrokeColor("white");
    obj.rectangle51:setCornerType("round");
    obj.rectangle51:setName("rectangle51");

    obj.textEditor11 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor11:setParent(obj.rectangle51);
    obj.textEditor11:setAlign("client");
    obj.textEditor11:setField("progressao_agricultura");
    obj.textEditor11:setTransparent(true);
    obj.textEditor11:setReadOnly(true);
    obj.textEditor11:setName("textEditor11");

    obj.rec_alfaiataria = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_alfaiataria:setParent(obj.scrollBox4);
    obj.rec_alfaiataria:setName("rec_alfaiataria");
    obj.rec_alfaiataria:setHeight(50);
    obj.rec_alfaiataria:setColor("black");
    obj.rec_alfaiataria:setStrokeSize(2);
    obj.rec_alfaiataria:setStrokeColor("white");
    obj.rec_alfaiataria.grid.role = "col";
    obj.rec_alfaiataria.grid.width = 6;
    obj.rec_alfaiataria:setCornerType("round");
    obj.rec_alfaiataria:setXradius(5);
    obj.rec_alfaiataria:setYradius(5);
    obj.rec_alfaiataria:setMargins({top=10});

    obj.label57 = GUI.fromHandle(_obj_newObject("label"));
    obj.label57:setParent(obj.rec_alfaiataria);
    obj.label57:setText("Alfaiataria");
    obj.label57:setHeight(50);
    obj.label57:setFontSize(18);
    obj.label57.grid.role = "col";
    obj.label57.grid.width = 8;
    obj.label57:setFontFamily("Wishes Script Caps Display");
    obj.label57:setHorzTextAlign("leading");
    obj.label57:setVertTextAlign("center");
    obj.label57:setMargins({left=10});
    obj.label57:setName("label57");

    obj.label58 = GUI.fromHandle(_obj_newObject("label"));
    obj.label58:setParent(obj.rec_alfaiataria);
    obj.label58:setField("nvt_alfaiataria");
    obj.label58.grid.role = "col";
    obj.label58.grid.width = 1;
    obj.label58:setHeight(50);
    obj.label58:setFontSize(12);
    obj.label58:setFontFamily("Wishes Script Caps Display");
    obj.label58:setHorzTextAlign("center");
    obj.label58:setVertTextAlign("center");
    obj.label58:setName("label58");

    obj.dataLink24 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink24:setParent(obj.rec_alfaiataria);
    obj.dataLink24:setField("nv_alfaiataria");
    obj.dataLink24:setName("dataLink24");

    obj.rectangle52 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle52:setParent(obj.rec_alfaiataria);
    obj.rectangle52:setHeight(40);
    obj.rectangle52:setColor("black");
    obj.rectangle52:setStrokeSize(2);
    obj.rectangle52:setStrokeColor("white");
    obj.rectangle52.grid.role = "col";
    obj.rectangle52.grid.width = 3;
    obj.rectangle52:setCornerType("round");
    obj.rectangle52:setXradius(5);
    obj.rectangle52:setYradius(5);
    obj.rectangle52:setMargins({top=4,right=4,bottom=4});
    obj.rectangle52:setName("rectangle52");

    obj.label59 = GUI.fromHandle(_obj_newObject("label"));
    obj.label59:setParent(obj.rectangle52);
    obj.label59:setField("mod_alfaiataria");
    obj.label59.grid.role = "col";
    obj.label59.grid.width = 12;
    obj.label59:setHeight(22);
    obj.label59:setFontSize(20);
    obj.label59:setFontFamily("Wishes Script Caps Display");
    obj.label59:setHorzTextAlign("center");
    obj.label59:setVertTextAlign("leading");
    obj.label59:setName("label59");

    obj.dataLink25 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink25:setParent(obj.rectangle52);
    obj.dataLink25:setField("mod_alfaiataria");
    obj.dataLink25:setDefaultValue("+0");
    obj.dataLink25:setName("dataLink25");

    obj.button3 = GUI.fromHandle(_obj_newObject("button"));
    obj.button3:setParent(obj.rectangle52);
    obj.button3:setText("Mais");
    obj.button3.grid.role = "col";
    obj.button3.grid.width = 12;
    obj.button3:setHeight(15);
    obj.button3:setFontSize(11);
    obj.button3:setFontFamily("Wishes Script Caps Display");
    obj.button3:setHorzTextAlign("center");
    obj.button3:setVertTextAlign("center");
    obj.button3:setMargins({left=3,right=3});
    obj.button3:setName("button3");

    obj.dataLink26 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink26:setParent(obj.scrollBox4);
    obj.dataLink26:setField("maestria_alfaiataria");
    obj.dataLink26:setName("dataLink26");

    obj.detalhes_alfaiataria = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_alfaiataria:setParent(obj.scrollBox4);
    obj.detalhes_alfaiataria:setName("detalhes_alfaiataria");
    obj.detalhes_alfaiataria:setWidth(400);
    obj.detalhes_alfaiataria:setHeight(600);
    obj.detalhes_alfaiataria:setLeft(0);
    obj.detalhes_alfaiataria:setBackOpacity(0.4);

    obj.rectangle53 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle53:setParent(obj.detalhes_alfaiataria);
    obj.rectangle53:setColor("black");
    obj.rectangle53:setLeft(-5);
    obj.rectangle53:setTop(-5);
    obj.rectangle53:setWidth(410);
    obj.rectangle53:setHeight(610);
    obj.rectangle53:setName("rectangle53");

    obj.rectangle54 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle54:setParent(obj.detalhes_alfaiataria);
    obj.rectangle54:setColor("#150e16");
    obj.rectangle54:setStrokeSize(2);
    obj.rectangle54:setStrokeColor("white");
    obj.rectangle54:setLeft(5);
    obj.rectangle54:setTop(5);
    obj.rectangle54:setWidth(390);
    obj.rectangle54:setHeight(590);
    obj.rectangle54:setCornerType("round");
    obj.rectangle54:setXradius(5);
    obj.rectangle54:setYradius(5);
    obj.rectangle54:setName("rectangle54");

    obj.label60 = GUI.fromHandle(_obj_newObject("label"));
    obj.label60:setParent(obj.detalhes_alfaiataria);
    obj.label60:setText("Alfaiataria");
    obj.label60:setHeight(30);
    obj.label60:setFontSize(25);
    obj.label60.grid.role = "col";
    obj.label60.grid.width = 12;
    obj.label60:setFontFamily("Wishes Script Caps Display");
    obj.label60:setHorzTextAlign("center");
    obj.label60:setVertTextAlign("center");
    obj.label60:setMargins({top=10});
    obj.label60:setName("label60");

    obj.image5 = GUI.fromHandle(_obj_newObject("image"));
    obj.image5:setParent(obj.detalhes_alfaiataria);
    obj.image5.animate = true;
    obj.image5:setField("icone_alfaiataria");
    obj.image5:setStyle("proportional");
    obj.image5.grid.role = "col";
    obj.image5.grid.width = 12;
    obj.image5:setHeight(200);
    obj.image5:setMargins({top=10});
    obj.image5:setURL("https://i.makeagif.com/media/5-22-2015/OKbtX0.gif");
    obj.image5:setName("image5");

    obj.label61 = GUI.fromHandle(_obj_newObject("label"));
    obj.label61:setParent(obj.detalhes_alfaiataria);
    obj.label61:setText("Maestria:");
    obj.label61.grid.role = "col";
    obj.label61.grid.width = 6;
    obj.label61:setHeight(20);
    obj.label61:setFontSize(12);
    obj.label61:setFontFamily("Wishes Script Caps Display");
    obj.label61:setMargins({top=5});
    obj.label61:setName("label61");

    obj.label62 = GUI.fromHandle(_obj_newObject("label"));
    obj.label62:setParent(obj.detalhes_alfaiataria);
    obj.label62:setText("Nível:");
    obj.label62.grid.role = "col";
    obj.label62.grid.width = 3;
    obj.label62:setHeight(20);
    obj.label62:setFontSize(12);
    obj.label62:setFontFamily("Wishes Script Caps Display");
    obj.label62:setMargins({top=5});
    obj.label62:setName("label62");

    obj.label63 = GUI.fromHandle(_obj_newObject("label"));
    obj.label63:setParent(obj.detalhes_alfaiataria);
    obj.label63:setText("Mod:");
    obj.label63.grid.role = "col";
    obj.label63.grid.width = 3;
    obj.label63:setHeight(20);
    obj.label63:setFontSize(12);
    obj.label63:setFontFamily("Wishes Script Caps Display");
    obj.label63:setMargins({top=5});
    obj.label63:setName("label63");

    obj.rectangle55 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle55:setParent(obj.detalhes_alfaiataria);
    obj.rectangle55:setHeight(25);
    obj.rectangle55:setColor("black");
    obj.rectangle55.grid.role = "col";
    obj.rectangle55.grid.width = 6;
    obj.rectangle55:setStrokeSize(1);
    obj.rectangle55:setStrokeColor("white");
    obj.rectangle55:setCornerType("round");
    obj.rectangle55:setXradius(5);
    obj.rectangle55:setYradius(5);
    obj.rectangle55:setName("rectangle55");

    obj.comboBox5 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox5:setParent(obj.rectangle55);
    obj.comboBox5:setField("maestria_alfaiataria");
    obj.comboBox5.grid.role = "col";
    obj.comboBox5.grid.width = 12;
    obj.comboBox5:setHeight(30);
    obj.comboBox5:setFontFamily("Wishes Script Caps Display");
    obj.comboBox5:setTransparent(true);
    obj.comboBox5:setFontSize(20);
    obj.comboBox5:setHorzTextAlign("center");
    obj.comboBox5:setVertTextAlign("center");
    obj.comboBox5:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox5:setName("comboBox5");

    obj.rectangle56 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle56:setParent(obj.detalhes_alfaiataria);
    obj.rectangle56:setHeight(25);
    obj.rectangle56:setColor("black");
    obj.rectangle56.grid.role = "col";
    obj.rectangle56.grid.width = 3;
    obj.rectangle56:setStrokeSize(1);
    obj.rectangle56:setStrokeColor("white");
    obj.rectangle56:setCornerType("round");
    obj.rectangle56:setXradius(5);
    obj.rectangle56:setYradius(5);
    obj.rectangle56:setName("rectangle56");

    obj.edit61 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit61:setParent(obj.rectangle56);
    obj.edit61:setField("nv_alfaiataria");
    obj.edit61.grid.role = "col";
    obj.edit61.grid.width = 12;
    obj.edit61:setHeight(30);
    obj.edit61:setFontFamily("Wishes Script Caps Display");
    obj.edit61:setTransparent(true);
    obj.edit61:setFontSize(20);
    obj.edit61:setHorzTextAlign("center");
    obj.edit61:setVertTextAlign("center");
    obj.edit61:setName("edit61");

    obj.rectangle57 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle57:setParent(obj.detalhes_alfaiataria);
    obj.rectangle57:setHeight(25);
    obj.rectangle57:setColor("black");
    obj.rectangle57.grid.role = "col";
    obj.rectangle57.grid.width = 3;
    obj.rectangle57:setStrokeSize(1);
    obj.rectangle57:setStrokeColor("white");
    obj.rectangle57:setCornerType("round");
    obj.rectangle57:setXradius(5);
    obj.rectangle57:setYradius(5);
    obj.rectangle57:setName("rectangle57");

    obj.edit62 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit62:setParent(obj.rectangle57);
    obj.edit62:setField("mod_alfaiataria");
    obj.edit62.grid.role = "col";
    obj.edit62.grid.width = 12;
    obj.edit62:setHeight(30);
    obj.edit62:setFontFamily("Wishes Script Caps Display");
    obj.edit62:setTransparent(true);
    obj.edit62:setFontSize(20);
    obj.edit62:setHorzTextAlign("center");
    obj.edit62:setVertTextAlign("center");
    obj.edit62:setName("edit62");

    obj.label64 = GUI.fromHandle(_obj_newObject("label"));
    obj.label64:setParent(obj.detalhes_alfaiataria);
    obj.label64:setText("Limite:");
    obj.label64.grid.role = "col";
    obj.label64.grid.width = 9;
    obj.label64:setHeight(20);
    obj.label64:setFontSize(12);
    obj.label64:setFontFamily("Wishes Script Caps Display");
    obj.label64:setMargins({top=5});
    obj.label64:setName("label64");

    obj.label65 = GUI.fromHandle(_obj_newObject("label"));
    obj.label65:setParent(obj.detalhes_alfaiataria);
    obj.label65:setText("Extra:");
    obj.label65.grid.role = "col";
    obj.label65.grid.width = 3;
    obj.label65:setHeight(20);
    obj.label65:setFontSize(12);
    obj.label65:setFontFamily("Wishes Script Caps Display");
    obj.label65:setMargins({top=5});
    obj.label65:setName("label65");

    obj.rectangle58 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle58:setParent(obj.detalhes_alfaiataria);
    obj.rectangle58:setHeight(25);
    obj.rectangle58:setColor("black");
    obj.rectangle58.grid.role = "col";
    obj.rectangle58.grid.width = 9;
    obj.rectangle58:setStrokeSize(1);
    obj.rectangle58:setStrokeColor("white");
    obj.rectangle58:setCornerType("round");
    obj.rectangle58:setName("rectangle58");

    obj.edit63 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit63:setParent(obj.rectangle58);
    obj.edit63:setField("limite_alfaiataria");
    obj.edit63.grid.role = "col";
    obj.edit63.grid.width = 12;
    obj.edit63:setHeight(30);
    obj.edit63:setFontFamily("Wishes Script Caps Display");
    obj.edit63:setReadOnly(true);
    obj.edit63:setTransparent(true);
    obj.edit63:setFontSize(20);
    obj.edit63:setHorzTextAlign("center");
    obj.edit63:setVertTextAlign("center");
    obj.edit63:setName("edit63");

    obj.rectangle59 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle59:setParent(obj.detalhes_alfaiataria);
    obj.rectangle59:setHeight(25);
    obj.rectangle59:setColor("black");
    obj.rectangle59.grid.role = "col";
    obj.rectangle59.grid.width = 3;
    obj.rectangle59:setStrokeSize(1);
    obj.rectangle59:setStrokeColor("white");
    obj.rectangle59:setCornerType("round");
    obj.rectangle59:setName("rectangle59");

    obj.edit64 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit64:setParent(obj.rectangle59);
    obj.edit64:setField("extra_alfaiataria");
    obj.edit64.grid.role = "col";
    obj.edit64.grid.width = 12;
    obj.edit64:setHeight(30);
    obj.edit64:setFontFamily("Wishes Script Caps Display");
    obj.edit64:setTransparent(true);
    obj.edit64:setFontSize(20);
    obj.edit64:setHorzTextAlign("center");
    obj.edit64:setVertTextAlign("center");
    obj.edit64:setName("edit64");

    obj.label66 = GUI.fromHandle(_obj_newObject("label"));
    obj.label66:setParent(obj.detalhes_alfaiataria);
    obj.label66:setText("Descrição:");
    obj.label66.grid.role = "col";
    obj.label66.grid.width = 12;
    obj.label66:setHeight(20);
    obj.label66:setFontSize(12);
    obj.label66:setFontFamily("Wishes Script Caps Display");
    obj.label66:setMargins({top=5});
    obj.label66:setName("label66");

    obj.rectangle60 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle60:setParent(obj.detalhes_alfaiataria);
    obj.rectangle60:setHeight(100);
    obj.rectangle60:setColor("black");
    obj.rectangle60.grid.role = "col";
    obj.rectangle60.grid.width = 12;
    obj.rectangle60:setStrokeSize(1);
    obj.rectangle60:setStrokeColor("white");
    obj.rectangle60:setCornerType("round");
    obj.rectangle60:setName("rectangle60");

    obj.textEditor12 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor12:setParent(obj.rectangle60);
    obj.textEditor12:setAlign("client");
    obj.textEditor12:setField("descricao_alfaiataria");
    obj.textEditor12:setTransparent(true);
    obj.textEditor12:setReadOnly(true);
    obj.textEditor12:setName("textEditor12");

    obj.label67 = GUI.fromHandle(_obj_newObject("label"));
    obj.label67:setParent(obj.detalhes_alfaiataria);
    obj.label67:setText("Progressão:");
    obj.label67.grid.role = "col";
    obj.label67.grid.width = 12;
    obj.label67:setHeight(20);
    obj.label67:setFontSize(12);
    obj.label67:setFontFamily("Wishes Script Caps Display");
    obj.label67:setMargins({top=5});
    obj.label67:setName("label67");

    obj.rectangle61 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle61:setParent(obj.detalhes_alfaiataria);
    obj.rectangle61:setHeight(80);
    obj.rectangle61:setColor("black");
    obj.rectangle61.grid.role = "col";
    obj.rectangle61.grid.width = 12;
    obj.rectangle61:setStrokeSize(1);
    obj.rectangle61:setStrokeColor("white");
    obj.rectangle61:setCornerType("round");
    obj.rectangle61:setName("rectangle61");

    obj.textEditor13 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor13:setParent(obj.rectangle61);
    obj.textEditor13:setAlign("client");
    obj.textEditor13:setField("progressao_alfaiataria");
    obj.textEditor13:setTransparent(true);
    obj.textEditor13:setReadOnly(true);
    obj.textEditor13:setName("textEditor13");

    obj.rec_alquimia = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_alquimia:setParent(obj.scrollBox4);
    obj.rec_alquimia:setName("rec_alquimia");
    obj.rec_alquimia:setHeight(50);
    obj.rec_alquimia:setColor("black");
    obj.rec_alquimia:setStrokeSize(2);
    obj.rec_alquimia:setStrokeColor("white");
    obj.rec_alquimia.grid.role = "col";
    obj.rec_alquimia.grid.width = 6;
    obj.rec_alquimia:setCornerType("round");
    obj.rec_alquimia:setXradius(5);
    obj.rec_alquimia:setYradius(5);
    obj.rec_alquimia:setMargins({top=10});

    obj.label68 = GUI.fromHandle(_obj_newObject("label"));
    obj.label68:setParent(obj.rec_alquimia);
    obj.label68:setText("Alquimia");
    obj.label68:setHeight(50);
    obj.label68:setFontSize(18);
    obj.label68.grid.role = "col";
    obj.label68.grid.width = 8;
    obj.label68:setFontFamily("Wishes Script Caps Display");
    obj.label68:setHorzTextAlign("leading");
    obj.label68:setVertTextAlign("center");
    obj.label68:setMargins({left=10});
    obj.label68:setName("label68");

    obj.label69 = GUI.fromHandle(_obj_newObject("label"));
    obj.label69:setParent(obj.rec_alquimia);
    obj.label69:setField("nvt_alquimia");
    obj.label69.grid.role = "col";
    obj.label69.grid.width = 1;
    obj.label69:setHeight(50);
    obj.label69:setFontSize(12);
    obj.label69:setFontFamily("Wishes Script Caps Display");
    obj.label69:setHorzTextAlign("center");
    obj.label69:setVertTextAlign("center");
    obj.label69:setName("label69");

    obj.dataLink27 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink27:setParent(obj.rec_alquimia);
    obj.dataLink27:setField("nv_alquimia");
    obj.dataLink27:setName("dataLink27");

    obj.rectangle62 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle62:setParent(obj.rec_alquimia);
    obj.rectangle62:setHeight(40);
    obj.rectangle62:setColor("black");
    obj.rectangle62:setStrokeSize(2);
    obj.rectangle62:setStrokeColor("white");
    obj.rectangle62.grid.role = "col";
    obj.rectangle62.grid.width = 3;
    obj.rectangle62:setCornerType("round");
    obj.rectangle62:setXradius(5);
    obj.rectangle62:setYradius(5);
    obj.rectangle62:setMargins({top=4,right=4,bottom=4});
    obj.rectangle62:setName("rectangle62");

    obj.label70 = GUI.fromHandle(_obj_newObject("label"));
    obj.label70:setParent(obj.rectangle62);
    obj.label70:setField("mod_alquimia");
    obj.label70.grid.role = "col";
    obj.label70.grid.width = 12;
    obj.label70:setHeight(22);
    obj.label70:setFontSize(20);
    obj.label70:setFontFamily("Wishes Script Caps Display");
    obj.label70:setHorzTextAlign("center");
    obj.label70:setVertTextAlign("leading");
    obj.label70:setName("label70");

    obj.dataLink28 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink28:setParent(obj.rectangle62);
    obj.dataLink28:setField("mod_alquimia");
    obj.dataLink28:setDefaultValue("+0");
    obj.dataLink28:setName("dataLink28");

    obj.button4 = GUI.fromHandle(_obj_newObject("button"));
    obj.button4:setParent(obj.rectangle62);
    obj.button4:setText("Mais");
    obj.button4.grid.role = "col";
    obj.button4.grid.width = 12;
    obj.button4:setHeight(15);
    obj.button4:setFontSize(11);
    obj.button4:setFontFamily("Wishes Script Caps Display");
    obj.button4:setHorzTextAlign("center");
    obj.button4:setVertTextAlign("center");
    obj.button4:setMargins({left=3,right=3});
    obj.button4:setName("button4");

    obj.dataLink29 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink29:setParent(obj.scrollBox4);
    obj.dataLink29:setField("maestria_alquimia");
    obj.dataLink29:setName("dataLink29");

    obj.detalhes_alquimia = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_alquimia:setParent(obj.scrollBox4);
    obj.detalhes_alquimia:setName("detalhes_alquimia");
    obj.detalhes_alquimia:setWidth(400);
    obj.detalhes_alquimia:setHeight(600);
    obj.detalhes_alquimia:setLeft(0);
    obj.detalhes_alquimia:setBackOpacity(0.4);

    obj.rectangle63 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle63:setParent(obj.detalhes_alquimia);
    obj.rectangle63:setColor("black");
    obj.rectangle63:setLeft(-5);
    obj.rectangle63:setTop(-5);
    obj.rectangle63:setWidth(410);
    obj.rectangle63:setHeight(610);
    obj.rectangle63:setName("rectangle63");

    obj.rectangle64 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle64:setParent(obj.detalhes_alquimia);
    obj.rectangle64:setColor("#150e16");
    obj.rectangle64:setStrokeSize(2);
    obj.rectangle64:setStrokeColor("white");
    obj.rectangle64:setLeft(5);
    obj.rectangle64:setTop(5);
    obj.rectangle64:setWidth(390);
    obj.rectangle64:setHeight(590);
    obj.rectangle64:setCornerType("round");
    obj.rectangle64:setXradius(5);
    obj.rectangle64:setYradius(5);
    obj.rectangle64:setName("rectangle64");

    obj.label71 = GUI.fromHandle(_obj_newObject("label"));
    obj.label71:setParent(obj.detalhes_alquimia);
    obj.label71:setText("Alquimia");
    obj.label71:setHeight(30);
    obj.label71:setFontSize(25);
    obj.label71.grid.role = "col";
    obj.label71.grid.width = 12;
    obj.label71:setFontFamily("Wishes Script Caps Display");
    obj.label71:setHorzTextAlign("center");
    obj.label71:setVertTextAlign("center");
    obj.label71:setMargins({top=10});
    obj.label71:setName("label71");

    obj.image6 = GUI.fromHandle(_obj_newObject("image"));
    obj.image6:setParent(obj.detalhes_alquimia);
    obj.image6.animate = true;
    obj.image6:setField("icone_alquimia");
    obj.image6:setStyle("proportional");
    obj.image6.grid.role = "col";
    obj.image6.grid.width = 12;
    obj.image6:setHeight(200);
    obj.image6:setMargins({top=10});
    obj.image6:setURL("https://monarchastrology.com/wp-content/uploads/2016/12/tumblr_odkb5iGVfK1vregoso1_500.gif");
    obj.image6:setName("image6");

    obj.label72 = GUI.fromHandle(_obj_newObject("label"));
    obj.label72:setParent(obj.detalhes_alquimia);
    obj.label72:setText("Maestria:");
    obj.label72.grid.role = "col";
    obj.label72.grid.width = 6;
    obj.label72:setHeight(20);
    obj.label72:setFontSize(12);
    obj.label72:setFontFamily("Wishes Script Caps Display");
    obj.label72:setMargins({top=5});
    obj.label72:setName("label72");

    obj.label73 = GUI.fromHandle(_obj_newObject("label"));
    obj.label73:setParent(obj.detalhes_alquimia);
    obj.label73:setText("Nível:");
    obj.label73.grid.role = "col";
    obj.label73.grid.width = 3;
    obj.label73:setHeight(20);
    obj.label73:setFontSize(12);
    obj.label73:setFontFamily("Wishes Script Caps Display");
    obj.label73:setMargins({top=5});
    obj.label73:setName("label73");

    obj.label74 = GUI.fromHandle(_obj_newObject("label"));
    obj.label74:setParent(obj.detalhes_alquimia);
    obj.label74:setText("Mod:");
    obj.label74.grid.role = "col";
    obj.label74.grid.width = 3;
    obj.label74:setHeight(20);
    obj.label74:setFontSize(12);
    obj.label74:setFontFamily("Wishes Script Caps Display");
    obj.label74:setMargins({top=5});
    obj.label74:setName("label74");

    obj.rectangle65 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle65:setParent(obj.detalhes_alquimia);
    obj.rectangle65:setHeight(25);
    obj.rectangle65:setColor("black");
    obj.rectangle65.grid.role = "col";
    obj.rectangle65.grid.width = 6;
    obj.rectangle65:setStrokeSize(1);
    obj.rectangle65:setStrokeColor("white");
    obj.rectangle65:setCornerType("round");
    obj.rectangle65:setXradius(5);
    obj.rectangle65:setYradius(5);
    obj.rectangle65:setName("rectangle65");

    obj.comboBox6 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox6:setParent(obj.rectangle65);
    obj.comboBox6:setField("maestria_alquimia");
    obj.comboBox6.grid.role = "col";
    obj.comboBox6.grid.width = 12;
    obj.comboBox6:setHeight(30);
    obj.comboBox6:setFontFamily("Wishes Script Caps Display");
    obj.comboBox6:setTransparent(true);
    obj.comboBox6:setFontSize(20);
    obj.comboBox6:setHorzTextAlign("center");
    obj.comboBox6:setVertTextAlign("center");
    obj.comboBox6:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox6:setName("comboBox6");

    obj.rectangle66 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle66:setParent(obj.detalhes_alquimia);
    obj.rectangle66:setHeight(25);
    obj.rectangle66:setColor("black");
    obj.rectangle66.grid.role = "col";
    obj.rectangle66.grid.width = 3;
    obj.rectangle66:setStrokeSize(1);
    obj.rectangle66:setStrokeColor("white");
    obj.rectangle66:setCornerType("round");
    obj.rectangle66:setXradius(5);
    obj.rectangle66:setYradius(5);
    obj.rectangle66:setName("rectangle66");

    obj.edit65 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit65:setParent(obj.rectangle66);
    obj.edit65:setField("nv_alquimia");
    obj.edit65.grid.role = "col";
    obj.edit65.grid.width = 12;
    obj.edit65:setHeight(30);
    obj.edit65:setFontFamily("Wishes Script Caps Display");
    obj.edit65:setTransparent(true);
    obj.edit65:setFontSize(20);
    obj.edit65:setHorzTextAlign("center");
    obj.edit65:setVertTextAlign("center");
    obj.edit65:setName("edit65");

    obj.rectangle67 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle67:setParent(obj.detalhes_alquimia);
    obj.rectangle67:setHeight(25);
    obj.rectangle67:setColor("black");
    obj.rectangle67.grid.role = "col";
    obj.rectangle67.grid.width = 3;
    obj.rectangle67:setStrokeSize(1);
    obj.rectangle67:setStrokeColor("white");
    obj.rectangle67:setCornerType("round");
    obj.rectangle67:setXradius(5);
    obj.rectangle67:setYradius(5);
    obj.rectangle67:setName("rectangle67");

    obj.edit66 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit66:setParent(obj.rectangle67);
    obj.edit66:setField("mod_alquimia");
    obj.edit66.grid.role = "col";
    obj.edit66.grid.width = 12;
    obj.edit66:setHeight(30);
    obj.edit66:setFontFamily("Wishes Script Caps Display");
    obj.edit66:setTransparent(true);
    obj.edit66:setFontSize(20);
    obj.edit66:setHorzTextAlign("center");
    obj.edit66:setVertTextAlign("center");
    obj.edit66:setName("edit66");

    obj.label75 = GUI.fromHandle(_obj_newObject("label"));
    obj.label75:setParent(obj.detalhes_alquimia);
    obj.label75:setText("Limite:");
    obj.label75.grid.role = "col";
    obj.label75.grid.width = 9;
    obj.label75:setHeight(20);
    obj.label75:setFontSize(12);
    obj.label75:setFontFamily("Wishes Script Caps Display");
    obj.label75:setMargins({top=5});
    obj.label75:setName("label75");

    obj.label76 = GUI.fromHandle(_obj_newObject("label"));
    obj.label76:setParent(obj.detalhes_alquimia);
    obj.label76:setText("Extra:");
    obj.label76.grid.role = "col";
    obj.label76.grid.width = 3;
    obj.label76:setHeight(20);
    obj.label76:setFontSize(12);
    obj.label76:setFontFamily("Wishes Script Caps Display");
    obj.label76:setMargins({top=5});
    obj.label76:setName("label76");

    obj.rectangle68 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle68:setParent(obj.detalhes_alquimia);
    obj.rectangle68:setHeight(25);
    obj.rectangle68:setColor("black");
    obj.rectangle68.grid.role = "col";
    obj.rectangle68.grid.width = 9;
    obj.rectangle68:setStrokeSize(1);
    obj.rectangle68:setStrokeColor("white");
    obj.rectangle68:setCornerType("round");
    obj.rectangle68:setName("rectangle68");

    obj.edit67 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit67:setParent(obj.rectangle68);
    obj.edit67:setField("limite_alquimia");
    obj.edit67.grid.role = "col";
    obj.edit67.grid.width = 12;
    obj.edit67:setHeight(30);
    obj.edit67:setFontFamily("Wishes Script Caps Display");
    obj.edit67:setReadOnly(true);
    obj.edit67:setTransparent(true);
    obj.edit67:setFontSize(20);
    obj.edit67:setHorzTextAlign("center");
    obj.edit67:setVertTextAlign("center");
    obj.edit67:setName("edit67");

    obj.rectangle69 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle69:setParent(obj.detalhes_alquimia);
    obj.rectangle69:setHeight(25);
    obj.rectangle69:setColor("black");
    obj.rectangle69.grid.role = "col";
    obj.rectangle69.grid.width = 3;
    obj.rectangle69:setStrokeSize(1);
    obj.rectangle69:setStrokeColor("white");
    obj.rectangle69:setCornerType("round");
    obj.rectangle69:setName("rectangle69");

    obj.edit68 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit68:setParent(obj.rectangle69);
    obj.edit68:setField("extra_alquimia");
    obj.edit68.grid.role = "col";
    obj.edit68.grid.width = 12;
    obj.edit68:setHeight(30);
    obj.edit68:setFontFamily("Wishes Script Caps Display");
    obj.edit68:setTransparent(true);
    obj.edit68:setFontSize(20);
    obj.edit68:setHorzTextAlign("center");
    obj.edit68:setVertTextAlign("center");
    obj.edit68:setName("edit68");

    obj.label77 = GUI.fromHandle(_obj_newObject("label"));
    obj.label77:setParent(obj.detalhes_alquimia);
    obj.label77:setText("Descrição:");
    obj.label77.grid.role = "col";
    obj.label77.grid.width = 12;
    obj.label77:setHeight(20);
    obj.label77:setFontSize(12);
    obj.label77:setFontFamily("Wishes Script Caps Display");
    obj.label77:setMargins({top=5});
    obj.label77:setName("label77");

    obj.rectangle70 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle70:setParent(obj.detalhes_alquimia);
    obj.rectangle70:setHeight(100);
    obj.rectangle70:setColor("black");
    obj.rectangle70.grid.role = "col";
    obj.rectangle70.grid.width = 12;
    obj.rectangle70:setStrokeSize(1);
    obj.rectangle70:setStrokeColor("white");
    obj.rectangle70:setCornerType("round");
    obj.rectangle70:setName("rectangle70");

    obj.textEditor14 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor14:setParent(obj.rectangle70);
    obj.textEditor14:setAlign("client");
    obj.textEditor14:setField("descricao_alquimia");
    obj.textEditor14:setTransparent(true);
    obj.textEditor14:setReadOnly(true);
    obj.textEditor14:setName("textEditor14");

    obj.label78 = GUI.fromHandle(_obj_newObject("label"));
    obj.label78:setParent(obj.detalhes_alquimia);
    obj.label78:setText("Progressão:");
    obj.label78.grid.role = "col";
    obj.label78.grid.width = 12;
    obj.label78:setHeight(20);
    obj.label78:setFontSize(12);
    obj.label78:setFontFamily("Wishes Script Caps Display");
    obj.label78:setMargins({top=5});
    obj.label78:setName("label78");

    obj.rectangle71 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle71:setParent(obj.detalhes_alquimia);
    obj.rectangle71:setHeight(80);
    obj.rectangle71:setColor("black");
    obj.rectangle71.grid.role = "col";
    obj.rectangle71.grid.width = 12;
    obj.rectangle71:setStrokeSize(1);
    obj.rectangle71:setStrokeColor("white");
    obj.rectangle71:setCornerType("round");
    obj.rectangle71:setName("rectangle71");

    obj.textEditor15 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor15:setParent(obj.rectangle71);
    obj.textEditor15:setAlign("client");
    obj.textEditor15:setField("progressao_alquimia");
    obj.textEditor15:setTransparent(true);
    obj.textEditor15:setReadOnly(true);
    obj.textEditor15:setName("textEditor15");

    obj.rec_carpintaria = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_carpintaria:setParent(obj.scrollBox4);
    obj.rec_carpintaria:setName("rec_carpintaria");
    obj.rec_carpintaria:setHeight(50);
    obj.rec_carpintaria:setColor("black");
    obj.rec_carpintaria:setStrokeSize(2);
    obj.rec_carpintaria:setStrokeColor("white");
    obj.rec_carpintaria.grid.role = "col";
    obj.rec_carpintaria.grid.width = 6;
    obj.rec_carpintaria:setCornerType("round");
    obj.rec_carpintaria:setXradius(5);
    obj.rec_carpintaria:setYradius(5);
    obj.rec_carpintaria:setMargins({top=10});

    obj.label79 = GUI.fromHandle(_obj_newObject("label"));
    obj.label79:setParent(obj.rec_carpintaria);
    obj.label79:setText("Carpintaria");
    obj.label79:setHeight(50);
    obj.label79:setFontSize(18);
    obj.label79.grid.role = "col";
    obj.label79.grid.width = 8;
    obj.label79:setFontFamily("Wishes Script Caps Display");
    obj.label79:setHorzTextAlign("leading");
    obj.label79:setVertTextAlign("center");
    obj.label79:setMargins({left=10});
    obj.label79:setName("label79");

    obj.label80 = GUI.fromHandle(_obj_newObject("label"));
    obj.label80:setParent(obj.rec_carpintaria);
    obj.label80:setField("nvt_carpintaria");
    obj.label80.grid.role = "col";
    obj.label80.grid.width = 1;
    obj.label80:setHeight(50);
    obj.label80:setFontSize(12);
    obj.label80:setFontFamily("Wishes Script Caps Display");
    obj.label80:setHorzTextAlign("center");
    obj.label80:setVertTextAlign("center");
    obj.label80:setName("label80");

    obj.dataLink30 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink30:setParent(obj.rec_carpintaria);
    obj.dataLink30:setField("nv_carpintaria");
    obj.dataLink30:setName("dataLink30");

    obj.rectangle72 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle72:setParent(obj.rec_carpintaria);
    obj.rectangle72:setHeight(40);
    obj.rectangle72:setColor("black");
    obj.rectangle72:setStrokeSize(2);
    obj.rectangle72:setStrokeColor("white");
    obj.rectangle72.grid.role = "col";
    obj.rectangle72.grid.width = 3;
    obj.rectangle72:setCornerType("round");
    obj.rectangle72:setXradius(5);
    obj.rectangle72:setYradius(5);
    obj.rectangle72:setMargins({top=4,right=4,bottom=4});
    obj.rectangle72:setName("rectangle72");

    obj.label81 = GUI.fromHandle(_obj_newObject("label"));
    obj.label81:setParent(obj.rectangle72);
    obj.label81:setField("mod_carpintaria");
    obj.label81.grid.role = "col";
    obj.label81.grid.width = 12;
    obj.label81:setHeight(22);
    obj.label81:setFontSize(20);
    obj.label81:setFontFamily("Wishes Script Caps Display");
    obj.label81:setHorzTextAlign("center");
    obj.label81:setVertTextAlign("leading");
    obj.label81:setName("label81");

    obj.dataLink31 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink31:setParent(obj.rectangle72);
    obj.dataLink31:setField("mod_carpintaria");
    obj.dataLink31:setDefaultValue("+0");
    obj.dataLink31:setName("dataLink31");

    obj.button5 = GUI.fromHandle(_obj_newObject("button"));
    obj.button5:setParent(obj.rectangle72);
    obj.button5:setText("Mais");
    obj.button5.grid.role = "col";
    obj.button5.grid.width = 12;
    obj.button5:setHeight(15);
    obj.button5:setFontSize(11);
    obj.button5:setFontFamily("Wishes Script Caps Display");
    obj.button5:setHorzTextAlign("center");
    obj.button5:setVertTextAlign("center");
    obj.button5:setMargins({left=3,right=3});
    obj.button5:setName("button5");

    obj.dataLink32 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink32:setParent(obj.scrollBox4);
    obj.dataLink32:setField("maestria_carpintaria");
    obj.dataLink32:setName("dataLink32");

    obj.detalhes_carpintaria = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_carpintaria:setParent(obj.scrollBox4);
    obj.detalhes_carpintaria:setName("detalhes_carpintaria");
    obj.detalhes_carpintaria:setWidth(400);
    obj.detalhes_carpintaria:setHeight(600);
    obj.detalhes_carpintaria:setLeft(0);
    obj.detalhes_carpintaria:setBackOpacity(0.4);

    obj.rectangle73 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle73:setParent(obj.detalhes_carpintaria);
    obj.rectangle73:setColor("black");
    obj.rectangle73:setLeft(-5);
    obj.rectangle73:setTop(-5);
    obj.rectangle73:setWidth(410);
    obj.rectangle73:setHeight(610);
    obj.rectangle73:setName("rectangle73");

    obj.rectangle74 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle74:setParent(obj.detalhes_carpintaria);
    obj.rectangle74:setColor("#150e16");
    obj.rectangle74:setStrokeSize(2);
    obj.rectangle74:setStrokeColor("white");
    obj.rectangle74:setLeft(5);
    obj.rectangle74:setTop(5);
    obj.rectangle74:setWidth(390);
    obj.rectangle74:setHeight(590);
    obj.rectangle74:setCornerType("round");
    obj.rectangle74:setXradius(5);
    obj.rectangle74:setYradius(5);
    obj.rectangle74:setName("rectangle74");

    obj.label82 = GUI.fromHandle(_obj_newObject("label"));
    obj.label82:setParent(obj.detalhes_carpintaria);
    obj.label82:setText("Carpintaria");
    obj.label82:setHeight(30);
    obj.label82:setFontSize(25);
    obj.label82.grid.role = "col";
    obj.label82.grid.width = 12;
    obj.label82:setFontFamily("Wishes Script Caps Display");
    obj.label82:setHorzTextAlign("center");
    obj.label82:setVertTextAlign("center");
    obj.label82:setMargins({top=10});
    obj.label82:setName("label82");

    obj.image7 = GUI.fromHandle(_obj_newObject("image"));
    obj.image7:setParent(obj.detalhes_carpintaria);
    obj.image7.animate = true;
    obj.image7:setField("icone_carpintaria");
    obj.image7:setStyle("proportional");
    obj.image7.grid.role = "col";
    obj.image7.grid.width = 12;
    obj.image7:setHeight(200);
    obj.image7:setMargins({top=10});
    obj.image7:setURL("https://media1.tenor.com/m/W-eRISSkkeMAAAAd/usopp-hamer.gif");
    obj.image7:setName("image7");

    obj.label83 = GUI.fromHandle(_obj_newObject("label"));
    obj.label83:setParent(obj.detalhes_carpintaria);
    obj.label83:setText("Maestria:");
    obj.label83.grid.role = "col";
    obj.label83.grid.width = 6;
    obj.label83:setHeight(20);
    obj.label83:setFontSize(12);
    obj.label83:setFontFamily("Wishes Script Caps Display");
    obj.label83:setMargins({top=5});
    obj.label83:setName("label83");

    obj.label84 = GUI.fromHandle(_obj_newObject("label"));
    obj.label84:setParent(obj.detalhes_carpintaria);
    obj.label84:setText("Nível:");
    obj.label84.grid.role = "col";
    obj.label84.grid.width = 3;
    obj.label84:setHeight(20);
    obj.label84:setFontSize(12);
    obj.label84:setFontFamily("Wishes Script Caps Display");
    obj.label84:setMargins({top=5});
    obj.label84:setName("label84");

    obj.label85 = GUI.fromHandle(_obj_newObject("label"));
    obj.label85:setParent(obj.detalhes_carpintaria);
    obj.label85:setText("Mod:");
    obj.label85.grid.role = "col";
    obj.label85.grid.width = 3;
    obj.label85:setHeight(20);
    obj.label85:setFontSize(12);
    obj.label85:setFontFamily("Wishes Script Caps Display");
    obj.label85:setMargins({top=5});
    obj.label85:setName("label85");

    obj.rectangle75 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle75:setParent(obj.detalhes_carpintaria);
    obj.rectangle75:setHeight(25);
    obj.rectangle75:setColor("black");
    obj.rectangle75.grid.role = "col";
    obj.rectangle75.grid.width = 6;
    obj.rectangle75:setStrokeSize(1);
    obj.rectangle75:setStrokeColor("white");
    obj.rectangle75:setCornerType("round");
    obj.rectangle75:setXradius(5);
    obj.rectangle75:setYradius(5);
    obj.rectangle75:setName("rectangle75");

    obj.comboBox7 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox7:setParent(obj.rectangle75);
    obj.comboBox7:setField("maestria_carpintaria");
    obj.comboBox7.grid.role = "col";
    obj.comboBox7.grid.width = 12;
    obj.comboBox7:setHeight(30);
    obj.comboBox7:setFontFamily("Wishes Script Caps Display");
    obj.comboBox7:setTransparent(true);
    obj.comboBox7:setFontSize(20);
    obj.comboBox7:setHorzTextAlign("center");
    obj.comboBox7:setVertTextAlign("center");
    obj.comboBox7:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox7:setName("comboBox7");

    obj.rectangle76 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle76:setParent(obj.detalhes_carpintaria);
    obj.rectangle76:setHeight(25);
    obj.rectangle76:setColor("black");
    obj.rectangle76.grid.role = "col";
    obj.rectangle76.grid.width = 3;
    obj.rectangle76:setStrokeSize(1);
    obj.rectangle76:setStrokeColor("white");
    obj.rectangle76:setCornerType("round");
    obj.rectangle76:setXradius(5);
    obj.rectangle76:setYradius(5);
    obj.rectangle76:setName("rectangle76");

    obj.edit69 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit69:setParent(obj.rectangle76);
    obj.edit69:setField("nv_carpintaria");
    obj.edit69.grid.role = "col";
    obj.edit69.grid.width = 12;
    obj.edit69:setHeight(30);
    obj.edit69:setFontFamily("Wishes Script Caps Display");
    obj.edit69:setTransparent(true);
    obj.edit69:setFontSize(20);
    obj.edit69:setHorzTextAlign("center");
    obj.edit69:setVertTextAlign("center");
    obj.edit69:setName("edit69");

    obj.rectangle77 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle77:setParent(obj.detalhes_carpintaria);
    obj.rectangle77:setHeight(25);
    obj.rectangle77:setColor("black");
    obj.rectangle77.grid.role = "col";
    obj.rectangle77.grid.width = 3;
    obj.rectangle77:setStrokeSize(1);
    obj.rectangle77:setStrokeColor("white");
    obj.rectangle77:setCornerType("round");
    obj.rectangle77:setXradius(5);
    obj.rectangle77:setYradius(5);
    obj.rectangle77:setName("rectangle77");

    obj.edit70 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit70:setParent(obj.rectangle77);
    obj.edit70:setField("mod_carpintaria");
    obj.edit70.grid.role = "col";
    obj.edit70.grid.width = 12;
    obj.edit70:setHeight(30);
    obj.edit70:setFontFamily("Wishes Script Caps Display");
    obj.edit70:setTransparent(true);
    obj.edit70:setFontSize(20);
    obj.edit70:setHorzTextAlign("center");
    obj.edit70:setVertTextAlign("center");
    obj.edit70:setName("edit70");

    obj.label86 = GUI.fromHandle(_obj_newObject("label"));
    obj.label86:setParent(obj.detalhes_carpintaria);
    obj.label86:setText("Limite:");
    obj.label86.grid.role = "col";
    obj.label86.grid.width = 9;
    obj.label86:setHeight(20);
    obj.label86:setFontSize(12);
    obj.label86:setFontFamily("Wishes Script Caps Display");
    obj.label86:setMargins({top=5});
    obj.label86:setName("label86");

    obj.label87 = GUI.fromHandle(_obj_newObject("label"));
    obj.label87:setParent(obj.detalhes_carpintaria);
    obj.label87:setText("Extra:");
    obj.label87.grid.role = "col";
    obj.label87.grid.width = 3;
    obj.label87:setHeight(20);
    obj.label87:setFontSize(12);
    obj.label87:setFontFamily("Wishes Script Caps Display");
    obj.label87:setMargins({top=5});
    obj.label87:setName("label87");

    obj.rectangle78 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle78:setParent(obj.detalhes_carpintaria);
    obj.rectangle78:setHeight(25);
    obj.rectangle78:setColor("black");
    obj.rectangle78.grid.role = "col";
    obj.rectangle78.grid.width = 9;
    obj.rectangle78:setStrokeSize(1);
    obj.rectangle78:setStrokeColor("white");
    obj.rectangle78:setCornerType("round");
    obj.rectangle78:setName("rectangle78");

    obj.edit71 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit71:setParent(obj.rectangle78);
    obj.edit71:setField("limite_carpintaria");
    obj.edit71.grid.role = "col";
    obj.edit71.grid.width = 12;
    obj.edit71:setHeight(30);
    obj.edit71:setFontFamily("Wishes Script Caps Display");
    obj.edit71:setReadOnly(true);
    obj.edit71:setTransparent(true);
    obj.edit71:setFontSize(20);
    obj.edit71:setHorzTextAlign("center");
    obj.edit71:setVertTextAlign("center");
    obj.edit71:setName("edit71");

    obj.rectangle79 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle79:setParent(obj.detalhes_carpintaria);
    obj.rectangle79:setHeight(25);
    obj.rectangle79:setColor("black");
    obj.rectangle79.grid.role = "col";
    obj.rectangle79.grid.width = 3;
    obj.rectangle79:setStrokeSize(1);
    obj.rectangle79:setStrokeColor("white");
    obj.rectangle79:setCornerType("round");
    obj.rectangle79:setName("rectangle79");

    obj.edit72 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit72:setParent(obj.rectangle79);
    obj.edit72:setField("extra_carpintaria");
    obj.edit72.grid.role = "col";
    obj.edit72.grid.width = 12;
    obj.edit72:setHeight(30);
    obj.edit72:setFontFamily("Wishes Script Caps Display");
    obj.edit72:setTransparent(true);
    obj.edit72:setFontSize(20);
    obj.edit72:setHorzTextAlign("center");
    obj.edit72:setVertTextAlign("center");
    obj.edit72:setName("edit72");

    obj.label88 = GUI.fromHandle(_obj_newObject("label"));
    obj.label88:setParent(obj.detalhes_carpintaria);
    obj.label88:setText("Descrição:");
    obj.label88.grid.role = "col";
    obj.label88.grid.width = 12;
    obj.label88:setHeight(20);
    obj.label88:setFontSize(12);
    obj.label88:setFontFamily("Wishes Script Caps Display");
    obj.label88:setMargins({top=5});
    obj.label88:setName("label88");

    obj.rectangle80 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle80:setParent(obj.detalhes_carpintaria);
    obj.rectangle80:setHeight(100);
    obj.rectangle80:setColor("black");
    obj.rectangle80.grid.role = "col";
    obj.rectangle80.grid.width = 12;
    obj.rectangle80:setStrokeSize(1);
    obj.rectangle80:setStrokeColor("white");
    obj.rectangle80:setCornerType("round");
    obj.rectangle80:setName("rectangle80");

    obj.textEditor16 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor16:setParent(obj.rectangle80);
    obj.textEditor16:setAlign("client");
    obj.textEditor16:setField("descricao_carpintaria");
    obj.textEditor16:setTransparent(true);
    obj.textEditor16:setReadOnly(true);
    obj.textEditor16:setName("textEditor16");

    obj.label89 = GUI.fromHandle(_obj_newObject("label"));
    obj.label89:setParent(obj.detalhes_carpintaria);
    obj.label89:setText("Progressão:");
    obj.label89.grid.role = "col";
    obj.label89.grid.width = 12;
    obj.label89:setHeight(20);
    obj.label89:setFontSize(12);
    obj.label89:setFontFamily("Wishes Script Caps Display");
    obj.label89:setMargins({top=5});
    obj.label89:setName("label89");

    obj.rectangle81 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle81:setParent(obj.detalhes_carpintaria);
    obj.rectangle81:setHeight(80);
    obj.rectangle81:setColor("black");
    obj.rectangle81.grid.role = "col";
    obj.rectangle81.grid.width = 12;
    obj.rectangle81:setStrokeSize(1);
    obj.rectangle81:setStrokeColor("white");
    obj.rectangle81:setCornerType("round");
    obj.rectangle81:setName("rectangle81");

    obj.textEditor17 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor17:setParent(obj.rectangle81);
    obj.textEditor17:setAlign("client");
    obj.textEditor17:setField("progressao_carpintaria");
    obj.textEditor17:setTransparent(true);
    obj.textEditor17:setReadOnly(true);
    obj.textEditor17:setName("textEditor17");

    obj.rec_criacao_animal = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_criacao_animal:setParent(obj.scrollBox4);
    obj.rec_criacao_animal:setName("rec_criacao_animal");
    obj.rec_criacao_animal:setHeight(50);
    obj.rec_criacao_animal:setColor("black");
    obj.rec_criacao_animal:setStrokeSize(2);
    obj.rec_criacao_animal:setStrokeColor("white");
    obj.rec_criacao_animal.grid.role = "col";
    obj.rec_criacao_animal.grid.width = 6;
    obj.rec_criacao_animal:setCornerType("round");
    obj.rec_criacao_animal:setXradius(5);
    obj.rec_criacao_animal:setYradius(5);
    obj.rec_criacao_animal:setMargins({top=10});

    obj.label90 = GUI.fromHandle(_obj_newObject("label"));
    obj.label90:setParent(obj.rec_criacao_animal);
    obj.label90:setText("Criação Animal");
    obj.label90:setHeight(50);
    obj.label90:setFontSize(18);
    obj.label90.grid.role = "col";
    obj.label90.grid.width = 8;
    obj.label90:setFontFamily("Wishes Script Caps Display");
    obj.label90:setHorzTextAlign("leading");
    obj.label90:setVertTextAlign("center");
    obj.label90:setMargins({left=10});
    obj.label90:setName("label90");

    obj.label91 = GUI.fromHandle(_obj_newObject("label"));
    obj.label91:setParent(obj.rec_criacao_animal);
    obj.label91:setField("nvt_criacao_animal");
    obj.label91.grid.role = "col";
    obj.label91.grid.width = 1;
    obj.label91:setHeight(50);
    obj.label91:setFontSize(12);
    obj.label91:setFontFamily("Wishes Script Caps Display");
    obj.label91:setHorzTextAlign("center");
    obj.label91:setVertTextAlign("center");
    obj.label91:setName("label91");

    obj.dataLink33 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink33:setParent(obj.rec_criacao_animal);
    obj.dataLink33:setField("nv_criacao_animal");
    obj.dataLink33:setName("dataLink33");

    obj.rectangle82 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle82:setParent(obj.rec_criacao_animal);
    obj.rectangle82:setHeight(40);
    obj.rectangle82:setColor("black");
    obj.rectangle82:setStrokeSize(2);
    obj.rectangle82:setStrokeColor("white");
    obj.rectangle82.grid.role = "col";
    obj.rectangle82.grid.width = 3;
    obj.rectangle82:setCornerType("round");
    obj.rectangle82:setXradius(5);
    obj.rectangle82:setYradius(5);
    obj.rectangle82:setMargins({top=4,right=4,bottom=4});
    obj.rectangle82:setName("rectangle82");

    obj.label92 = GUI.fromHandle(_obj_newObject("label"));
    obj.label92:setParent(obj.rectangle82);
    obj.label92:setField("mod_criacao_animal");
    obj.label92.grid.role = "col";
    obj.label92.grid.width = 12;
    obj.label92:setHeight(22);
    obj.label92:setFontSize(20);
    obj.label92:setFontFamily("Wishes Script Caps Display");
    obj.label92:setHorzTextAlign("center");
    obj.label92:setVertTextAlign("leading");
    obj.label92:setName("label92");

    obj.dataLink34 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink34:setParent(obj.rectangle82);
    obj.dataLink34:setField("mod_criacao_animal");
    obj.dataLink34:setDefaultValue("+0");
    obj.dataLink34:setName("dataLink34");

    obj.button6 = GUI.fromHandle(_obj_newObject("button"));
    obj.button6:setParent(obj.rectangle82);
    obj.button6:setText("Mais");
    obj.button6.grid.role = "col";
    obj.button6.grid.width = 12;
    obj.button6:setHeight(15);
    obj.button6:setFontSize(11);
    obj.button6:setFontFamily("Wishes Script Caps Display");
    obj.button6:setHorzTextAlign("center");
    obj.button6:setVertTextAlign("center");
    obj.button6:setMargins({left=3,right=3});
    obj.button6:setName("button6");

    obj.dataLink35 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink35:setParent(obj.scrollBox4);
    obj.dataLink35:setField("maestria_criacao_animal");
    obj.dataLink35:setName("dataLink35");

    obj.detalhes_criacao_animal = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_criacao_animal:setParent(obj.scrollBox4);
    obj.detalhes_criacao_animal:setName("detalhes_criacao_animal");
    obj.detalhes_criacao_animal:setWidth(400);
    obj.detalhes_criacao_animal:setHeight(600);
    obj.detalhes_criacao_animal:setLeft(0);
    obj.detalhes_criacao_animal:setBackOpacity(0.4);

    obj.rectangle83 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle83:setParent(obj.detalhes_criacao_animal);
    obj.rectangle83:setColor("black");
    obj.rectangle83:setLeft(-5);
    obj.rectangle83:setTop(-5);
    obj.rectangle83:setWidth(410);
    obj.rectangle83:setHeight(610);
    obj.rectangle83:setName("rectangle83");

    obj.rectangle84 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle84:setParent(obj.detalhes_criacao_animal);
    obj.rectangle84:setColor("#150e16");
    obj.rectangle84:setStrokeSize(2);
    obj.rectangle84:setStrokeColor("white");
    obj.rectangle84:setLeft(5);
    obj.rectangle84:setTop(5);
    obj.rectangle84:setWidth(390);
    obj.rectangle84:setHeight(590);
    obj.rectangle84:setCornerType("round");
    obj.rectangle84:setXradius(5);
    obj.rectangle84:setYradius(5);
    obj.rectangle84:setName("rectangle84");

    obj.label93 = GUI.fromHandle(_obj_newObject("label"));
    obj.label93:setParent(obj.detalhes_criacao_animal);
    obj.label93:setText("Criação Animal");
    obj.label93:setHeight(30);
    obj.label93:setFontSize(25);
    obj.label93.grid.role = "col";
    obj.label93.grid.width = 12;
    obj.label93:setFontFamily("Wishes Script Caps Display");
    obj.label93:setHorzTextAlign("center");
    obj.label93:setVertTextAlign("center");
    obj.label93:setMargins({top=10});
    obj.label93:setName("label93");

    obj.image8 = GUI.fromHandle(_obj_newObject("image"));
    obj.image8:setParent(obj.detalhes_criacao_animal);
    obj.image8.animate = true;
    obj.image8:setField("icone_criacao_animal");
    obj.image8:setStyle("proportional");
    obj.image8.grid.role = "col";
    obj.image8.grid.width = 12;
    obj.image8:setHeight(200);
    obj.image8:setMargins({top=10});
    obj.image8:setURL("https://64.media.tumblr.com/8f19e8ac9cb7a1d8273960a75b85e47c/tumblr_mqr3cza8tw1rdvsijo1_500.gif");
    obj.image8:setName("image8");

    obj.label94 = GUI.fromHandle(_obj_newObject("label"));
    obj.label94:setParent(obj.detalhes_criacao_animal);
    obj.label94:setText("Maestria:");
    obj.label94.grid.role = "col";
    obj.label94.grid.width = 6;
    obj.label94:setHeight(20);
    obj.label94:setFontSize(12);
    obj.label94:setFontFamily("Wishes Script Caps Display");
    obj.label94:setMargins({top=5});
    obj.label94:setName("label94");

    obj.label95 = GUI.fromHandle(_obj_newObject("label"));
    obj.label95:setParent(obj.detalhes_criacao_animal);
    obj.label95:setText("Nível:");
    obj.label95.grid.role = "col";
    obj.label95.grid.width = 3;
    obj.label95:setHeight(20);
    obj.label95:setFontSize(12);
    obj.label95:setFontFamily("Wishes Script Caps Display");
    obj.label95:setMargins({top=5});
    obj.label95:setName("label95");

    obj.label96 = GUI.fromHandle(_obj_newObject("label"));
    obj.label96:setParent(obj.detalhes_criacao_animal);
    obj.label96:setText("Mod:");
    obj.label96.grid.role = "col";
    obj.label96.grid.width = 3;
    obj.label96:setHeight(20);
    obj.label96:setFontSize(12);
    obj.label96:setFontFamily("Wishes Script Caps Display");
    obj.label96:setMargins({top=5});
    obj.label96:setName("label96");

    obj.rectangle85 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle85:setParent(obj.detalhes_criacao_animal);
    obj.rectangle85:setHeight(25);
    obj.rectangle85:setColor("black");
    obj.rectangle85.grid.role = "col";
    obj.rectangle85.grid.width = 6;
    obj.rectangle85:setStrokeSize(1);
    obj.rectangle85:setStrokeColor("white");
    obj.rectangle85:setCornerType("round");
    obj.rectangle85:setXradius(5);
    obj.rectangle85:setYradius(5);
    obj.rectangle85:setName("rectangle85");

    obj.comboBox8 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox8:setParent(obj.rectangle85);
    obj.comboBox8:setField("maestria_criacao_animal");
    obj.comboBox8.grid.role = "col";
    obj.comboBox8.grid.width = 12;
    obj.comboBox8:setHeight(30);
    obj.comboBox8:setFontFamily("Wishes Script Caps Display");
    obj.comboBox8:setTransparent(true);
    obj.comboBox8:setFontSize(20);
    obj.comboBox8:setHorzTextAlign("center");
    obj.comboBox8:setVertTextAlign("center");
    obj.comboBox8:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox8:setName("comboBox8");

    obj.rectangle86 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle86:setParent(obj.detalhes_criacao_animal);
    obj.rectangle86:setHeight(25);
    obj.rectangle86:setColor("black");
    obj.rectangle86.grid.role = "col";
    obj.rectangle86.grid.width = 3;
    obj.rectangle86:setStrokeSize(1);
    obj.rectangle86:setStrokeColor("white");
    obj.rectangle86:setCornerType("round");
    obj.rectangle86:setXradius(5);
    obj.rectangle86:setYradius(5);
    obj.rectangle86:setName("rectangle86");

    obj.edit73 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit73:setParent(obj.rectangle86);
    obj.edit73:setField("nv_criacao_animal");
    obj.edit73.grid.role = "col";
    obj.edit73.grid.width = 12;
    obj.edit73:setHeight(30);
    obj.edit73:setFontFamily("Wishes Script Caps Display");
    obj.edit73:setTransparent(true);
    obj.edit73:setFontSize(20);
    obj.edit73:setHorzTextAlign("center");
    obj.edit73:setVertTextAlign("center");
    obj.edit73:setName("edit73");

    obj.rectangle87 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle87:setParent(obj.detalhes_criacao_animal);
    obj.rectangle87:setHeight(25);
    obj.rectangle87:setColor("black");
    obj.rectangle87.grid.role = "col";
    obj.rectangle87.grid.width = 3;
    obj.rectangle87:setStrokeSize(1);
    obj.rectangle87:setStrokeColor("white");
    obj.rectangle87:setCornerType("round");
    obj.rectangle87:setXradius(5);
    obj.rectangle87:setYradius(5);
    obj.rectangle87:setName("rectangle87");

    obj.edit74 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit74:setParent(obj.rectangle87);
    obj.edit74:setField("mod_criacao_animal");
    obj.edit74.grid.role = "col";
    obj.edit74.grid.width = 12;
    obj.edit74:setHeight(30);
    obj.edit74:setFontFamily("Wishes Script Caps Display");
    obj.edit74:setTransparent(true);
    obj.edit74:setFontSize(20);
    obj.edit74:setHorzTextAlign("center");
    obj.edit74:setVertTextAlign("center");
    obj.edit74:setName("edit74");

    obj.label97 = GUI.fromHandle(_obj_newObject("label"));
    obj.label97:setParent(obj.detalhes_criacao_animal);
    obj.label97:setText("Limite:");
    obj.label97.grid.role = "col";
    obj.label97.grid.width = 9;
    obj.label97:setHeight(20);
    obj.label97:setFontSize(12);
    obj.label97:setFontFamily("Wishes Script Caps Display");
    obj.label97:setMargins({top=5});
    obj.label97:setName("label97");

    obj.label98 = GUI.fromHandle(_obj_newObject("label"));
    obj.label98:setParent(obj.detalhes_criacao_animal);
    obj.label98:setText("Extra:");
    obj.label98.grid.role = "col";
    obj.label98.grid.width = 3;
    obj.label98:setHeight(20);
    obj.label98:setFontSize(12);
    obj.label98:setFontFamily("Wishes Script Caps Display");
    obj.label98:setMargins({top=5});
    obj.label98:setName("label98");

    obj.rectangle88 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle88:setParent(obj.detalhes_criacao_animal);
    obj.rectangle88:setHeight(25);
    obj.rectangle88:setColor("black");
    obj.rectangle88.grid.role = "col";
    obj.rectangle88.grid.width = 9;
    obj.rectangle88:setStrokeSize(1);
    obj.rectangle88:setStrokeColor("white");
    obj.rectangle88:setCornerType("round");
    obj.rectangle88:setName("rectangle88");

    obj.edit75 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit75:setParent(obj.rectangle88);
    obj.edit75:setField("limite_criacao_animal");
    obj.edit75.grid.role = "col";
    obj.edit75.grid.width = 12;
    obj.edit75:setHeight(30);
    obj.edit75:setFontFamily("Wishes Script Caps Display");
    obj.edit75:setReadOnly(true);
    obj.edit75:setTransparent(true);
    obj.edit75:setFontSize(20);
    obj.edit75:setHorzTextAlign("center");
    obj.edit75:setVertTextAlign("center");
    obj.edit75:setName("edit75");

    obj.rectangle89 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle89:setParent(obj.detalhes_criacao_animal);
    obj.rectangle89:setHeight(25);
    obj.rectangle89:setColor("black");
    obj.rectangle89.grid.role = "col";
    obj.rectangle89.grid.width = 3;
    obj.rectangle89:setStrokeSize(1);
    obj.rectangle89:setStrokeColor("white");
    obj.rectangle89:setCornerType("round");
    obj.rectangle89:setName("rectangle89");

    obj.edit76 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit76:setParent(obj.rectangle89);
    obj.edit76:setField("extra_criacao_animal");
    obj.edit76.grid.role = "col";
    obj.edit76.grid.width = 12;
    obj.edit76:setHeight(30);
    obj.edit76:setFontFamily("Wishes Script Caps Display");
    obj.edit76:setTransparent(true);
    obj.edit76:setFontSize(20);
    obj.edit76:setHorzTextAlign("center");
    obj.edit76:setVertTextAlign("center");
    obj.edit76:setName("edit76");

    obj.label99 = GUI.fromHandle(_obj_newObject("label"));
    obj.label99:setParent(obj.detalhes_criacao_animal);
    obj.label99:setText("Descrição:");
    obj.label99.grid.role = "col";
    obj.label99.grid.width = 12;
    obj.label99:setHeight(20);
    obj.label99:setFontSize(12);
    obj.label99:setFontFamily("Wishes Script Caps Display");
    obj.label99:setMargins({top=5});
    obj.label99:setName("label99");

    obj.rectangle90 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle90:setParent(obj.detalhes_criacao_animal);
    obj.rectangle90:setHeight(100);
    obj.rectangle90:setColor("black");
    obj.rectangle90.grid.role = "col";
    obj.rectangle90.grid.width = 12;
    obj.rectangle90:setStrokeSize(1);
    obj.rectangle90:setStrokeColor("white");
    obj.rectangle90:setCornerType("round");
    obj.rectangle90:setName("rectangle90");

    obj.textEditor18 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor18:setParent(obj.rectangle90);
    obj.textEditor18:setAlign("client");
    obj.textEditor18:setField("descricao_criacao_animal");
    obj.textEditor18:setTransparent(true);
    obj.textEditor18:setReadOnly(true);
    obj.textEditor18:setName("textEditor18");

    obj.label100 = GUI.fromHandle(_obj_newObject("label"));
    obj.label100:setParent(obj.detalhes_criacao_animal);
    obj.label100:setText("Progressão:");
    obj.label100.grid.role = "col";
    obj.label100.grid.width = 12;
    obj.label100:setHeight(20);
    obj.label100:setFontSize(12);
    obj.label100:setFontFamily("Wishes Script Caps Display");
    obj.label100:setMargins({top=5});
    obj.label100:setName("label100");

    obj.rectangle91 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle91:setParent(obj.detalhes_criacao_animal);
    obj.rectangle91:setHeight(80);
    obj.rectangle91:setColor("black");
    obj.rectangle91.grid.role = "col";
    obj.rectangle91.grid.width = 12;
    obj.rectangle91:setStrokeSize(1);
    obj.rectangle91:setStrokeColor("white");
    obj.rectangle91:setCornerType("round");
    obj.rectangle91:setName("rectangle91");

    obj.textEditor19 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor19:setParent(obj.rectangle91);
    obj.textEditor19:setAlign("client");
    obj.textEditor19:setField("progressao_criacao_animal");
    obj.textEditor19:setTransparent(true);
    obj.textEditor19:setReadOnly(true);
    obj.textEditor19:setName("textEditor19");

    obj.rec_culinaria = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_culinaria:setParent(obj.scrollBox4);
    obj.rec_culinaria:setName("rec_culinaria");
    obj.rec_culinaria:setHeight(50);
    obj.rec_culinaria:setColor("black");
    obj.rec_culinaria:setStrokeSize(2);
    obj.rec_culinaria:setStrokeColor("white");
    obj.rec_culinaria.grid.role = "col";
    obj.rec_culinaria.grid.width = 6;
    obj.rec_culinaria:setCornerType("round");
    obj.rec_culinaria:setXradius(5);
    obj.rec_culinaria:setYradius(5);
    obj.rec_culinaria:setMargins({top=10});

    obj.label101 = GUI.fromHandle(_obj_newObject("label"));
    obj.label101:setParent(obj.rec_culinaria);
    obj.label101:setText("Culinária");
    obj.label101:setHeight(50);
    obj.label101:setFontSize(18);
    obj.label101.grid.role = "col";
    obj.label101.grid.width = 8;
    obj.label101:setFontFamily("Wishes Script Caps Display");
    obj.label101:setHorzTextAlign("leading");
    obj.label101:setVertTextAlign("center");
    obj.label101:setMargins({left=10});
    obj.label101:setName("label101");

    obj.label102 = GUI.fromHandle(_obj_newObject("label"));
    obj.label102:setParent(obj.rec_culinaria);
    obj.label102:setField("nvt_culinaria");
    obj.label102.grid.role = "col";
    obj.label102.grid.width = 1;
    obj.label102:setHeight(50);
    obj.label102:setFontSize(12);
    obj.label102:setFontFamily("Wishes Script Caps Display");
    obj.label102:setHorzTextAlign("center");
    obj.label102:setVertTextAlign("center");
    obj.label102:setName("label102");

    obj.dataLink36 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink36:setParent(obj.rec_culinaria);
    obj.dataLink36:setField("nv_culinaria");
    obj.dataLink36:setName("dataLink36");

    obj.rectangle92 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle92:setParent(obj.rec_culinaria);
    obj.rectangle92:setHeight(40);
    obj.rectangle92:setColor("black");
    obj.rectangle92:setStrokeSize(2);
    obj.rectangle92:setStrokeColor("white");
    obj.rectangle92.grid.role = "col";
    obj.rectangle92.grid.width = 3;
    obj.rectangle92:setCornerType("round");
    obj.rectangle92:setXradius(5);
    obj.rectangle92:setYradius(5);
    obj.rectangle92:setMargins({top=4,right=4,bottom=4});
    obj.rectangle92:setName("rectangle92");

    obj.label103 = GUI.fromHandle(_obj_newObject("label"));
    obj.label103:setParent(obj.rectangle92);
    obj.label103:setField("mod_culinaria");
    obj.label103.grid.role = "col";
    obj.label103.grid.width = 12;
    obj.label103:setHeight(22);
    obj.label103:setFontSize(20);
    obj.label103:setFontFamily("Wishes Script Caps Display");
    obj.label103:setHorzTextAlign("center");
    obj.label103:setVertTextAlign("leading");
    obj.label103:setName("label103");

    obj.dataLink37 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink37:setParent(obj.rectangle92);
    obj.dataLink37:setField("mod_culinaria");
    obj.dataLink37:setDefaultValue("+0");
    obj.dataLink37:setName("dataLink37");

    obj.button7 = GUI.fromHandle(_obj_newObject("button"));
    obj.button7:setParent(obj.rectangle92);
    obj.button7:setText("Mais");
    obj.button7.grid.role = "col";
    obj.button7.grid.width = 12;
    obj.button7:setHeight(15);
    obj.button7:setFontSize(11);
    obj.button7:setFontFamily("Wishes Script Caps Display");
    obj.button7:setHorzTextAlign("center");
    obj.button7:setVertTextAlign("center");
    obj.button7:setMargins({left=3,right=3});
    obj.button7:setName("button7");

    obj.dataLink38 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink38:setParent(obj.scrollBox4);
    obj.dataLink38:setField("maestria_culinaria");
    obj.dataLink38:setName("dataLink38");

    obj.detalhes_culinaria = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_culinaria:setParent(obj.scrollBox4);
    obj.detalhes_culinaria:setName("detalhes_culinaria");
    obj.detalhes_culinaria:setWidth(400);
    obj.detalhes_culinaria:setHeight(600);
    obj.detalhes_culinaria:setLeft(0);
    obj.detalhes_culinaria:setBackOpacity(0.4);

    obj.rectangle93 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle93:setParent(obj.detalhes_culinaria);
    obj.rectangle93:setColor("black");
    obj.rectangle93:setLeft(-5);
    obj.rectangle93:setTop(-5);
    obj.rectangle93:setWidth(410);
    obj.rectangle93:setHeight(610);
    obj.rectangle93:setName("rectangle93");

    obj.rectangle94 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle94:setParent(obj.detalhes_culinaria);
    obj.rectangle94:setColor("#150e16");
    obj.rectangle94:setStrokeSize(2);
    obj.rectangle94:setStrokeColor("white");
    obj.rectangle94:setLeft(5);
    obj.rectangle94:setTop(5);
    obj.rectangle94:setWidth(390);
    obj.rectangle94:setHeight(590);
    obj.rectangle94:setCornerType("round");
    obj.rectangle94:setXradius(5);
    obj.rectangle94:setYradius(5);
    obj.rectangle94:setName("rectangle94");

    obj.label104 = GUI.fromHandle(_obj_newObject("label"));
    obj.label104:setParent(obj.detalhes_culinaria);
    obj.label104:setText("Culinária");
    obj.label104:setHeight(30);
    obj.label104:setFontSize(25);
    obj.label104.grid.role = "col";
    obj.label104.grid.width = 12;
    obj.label104:setFontFamily("Wishes Script Caps Display");
    obj.label104:setHorzTextAlign("center");
    obj.label104:setVertTextAlign("center");
    obj.label104:setMargins({top=10});
    obj.label104:setName("label104");

    obj.image9 = GUI.fromHandle(_obj_newObject("image"));
    obj.image9:setParent(obj.detalhes_culinaria);
    obj.image9.animate = true;
    obj.image9:setField("icone_culinaria");
    obj.image9:setStyle("proportional");
    obj.image9.grid.role = "col";
    obj.image9.grid.width = 12;
    obj.image9:setHeight(200);
    obj.image9:setMargins({top=10});
    obj.image9:setURL("https://media1.tenor.com/m/z-k63cEg48sAAAAd/sanji-cooking.gif");
    obj.image9:setName("image9");

    obj.label105 = GUI.fromHandle(_obj_newObject("label"));
    obj.label105:setParent(obj.detalhes_culinaria);
    obj.label105:setText("Maestria:");
    obj.label105.grid.role = "col";
    obj.label105.grid.width = 6;
    obj.label105:setHeight(20);
    obj.label105:setFontSize(12);
    obj.label105:setFontFamily("Wishes Script Caps Display");
    obj.label105:setMargins({top=5});
    obj.label105:setName("label105");

    obj.label106 = GUI.fromHandle(_obj_newObject("label"));
    obj.label106:setParent(obj.detalhes_culinaria);
    obj.label106:setText("Nível:");
    obj.label106.grid.role = "col";
    obj.label106.grid.width = 3;
    obj.label106:setHeight(20);
    obj.label106:setFontSize(12);
    obj.label106:setFontFamily("Wishes Script Caps Display");
    obj.label106:setMargins({top=5});
    obj.label106:setName("label106");

    obj.label107 = GUI.fromHandle(_obj_newObject("label"));
    obj.label107:setParent(obj.detalhes_culinaria);
    obj.label107:setText("Mod:");
    obj.label107.grid.role = "col";
    obj.label107.grid.width = 3;
    obj.label107:setHeight(20);
    obj.label107:setFontSize(12);
    obj.label107:setFontFamily("Wishes Script Caps Display");
    obj.label107:setMargins({top=5});
    obj.label107:setName("label107");

    obj.rectangle95 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle95:setParent(obj.detalhes_culinaria);
    obj.rectangle95:setHeight(25);
    obj.rectangle95:setColor("black");
    obj.rectangle95.grid.role = "col";
    obj.rectangle95.grid.width = 6;
    obj.rectangle95:setStrokeSize(1);
    obj.rectangle95:setStrokeColor("white");
    obj.rectangle95:setCornerType("round");
    obj.rectangle95:setXradius(5);
    obj.rectangle95:setYradius(5);
    obj.rectangle95:setName("rectangle95");

    obj.comboBox9 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox9:setParent(obj.rectangle95);
    obj.comboBox9:setField("maestria_culinaria");
    obj.comboBox9.grid.role = "col";
    obj.comboBox9.grid.width = 12;
    obj.comboBox9:setHeight(30);
    obj.comboBox9:setFontFamily("Wishes Script Caps Display");
    obj.comboBox9:setTransparent(true);
    obj.comboBox9:setFontSize(20);
    obj.comboBox9:setHorzTextAlign("center");
    obj.comboBox9:setVertTextAlign("center");
    obj.comboBox9:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox9:setName("comboBox9");

    obj.rectangle96 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle96:setParent(obj.detalhes_culinaria);
    obj.rectangle96:setHeight(25);
    obj.rectangle96:setColor("black");
    obj.rectangle96.grid.role = "col";
    obj.rectangle96.grid.width = 3;
    obj.rectangle96:setStrokeSize(1);
    obj.rectangle96:setStrokeColor("white");
    obj.rectangle96:setCornerType("round");
    obj.rectangle96:setXradius(5);
    obj.rectangle96:setYradius(5);
    obj.rectangle96:setName("rectangle96");

    obj.edit77 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit77:setParent(obj.rectangle96);
    obj.edit77:setField("nv_culinaria");
    obj.edit77.grid.role = "col";
    obj.edit77.grid.width = 12;
    obj.edit77:setHeight(30);
    obj.edit77:setFontFamily("Wishes Script Caps Display");
    obj.edit77:setTransparent(true);
    obj.edit77:setFontSize(20);
    obj.edit77:setHorzTextAlign("center");
    obj.edit77:setVertTextAlign("center");
    obj.edit77:setName("edit77");

    obj.rectangle97 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle97:setParent(obj.detalhes_culinaria);
    obj.rectangle97:setHeight(25);
    obj.rectangle97:setColor("black");
    obj.rectangle97.grid.role = "col";
    obj.rectangle97.grid.width = 3;
    obj.rectangle97:setStrokeSize(1);
    obj.rectangle97:setStrokeColor("white");
    obj.rectangle97:setCornerType("round");
    obj.rectangle97:setXradius(5);
    obj.rectangle97:setYradius(5);
    obj.rectangle97:setName("rectangle97");

    obj.edit78 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit78:setParent(obj.rectangle97);
    obj.edit78:setField("mod_culinaria");
    obj.edit78.grid.role = "col";
    obj.edit78.grid.width = 12;
    obj.edit78:setHeight(30);
    obj.edit78:setFontFamily("Wishes Script Caps Display");
    obj.edit78:setTransparent(true);
    obj.edit78:setFontSize(20);
    obj.edit78:setHorzTextAlign("center");
    obj.edit78:setVertTextAlign("center");
    obj.edit78:setName("edit78");

    obj.label108 = GUI.fromHandle(_obj_newObject("label"));
    obj.label108:setParent(obj.detalhes_culinaria);
    obj.label108:setText("Limite:");
    obj.label108.grid.role = "col";
    obj.label108.grid.width = 9;
    obj.label108:setHeight(20);
    obj.label108:setFontSize(12);
    obj.label108:setFontFamily("Wishes Script Caps Display");
    obj.label108:setMargins({top=5});
    obj.label108:setName("label108");

    obj.label109 = GUI.fromHandle(_obj_newObject("label"));
    obj.label109:setParent(obj.detalhes_culinaria);
    obj.label109:setText("Extra:");
    obj.label109.grid.role = "col";
    obj.label109.grid.width = 3;
    obj.label109:setHeight(20);
    obj.label109:setFontSize(12);
    obj.label109:setFontFamily("Wishes Script Caps Display");
    obj.label109:setMargins({top=5});
    obj.label109:setName("label109");

    obj.rectangle98 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle98:setParent(obj.detalhes_culinaria);
    obj.rectangle98:setHeight(25);
    obj.rectangle98:setColor("black");
    obj.rectangle98.grid.role = "col";
    obj.rectangle98.grid.width = 9;
    obj.rectangle98:setStrokeSize(1);
    obj.rectangle98:setStrokeColor("white");
    obj.rectangle98:setCornerType("round");
    obj.rectangle98:setName("rectangle98");

    obj.edit79 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit79:setParent(obj.rectangle98);
    obj.edit79:setField("limite_culinaria");
    obj.edit79.grid.role = "col";
    obj.edit79.grid.width = 12;
    obj.edit79:setHeight(30);
    obj.edit79:setFontFamily("Wishes Script Caps Display");
    obj.edit79:setReadOnly(true);
    obj.edit79:setTransparent(true);
    obj.edit79:setFontSize(20);
    obj.edit79:setHorzTextAlign("center");
    obj.edit79:setVertTextAlign("center");
    obj.edit79:setName("edit79");

    obj.rectangle99 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle99:setParent(obj.detalhes_culinaria);
    obj.rectangle99:setHeight(25);
    obj.rectangle99:setColor("black");
    obj.rectangle99.grid.role = "col";
    obj.rectangle99.grid.width = 3;
    obj.rectangle99:setStrokeSize(1);
    obj.rectangle99:setStrokeColor("white");
    obj.rectangle99:setCornerType("round");
    obj.rectangle99:setName("rectangle99");

    obj.edit80 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit80:setParent(obj.rectangle99);
    obj.edit80:setField("extra_culinaria");
    obj.edit80.grid.role = "col";
    obj.edit80.grid.width = 12;
    obj.edit80:setHeight(30);
    obj.edit80:setFontFamily("Wishes Script Caps Display");
    obj.edit80:setTransparent(true);
    obj.edit80:setFontSize(20);
    obj.edit80:setHorzTextAlign("center");
    obj.edit80:setVertTextAlign("center");
    obj.edit80:setName("edit80");

    obj.label110 = GUI.fromHandle(_obj_newObject("label"));
    obj.label110:setParent(obj.detalhes_culinaria);
    obj.label110:setText("Descrição:");
    obj.label110.grid.role = "col";
    obj.label110.grid.width = 12;
    obj.label110:setHeight(20);
    obj.label110:setFontSize(12);
    obj.label110:setFontFamily("Wishes Script Caps Display");
    obj.label110:setMargins({top=5});
    obj.label110:setName("label110");

    obj.rectangle100 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle100:setParent(obj.detalhes_culinaria);
    obj.rectangle100:setHeight(100);
    obj.rectangle100:setColor("black");
    obj.rectangle100.grid.role = "col";
    obj.rectangle100.grid.width = 12;
    obj.rectangle100:setStrokeSize(1);
    obj.rectangle100:setStrokeColor("white");
    obj.rectangle100:setCornerType("round");
    obj.rectangle100:setName("rectangle100");

    obj.textEditor20 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor20:setParent(obj.rectangle100);
    obj.textEditor20:setAlign("client");
    obj.textEditor20:setField("descricao_culinaria");
    obj.textEditor20:setTransparent(true);
    obj.textEditor20:setReadOnly(true);
    obj.textEditor20:setName("textEditor20");

    obj.label111 = GUI.fromHandle(_obj_newObject("label"));
    obj.label111:setParent(obj.detalhes_culinaria);
    obj.label111:setText("Progressão:");
    obj.label111.grid.role = "col";
    obj.label111.grid.width = 12;
    obj.label111:setHeight(20);
    obj.label111:setFontSize(12);
    obj.label111:setFontFamily("Wishes Script Caps Display");
    obj.label111:setMargins({top=5});
    obj.label111:setName("label111");

    obj.rectangle101 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle101:setParent(obj.detalhes_culinaria);
    obj.rectangle101:setHeight(80);
    obj.rectangle101:setColor("black");
    obj.rectangle101.grid.role = "col";
    obj.rectangle101.grid.width = 12;
    obj.rectangle101:setStrokeSize(1);
    obj.rectangle101:setStrokeColor("white");
    obj.rectangle101:setCornerType("round");
    obj.rectangle101:setName("rectangle101");

    obj.textEditor21 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor21:setParent(obj.rectangle101);
    obj.textEditor21:setAlign("client");
    obj.textEditor21:setField("progressao_culinaria");
    obj.textEditor21:setTransparent(true);
    obj.textEditor21:setReadOnly(true);
    obj.textEditor21:setName("textEditor21");

    obj.rec_ecomorfia = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_ecomorfia:setParent(obj.scrollBox4);
    obj.rec_ecomorfia:setName("rec_ecomorfia");
    obj.rec_ecomorfia:setHeight(50);
    obj.rec_ecomorfia:setColor("black");
    obj.rec_ecomorfia:setStrokeSize(2);
    obj.rec_ecomorfia:setStrokeColor("white");
    obj.rec_ecomorfia.grid.role = "col";
    obj.rec_ecomorfia.grid.width = 6;
    obj.rec_ecomorfia:setCornerType("round");
    obj.rec_ecomorfia:setXradius(5);
    obj.rec_ecomorfia:setYradius(5);
    obj.rec_ecomorfia:setMargins({top=10});

    obj.label112 = GUI.fromHandle(_obj_newObject("label"));
    obj.label112:setParent(obj.rec_ecomorfia);
    obj.label112:setText("Ecomorfia");
    obj.label112:setHeight(50);
    obj.label112:setFontSize(18);
    obj.label112.grid.role = "col";
    obj.label112.grid.width = 8;
    obj.label112:setFontFamily("Wishes Script Caps Display");
    obj.label112:setHorzTextAlign("leading");
    obj.label112:setVertTextAlign("center");
    obj.label112:setMargins({left=10});
    obj.label112:setName("label112");

    obj.label113 = GUI.fromHandle(_obj_newObject("label"));
    obj.label113:setParent(obj.rec_ecomorfia);
    obj.label113:setField("nvt_ecomorfia");
    obj.label113.grid.role = "col";
    obj.label113.grid.width = 1;
    obj.label113:setHeight(50);
    obj.label113:setFontSize(12);
    obj.label113:setFontFamily("Wishes Script Caps Display");
    obj.label113:setHorzTextAlign("center");
    obj.label113:setVertTextAlign("center");
    obj.label113:setName("label113");

    obj.dataLink39 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink39:setParent(obj.rec_ecomorfia);
    obj.dataLink39:setField("nv_ecomorfia");
    obj.dataLink39:setName("dataLink39");

    obj.rectangle102 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle102:setParent(obj.rec_ecomorfia);
    obj.rectangle102:setHeight(40);
    obj.rectangle102:setColor("black");
    obj.rectangle102:setStrokeSize(2);
    obj.rectangle102:setStrokeColor("white");
    obj.rectangle102.grid.role = "col";
    obj.rectangle102.grid.width = 3;
    obj.rectangle102:setCornerType("round");
    obj.rectangle102:setXradius(5);
    obj.rectangle102:setYradius(5);
    obj.rectangle102:setMargins({top=4,right=4,bottom=4});
    obj.rectangle102:setName("rectangle102");

    obj.label114 = GUI.fromHandle(_obj_newObject("label"));
    obj.label114:setParent(obj.rectangle102);
    obj.label114:setField("mod_ecomorfia");
    obj.label114.grid.role = "col";
    obj.label114.grid.width = 12;
    obj.label114:setHeight(22);
    obj.label114:setFontSize(20);
    obj.label114:setFontFamily("Wishes Script Caps Display");
    obj.label114:setHorzTextAlign("center");
    obj.label114:setVertTextAlign("leading");
    obj.label114:setName("label114");

    obj.dataLink40 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink40:setParent(obj.rectangle102);
    obj.dataLink40:setField("mod_ecomorfia");
    obj.dataLink40:setDefaultValue("+0");
    obj.dataLink40:setName("dataLink40");

    obj.button8 = GUI.fromHandle(_obj_newObject("button"));
    obj.button8:setParent(obj.rectangle102);
    obj.button8:setText("Mais");
    obj.button8.grid.role = "col";
    obj.button8.grid.width = 12;
    obj.button8:setHeight(15);
    obj.button8:setFontSize(11);
    obj.button8:setFontFamily("Wishes Script Caps Display");
    obj.button8:setHorzTextAlign("center");
    obj.button8:setVertTextAlign("center");
    obj.button8:setMargins({left=3,right=3});
    obj.button8:setName("button8");

    obj.dataLink41 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink41:setParent(obj.scrollBox4);
    obj.dataLink41:setField("maestria_ecomorfia");
    obj.dataLink41:setName("dataLink41");

    obj.detalhes_ecomorfia = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_ecomorfia:setParent(obj.scrollBox4);
    obj.detalhes_ecomorfia:setName("detalhes_ecomorfia");
    obj.detalhes_ecomorfia:setWidth(400);
    obj.detalhes_ecomorfia:setHeight(600);
    obj.detalhes_ecomorfia:setLeft(0);
    obj.detalhes_ecomorfia:setBackOpacity(0.4);

    obj.rectangle103 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle103:setParent(obj.detalhes_ecomorfia);
    obj.rectangle103:setColor("black");
    obj.rectangle103:setLeft(-5);
    obj.rectangle103:setTop(-5);
    obj.rectangle103:setWidth(410);
    obj.rectangle103:setHeight(610);
    obj.rectangle103:setName("rectangle103");

    obj.rectangle104 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle104:setParent(obj.detalhes_ecomorfia);
    obj.rectangle104:setColor("#150e16");
    obj.rectangle104:setStrokeSize(2);
    obj.rectangle104:setStrokeColor("white");
    obj.rectangle104:setLeft(5);
    obj.rectangle104:setTop(5);
    obj.rectangle104:setWidth(390);
    obj.rectangle104:setHeight(590);
    obj.rectangle104:setCornerType("round");
    obj.rectangle104:setXradius(5);
    obj.rectangle104:setYradius(5);
    obj.rectangle104:setName("rectangle104");

    obj.label115 = GUI.fromHandle(_obj_newObject("label"));
    obj.label115:setParent(obj.detalhes_ecomorfia);
    obj.label115:setText("Ecomorfia");
    obj.label115:setHeight(30);
    obj.label115:setFontSize(25);
    obj.label115.grid.role = "col";
    obj.label115.grid.width = 12;
    obj.label115:setFontFamily("Wishes Script Caps Display");
    obj.label115:setHorzTextAlign("center");
    obj.label115:setVertTextAlign("center");
    obj.label115:setMargins({top=10});
    obj.label115:setName("label115");

    obj.image10 = GUI.fromHandle(_obj_newObject("image"));
    obj.image10:setParent(obj.detalhes_ecomorfia);
    obj.image10.animate = true;
    obj.image10:setField("icone_ecomorfia");
    obj.image10:setStyle("proportional");
    obj.image10.grid.role = "col";
    obj.image10.grid.width = 12;
    obj.image10:setHeight(200);
    obj.image10:setMargins({top=10});
    obj.image10:setURL("https://blob.firecast.com.br/blobs/CNSAFLKM_4300216/ecomorfia.gif");
    obj.image10:setName("image10");

    obj.label116 = GUI.fromHandle(_obj_newObject("label"));
    obj.label116:setParent(obj.detalhes_ecomorfia);
    obj.label116:setText("Maestria:");
    obj.label116.grid.role = "col";
    obj.label116.grid.width = 6;
    obj.label116:setHeight(20);
    obj.label116:setFontSize(12);
    obj.label116:setFontFamily("Wishes Script Caps Display");
    obj.label116:setMargins({top=5});
    obj.label116:setName("label116");

    obj.label117 = GUI.fromHandle(_obj_newObject("label"));
    obj.label117:setParent(obj.detalhes_ecomorfia);
    obj.label117:setText("Nível:");
    obj.label117.grid.role = "col";
    obj.label117.grid.width = 3;
    obj.label117:setHeight(20);
    obj.label117:setFontSize(12);
    obj.label117:setFontFamily("Wishes Script Caps Display");
    obj.label117:setMargins({top=5});
    obj.label117:setName("label117");

    obj.label118 = GUI.fromHandle(_obj_newObject("label"));
    obj.label118:setParent(obj.detalhes_ecomorfia);
    obj.label118:setText("Mod:");
    obj.label118.grid.role = "col";
    obj.label118.grid.width = 3;
    obj.label118:setHeight(20);
    obj.label118:setFontSize(12);
    obj.label118:setFontFamily("Wishes Script Caps Display");
    obj.label118:setMargins({top=5});
    obj.label118:setName("label118");

    obj.rectangle105 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle105:setParent(obj.detalhes_ecomorfia);
    obj.rectangle105:setHeight(25);
    obj.rectangle105:setColor("black");
    obj.rectangle105.grid.role = "col";
    obj.rectangle105.grid.width = 6;
    obj.rectangle105:setStrokeSize(1);
    obj.rectangle105:setStrokeColor("white");
    obj.rectangle105:setCornerType("round");
    obj.rectangle105:setXradius(5);
    obj.rectangle105:setYradius(5);
    obj.rectangle105:setName("rectangle105");

    obj.comboBox10 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox10:setParent(obj.rectangle105);
    obj.comboBox10:setField("maestria_ecomorfia");
    obj.comboBox10.grid.role = "col";
    obj.comboBox10.grid.width = 12;
    obj.comboBox10:setHeight(30);
    obj.comboBox10:setFontFamily("Wishes Script Caps Display");
    obj.comboBox10:setTransparent(true);
    obj.comboBox10:setFontSize(20);
    obj.comboBox10:setHorzTextAlign("center");
    obj.comboBox10:setVertTextAlign("center");
    obj.comboBox10:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox10:setName("comboBox10");

    obj.rectangle106 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle106:setParent(obj.detalhes_ecomorfia);
    obj.rectangle106:setHeight(25);
    obj.rectangle106:setColor("black");
    obj.rectangle106.grid.role = "col";
    obj.rectangle106.grid.width = 3;
    obj.rectangle106:setStrokeSize(1);
    obj.rectangle106:setStrokeColor("white");
    obj.rectangle106:setCornerType("round");
    obj.rectangle106:setXradius(5);
    obj.rectangle106:setYradius(5);
    obj.rectangle106:setName("rectangle106");

    obj.edit81 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit81:setParent(obj.rectangle106);
    obj.edit81:setField("nv_ecomorfia");
    obj.edit81.grid.role = "col";
    obj.edit81.grid.width = 12;
    obj.edit81:setHeight(30);
    obj.edit81:setFontFamily("Wishes Script Caps Display");
    obj.edit81:setTransparent(true);
    obj.edit81:setFontSize(20);
    obj.edit81:setHorzTextAlign("center");
    obj.edit81:setVertTextAlign("center");
    obj.edit81:setName("edit81");

    obj.rectangle107 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle107:setParent(obj.detalhes_ecomorfia);
    obj.rectangle107:setHeight(25);
    obj.rectangle107:setColor("black");
    obj.rectangle107.grid.role = "col";
    obj.rectangle107.grid.width = 3;
    obj.rectangle107:setStrokeSize(1);
    obj.rectangle107:setStrokeColor("white");
    obj.rectangle107:setCornerType("round");
    obj.rectangle107:setXradius(5);
    obj.rectangle107:setYradius(5);
    obj.rectangle107:setName("rectangle107");

    obj.edit82 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit82:setParent(obj.rectangle107);
    obj.edit82:setField("mod_ecomorfia");
    obj.edit82.grid.role = "col";
    obj.edit82.grid.width = 12;
    obj.edit82:setHeight(30);
    obj.edit82:setFontFamily("Wishes Script Caps Display");
    obj.edit82:setTransparent(true);
    obj.edit82:setFontSize(20);
    obj.edit82:setHorzTextAlign("center");
    obj.edit82:setVertTextAlign("center");
    obj.edit82:setName("edit82");

    obj.label119 = GUI.fromHandle(_obj_newObject("label"));
    obj.label119:setParent(obj.detalhes_ecomorfia);
    obj.label119:setText("Limite:");
    obj.label119.grid.role = "col";
    obj.label119.grid.width = 9;
    obj.label119:setHeight(20);
    obj.label119:setFontSize(12);
    obj.label119:setFontFamily("Wishes Script Caps Display");
    obj.label119:setMargins({top=5});
    obj.label119:setName("label119");

    obj.label120 = GUI.fromHandle(_obj_newObject("label"));
    obj.label120:setParent(obj.detalhes_ecomorfia);
    obj.label120:setText("Extra:");
    obj.label120.grid.role = "col";
    obj.label120.grid.width = 3;
    obj.label120:setHeight(20);
    obj.label120:setFontSize(12);
    obj.label120:setFontFamily("Wishes Script Caps Display");
    obj.label120:setMargins({top=5});
    obj.label120:setName("label120");

    obj.rectangle108 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle108:setParent(obj.detalhes_ecomorfia);
    obj.rectangle108:setHeight(25);
    obj.rectangle108:setColor("black");
    obj.rectangle108.grid.role = "col";
    obj.rectangle108.grid.width = 9;
    obj.rectangle108:setStrokeSize(1);
    obj.rectangle108:setStrokeColor("white");
    obj.rectangle108:setCornerType("round");
    obj.rectangle108:setName("rectangle108");

    obj.edit83 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit83:setParent(obj.rectangle108);
    obj.edit83:setField("limite_ecomorfia");
    obj.edit83.grid.role = "col";
    obj.edit83.grid.width = 12;
    obj.edit83:setHeight(30);
    obj.edit83:setFontFamily("Wishes Script Caps Display");
    obj.edit83:setReadOnly(true);
    obj.edit83:setTransparent(true);
    obj.edit83:setFontSize(20);
    obj.edit83:setHorzTextAlign("center");
    obj.edit83:setVertTextAlign("center");
    obj.edit83:setName("edit83");

    obj.rectangle109 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle109:setParent(obj.detalhes_ecomorfia);
    obj.rectangle109:setHeight(25);
    obj.rectangle109:setColor("black");
    obj.rectangle109.grid.role = "col";
    obj.rectangle109.grid.width = 3;
    obj.rectangle109:setStrokeSize(1);
    obj.rectangle109:setStrokeColor("white");
    obj.rectangle109:setCornerType("round");
    obj.rectangle109:setName("rectangle109");

    obj.edit84 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit84:setParent(obj.rectangle109);
    obj.edit84:setField("extra_ecomorfia");
    obj.edit84.grid.role = "col";
    obj.edit84.grid.width = 12;
    obj.edit84:setHeight(30);
    obj.edit84:setFontFamily("Wishes Script Caps Display");
    obj.edit84:setTransparent(true);
    obj.edit84:setFontSize(20);
    obj.edit84:setHorzTextAlign("center");
    obj.edit84:setVertTextAlign("center");
    obj.edit84:setName("edit84");

    obj.label121 = GUI.fromHandle(_obj_newObject("label"));
    obj.label121:setParent(obj.detalhes_ecomorfia);
    obj.label121:setText("Descrição:");
    obj.label121.grid.role = "col";
    obj.label121.grid.width = 12;
    obj.label121:setHeight(20);
    obj.label121:setFontSize(12);
    obj.label121:setFontFamily("Wishes Script Caps Display");
    obj.label121:setMargins({top=5});
    obj.label121:setName("label121");

    obj.rectangle110 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle110:setParent(obj.detalhes_ecomorfia);
    obj.rectangle110:setHeight(100);
    obj.rectangle110:setColor("black");
    obj.rectangle110.grid.role = "col";
    obj.rectangle110.grid.width = 12;
    obj.rectangle110:setStrokeSize(1);
    obj.rectangle110:setStrokeColor("white");
    obj.rectangle110:setCornerType("round");
    obj.rectangle110:setName("rectangle110");

    obj.textEditor22 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor22:setParent(obj.rectangle110);
    obj.textEditor22:setAlign("client");
    obj.textEditor22:setField("descricao_ecomorfia");
    obj.textEditor22:setTransparent(true);
    obj.textEditor22:setReadOnly(true);
    obj.textEditor22:setName("textEditor22");

    obj.label122 = GUI.fromHandle(_obj_newObject("label"));
    obj.label122:setParent(obj.detalhes_ecomorfia);
    obj.label122:setText("Progressão:");
    obj.label122.grid.role = "col";
    obj.label122.grid.width = 12;
    obj.label122:setHeight(20);
    obj.label122:setFontSize(12);
    obj.label122:setFontFamily("Wishes Script Caps Display");
    obj.label122:setMargins({top=5});
    obj.label122:setName("label122");

    obj.rectangle111 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle111:setParent(obj.detalhes_ecomorfia);
    obj.rectangle111:setHeight(80);
    obj.rectangle111:setColor("black");
    obj.rectangle111.grid.role = "col";
    obj.rectangle111.grid.width = 12;
    obj.rectangle111:setStrokeSize(1);
    obj.rectangle111:setStrokeColor("white");
    obj.rectangle111:setCornerType("round");
    obj.rectangle111:setName("rectangle111");

    obj.textEditor23 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor23:setParent(obj.rectangle111);
    obj.textEditor23:setAlign("client");
    obj.textEditor23:setField("progressao_ecomorfia");
    obj.textEditor23:setTransparent(true);
    obj.textEditor23:setReadOnly(true);
    obj.textEditor23:setName("textEditor23");

    obj.rec_forja = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_forja:setParent(obj.scrollBox4);
    obj.rec_forja:setName("rec_forja");
    obj.rec_forja:setHeight(50);
    obj.rec_forja:setColor("black");
    obj.rec_forja:setStrokeSize(2);
    obj.rec_forja:setStrokeColor("white");
    obj.rec_forja.grid.role = "col";
    obj.rec_forja.grid.width = 6;
    obj.rec_forja:setCornerType("round");
    obj.rec_forja:setXradius(5);
    obj.rec_forja:setYradius(5);
    obj.rec_forja:setMargins({top=10});

    obj.label123 = GUI.fromHandle(_obj_newObject("label"));
    obj.label123:setParent(obj.rec_forja);
    obj.label123:setText("Forja");
    obj.label123:setHeight(50);
    obj.label123:setFontSize(18);
    obj.label123.grid.role = "col";
    obj.label123.grid.width = 8;
    obj.label123:setFontFamily("Wishes Script Caps Display");
    obj.label123:setHorzTextAlign("leading");
    obj.label123:setVertTextAlign("center");
    obj.label123:setMargins({left=10});
    obj.label123:setName("label123");

    obj.label124 = GUI.fromHandle(_obj_newObject("label"));
    obj.label124:setParent(obj.rec_forja);
    obj.label124:setField("nvt_forja");
    obj.label124.grid.role = "col";
    obj.label124.grid.width = 1;
    obj.label124:setHeight(50);
    obj.label124:setFontSize(12);
    obj.label124:setFontFamily("Wishes Script Caps Display");
    obj.label124:setHorzTextAlign("center");
    obj.label124:setVertTextAlign("center");
    obj.label124:setName("label124");

    obj.dataLink42 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink42:setParent(obj.rec_forja);
    obj.dataLink42:setField("nv_forja");
    obj.dataLink42:setName("dataLink42");

    obj.rectangle112 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle112:setParent(obj.rec_forja);
    obj.rectangle112:setHeight(40);
    obj.rectangle112:setColor("black");
    obj.rectangle112:setStrokeSize(2);
    obj.rectangle112:setStrokeColor("white");
    obj.rectangle112.grid.role = "col";
    obj.rectangle112.grid.width = 3;
    obj.rectangle112:setCornerType("round");
    obj.rectangle112:setXradius(5);
    obj.rectangle112:setYradius(5);
    obj.rectangle112:setMargins({top=4,right=4,bottom=4});
    obj.rectangle112:setName("rectangle112");

    obj.label125 = GUI.fromHandle(_obj_newObject("label"));
    obj.label125:setParent(obj.rectangle112);
    obj.label125:setField("mod_forja");
    obj.label125.grid.role = "col";
    obj.label125.grid.width = 12;
    obj.label125:setHeight(22);
    obj.label125:setFontSize(20);
    obj.label125:setFontFamily("Wishes Script Caps Display");
    obj.label125:setHorzTextAlign("center");
    obj.label125:setVertTextAlign("leading");
    obj.label125:setName("label125");

    obj.dataLink43 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink43:setParent(obj.rectangle112);
    obj.dataLink43:setField("mod_forja");
    obj.dataLink43:setDefaultValue("+0");
    obj.dataLink43:setName("dataLink43");

    obj.button9 = GUI.fromHandle(_obj_newObject("button"));
    obj.button9:setParent(obj.rectangle112);
    obj.button9:setText("Mais");
    obj.button9.grid.role = "col";
    obj.button9.grid.width = 12;
    obj.button9:setHeight(15);
    obj.button9:setFontSize(11);
    obj.button9:setFontFamily("Wishes Script Caps Display");
    obj.button9:setHorzTextAlign("center");
    obj.button9:setVertTextAlign("center");
    obj.button9:setMargins({left=3,right=3});
    obj.button9:setName("button9");

    obj.dataLink44 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink44:setParent(obj.scrollBox4);
    obj.dataLink44:setField("maestria_forja");
    obj.dataLink44:setName("dataLink44");

    obj.detalhes_forja = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_forja:setParent(obj.scrollBox4);
    obj.detalhes_forja:setName("detalhes_forja");
    obj.detalhes_forja:setWidth(400);
    obj.detalhes_forja:setHeight(600);
    obj.detalhes_forja:setLeft(0);
    obj.detalhes_forja:setBackOpacity(0.4);

    obj.rectangle113 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle113:setParent(obj.detalhes_forja);
    obj.rectangle113:setColor("black");
    obj.rectangle113:setLeft(-5);
    obj.rectangle113:setTop(-5);
    obj.rectangle113:setWidth(410);
    obj.rectangle113:setHeight(610);
    obj.rectangle113:setName("rectangle113");

    obj.rectangle114 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle114:setParent(obj.detalhes_forja);
    obj.rectangle114:setColor("#150e16");
    obj.rectangle114:setStrokeSize(2);
    obj.rectangle114:setStrokeColor("white");
    obj.rectangle114:setLeft(5);
    obj.rectangle114:setTop(5);
    obj.rectangle114:setWidth(390);
    obj.rectangle114:setHeight(590);
    obj.rectangle114:setCornerType("round");
    obj.rectangle114:setXradius(5);
    obj.rectangle114:setYradius(5);
    obj.rectangle114:setName("rectangle114");

    obj.label126 = GUI.fromHandle(_obj_newObject("label"));
    obj.label126:setParent(obj.detalhes_forja);
    obj.label126:setText("Forja");
    obj.label126:setHeight(30);
    obj.label126:setFontSize(25);
    obj.label126.grid.role = "col";
    obj.label126.grid.width = 12;
    obj.label126:setFontFamily("Wishes Script Caps Display");
    obj.label126:setHorzTextAlign("center");
    obj.label126:setVertTextAlign("center");
    obj.label126:setMargins({top=10});
    obj.label126:setName("label126");

    obj.image11 = GUI.fromHandle(_obj_newObject("image"));
    obj.image11:setParent(obj.detalhes_forja);
    obj.image11.animate = true;
    obj.image11:setField("icone_forja");
    obj.image11:setStyle("proportional");
    obj.image11.grid.role = "col";
    obj.image11.grid.width = 12;
    obj.image11:setHeight(200);
    obj.image11:setMargins({top=10});
    obj.image11:setURL("https://art.ngfiles.com/images/1081000/1081135_namenloose_smithing-at-the-smithy.gif?f1573595230");
    obj.image11:setName("image11");

    obj.label127 = GUI.fromHandle(_obj_newObject("label"));
    obj.label127:setParent(obj.detalhes_forja);
    obj.label127:setText("Maestria:");
    obj.label127.grid.role = "col";
    obj.label127.grid.width = 6;
    obj.label127:setHeight(20);
    obj.label127:setFontSize(12);
    obj.label127:setFontFamily("Wishes Script Caps Display");
    obj.label127:setMargins({top=5});
    obj.label127:setName("label127");

    obj.label128 = GUI.fromHandle(_obj_newObject("label"));
    obj.label128:setParent(obj.detalhes_forja);
    obj.label128:setText("Nível:");
    obj.label128.grid.role = "col";
    obj.label128.grid.width = 3;
    obj.label128:setHeight(20);
    obj.label128:setFontSize(12);
    obj.label128:setFontFamily("Wishes Script Caps Display");
    obj.label128:setMargins({top=5});
    obj.label128:setName("label128");

    obj.label129 = GUI.fromHandle(_obj_newObject("label"));
    obj.label129:setParent(obj.detalhes_forja);
    obj.label129:setText("Mod:");
    obj.label129.grid.role = "col";
    obj.label129.grid.width = 3;
    obj.label129:setHeight(20);
    obj.label129:setFontSize(12);
    obj.label129:setFontFamily("Wishes Script Caps Display");
    obj.label129:setMargins({top=5});
    obj.label129:setName("label129");

    obj.rectangle115 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle115:setParent(obj.detalhes_forja);
    obj.rectangle115:setHeight(25);
    obj.rectangle115:setColor("black");
    obj.rectangle115.grid.role = "col";
    obj.rectangle115.grid.width = 6;
    obj.rectangle115:setStrokeSize(1);
    obj.rectangle115:setStrokeColor("white");
    obj.rectangle115:setCornerType("round");
    obj.rectangle115:setXradius(5);
    obj.rectangle115:setYradius(5);
    obj.rectangle115:setName("rectangle115");

    obj.comboBox11 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox11:setParent(obj.rectangle115);
    obj.comboBox11:setField("maestria_forja");
    obj.comboBox11.grid.role = "col";
    obj.comboBox11.grid.width = 12;
    obj.comboBox11:setHeight(30);
    obj.comboBox11:setFontFamily("Wishes Script Caps Display");
    obj.comboBox11:setTransparent(true);
    obj.comboBox11:setFontSize(20);
    obj.comboBox11:setHorzTextAlign("center");
    obj.comboBox11:setVertTextAlign("center");
    obj.comboBox11:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox11:setName("comboBox11");

    obj.rectangle116 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle116:setParent(obj.detalhes_forja);
    obj.rectangle116:setHeight(25);
    obj.rectangle116:setColor("black");
    obj.rectangle116.grid.role = "col";
    obj.rectangle116.grid.width = 3;
    obj.rectangle116:setStrokeSize(1);
    obj.rectangle116:setStrokeColor("white");
    obj.rectangle116:setCornerType("round");
    obj.rectangle116:setXradius(5);
    obj.rectangle116:setYradius(5);
    obj.rectangle116:setName("rectangle116");

    obj.edit85 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit85:setParent(obj.rectangle116);
    obj.edit85:setField("nv_forja");
    obj.edit85.grid.role = "col";
    obj.edit85.grid.width = 12;
    obj.edit85:setHeight(30);
    obj.edit85:setFontFamily("Wishes Script Caps Display");
    obj.edit85:setTransparent(true);
    obj.edit85:setFontSize(20);
    obj.edit85:setHorzTextAlign("center");
    obj.edit85:setVertTextAlign("center");
    obj.edit85:setName("edit85");

    obj.rectangle117 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle117:setParent(obj.detalhes_forja);
    obj.rectangle117:setHeight(25);
    obj.rectangle117:setColor("black");
    obj.rectangle117.grid.role = "col";
    obj.rectangle117.grid.width = 3;
    obj.rectangle117:setStrokeSize(1);
    obj.rectangle117:setStrokeColor("white");
    obj.rectangle117:setCornerType("round");
    obj.rectangle117:setXradius(5);
    obj.rectangle117:setYradius(5);
    obj.rectangle117:setName("rectangle117");

    obj.edit86 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit86:setParent(obj.rectangle117);
    obj.edit86:setField("mod_forja");
    obj.edit86.grid.role = "col";
    obj.edit86.grid.width = 12;
    obj.edit86:setHeight(30);
    obj.edit86:setFontFamily("Wishes Script Caps Display");
    obj.edit86:setTransparent(true);
    obj.edit86:setFontSize(20);
    obj.edit86:setHorzTextAlign("center");
    obj.edit86:setVertTextAlign("center");
    obj.edit86:setName("edit86");

    obj.label130 = GUI.fromHandle(_obj_newObject("label"));
    obj.label130:setParent(obj.detalhes_forja);
    obj.label130:setText("Limite:");
    obj.label130.grid.role = "col";
    obj.label130.grid.width = 9;
    obj.label130:setHeight(20);
    obj.label130:setFontSize(12);
    obj.label130:setFontFamily("Wishes Script Caps Display");
    obj.label130:setMargins({top=5});
    obj.label130:setName("label130");

    obj.label131 = GUI.fromHandle(_obj_newObject("label"));
    obj.label131:setParent(obj.detalhes_forja);
    obj.label131:setText("Extra:");
    obj.label131.grid.role = "col";
    obj.label131.grid.width = 3;
    obj.label131:setHeight(20);
    obj.label131:setFontSize(12);
    obj.label131:setFontFamily("Wishes Script Caps Display");
    obj.label131:setMargins({top=5});
    obj.label131:setName("label131");

    obj.rectangle118 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle118:setParent(obj.detalhes_forja);
    obj.rectangle118:setHeight(25);
    obj.rectangle118:setColor("black");
    obj.rectangle118.grid.role = "col";
    obj.rectangle118.grid.width = 9;
    obj.rectangle118:setStrokeSize(1);
    obj.rectangle118:setStrokeColor("white");
    obj.rectangle118:setCornerType("round");
    obj.rectangle118:setName("rectangle118");

    obj.edit87 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit87:setParent(obj.rectangle118);
    obj.edit87:setField("limite_forja");
    obj.edit87.grid.role = "col";
    obj.edit87.grid.width = 12;
    obj.edit87:setHeight(30);
    obj.edit87:setFontFamily("Wishes Script Caps Display");
    obj.edit87:setReadOnly(true);
    obj.edit87:setTransparent(true);
    obj.edit87:setFontSize(20);
    obj.edit87:setHorzTextAlign("center");
    obj.edit87:setVertTextAlign("center");
    obj.edit87:setName("edit87");

    obj.rectangle119 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle119:setParent(obj.detalhes_forja);
    obj.rectangle119:setHeight(25);
    obj.rectangle119:setColor("black");
    obj.rectangle119.grid.role = "col";
    obj.rectangle119.grid.width = 3;
    obj.rectangle119:setStrokeSize(1);
    obj.rectangle119:setStrokeColor("white");
    obj.rectangle119:setCornerType("round");
    obj.rectangle119:setName("rectangle119");

    obj.edit88 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit88:setParent(obj.rectangle119);
    obj.edit88:setField("extra_forja");
    obj.edit88.grid.role = "col";
    obj.edit88.grid.width = 12;
    obj.edit88:setHeight(30);
    obj.edit88:setFontFamily("Wishes Script Caps Display");
    obj.edit88:setTransparent(true);
    obj.edit88:setFontSize(20);
    obj.edit88:setHorzTextAlign("center");
    obj.edit88:setVertTextAlign("center");
    obj.edit88:setName("edit88");

    obj.label132 = GUI.fromHandle(_obj_newObject("label"));
    obj.label132:setParent(obj.detalhes_forja);
    obj.label132:setText("Descrição:");
    obj.label132.grid.role = "col";
    obj.label132.grid.width = 12;
    obj.label132:setHeight(20);
    obj.label132:setFontSize(12);
    obj.label132:setFontFamily("Wishes Script Caps Display");
    obj.label132:setMargins({top=5});
    obj.label132:setName("label132");

    obj.rectangle120 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle120:setParent(obj.detalhes_forja);
    obj.rectangle120:setHeight(100);
    obj.rectangle120:setColor("black");
    obj.rectangle120.grid.role = "col";
    obj.rectangle120.grid.width = 12;
    obj.rectangle120:setStrokeSize(1);
    obj.rectangle120:setStrokeColor("white");
    obj.rectangle120:setCornerType("round");
    obj.rectangle120:setName("rectangle120");

    obj.textEditor24 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor24:setParent(obj.rectangle120);
    obj.textEditor24:setAlign("client");
    obj.textEditor24:setField("descricao_forja");
    obj.textEditor24:setTransparent(true);
    obj.textEditor24:setReadOnly(true);
    obj.textEditor24:setName("textEditor24");

    obj.label133 = GUI.fromHandle(_obj_newObject("label"));
    obj.label133:setParent(obj.detalhes_forja);
    obj.label133:setText("Progressão:");
    obj.label133.grid.role = "col";
    obj.label133.grid.width = 12;
    obj.label133:setHeight(20);
    obj.label133:setFontSize(12);
    obj.label133:setFontFamily("Wishes Script Caps Display");
    obj.label133:setMargins({top=5});
    obj.label133:setName("label133");

    obj.rectangle121 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle121:setParent(obj.detalhes_forja);
    obj.rectangle121:setHeight(80);
    obj.rectangle121:setColor("black");
    obj.rectangle121.grid.role = "col";
    obj.rectangle121.grid.width = 12;
    obj.rectangle121:setStrokeSize(1);
    obj.rectangle121:setStrokeColor("white");
    obj.rectangle121:setCornerType("round");
    obj.rectangle121:setName("rectangle121");

    obj.textEditor25 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor25:setParent(obj.rectangle121);
    obj.textEditor25:setAlign("client");
    obj.textEditor25:setField("progressao_forja");
    obj.textEditor25:setTransparent(true);
    obj.textEditor25:setReadOnly(true);
    obj.textEditor25:setName("textEditor25");

    obj.rec_insetocultura = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_insetocultura:setParent(obj.scrollBox4);
    obj.rec_insetocultura:setName("rec_insetocultura");
    obj.rec_insetocultura:setHeight(50);
    obj.rec_insetocultura:setColor("black");
    obj.rec_insetocultura:setStrokeSize(2);
    obj.rec_insetocultura:setStrokeColor("white");
    obj.rec_insetocultura.grid.role = "col";
    obj.rec_insetocultura.grid.width = 6;
    obj.rec_insetocultura:setCornerType("round");
    obj.rec_insetocultura:setXradius(5);
    obj.rec_insetocultura:setYradius(5);
    obj.rec_insetocultura:setMargins({top=10});

    obj.label134 = GUI.fromHandle(_obj_newObject("label"));
    obj.label134:setParent(obj.rec_insetocultura);
    obj.label134:setText("Insetocultura");
    obj.label134:setHeight(50);
    obj.label134:setFontSize(18);
    obj.label134.grid.role = "col";
    obj.label134.grid.width = 8;
    obj.label134:setFontFamily("Wishes Script Caps Display");
    obj.label134:setHorzTextAlign("leading");
    obj.label134:setVertTextAlign("center");
    obj.label134:setMargins({left=10});
    obj.label134:setName("label134");

    obj.label135 = GUI.fromHandle(_obj_newObject("label"));
    obj.label135:setParent(obj.rec_insetocultura);
    obj.label135:setField("nvt_insetocultura");
    obj.label135.grid.role = "col";
    obj.label135.grid.width = 1;
    obj.label135:setHeight(50);
    obj.label135:setFontSize(12);
    obj.label135:setFontFamily("Wishes Script Caps Display");
    obj.label135:setHorzTextAlign("center");
    obj.label135:setVertTextAlign("center");
    obj.label135:setName("label135");

    obj.dataLink45 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink45:setParent(obj.rec_insetocultura);
    obj.dataLink45:setField("nv_insetocultura");
    obj.dataLink45:setName("dataLink45");

    obj.rectangle122 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle122:setParent(obj.rec_insetocultura);
    obj.rectangle122:setHeight(40);
    obj.rectangle122:setColor("black");
    obj.rectangle122:setStrokeSize(2);
    obj.rectangle122:setStrokeColor("white");
    obj.rectangle122.grid.role = "col";
    obj.rectangle122.grid.width = 3;
    obj.rectangle122:setCornerType("round");
    obj.rectangle122:setXradius(5);
    obj.rectangle122:setYradius(5);
    obj.rectangle122:setMargins({top=4,right=4,bottom=4});
    obj.rectangle122:setName("rectangle122");

    obj.label136 = GUI.fromHandle(_obj_newObject("label"));
    obj.label136:setParent(obj.rectangle122);
    obj.label136:setField("mod_insetocultura");
    obj.label136.grid.role = "col";
    obj.label136.grid.width = 12;
    obj.label136:setHeight(22);
    obj.label136:setFontSize(20);
    obj.label136:setFontFamily("Wishes Script Caps Display");
    obj.label136:setHorzTextAlign("center");
    obj.label136:setVertTextAlign("leading");
    obj.label136:setName("label136");

    obj.dataLink46 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink46:setParent(obj.rectangle122);
    obj.dataLink46:setField("mod_insetocultura");
    obj.dataLink46:setDefaultValue("+0");
    obj.dataLink46:setName("dataLink46");

    obj.button10 = GUI.fromHandle(_obj_newObject("button"));
    obj.button10:setParent(obj.rectangle122);
    obj.button10:setText("Mais");
    obj.button10.grid.role = "col";
    obj.button10.grid.width = 12;
    obj.button10:setHeight(15);
    obj.button10:setFontSize(11);
    obj.button10:setFontFamily("Wishes Script Caps Display");
    obj.button10:setHorzTextAlign("center");
    obj.button10:setVertTextAlign("center");
    obj.button10:setMargins({left=3,right=3});
    obj.button10:setName("button10");

    obj.dataLink47 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink47:setParent(obj.scrollBox4);
    obj.dataLink47:setField("maestria_insetocultura");
    obj.dataLink47:setName("dataLink47");

    obj.detalhes_insetocultura = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_insetocultura:setParent(obj.scrollBox4);
    obj.detalhes_insetocultura:setName("detalhes_insetocultura");
    obj.detalhes_insetocultura:setWidth(400);
    obj.detalhes_insetocultura:setHeight(600);
    obj.detalhes_insetocultura:setLeft(0);
    obj.detalhes_insetocultura:setBackOpacity(0.4);

    obj.rectangle123 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle123:setParent(obj.detalhes_insetocultura);
    obj.rectangle123:setColor("black");
    obj.rectangle123:setLeft(-5);
    obj.rectangle123:setTop(-5);
    obj.rectangle123:setWidth(410);
    obj.rectangle123:setHeight(610);
    obj.rectangle123:setName("rectangle123");

    obj.rectangle124 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle124:setParent(obj.detalhes_insetocultura);
    obj.rectangle124:setColor("#150e16");
    obj.rectangle124:setStrokeSize(2);
    obj.rectangle124:setStrokeColor("white");
    obj.rectangle124:setLeft(5);
    obj.rectangle124:setTop(5);
    obj.rectangle124:setWidth(390);
    obj.rectangle124:setHeight(590);
    obj.rectangle124:setCornerType("round");
    obj.rectangle124:setXradius(5);
    obj.rectangle124:setYradius(5);
    obj.rectangle124:setName("rectangle124");

    obj.label137 = GUI.fromHandle(_obj_newObject("label"));
    obj.label137:setParent(obj.detalhes_insetocultura);
    obj.label137:setText("Insetocultura");
    obj.label137:setHeight(30);
    obj.label137:setFontSize(25);
    obj.label137.grid.role = "col";
    obj.label137.grid.width = 12;
    obj.label137:setFontFamily("Wishes Script Caps Display");
    obj.label137:setHorzTextAlign("center");
    obj.label137:setVertTextAlign("center");
    obj.label137:setMargins({top=10});
    obj.label137:setName("label137");

    obj.image12 = GUI.fromHandle(_obj_newObject("image"));
    obj.image12:setParent(obj.detalhes_insetocultura);
    obj.image12.animate = true;
    obj.image12:setField("icone_insetocultura");
    obj.image12:setStyle("proportional");
    obj.image12.grid.role = "col";
    obj.image12.grid.width = 12;
    obj.image12:setHeight(200);
    obj.image12:setMargins({top=10});
    obj.image12:setURL("https://media.tenor.com/2Fwdg49b030AAAAM/honey-pooh.gif");
    obj.image12:setName("image12");

    obj.label138 = GUI.fromHandle(_obj_newObject("label"));
    obj.label138:setParent(obj.detalhes_insetocultura);
    obj.label138:setText("Maestria:");
    obj.label138.grid.role = "col";
    obj.label138.grid.width = 6;
    obj.label138:setHeight(20);
    obj.label138:setFontSize(12);
    obj.label138:setFontFamily("Wishes Script Caps Display");
    obj.label138:setMargins({top=5});
    obj.label138:setName("label138");

    obj.label139 = GUI.fromHandle(_obj_newObject("label"));
    obj.label139:setParent(obj.detalhes_insetocultura);
    obj.label139:setText("Nível:");
    obj.label139.grid.role = "col";
    obj.label139.grid.width = 3;
    obj.label139:setHeight(20);
    obj.label139:setFontSize(12);
    obj.label139:setFontFamily("Wishes Script Caps Display");
    obj.label139:setMargins({top=5});
    obj.label139:setName("label139");

    obj.label140 = GUI.fromHandle(_obj_newObject("label"));
    obj.label140:setParent(obj.detalhes_insetocultura);
    obj.label140:setText("Mod:");
    obj.label140.grid.role = "col";
    obj.label140.grid.width = 3;
    obj.label140:setHeight(20);
    obj.label140:setFontSize(12);
    obj.label140:setFontFamily("Wishes Script Caps Display");
    obj.label140:setMargins({top=5});
    obj.label140:setName("label140");

    obj.rectangle125 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle125:setParent(obj.detalhes_insetocultura);
    obj.rectangle125:setHeight(25);
    obj.rectangle125:setColor("black");
    obj.rectangle125.grid.role = "col";
    obj.rectangle125.grid.width = 6;
    obj.rectangle125:setStrokeSize(1);
    obj.rectangle125:setStrokeColor("white");
    obj.rectangle125:setCornerType("round");
    obj.rectangle125:setXradius(5);
    obj.rectangle125:setYradius(5);
    obj.rectangle125:setName("rectangle125");

    obj.comboBox12 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox12:setParent(obj.rectangle125);
    obj.comboBox12:setField("maestria_insetocultura");
    obj.comboBox12.grid.role = "col";
    obj.comboBox12.grid.width = 12;
    obj.comboBox12:setHeight(30);
    obj.comboBox12:setFontFamily("Wishes Script Caps Display");
    obj.comboBox12:setTransparent(true);
    obj.comboBox12:setFontSize(20);
    obj.comboBox12:setHorzTextAlign("center");
    obj.comboBox12:setVertTextAlign("center");
    obj.comboBox12:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox12:setName("comboBox12");

    obj.rectangle126 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle126:setParent(obj.detalhes_insetocultura);
    obj.rectangle126:setHeight(25);
    obj.rectangle126:setColor("black");
    obj.rectangle126.grid.role = "col";
    obj.rectangle126.grid.width = 3;
    obj.rectangle126:setStrokeSize(1);
    obj.rectangle126:setStrokeColor("white");
    obj.rectangle126:setCornerType("round");
    obj.rectangle126:setXradius(5);
    obj.rectangle126:setYradius(5);
    obj.rectangle126:setName("rectangle126");

    obj.edit89 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit89:setParent(obj.rectangle126);
    obj.edit89:setField("nv_insetocultura");
    obj.edit89.grid.role = "col";
    obj.edit89.grid.width = 12;
    obj.edit89:setHeight(30);
    obj.edit89:setFontFamily("Wishes Script Caps Display");
    obj.edit89:setTransparent(true);
    obj.edit89:setFontSize(20);
    obj.edit89:setHorzTextAlign("center");
    obj.edit89:setVertTextAlign("center");
    obj.edit89:setName("edit89");

    obj.rectangle127 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle127:setParent(obj.detalhes_insetocultura);
    obj.rectangle127:setHeight(25);
    obj.rectangle127:setColor("black");
    obj.rectangle127.grid.role = "col";
    obj.rectangle127.grid.width = 3;
    obj.rectangle127:setStrokeSize(1);
    obj.rectangle127:setStrokeColor("white");
    obj.rectangle127:setCornerType("round");
    obj.rectangle127:setXradius(5);
    obj.rectangle127:setYradius(5);
    obj.rectangle127:setName("rectangle127");

    obj.edit90 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit90:setParent(obj.rectangle127);
    obj.edit90:setField("mod_insetocultura");
    obj.edit90.grid.role = "col";
    obj.edit90.grid.width = 12;
    obj.edit90:setHeight(30);
    obj.edit90:setFontFamily("Wishes Script Caps Display");
    obj.edit90:setTransparent(true);
    obj.edit90:setFontSize(20);
    obj.edit90:setHorzTextAlign("center");
    obj.edit90:setVertTextAlign("center");
    obj.edit90:setName("edit90");

    obj.label141 = GUI.fromHandle(_obj_newObject("label"));
    obj.label141:setParent(obj.detalhes_insetocultura);
    obj.label141:setText("Limite:");
    obj.label141.grid.role = "col";
    obj.label141.grid.width = 9;
    obj.label141:setHeight(20);
    obj.label141:setFontSize(12);
    obj.label141:setFontFamily("Wishes Script Caps Display");
    obj.label141:setMargins({top=5});
    obj.label141:setName("label141");

    obj.label142 = GUI.fromHandle(_obj_newObject("label"));
    obj.label142:setParent(obj.detalhes_insetocultura);
    obj.label142:setText("Extra:");
    obj.label142.grid.role = "col";
    obj.label142.grid.width = 3;
    obj.label142:setHeight(20);
    obj.label142:setFontSize(12);
    obj.label142:setFontFamily("Wishes Script Caps Display");
    obj.label142:setMargins({top=5});
    obj.label142:setName("label142");

    obj.rectangle128 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle128:setParent(obj.detalhes_insetocultura);
    obj.rectangle128:setHeight(25);
    obj.rectangle128:setColor("black");
    obj.rectangle128.grid.role = "col";
    obj.rectangle128.grid.width = 9;
    obj.rectangle128:setStrokeSize(1);
    obj.rectangle128:setStrokeColor("white");
    obj.rectangle128:setCornerType("round");
    obj.rectangle128:setName("rectangle128");

    obj.edit91 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit91:setParent(obj.rectangle128);
    obj.edit91:setField("limite_insetocultura");
    obj.edit91.grid.role = "col";
    obj.edit91.grid.width = 12;
    obj.edit91:setHeight(30);
    obj.edit91:setFontFamily("Wishes Script Caps Display");
    obj.edit91:setReadOnly(true);
    obj.edit91:setTransparent(true);
    obj.edit91:setFontSize(20);
    obj.edit91:setHorzTextAlign("center");
    obj.edit91:setVertTextAlign("center");
    obj.edit91:setName("edit91");

    obj.rectangle129 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle129:setParent(obj.detalhes_insetocultura);
    obj.rectangle129:setHeight(25);
    obj.rectangle129:setColor("black");
    obj.rectangle129.grid.role = "col";
    obj.rectangle129.grid.width = 3;
    obj.rectangle129:setStrokeSize(1);
    obj.rectangle129:setStrokeColor("white");
    obj.rectangle129:setCornerType("round");
    obj.rectangle129:setName("rectangle129");

    obj.edit92 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit92:setParent(obj.rectangle129);
    obj.edit92:setField("extra_insetocultura");
    obj.edit92.grid.role = "col";
    obj.edit92.grid.width = 12;
    obj.edit92:setHeight(30);
    obj.edit92:setFontFamily("Wishes Script Caps Display");
    obj.edit92:setTransparent(true);
    obj.edit92:setFontSize(20);
    obj.edit92:setHorzTextAlign("center");
    obj.edit92:setVertTextAlign("center");
    obj.edit92:setName("edit92");

    obj.label143 = GUI.fromHandle(_obj_newObject("label"));
    obj.label143:setParent(obj.detalhes_insetocultura);
    obj.label143:setText("Descrição:");
    obj.label143.grid.role = "col";
    obj.label143.grid.width = 12;
    obj.label143:setHeight(20);
    obj.label143:setFontSize(12);
    obj.label143:setFontFamily("Wishes Script Caps Display");
    obj.label143:setMargins({top=5});
    obj.label143:setName("label143");

    obj.rectangle130 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle130:setParent(obj.detalhes_insetocultura);
    obj.rectangle130:setHeight(100);
    obj.rectangle130:setColor("black");
    obj.rectangle130.grid.role = "col";
    obj.rectangle130.grid.width = 12;
    obj.rectangle130:setStrokeSize(1);
    obj.rectangle130:setStrokeColor("white");
    obj.rectangle130:setCornerType("round");
    obj.rectangle130:setName("rectangle130");

    obj.textEditor26 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor26:setParent(obj.rectangle130);
    obj.textEditor26:setAlign("client");
    obj.textEditor26:setField("descricao_insetocultura");
    obj.textEditor26:setTransparent(true);
    obj.textEditor26:setReadOnly(true);
    obj.textEditor26:setName("textEditor26");

    obj.label144 = GUI.fromHandle(_obj_newObject("label"));
    obj.label144:setParent(obj.detalhes_insetocultura);
    obj.label144:setText("Progressão:");
    obj.label144.grid.role = "col";
    obj.label144.grid.width = 12;
    obj.label144:setHeight(20);
    obj.label144:setFontSize(12);
    obj.label144:setFontFamily("Wishes Script Caps Display");
    obj.label144:setMargins({top=5});
    obj.label144:setName("label144");

    obj.rectangle131 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle131:setParent(obj.detalhes_insetocultura);
    obj.rectangle131:setHeight(80);
    obj.rectangle131:setColor("black");
    obj.rectangle131.grid.role = "col";
    obj.rectangle131.grid.width = 12;
    obj.rectangle131:setStrokeSize(1);
    obj.rectangle131:setStrokeColor("white");
    obj.rectangle131:setCornerType("round");
    obj.rectangle131:setName("rectangle131");

    obj.textEditor27 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor27:setParent(obj.rectangle131);
    obj.textEditor27:setAlign("client");
    obj.textEditor27:setField("progressao_insetocultura");
    obj.textEditor27:setTransparent(true);
    obj.textEditor27:setReadOnly(true);
    obj.textEditor27:setName("textEditor27");

    obj.rec_joalheria = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_joalheria:setParent(obj.scrollBox4);
    obj.rec_joalheria:setName("rec_joalheria");
    obj.rec_joalheria:setHeight(50);
    obj.rec_joalheria:setColor("black");
    obj.rec_joalheria:setStrokeSize(2);
    obj.rec_joalheria:setStrokeColor("white");
    obj.rec_joalheria.grid.role = "col";
    obj.rec_joalheria.grid.width = 6;
    obj.rec_joalheria:setCornerType("round");
    obj.rec_joalheria:setXradius(5);
    obj.rec_joalheria:setYradius(5);
    obj.rec_joalheria:setMargins({top=10});

    obj.label145 = GUI.fromHandle(_obj_newObject("label"));
    obj.label145:setParent(obj.rec_joalheria);
    obj.label145:setText("Joalheira");
    obj.label145:setHeight(50);
    obj.label145:setFontSize(18);
    obj.label145.grid.role = "col";
    obj.label145.grid.width = 8;
    obj.label145:setFontFamily("Wishes Script Caps Display");
    obj.label145:setHorzTextAlign("leading");
    obj.label145:setVertTextAlign("center");
    obj.label145:setMargins({left=10});
    obj.label145:setName("label145");

    obj.label146 = GUI.fromHandle(_obj_newObject("label"));
    obj.label146:setParent(obj.rec_joalheria);
    obj.label146:setField("nvt_joalheria");
    obj.label146.grid.role = "col";
    obj.label146.grid.width = 1;
    obj.label146:setHeight(50);
    obj.label146:setFontSize(12);
    obj.label146:setFontFamily("Wishes Script Caps Display");
    obj.label146:setHorzTextAlign("center");
    obj.label146:setVertTextAlign("center");
    obj.label146:setName("label146");

    obj.dataLink48 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink48:setParent(obj.rec_joalheria);
    obj.dataLink48:setField("nv_joalheria");
    obj.dataLink48:setName("dataLink48");

    obj.rectangle132 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle132:setParent(obj.rec_joalheria);
    obj.rectangle132:setHeight(40);
    obj.rectangle132:setColor("black");
    obj.rectangle132:setStrokeSize(2);
    obj.rectangle132:setStrokeColor("white");
    obj.rectangle132.grid.role = "col";
    obj.rectangle132.grid.width = 3;
    obj.rectangle132:setCornerType("round");
    obj.rectangle132:setXradius(5);
    obj.rectangle132:setYradius(5);
    obj.rectangle132:setMargins({top=4,right=4,bottom=4});
    obj.rectangle132:setName("rectangle132");

    obj.label147 = GUI.fromHandle(_obj_newObject("label"));
    obj.label147:setParent(obj.rectangle132);
    obj.label147:setField("mod_joalheria");
    obj.label147.grid.role = "col";
    obj.label147.grid.width = 12;
    obj.label147:setHeight(22);
    obj.label147:setFontSize(20);
    obj.label147:setFontFamily("Wishes Script Caps Display");
    obj.label147:setHorzTextAlign("center");
    obj.label147:setVertTextAlign("leading");
    obj.label147:setName("label147");

    obj.dataLink49 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink49:setParent(obj.rectangle132);
    obj.dataLink49:setField("mod_joalheria");
    obj.dataLink49:setDefaultValue("+0");
    obj.dataLink49:setName("dataLink49");

    obj.button11 = GUI.fromHandle(_obj_newObject("button"));
    obj.button11:setParent(obj.rectangle132);
    obj.button11:setText("Mais");
    obj.button11.grid.role = "col";
    obj.button11.grid.width = 12;
    obj.button11:setHeight(15);
    obj.button11:setFontSize(11);
    obj.button11:setFontFamily("Wishes Script Caps Display");
    obj.button11:setHorzTextAlign("center");
    obj.button11:setVertTextAlign("center");
    obj.button11:setMargins({left=3,right=3});
    obj.button11:setName("button11");

    obj.dataLink50 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink50:setParent(obj.scrollBox4);
    obj.dataLink50:setField("maestria_joalheria");
    obj.dataLink50:setName("dataLink50");

    obj.detalhes_joalheria = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_joalheria:setParent(obj.scrollBox4);
    obj.detalhes_joalheria:setName("detalhes_joalheria");
    obj.detalhes_joalheria:setWidth(400);
    obj.detalhes_joalheria:setHeight(600);
    obj.detalhes_joalheria:setLeft(0);
    obj.detalhes_joalheria:setBackOpacity(0.4);

    obj.rectangle133 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle133:setParent(obj.detalhes_joalheria);
    obj.rectangle133:setColor("black");
    obj.rectangle133:setLeft(-5);
    obj.rectangle133:setTop(-5);
    obj.rectangle133:setWidth(410);
    obj.rectangle133:setHeight(610);
    obj.rectangle133:setName("rectangle133");

    obj.rectangle134 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle134:setParent(obj.detalhes_joalheria);
    obj.rectangle134:setColor("#150e16");
    obj.rectangle134:setStrokeSize(2);
    obj.rectangle134:setStrokeColor("white");
    obj.rectangle134:setLeft(5);
    obj.rectangle134:setTop(5);
    obj.rectangle134:setWidth(390);
    obj.rectangle134:setHeight(590);
    obj.rectangle134:setCornerType("round");
    obj.rectangle134:setXradius(5);
    obj.rectangle134:setYradius(5);
    obj.rectangle134:setName("rectangle134");

    obj.label148 = GUI.fromHandle(_obj_newObject("label"));
    obj.label148:setParent(obj.detalhes_joalheria);
    obj.label148:setText("Joalheira");
    obj.label148:setHeight(30);
    obj.label148:setFontSize(25);
    obj.label148.grid.role = "col";
    obj.label148.grid.width = 12;
    obj.label148:setFontFamily("Wishes Script Caps Display");
    obj.label148:setHorzTextAlign("center");
    obj.label148:setVertTextAlign("center");
    obj.label148:setMargins({top=10});
    obj.label148:setName("label148");

    obj.image13 = GUI.fromHandle(_obj_newObject("image"));
    obj.image13:setParent(obj.detalhes_joalheria);
    obj.image13.animate = true;
    obj.image13:setField("icone_joalheria");
    obj.image13:setStyle("proportional");
    obj.image13.grid.role = "col";
    obj.image13.grid.width = 12;
    obj.image13:setHeight(200);
    obj.image13:setMargins({top=10});
    obj.image13:setURL("https://media.tenor.com/dF8bikX7iQ8AAAAM/jewelry-sailor.gif");
    obj.image13:setName("image13");

    obj.label149 = GUI.fromHandle(_obj_newObject("label"));
    obj.label149:setParent(obj.detalhes_joalheria);
    obj.label149:setText("Maestria:");
    obj.label149.grid.role = "col";
    obj.label149.grid.width = 6;
    obj.label149:setHeight(20);
    obj.label149:setFontSize(12);
    obj.label149:setFontFamily("Wishes Script Caps Display");
    obj.label149:setMargins({top=5});
    obj.label149:setName("label149");

    obj.label150 = GUI.fromHandle(_obj_newObject("label"));
    obj.label150:setParent(obj.detalhes_joalheria);
    obj.label150:setText("Nível:");
    obj.label150.grid.role = "col";
    obj.label150.grid.width = 3;
    obj.label150:setHeight(20);
    obj.label150:setFontSize(12);
    obj.label150:setFontFamily("Wishes Script Caps Display");
    obj.label150:setMargins({top=5});
    obj.label150:setName("label150");

    obj.label151 = GUI.fromHandle(_obj_newObject("label"));
    obj.label151:setParent(obj.detalhes_joalheria);
    obj.label151:setText("Mod:");
    obj.label151.grid.role = "col";
    obj.label151.grid.width = 3;
    obj.label151:setHeight(20);
    obj.label151:setFontSize(12);
    obj.label151:setFontFamily("Wishes Script Caps Display");
    obj.label151:setMargins({top=5});
    obj.label151:setName("label151");

    obj.rectangle135 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle135:setParent(obj.detalhes_joalheria);
    obj.rectangle135:setHeight(25);
    obj.rectangle135:setColor("black");
    obj.rectangle135.grid.role = "col";
    obj.rectangle135.grid.width = 6;
    obj.rectangle135:setStrokeSize(1);
    obj.rectangle135:setStrokeColor("white");
    obj.rectangle135:setCornerType("round");
    obj.rectangle135:setXradius(5);
    obj.rectangle135:setYradius(5);
    obj.rectangle135:setName("rectangle135");

    obj.comboBox13 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox13:setParent(obj.rectangle135);
    obj.comboBox13:setField("maestria_joalheria");
    obj.comboBox13.grid.role = "col";
    obj.comboBox13.grid.width = 12;
    obj.comboBox13:setHeight(30);
    obj.comboBox13:setFontFamily("Wishes Script Caps Display");
    obj.comboBox13:setTransparent(true);
    obj.comboBox13:setFontSize(20);
    obj.comboBox13:setHorzTextAlign("center");
    obj.comboBox13:setVertTextAlign("center");
    obj.comboBox13:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox13:setName("comboBox13");

    obj.rectangle136 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle136:setParent(obj.detalhes_joalheria);
    obj.rectangle136:setHeight(25);
    obj.rectangle136:setColor("black");
    obj.rectangle136.grid.role = "col";
    obj.rectangle136.grid.width = 3;
    obj.rectangle136:setStrokeSize(1);
    obj.rectangle136:setStrokeColor("white");
    obj.rectangle136:setCornerType("round");
    obj.rectangle136:setXradius(5);
    obj.rectangle136:setYradius(5);
    obj.rectangle136:setName("rectangle136");

    obj.edit93 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit93:setParent(obj.rectangle136);
    obj.edit93:setField("nv_joalheria");
    obj.edit93.grid.role = "col";
    obj.edit93.grid.width = 12;
    obj.edit93:setHeight(30);
    obj.edit93:setFontFamily("Wishes Script Caps Display");
    obj.edit93:setTransparent(true);
    obj.edit93:setFontSize(20);
    obj.edit93:setHorzTextAlign("center");
    obj.edit93:setVertTextAlign("center");
    obj.edit93:setName("edit93");

    obj.rectangle137 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle137:setParent(obj.detalhes_joalheria);
    obj.rectangle137:setHeight(25);
    obj.rectangle137:setColor("black");
    obj.rectangle137.grid.role = "col";
    obj.rectangle137.grid.width = 3;
    obj.rectangle137:setStrokeSize(1);
    obj.rectangle137:setStrokeColor("white");
    obj.rectangle137:setCornerType("round");
    obj.rectangle137:setXradius(5);
    obj.rectangle137:setYradius(5);
    obj.rectangle137:setName("rectangle137");

    obj.edit94 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit94:setParent(obj.rectangle137);
    obj.edit94:setField("mod_joalheria");
    obj.edit94.grid.role = "col";
    obj.edit94.grid.width = 12;
    obj.edit94:setHeight(30);
    obj.edit94:setFontFamily("Wishes Script Caps Display");
    obj.edit94:setTransparent(true);
    obj.edit94:setFontSize(20);
    obj.edit94:setHorzTextAlign("center");
    obj.edit94:setVertTextAlign("center");
    obj.edit94:setName("edit94");

    obj.label152 = GUI.fromHandle(_obj_newObject("label"));
    obj.label152:setParent(obj.detalhes_joalheria);
    obj.label152:setText("Limite:");
    obj.label152.grid.role = "col";
    obj.label152.grid.width = 9;
    obj.label152:setHeight(20);
    obj.label152:setFontSize(12);
    obj.label152:setFontFamily("Wishes Script Caps Display");
    obj.label152:setMargins({top=5});
    obj.label152:setName("label152");

    obj.label153 = GUI.fromHandle(_obj_newObject("label"));
    obj.label153:setParent(obj.detalhes_joalheria);
    obj.label153:setText("Extra:");
    obj.label153.grid.role = "col";
    obj.label153.grid.width = 3;
    obj.label153:setHeight(20);
    obj.label153:setFontSize(12);
    obj.label153:setFontFamily("Wishes Script Caps Display");
    obj.label153:setMargins({top=5});
    obj.label153:setName("label153");

    obj.rectangle138 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle138:setParent(obj.detalhes_joalheria);
    obj.rectangle138:setHeight(25);
    obj.rectangle138:setColor("black");
    obj.rectangle138.grid.role = "col";
    obj.rectangle138.grid.width = 9;
    obj.rectangle138:setStrokeSize(1);
    obj.rectangle138:setStrokeColor("white");
    obj.rectangle138:setCornerType("round");
    obj.rectangle138:setName("rectangle138");

    obj.edit95 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit95:setParent(obj.rectangle138);
    obj.edit95:setField("limite_joalheria");
    obj.edit95.grid.role = "col";
    obj.edit95.grid.width = 12;
    obj.edit95:setHeight(30);
    obj.edit95:setFontFamily("Wishes Script Caps Display");
    obj.edit95:setReadOnly(true);
    obj.edit95:setTransparent(true);
    obj.edit95:setFontSize(20);
    obj.edit95:setHorzTextAlign("center");
    obj.edit95:setVertTextAlign("center");
    obj.edit95:setName("edit95");

    obj.rectangle139 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle139:setParent(obj.detalhes_joalheria);
    obj.rectangle139:setHeight(25);
    obj.rectangle139:setColor("black");
    obj.rectangle139.grid.role = "col";
    obj.rectangle139.grid.width = 3;
    obj.rectangle139:setStrokeSize(1);
    obj.rectangle139:setStrokeColor("white");
    obj.rectangle139:setCornerType("round");
    obj.rectangle139:setName("rectangle139");

    obj.edit96 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit96:setParent(obj.rectangle139);
    obj.edit96:setField("extra_joalheria");
    obj.edit96.grid.role = "col";
    obj.edit96.grid.width = 12;
    obj.edit96:setHeight(30);
    obj.edit96:setFontFamily("Wishes Script Caps Display");
    obj.edit96:setTransparent(true);
    obj.edit96:setFontSize(20);
    obj.edit96:setHorzTextAlign("center");
    obj.edit96:setVertTextAlign("center");
    obj.edit96:setName("edit96");

    obj.label154 = GUI.fromHandle(_obj_newObject("label"));
    obj.label154:setParent(obj.detalhes_joalheria);
    obj.label154:setText("Descrição:");
    obj.label154.grid.role = "col";
    obj.label154.grid.width = 12;
    obj.label154:setHeight(20);
    obj.label154:setFontSize(12);
    obj.label154:setFontFamily("Wishes Script Caps Display");
    obj.label154:setMargins({top=5});
    obj.label154:setName("label154");

    obj.rectangle140 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle140:setParent(obj.detalhes_joalheria);
    obj.rectangle140:setHeight(100);
    obj.rectangle140:setColor("black");
    obj.rectangle140.grid.role = "col";
    obj.rectangle140.grid.width = 12;
    obj.rectangle140:setStrokeSize(1);
    obj.rectangle140:setStrokeColor("white");
    obj.rectangle140:setCornerType("round");
    obj.rectangle140:setName("rectangle140");

    obj.textEditor28 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor28:setParent(obj.rectangle140);
    obj.textEditor28:setAlign("client");
    obj.textEditor28:setField("descricao_joalheria");
    obj.textEditor28:setTransparent(true);
    obj.textEditor28:setReadOnly(true);
    obj.textEditor28:setName("textEditor28");

    obj.label155 = GUI.fromHandle(_obj_newObject("label"));
    obj.label155:setParent(obj.detalhes_joalheria);
    obj.label155:setText("Progressão:");
    obj.label155.grid.role = "col";
    obj.label155.grid.width = 12;
    obj.label155:setHeight(20);
    obj.label155:setFontSize(12);
    obj.label155:setFontFamily("Wishes Script Caps Display");
    obj.label155:setMargins({top=5});
    obj.label155:setName("label155");

    obj.rectangle141 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle141:setParent(obj.detalhes_joalheria);
    obj.rectangle141:setHeight(80);
    obj.rectangle141:setColor("black");
    obj.rectangle141.grid.role = "col";
    obj.rectangle141.grid.width = 12;
    obj.rectangle141:setStrokeSize(1);
    obj.rectangle141:setStrokeColor("white");
    obj.rectangle141:setCornerType("round");
    obj.rectangle141:setName("rectangle141");

    obj.textEditor29 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor29:setParent(obj.rectangle141);
    obj.textEditor29:setAlign("client");
    obj.textEditor29:setField("progressao_joalheria");
    obj.textEditor29:setTransparent(true);
    obj.textEditor29:setReadOnly(true);
    obj.textEditor29:setName("textEditor29");

    obj.rec_mineracao = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_mineracao:setParent(obj.scrollBox4);
    obj.rec_mineracao:setName("rec_mineracao");
    obj.rec_mineracao:setHeight(50);
    obj.rec_mineracao:setColor("black");
    obj.rec_mineracao:setStrokeSize(2);
    obj.rec_mineracao:setStrokeColor("white");
    obj.rec_mineracao.grid.role = "col";
    obj.rec_mineracao.grid.width = 6;
    obj.rec_mineracao:setCornerType("round");
    obj.rec_mineracao:setXradius(5);
    obj.rec_mineracao:setYradius(5);
    obj.rec_mineracao:setMargins({top=10});

    obj.label156 = GUI.fromHandle(_obj_newObject("label"));
    obj.label156:setParent(obj.rec_mineracao);
    obj.label156:setText("Mineração");
    obj.label156:setHeight(50);
    obj.label156:setFontSize(18);
    obj.label156.grid.role = "col";
    obj.label156.grid.width = 8;
    obj.label156:setFontFamily("Wishes Script Caps Display");
    obj.label156:setHorzTextAlign("leading");
    obj.label156:setVertTextAlign("center");
    obj.label156:setMargins({left=10});
    obj.label156:setName("label156");

    obj.label157 = GUI.fromHandle(_obj_newObject("label"));
    obj.label157:setParent(obj.rec_mineracao);
    obj.label157:setField("nvt_mineracao");
    obj.label157.grid.role = "col";
    obj.label157.grid.width = 1;
    obj.label157:setHeight(50);
    obj.label157:setFontSize(12);
    obj.label157:setFontFamily("Wishes Script Caps Display");
    obj.label157:setHorzTextAlign("center");
    obj.label157:setVertTextAlign("center");
    obj.label157:setName("label157");

    obj.dataLink51 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink51:setParent(obj.rec_mineracao);
    obj.dataLink51:setField("nv_mineracao");
    obj.dataLink51:setName("dataLink51");

    obj.rectangle142 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle142:setParent(obj.rec_mineracao);
    obj.rectangle142:setHeight(40);
    obj.rectangle142:setColor("black");
    obj.rectangle142:setStrokeSize(2);
    obj.rectangle142:setStrokeColor("white");
    obj.rectangle142.grid.role = "col";
    obj.rectangle142.grid.width = 3;
    obj.rectangle142:setCornerType("round");
    obj.rectangle142:setXradius(5);
    obj.rectangle142:setYradius(5);
    obj.rectangle142:setMargins({top=4,right=4,bottom=4});
    obj.rectangle142:setName("rectangle142");

    obj.label158 = GUI.fromHandle(_obj_newObject("label"));
    obj.label158:setParent(obj.rectangle142);
    obj.label158:setField("mod_mineracao");
    obj.label158.grid.role = "col";
    obj.label158.grid.width = 12;
    obj.label158:setHeight(22);
    obj.label158:setFontSize(20);
    obj.label158:setFontFamily("Wishes Script Caps Display");
    obj.label158:setHorzTextAlign("center");
    obj.label158:setVertTextAlign("leading");
    obj.label158:setName("label158");

    obj.dataLink52 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink52:setParent(obj.rectangle142);
    obj.dataLink52:setField("mod_mineracao");
    obj.dataLink52:setDefaultValue("+0");
    obj.dataLink52:setName("dataLink52");

    obj.button12 = GUI.fromHandle(_obj_newObject("button"));
    obj.button12:setParent(obj.rectangle142);
    obj.button12:setText("Mais");
    obj.button12.grid.role = "col";
    obj.button12.grid.width = 12;
    obj.button12:setHeight(15);
    obj.button12:setFontSize(11);
    obj.button12:setFontFamily("Wishes Script Caps Display");
    obj.button12:setHorzTextAlign("center");
    obj.button12:setVertTextAlign("center");
    obj.button12:setMargins({left=3,right=3});
    obj.button12:setName("button12");

    obj.dataLink53 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink53:setParent(obj.scrollBox4);
    obj.dataLink53:setField("maestria_mineracao");
    obj.dataLink53:setName("dataLink53");

    obj.detalhes_mineracao = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_mineracao:setParent(obj.scrollBox4);
    obj.detalhes_mineracao:setName("detalhes_mineracao");
    obj.detalhes_mineracao:setWidth(400);
    obj.detalhes_mineracao:setHeight(600);
    obj.detalhes_mineracao:setLeft(0);
    obj.detalhes_mineracao:setBackOpacity(0.4);

    obj.rectangle143 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle143:setParent(obj.detalhes_mineracao);
    obj.rectangle143:setColor("black");
    obj.rectangle143:setLeft(-5);
    obj.rectangle143:setTop(-5);
    obj.rectangle143:setWidth(410);
    obj.rectangle143:setHeight(610);
    obj.rectangle143:setName("rectangle143");

    obj.rectangle144 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle144:setParent(obj.detalhes_mineracao);
    obj.rectangle144:setColor("#150e16");
    obj.rectangle144:setStrokeSize(2);
    obj.rectangle144:setStrokeColor("white");
    obj.rectangle144:setLeft(5);
    obj.rectangle144:setTop(5);
    obj.rectangle144:setWidth(390);
    obj.rectangle144:setHeight(590);
    obj.rectangle144:setCornerType("round");
    obj.rectangle144:setXradius(5);
    obj.rectangle144:setYradius(5);
    obj.rectangle144:setName("rectangle144");

    obj.label159 = GUI.fromHandle(_obj_newObject("label"));
    obj.label159:setParent(obj.detalhes_mineracao);
    obj.label159:setText("Mineração");
    obj.label159:setHeight(30);
    obj.label159:setFontSize(25);
    obj.label159.grid.role = "col";
    obj.label159.grid.width = 12;
    obj.label159:setFontFamily("Wishes Script Caps Display");
    obj.label159:setHorzTextAlign("center");
    obj.label159:setVertTextAlign("center");
    obj.label159:setMargins({top=10});
    obj.label159:setName("label159");

    obj.image14 = GUI.fromHandle(_obj_newObject("image"));
    obj.image14:setParent(obj.detalhes_mineracao);
    obj.image14.animate = true;
    obj.image14:setField("icone_mineracao");
    obj.image14:setStyle("proportional");
    obj.image14.grid.role = "col";
    obj.image14.grid.width = 12;
    obj.image14:setHeight(200);
    obj.image14:setMargins({top=10});
    obj.image14:setURL("https://media1.tenor.com/m/_s-8iQeg8kIAAAAd/the-strongest-sage-with-the-weakest-crest-iris.gif");
    obj.image14:setName("image14");

    obj.label160 = GUI.fromHandle(_obj_newObject("label"));
    obj.label160:setParent(obj.detalhes_mineracao);
    obj.label160:setText("Maestria:");
    obj.label160.grid.role = "col";
    obj.label160.grid.width = 6;
    obj.label160:setHeight(20);
    obj.label160:setFontSize(12);
    obj.label160:setFontFamily("Wishes Script Caps Display");
    obj.label160:setMargins({top=5});
    obj.label160:setName("label160");

    obj.label161 = GUI.fromHandle(_obj_newObject("label"));
    obj.label161:setParent(obj.detalhes_mineracao);
    obj.label161:setText("Nível:");
    obj.label161.grid.role = "col";
    obj.label161.grid.width = 3;
    obj.label161:setHeight(20);
    obj.label161:setFontSize(12);
    obj.label161:setFontFamily("Wishes Script Caps Display");
    obj.label161:setMargins({top=5});
    obj.label161:setName("label161");

    obj.label162 = GUI.fromHandle(_obj_newObject("label"));
    obj.label162:setParent(obj.detalhes_mineracao);
    obj.label162:setText("Mod:");
    obj.label162.grid.role = "col";
    obj.label162.grid.width = 3;
    obj.label162:setHeight(20);
    obj.label162:setFontSize(12);
    obj.label162:setFontFamily("Wishes Script Caps Display");
    obj.label162:setMargins({top=5});
    obj.label162:setName("label162");

    obj.rectangle145 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle145:setParent(obj.detalhes_mineracao);
    obj.rectangle145:setHeight(25);
    obj.rectangle145:setColor("black");
    obj.rectangle145.grid.role = "col";
    obj.rectangle145.grid.width = 6;
    obj.rectangle145:setStrokeSize(1);
    obj.rectangle145:setStrokeColor("white");
    obj.rectangle145:setCornerType("round");
    obj.rectangle145:setXradius(5);
    obj.rectangle145:setYradius(5);
    obj.rectangle145:setName("rectangle145");

    obj.comboBox14 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox14:setParent(obj.rectangle145);
    obj.comboBox14:setField("maestria_mineracao");
    obj.comboBox14.grid.role = "col";
    obj.comboBox14.grid.width = 12;
    obj.comboBox14:setHeight(30);
    obj.comboBox14:setFontFamily("Wishes Script Caps Display");
    obj.comboBox14:setTransparent(true);
    obj.comboBox14:setFontSize(20);
    obj.comboBox14:setHorzTextAlign("center");
    obj.comboBox14:setVertTextAlign("center");
    obj.comboBox14:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox14:setName("comboBox14");

    obj.rectangle146 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle146:setParent(obj.detalhes_mineracao);
    obj.rectangle146:setHeight(25);
    obj.rectangle146:setColor("black");
    obj.rectangle146.grid.role = "col";
    obj.rectangle146.grid.width = 3;
    obj.rectangle146:setStrokeSize(1);
    obj.rectangle146:setStrokeColor("white");
    obj.rectangle146:setCornerType("round");
    obj.rectangle146:setXradius(5);
    obj.rectangle146:setYradius(5);
    obj.rectangle146:setName("rectangle146");

    obj.edit97 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit97:setParent(obj.rectangle146);
    obj.edit97:setField("nv_mineracao");
    obj.edit97.grid.role = "col";
    obj.edit97.grid.width = 12;
    obj.edit97:setHeight(30);
    obj.edit97:setFontFamily("Wishes Script Caps Display");
    obj.edit97:setTransparent(true);
    obj.edit97:setFontSize(20);
    obj.edit97:setHorzTextAlign("center");
    obj.edit97:setVertTextAlign("center");
    obj.edit97:setName("edit97");

    obj.rectangle147 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle147:setParent(obj.detalhes_mineracao);
    obj.rectangle147:setHeight(25);
    obj.rectangle147:setColor("black");
    obj.rectangle147.grid.role = "col";
    obj.rectangle147.grid.width = 3;
    obj.rectangle147:setStrokeSize(1);
    obj.rectangle147:setStrokeColor("white");
    obj.rectangle147:setCornerType("round");
    obj.rectangle147:setXradius(5);
    obj.rectangle147:setYradius(5);
    obj.rectangle147:setName("rectangle147");

    obj.edit98 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit98:setParent(obj.rectangle147);
    obj.edit98:setField("mod_mineracao");
    obj.edit98.grid.role = "col";
    obj.edit98.grid.width = 12;
    obj.edit98:setHeight(30);
    obj.edit98:setFontFamily("Wishes Script Caps Display");
    obj.edit98:setTransparent(true);
    obj.edit98:setFontSize(20);
    obj.edit98:setHorzTextAlign("center");
    obj.edit98:setVertTextAlign("center");
    obj.edit98:setName("edit98");

    obj.label163 = GUI.fromHandle(_obj_newObject("label"));
    obj.label163:setParent(obj.detalhes_mineracao);
    obj.label163:setText("Limite:");
    obj.label163.grid.role = "col";
    obj.label163.grid.width = 9;
    obj.label163:setHeight(20);
    obj.label163:setFontSize(12);
    obj.label163:setFontFamily("Wishes Script Caps Display");
    obj.label163:setMargins({top=5});
    obj.label163:setName("label163");

    obj.label164 = GUI.fromHandle(_obj_newObject("label"));
    obj.label164:setParent(obj.detalhes_mineracao);
    obj.label164:setText("Extra:");
    obj.label164.grid.role = "col";
    obj.label164.grid.width = 3;
    obj.label164:setHeight(20);
    obj.label164:setFontSize(12);
    obj.label164:setFontFamily("Wishes Script Caps Display");
    obj.label164:setMargins({top=5});
    obj.label164:setName("label164");

    obj.rectangle148 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle148:setParent(obj.detalhes_mineracao);
    obj.rectangle148:setHeight(25);
    obj.rectangle148:setColor("black");
    obj.rectangle148.grid.role = "col";
    obj.rectangle148.grid.width = 9;
    obj.rectangle148:setStrokeSize(1);
    obj.rectangle148:setStrokeColor("white");
    obj.rectangle148:setCornerType("round");
    obj.rectangle148:setName("rectangle148");

    obj.edit99 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit99:setParent(obj.rectangle148);
    obj.edit99:setField("limite_mineracao");
    obj.edit99.grid.role = "col";
    obj.edit99.grid.width = 12;
    obj.edit99:setHeight(30);
    obj.edit99:setFontFamily("Wishes Script Caps Display");
    obj.edit99:setReadOnly(true);
    obj.edit99:setTransparent(true);
    obj.edit99:setFontSize(20);
    obj.edit99:setHorzTextAlign("center");
    obj.edit99:setVertTextAlign("center");
    obj.edit99:setName("edit99");

    obj.rectangle149 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle149:setParent(obj.detalhes_mineracao);
    obj.rectangle149:setHeight(25);
    obj.rectangle149:setColor("black");
    obj.rectangle149.grid.role = "col";
    obj.rectangle149.grid.width = 3;
    obj.rectangle149:setStrokeSize(1);
    obj.rectangle149:setStrokeColor("white");
    obj.rectangle149:setCornerType("round");
    obj.rectangle149:setName("rectangle149");

    obj.edit100 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit100:setParent(obj.rectangle149);
    obj.edit100:setField("extra_mineracao");
    obj.edit100.grid.role = "col";
    obj.edit100.grid.width = 12;
    obj.edit100:setHeight(30);
    obj.edit100:setFontFamily("Wishes Script Caps Display");
    obj.edit100:setTransparent(true);
    obj.edit100:setFontSize(20);
    obj.edit100:setHorzTextAlign("center");
    obj.edit100:setVertTextAlign("center");
    obj.edit100:setName("edit100");

    obj.label165 = GUI.fromHandle(_obj_newObject("label"));
    obj.label165:setParent(obj.detalhes_mineracao);
    obj.label165:setText("Descrição:");
    obj.label165.grid.role = "col";
    obj.label165.grid.width = 12;
    obj.label165:setHeight(20);
    obj.label165:setFontSize(12);
    obj.label165:setFontFamily("Wishes Script Caps Display");
    obj.label165:setMargins({top=5});
    obj.label165:setName("label165");

    obj.rectangle150 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle150:setParent(obj.detalhes_mineracao);
    obj.rectangle150:setHeight(100);
    obj.rectangle150:setColor("black");
    obj.rectangle150.grid.role = "col";
    obj.rectangle150.grid.width = 12;
    obj.rectangle150:setStrokeSize(1);
    obj.rectangle150:setStrokeColor("white");
    obj.rectangle150:setCornerType("round");
    obj.rectangle150:setName("rectangle150");

    obj.textEditor30 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor30:setParent(obj.rectangle150);
    obj.textEditor30:setAlign("client");
    obj.textEditor30:setField("descricao_mineracao");
    obj.textEditor30:setTransparent(true);
    obj.textEditor30:setReadOnly(true);
    obj.textEditor30:setName("textEditor30");

    obj.label166 = GUI.fromHandle(_obj_newObject("label"));
    obj.label166:setParent(obj.detalhes_mineracao);
    obj.label166:setText("Progressão:");
    obj.label166.grid.role = "col";
    obj.label166.grid.width = 12;
    obj.label166:setHeight(20);
    obj.label166:setFontSize(12);
    obj.label166:setFontFamily("Wishes Script Caps Display");
    obj.label166:setMargins({top=5});
    obj.label166:setName("label166");

    obj.rectangle151 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle151:setParent(obj.detalhes_mineracao);
    obj.rectangle151:setHeight(80);
    obj.rectangle151:setColor("black");
    obj.rectangle151.grid.role = "col";
    obj.rectangle151.grid.width = 12;
    obj.rectangle151:setStrokeSize(1);
    obj.rectangle151:setStrokeColor("white");
    obj.rectangle151:setCornerType("round");
    obj.rectangle151:setName("rectangle151");

    obj.textEditor31 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor31:setParent(obj.rectangle151);
    obj.textEditor31:setAlign("client");
    obj.textEditor31:setField("progressao_mineracao");
    obj.textEditor31:setTransparent(true);
    obj.textEditor31:setReadOnly(true);
    obj.textEditor31:setName("textEditor31");

    obj.rec_pesca = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_pesca:setParent(obj.scrollBox4);
    obj.rec_pesca:setName("rec_pesca");
    obj.rec_pesca:setHeight(50);
    obj.rec_pesca:setColor("black");
    obj.rec_pesca:setStrokeSize(2);
    obj.rec_pesca:setStrokeColor("white");
    obj.rec_pesca.grid.role = "col";
    obj.rec_pesca.grid.width = 6;
    obj.rec_pesca:setCornerType("round");
    obj.rec_pesca:setXradius(5);
    obj.rec_pesca:setYradius(5);
    obj.rec_pesca:setMargins({top=10});

    obj.label167 = GUI.fromHandle(_obj_newObject("label"));
    obj.label167:setParent(obj.rec_pesca);
    obj.label167:setText("Pesca");
    obj.label167:setHeight(50);
    obj.label167:setFontSize(18);
    obj.label167.grid.role = "col";
    obj.label167.grid.width = 8;
    obj.label167:setFontFamily("Wishes Script Caps Display");
    obj.label167:setHorzTextAlign("leading");
    obj.label167:setVertTextAlign("center");
    obj.label167:setMargins({left=10});
    obj.label167:setName("label167");

    obj.label168 = GUI.fromHandle(_obj_newObject("label"));
    obj.label168:setParent(obj.rec_pesca);
    obj.label168:setField("nvt_pesca");
    obj.label168.grid.role = "col";
    obj.label168.grid.width = 1;
    obj.label168:setHeight(50);
    obj.label168:setFontSize(12);
    obj.label168:setFontFamily("Wishes Script Caps Display");
    obj.label168:setHorzTextAlign("center");
    obj.label168:setVertTextAlign("center");
    obj.label168:setName("label168");

    obj.dataLink54 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink54:setParent(obj.rec_pesca);
    obj.dataLink54:setField("nv_pesca");
    obj.dataLink54:setName("dataLink54");

    obj.rectangle152 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle152:setParent(obj.rec_pesca);
    obj.rectangle152:setHeight(40);
    obj.rectangle152:setColor("black");
    obj.rectangle152:setStrokeSize(2);
    obj.rectangle152:setStrokeColor("white");
    obj.rectangle152.grid.role = "col";
    obj.rectangle152.grid.width = 3;
    obj.rectangle152:setCornerType("round");
    obj.rectangle152:setXradius(5);
    obj.rectangle152:setYradius(5);
    obj.rectangle152:setMargins({top=4,right=4,bottom=4});
    obj.rectangle152:setName("rectangle152");

    obj.label169 = GUI.fromHandle(_obj_newObject("label"));
    obj.label169:setParent(obj.rectangle152);
    obj.label169:setField("mod_pesca");
    obj.label169.grid.role = "col";
    obj.label169.grid.width = 12;
    obj.label169:setHeight(22);
    obj.label169:setFontSize(20);
    obj.label169:setFontFamily("Wishes Script Caps Display");
    obj.label169:setHorzTextAlign("center");
    obj.label169:setVertTextAlign("leading");
    obj.label169:setName("label169");

    obj.dataLink55 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink55:setParent(obj.rectangle152);
    obj.dataLink55:setField("mod_pesca");
    obj.dataLink55:setDefaultValue("+0");
    obj.dataLink55:setName("dataLink55");

    obj.button13 = GUI.fromHandle(_obj_newObject("button"));
    obj.button13:setParent(obj.rectangle152);
    obj.button13:setText("Mais");
    obj.button13.grid.role = "col";
    obj.button13.grid.width = 12;
    obj.button13:setHeight(15);
    obj.button13:setFontSize(11);
    obj.button13:setFontFamily("Wishes Script Caps Display");
    obj.button13:setHorzTextAlign("center");
    obj.button13:setVertTextAlign("center");
    obj.button13:setMargins({left=3,right=3});
    obj.button13:setName("button13");

    obj.dataLink56 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink56:setParent(obj.scrollBox4);
    obj.dataLink56:setField("maestria_pesca");
    obj.dataLink56:setName("dataLink56");

    obj.detalhes_pesca = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_pesca:setParent(obj.scrollBox4);
    obj.detalhes_pesca:setName("detalhes_pesca");
    obj.detalhes_pesca:setWidth(400);
    obj.detalhes_pesca:setHeight(600);
    obj.detalhes_pesca:setLeft(0);
    obj.detalhes_pesca:setBackOpacity(0.4);

    obj.rectangle153 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle153:setParent(obj.detalhes_pesca);
    obj.rectangle153:setColor("black");
    obj.rectangle153:setLeft(-5);
    obj.rectangle153:setTop(-5);
    obj.rectangle153:setWidth(410);
    obj.rectangle153:setHeight(610);
    obj.rectangle153:setName("rectangle153");

    obj.rectangle154 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle154:setParent(obj.detalhes_pesca);
    obj.rectangle154:setColor("#150e16");
    obj.rectangle154:setStrokeSize(2);
    obj.rectangle154:setStrokeColor("white");
    obj.rectangle154:setLeft(5);
    obj.rectangle154:setTop(5);
    obj.rectangle154:setWidth(390);
    obj.rectangle154:setHeight(590);
    obj.rectangle154:setCornerType("round");
    obj.rectangle154:setXradius(5);
    obj.rectangle154:setYradius(5);
    obj.rectangle154:setName("rectangle154");

    obj.label170 = GUI.fromHandle(_obj_newObject("label"));
    obj.label170:setParent(obj.detalhes_pesca);
    obj.label170:setText("Pesca");
    obj.label170:setHeight(30);
    obj.label170:setFontSize(25);
    obj.label170.grid.role = "col";
    obj.label170.grid.width = 12;
    obj.label170:setFontFamily("Wishes Script Caps Display");
    obj.label170:setHorzTextAlign("center");
    obj.label170:setVertTextAlign("center");
    obj.label170:setMargins({top=10});
    obj.label170:setName("label170");

    obj.image15 = GUI.fromHandle(_obj_newObject("image"));
    obj.image15:setParent(obj.detalhes_pesca);
    obj.image15.animate = true;
    obj.image15:setField("icone_pesca");
    obj.image15:setStyle("proportional");
    obj.image15.grid.role = "col";
    obj.image15.grid.width = 12;
    obj.image15:setHeight(200);
    obj.image15:setMargins({top=10});
    obj.image15:setURL("https://images.payhip.com/o_1ide1q2ngvumjpvaki7d1hvd10.gif");
    obj.image15:setName("image15");

    obj.label171 = GUI.fromHandle(_obj_newObject("label"));
    obj.label171:setParent(obj.detalhes_pesca);
    obj.label171:setText("Maestria:");
    obj.label171.grid.role = "col";
    obj.label171.grid.width = 6;
    obj.label171:setHeight(20);
    obj.label171:setFontSize(12);
    obj.label171:setFontFamily("Wishes Script Caps Display");
    obj.label171:setMargins({top=5});
    obj.label171:setName("label171");

    obj.label172 = GUI.fromHandle(_obj_newObject("label"));
    obj.label172:setParent(obj.detalhes_pesca);
    obj.label172:setText("Nível:");
    obj.label172.grid.role = "col";
    obj.label172.grid.width = 3;
    obj.label172:setHeight(20);
    obj.label172:setFontSize(12);
    obj.label172:setFontFamily("Wishes Script Caps Display");
    obj.label172:setMargins({top=5});
    obj.label172:setName("label172");

    obj.label173 = GUI.fromHandle(_obj_newObject("label"));
    obj.label173:setParent(obj.detalhes_pesca);
    obj.label173:setText("Mod:");
    obj.label173.grid.role = "col";
    obj.label173.grid.width = 3;
    obj.label173:setHeight(20);
    obj.label173:setFontSize(12);
    obj.label173:setFontFamily("Wishes Script Caps Display");
    obj.label173:setMargins({top=5});
    obj.label173:setName("label173");

    obj.rectangle155 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle155:setParent(obj.detalhes_pesca);
    obj.rectangle155:setHeight(25);
    obj.rectangle155:setColor("black");
    obj.rectangle155.grid.role = "col";
    obj.rectangle155.grid.width = 6;
    obj.rectangle155:setStrokeSize(1);
    obj.rectangle155:setStrokeColor("white");
    obj.rectangle155:setCornerType("round");
    obj.rectangle155:setXradius(5);
    obj.rectangle155:setYradius(5);
    obj.rectangle155:setName("rectangle155");

    obj.comboBox15 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox15:setParent(obj.rectangle155);
    obj.comboBox15:setField("maestria_pesca");
    obj.comboBox15.grid.role = "col";
    obj.comboBox15.grid.width = 12;
    obj.comboBox15:setHeight(30);
    obj.comboBox15:setFontFamily("Wishes Script Caps Display");
    obj.comboBox15:setTransparent(true);
    obj.comboBox15:setFontSize(20);
    obj.comboBox15:setHorzTextAlign("center");
    obj.comboBox15:setVertTextAlign("center");
    obj.comboBox15:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox15:setName("comboBox15");

    obj.rectangle156 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle156:setParent(obj.detalhes_pesca);
    obj.rectangle156:setHeight(25);
    obj.rectangle156:setColor("black");
    obj.rectangle156.grid.role = "col";
    obj.rectangle156.grid.width = 3;
    obj.rectangle156:setStrokeSize(1);
    obj.rectangle156:setStrokeColor("white");
    obj.rectangle156:setCornerType("round");
    obj.rectangle156:setXradius(5);
    obj.rectangle156:setYradius(5);
    obj.rectangle156:setName("rectangle156");

    obj.edit101 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit101:setParent(obj.rectangle156);
    obj.edit101:setField("nv_pesca");
    obj.edit101.grid.role = "col";
    obj.edit101.grid.width = 12;
    obj.edit101:setHeight(30);
    obj.edit101:setFontFamily("Wishes Script Caps Display");
    obj.edit101:setTransparent(true);
    obj.edit101:setFontSize(20);
    obj.edit101:setHorzTextAlign("center");
    obj.edit101:setVertTextAlign("center");
    obj.edit101:setName("edit101");

    obj.rectangle157 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle157:setParent(obj.detalhes_pesca);
    obj.rectangle157:setHeight(25);
    obj.rectangle157:setColor("black");
    obj.rectangle157.grid.role = "col";
    obj.rectangle157.grid.width = 3;
    obj.rectangle157:setStrokeSize(1);
    obj.rectangle157:setStrokeColor("white");
    obj.rectangle157:setCornerType("round");
    obj.rectangle157:setXradius(5);
    obj.rectangle157:setYradius(5);
    obj.rectangle157:setName("rectangle157");

    obj.edit102 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit102:setParent(obj.rectangle157);
    obj.edit102:setField("mod_pesca");
    obj.edit102.grid.role = "col";
    obj.edit102.grid.width = 12;
    obj.edit102:setHeight(30);
    obj.edit102:setFontFamily("Wishes Script Caps Display");
    obj.edit102:setTransparent(true);
    obj.edit102:setFontSize(20);
    obj.edit102:setHorzTextAlign("center");
    obj.edit102:setVertTextAlign("center");
    obj.edit102:setName("edit102");

    obj.label174 = GUI.fromHandle(_obj_newObject("label"));
    obj.label174:setParent(obj.detalhes_pesca);
    obj.label174:setText("Limite:");
    obj.label174.grid.role = "col";
    obj.label174.grid.width = 9;
    obj.label174:setHeight(20);
    obj.label174:setFontSize(12);
    obj.label174:setFontFamily("Wishes Script Caps Display");
    obj.label174:setMargins({top=5});
    obj.label174:setName("label174");

    obj.label175 = GUI.fromHandle(_obj_newObject("label"));
    obj.label175:setParent(obj.detalhes_pesca);
    obj.label175:setText("Extra:");
    obj.label175.grid.role = "col";
    obj.label175.grid.width = 3;
    obj.label175:setHeight(20);
    obj.label175:setFontSize(12);
    obj.label175:setFontFamily("Wishes Script Caps Display");
    obj.label175:setMargins({top=5});
    obj.label175:setName("label175");

    obj.rectangle158 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle158:setParent(obj.detalhes_pesca);
    obj.rectangle158:setHeight(25);
    obj.rectangle158:setColor("black");
    obj.rectangle158.grid.role = "col";
    obj.rectangle158.grid.width = 9;
    obj.rectangle158:setStrokeSize(1);
    obj.rectangle158:setStrokeColor("white");
    obj.rectangle158:setCornerType("round");
    obj.rectangle158:setName("rectangle158");

    obj.edit103 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit103:setParent(obj.rectangle158);
    obj.edit103:setField("limite_pesca");
    obj.edit103.grid.role = "col";
    obj.edit103.grid.width = 12;
    obj.edit103:setHeight(30);
    obj.edit103:setFontFamily("Wishes Script Caps Display");
    obj.edit103:setReadOnly(true);
    obj.edit103:setTransparent(true);
    obj.edit103:setFontSize(20);
    obj.edit103:setHorzTextAlign("center");
    obj.edit103:setVertTextAlign("center");
    obj.edit103:setName("edit103");

    obj.rectangle159 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle159:setParent(obj.detalhes_pesca);
    obj.rectangle159:setHeight(25);
    obj.rectangle159:setColor("black");
    obj.rectangle159.grid.role = "col";
    obj.rectangle159.grid.width = 3;
    obj.rectangle159:setStrokeSize(1);
    obj.rectangle159:setStrokeColor("white");
    obj.rectangle159:setCornerType("round");
    obj.rectangle159:setName("rectangle159");

    obj.edit104 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit104:setParent(obj.rectangle159);
    obj.edit104:setField("extra_pesca");
    obj.edit104.grid.role = "col";
    obj.edit104.grid.width = 12;
    obj.edit104:setHeight(30);
    obj.edit104:setFontFamily("Wishes Script Caps Display");
    obj.edit104:setTransparent(true);
    obj.edit104:setFontSize(20);
    obj.edit104:setHorzTextAlign("center");
    obj.edit104:setVertTextAlign("center");
    obj.edit104:setName("edit104");

    obj.label176 = GUI.fromHandle(_obj_newObject("label"));
    obj.label176:setParent(obj.detalhes_pesca);
    obj.label176:setText("Descrição:");
    obj.label176.grid.role = "col";
    obj.label176.grid.width = 12;
    obj.label176:setHeight(20);
    obj.label176:setFontSize(12);
    obj.label176:setFontFamily("Wishes Script Caps Display");
    obj.label176:setMargins({top=5});
    obj.label176:setName("label176");

    obj.rectangle160 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle160:setParent(obj.detalhes_pesca);
    obj.rectangle160:setHeight(100);
    obj.rectangle160:setColor("black");
    obj.rectangle160.grid.role = "col";
    obj.rectangle160.grid.width = 12;
    obj.rectangle160:setStrokeSize(1);
    obj.rectangle160:setStrokeColor("white");
    obj.rectangle160:setCornerType("round");
    obj.rectangle160:setName("rectangle160");

    obj.textEditor32 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor32:setParent(obj.rectangle160);
    obj.textEditor32:setAlign("client");
    obj.textEditor32:setField("descricao_pesca");
    obj.textEditor32:setTransparent(true);
    obj.textEditor32:setReadOnly(true);
    obj.textEditor32:setName("textEditor32");

    obj.label177 = GUI.fromHandle(_obj_newObject("label"));
    obj.label177:setParent(obj.detalhes_pesca);
    obj.label177:setText("Progressão:");
    obj.label177.grid.role = "col";
    obj.label177.grid.width = 12;
    obj.label177:setHeight(20);
    obj.label177:setFontSize(12);
    obj.label177:setFontFamily("Wishes Script Caps Display");
    obj.label177:setMargins({top=5});
    obj.label177:setName("label177");

    obj.rectangle161 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle161:setParent(obj.detalhes_pesca);
    obj.rectangle161:setHeight(80);
    obj.rectangle161:setColor("black");
    obj.rectangle161.grid.role = "col";
    obj.rectangle161.grid.width = 12;
    obj.rectangle161:setStrokeSize(1);
    obj.rectangle161:setStrokeColor("white");
    obj.rectangle161:setCornerType("round");
    obj.rectangle161:setName("rectangle161");

    obj.textEditor33 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor33:setParent(obj.rectangle161);
    obj.textEditor33:setAlign("client");
    obj.textEditor33:setField("progressao_pesca");
    obj.textEditor33:setTransparent(true);
    obj.textEditor33:setReadOnly(true);
    obj.textEditor33:setName("textEditor33");

    obj.rec_pesquisa = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rec_pesquisa:setParent(obj.scrollBox4);
    obj.rec_pesquisa:setName("rec_pesquisa");
    obj.rec_pesquisa:setHeight(50);
    obj.rec_pesquisa:setColor("black");
    obj.rec_pesquisa:setStrokeSize(2);
    obj.rec_pesquisa:setStrokeColor("white");
    obj.rec_pesquisa.grid.role = "col";
    obj.rec_pesquisa.grid.width = 6;
    obj.rec_pesquisa:setCornerType("round");
    obj.rec_pesquisa:setXradius(5);
    obj.rec_pesquisa:setYradius(5);
    obj.rec_pesquisa:setMargins({top=10});

    obj.label178 = GUI.fromHandle(_obj_newObject("label"));
    obj.label178:setParent(obj.rec_pesquisa);
    obj.label178:setText("Pesquisa");
    obj.label178:setHeight(50);
    obj.label178:setFontSize(18);
    obj.label178.grid.role = "col";
    obj.label178.grid.width = 8;
    obj.label178:setFontFamily("Wishes Script Caps Display");
    obj.label178:setHorzTextAlign("leading");
    obj.label178:setVertTextAlign("center");
    obj.label178:setMargins({left=10});
    obj.label178:setName("label178");

    obj.label179 = GUI.fromHandle(_obj_newObject("label"));
    obj.label179:setParent(obj.rec_pesquisa);
    obj.label179:setField("nvt_pesquisa");
    obj.label179.grid.role = "col";
    obj.label179.grid.width = 1;
    obj.label179:setHeight(50);
    obj.label179:setFontSize(12);
    obj.label179:setFontFamily("Wishes Script Caps Display");
    obj.label179:setHorzTextAlign("center");
    obj.label179:setVertTextAlign("center");
    obj.label179:setName("label179");

    obj.dataLink57 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink57:setParent(obj.rec_pesquisa);
    obj.dataLink57:setField("nv_pesquisa");
    obj.dataLink57:setName("dataLink57");

    obj.rectangle162 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle162:setParent(obj.rec_pesquisa);
    obj.rectangle162:setHeight(40);
    obj.rectangle162:setColor("black");
    obj.rectangle162:setStrokeSize(2);
    obj.rectangle162:setStrokeColor("white");
    obj.rectangle162.grid.role = "col";
    obj.rectangle162.grid.width = 3;
    obj.rectangle162:setCornerType("round");
    obj.rectangle162:setXradius(5);
    obj.rectangle162:setYradius(5);
    obj.rectangle162:setMargins({top=4,right=4,bottom=4});
    obj.rectangle162:setName("rectangle162");

    obj.label180 = GUI.fromHandle(_obj_newObject("label"));
    obj.label180:setParent(obj.rectangle162);
    obj.label180:setField("mod_pesquisa");
    obj.label180.grid.role = "col";
    obj.label180.grid.width = 12;
    obj.label180:setHeight(22);
    obj.label180:setFontSize(20);
    obj.label180:setFontFamily("Wishes Script Caps Display");
    obj.label180:setHorzTextAlign("center");
    obj.label180:setVertTextAlign("leading");
    obj.label180:setName("label180");

    obj.dataLink58 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink58:setParent(obj.rectangle162);
    obj.dataLink58:setField("mod_pesquisa");
    obj.dataLink58:setDefaultValue("+0");
    obj.dataLink58:setName("dataLink58");

    obj.button14 = GUI.fromHandle(_obj_newObject("button"));
    obj.button14:setParent(obj.rectangle162);
    obj.button14:setText("Mais");
    obj.button14.grid.role = "col";
    obj.button14.grid.width = 12;
    obj.button14:setHeight(15);
    obj.button14:setFontSize(11);
    obj.button14:setFontFamily("Wishes Script Caps Display");
    obj.button14:setHorzTextAlign("center");
    obj.button14:setVertTextAlign("center");
    obj.button14:setMargins({left=3,right=3});
    obj.button14:setName("button14");

    obj.dataLink59 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink59:setParent(obj.scrollBox4);
    obj.dataLink59:setField("maestria_pesquisa");
    obj.dataLink59:setName("dataLink59");

    obj.detalhes_pesquisa = GUI.fromHandle(_obj_newObject("popup"));
    obj.detalhes_pesquisa:setParent(obj.scrollBox4);
    obj.detalhes_pesquisa:setName("detalhes_pesquisa");
    obj.detalhes_pesquisa:setWidth(400);
    obj.detalhes_pesquisa:setHeight(600);
    obj.detalhes_pesquisa:setLeft(0);
    obj.detalhes_pesquisa:setBackOpacity(0.4);

    obj.rectangle163 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle163:setParent(obj.detalhes_pesquisa);
    obj.rectangle163:setColor("black");
    obj.rectangle163:setLeft(-5);
    obj.rectangle163:setTop(-5);
    obj.rectangle163:setWidth(410);
    obj.rectangle163:setHeight(610);
    obj.rectangle163:setName("rectangle163");

    obj.rectangle164 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle164:setParent(obj.detalhes_pesquisa);
    obj.rectangle164:setColor("#150e16");
    obj.rectangle164:setStrokeSize(2);
    obj.rectangle164:setStrokeColor("white");
    obj.rectangle164:setLeft(5);
    obj.rectangle164:setTop(5);
    obj.rectangle164:setWidth(390);
    obj.rectangle164:setHeight(590);
    obj.rectangle164:setCornerType("round");
    obj.rectangle164:setXradius(5);
    obj.rectangle164:setYradius(5);
    obj.rectangle164:setName("rectangle164");

    obj.label181 = GUI.fromHandle(_obj_newObject("label"));
    obj.label181:setParent(obj.detalhes_pesquisa);
    obj.label181:setText("Pesquisa");
    obj.label181:setHeight(30);
    obj.label181:setFontSize(25);
    obj.label181.grid.role = "col";
    obj.label181.grid.width = 12;
    obj.label181:setFontFamily("Wishes Script Caps Display");
    obj.label181:setHorzTextAlign("center");
    obj.label181:setVertTextAlign("center");
    obj.label181:setMargins({top=10});
    obj.label181:setName("label181");

    obj.image16 = GUI.fromHandle(_obj_newObject("image"));
    obj.image16:setParent(obj.detalhes_pesquisa);
    obj.image16.animate = true;
    obj.image16:setField("icone_pesquisa");
    obj.image16:setStyle("proportional");
    obj.image16.grid.role = "col";
    obj.image16.grid.width = 12;
    obj.image16:setHeight(200);
    obj.image16:setMargins({top=10});
    obj.image16:setURL("https://media1.tenor.com/m/-jncD6Ey3CQAAAAd/studying-anime.gif");
    obj.image16:setName("image16");

    obj.label182 = GUI.fromHandle(_obj_newObject("label"));
    obj.label182:setParent(obj.detalhes_pesquisa);
    obj.label182:setText("Maestria:");
    obj.label182.grid.role = "col";
    obj.label182.grid.width = 6;
    obj.label182:setHeight(20);
    obj.label182:setFontSize(12);
    obj.label182:setFontFamily("Wishes Script Caps Display");
    obj.label182:setMargins({top=5});
    obj.label182:setName("label182");

    obj.label183 = GUI.fromHandle(_obj_newObject("label"));
    obj.label183:setParent(obj.detalhes_pesquisa);
    obj.label183:setText("Nível:");
    obj.label183.grid.role = "col";
    obj.label183.grid.width = 3;
    obj.label183:setHeight(20);
    obj.label183:setFontSize(12);
    obj.label183:setFontFamily("Wishes Script Caps Display");
    obj.label183:setMargins({top=5});
    obj.label183:setName("label183");

    obj.label184 = GUI.fromHandle(_obj_newObject("label"));
    obj.label184:setParent(obj.detalhes_pesquisa);
    obj.label184:setText("Mod:");
    obj.label184.grid.role = "col";
    obj.label184.grid.width = 3;
    obj.label184:setHeight(20);
    obj.label184:setFontSize(12);
    obj.label184:setFontFamily("Wishes Script Caps Display");
    obj.label184:setMargins({top=5});
    obj.label184:setName("label184");

    obj.rectangle165 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle165:setParent(obj.detalhes_pesquisa);
    obj.rectangle165:setHeight(25);
    obj.rectangle165:setColor("black");
    obj.rectangle165.grid.role = "col";
    obj.rectangle165.grid.width = 6;
    obj.rectangle165:setStrokeSize(1);
    obj.rectangle165:setStrokeColor("white");
    obj.rectangle165:setCornerType("round");
    obj.rectangle165:setXradius(5);
    obj.rectangle165:setYradius(5);
    obj.rectangle165:setName("rectangle165");

    obj.comboBox16 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox16:setParent(obj.rectangle165);
    obj.comboBox16:setField("maestria_pesquisa");
    obj.comboBox16.grid.role = "col";
    obj.comboBox16.grid.width = 12;
    obj.comboBox16:setHeight(30);
    obj.comboBox16:setFontFamily("Wishes Script Caps Display");
    obj.comboBox16:setTransparent(true);
    obj.comboBox16:setFontSize(20);
    obj.comboBox16:setHorzTextAlign("center");
    obj.comboBox16:setVertTextAlign("center");
    obj.comboBox16:setItems({'Sem Skill', 'Básica', 'Intermediária', 'Avançada', 'Mestra', 'Suprema'});
    obj.comboBox16:setName("comboBox16");

    obj.rectangle166 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle166:setParent(obj.detalhes_pesquisa);
    obj.rectangle166:setHeight(25);
    obj.rectangle166:setColor("black");
    obj.rectangle166.grid.role = "col";
    obj.rectangle166.grid.width = 3;
    obj.rectangle166:setStrokeSize(1);
    obj.rectangle166:setStrokeColor("white");
    obj.rectangle166:setCornerType("round");
    obj.rectangle166:setXradius(5);
    obj.rectangle166:setYradius(5);
    obj.rectangle166:setName("rectangle166");

    obj.edit105 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit105:setParent(obj.rectangle166);
    obj.edit105:setField("nv_pesquisa");
    obj.edit105.grid.role = "col";
    obj.edit105.grid.width = 12;
    obj.edit105:setHeight(30);
    obj.edit105:setFontFamily("Wishes Script Caps Display");
    obj.edit105:setTransparent(true);
    obj.edit105:setFontSize(20);
    obj.edit105:setHorzTextAlign("center");
    obj.edit105:setVertTextAlign("center");
    obj.edit105:setName("edit105");

    obj.rectangle167 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle167:setParent(obj.detalhes_pesquisa);
    obj.rectangle167:setHeight(25);
    obj.rectangle167:setColor("black");
    obj.rectangle167.grid.role = "col";
    obj.rectangle167.grid.width = 3;
    obj.rectangle167:setStrokeSize(1);
    obj.rectangle167:setStrokeColor("white");
    obj.rectangle167:setCornerType("round");
    obj.rectangle167:setXradius(5);
    obj.rectangle167:setYradius(5);
    obj.rectangle167:setName("rectangle167");

    obj.edit106 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit106:setParent(obj.rectangle167);
    obj.edit106:setField("mod_pesquisa");
    obj.edit106.grid.role = "col";
    obj.edit106.grid.width = 12;
    obj.edit106:setHeight(30);
    obj.edit106:setFontFamily("Wishes Script Caps Display");
    obj.edit106:setTransparent(true);
    obj.edit106:setFontSize(20);
    obj.edit106:setHorzTextAlign("center");
    obj.edit106:setVertTextAlign("center");
    obj.edit106:setName("edit106");

    obj.label185 = GUI.fromHandle(_obj_newObject("label"));
    obj.label185:setParent(obj.detalhes_pesquisa);
    obj.label185:setText("Limite:");
    obj.label185.grid.role = "col";
    obj.label185.grid.width = 9;
    obj.label185:setHeight(20);
    obj.label185:setFontSize(12);
    obj.label185:setFontFamily("Wishes Script Caps Display");
    obj.label185:setMargins({top=5});
    obj.label185:setName("label185");

    obj.label186 = GUI.fromHandle(_obj_newObject("label"));
    obj.label186:setParent(obj.detalhes_pesquisa);
    obj.label186:setText("Extra:");
    obj.label186.grid.role = "col";
    obj.label186.grid.width = 3;
    obj.label186:setHeight(20);
    obj.label186:setFontSize(12);
    obj.label186:setFontFamily("Wishes Script Caps Display");
    obj.label186:setMargins({top=5});
    obj.label186:setName("label186");

    obj.rectangle168 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle168:setParent(obj.detalhes_pesquisa);
    obj.rectangle168:setHeight(25);
    obj.rectangle168:setColor("black");
    obj.rectangle168.grid.role = "col";
    obj.rectangle168.grid.width = 9;
    obj.rectangle168:setStrokeSize(1);
    obj.rectangle168:setStrokeColor("white");
    obj.rectangle168:setCornerType("round");
    obj.rectangle168:setName("rectangle168");

    obj.edit107 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit107:setParent(obj.rectangle168);
    obj.edit107:setField("limite_pesquisa");
    obj.edit107.grid.role = "col";
    obj.edit107.grid.width = 12;
    obj.edit107:setHeight(30);
    obj.edit107:setFontFamily("Wishes Script Caps Display");
    obj.edit107:setReadOnly(true);
    obj.edit107:setTransparent(true);
    obj.edit107:setFontSize(20);
    obj.edit107:setHorzTextAlign("center");
    obj.edit107:setVertTextAlign("center");
    obj.edit107:setName("edit107");

    obj.rectangle169 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle169:setParent(obj.detalhes_pesquisa);
    obj.rectangle169:setHeight(25);
    obj.rectangle169:setColor("black");
    obj.rectangle169.grid.role = "col";
    obj.rectangle169.grid.width = 3;
    obj.rectangle169:setStrokeSize(1);
    obj.rectangle169:setStrokeColor("white");
    obj.rectangle169:setCornerType("round");
    obj.rectangle169:setName("rectangle169");

    obj.edit108 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit108:setParent(obj.rectangle169);
    obj.edit108:setField("extra_pesquisa");
    obj.edit108.grid.role = "col";
    obj.edit108.grid.width = 12;
    obj.edit108:setHeight(30);
    obj.edit108:setFontFamily("Wishes Script Caps Display");
    obj.edit108:setTransparent(true);
    obj.edit108:setFontSize(20);
    obj.edit108:setHorzTextAlign("center");
    obj.edit108:setVertTextAlign("center");
    obj.edit108:setName("edit108");

    obj.label187 = GUI.fromHandle(_obj_newObject("label"));
    obj.label187:setParent(obj.detalhes_pesquisa);
    obj.label187:setText("Descrição:");
    obj.label187.grid.role = "col";
    obj.label187.grid.width = 12;
    obj.label187:setHeight(20);
    obj.label187:setFontSize(12);
    obj.label187:setFontFamily("Wishes Script Caps Display");
    obj.label187:setMargins({top=5});
    obj.label187:setName("label187");

    obj.rectangle170 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle170:setParent(obj.detalhes_pesquisa);
    obj.rectangle170:setHeight(100);
    obj.rectangle170:setColor("black");
    obj.rectangle170.grid.role = "col";
    obj.rectangle170.grid.width = 12;
    obj.rectangle170:setStrokeSize(1);
    obj.rectangle170:setStrokeColor("white");
    obj.rectangle170:setCornerType("round");
    obj.rectangle170:setName("rectangle170");

    obj.textEditor34 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor34:setParent(obj.rectangle170);
    obj.textEditor34:setAlign("client");
    obj.textEditor34:setField("descricao_pesquisa");
    obj.textEditor34:setTransparent(true);
    obj.textEditor34:setReadOnly(true);
    obj.textEditor34:setName("textEditor34");

    obj.label188 = GUI.fromHandle(_obj_newObject("label"));
    obj.label188:setParent(obj.detalhes_pesquisa);
    obj.label188:setText("Progressão:");
    obj.label188.grid.role = "col";
    obj.label188.grid.width = 12;
    obj.label188:setHeight(20);
    obj.label188:setFontSize(12);
    obj.label188:setFontFamily("Wishes Script Caps Display");
    obj.label188:setMargins({top=5});
    obj.label188:setName("label188");

    obj.rectangle171 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle171:setParent(obj.detalhes_pesquisa);
    obj.rectangle171:setHeight(80);
    obj.rectangle171:setColor("black");
    obj.rectangle171.grid.role = "col";
    obj.rectangle171.grid.width = 12;
    obj.rectangle171:setStrokeSize(1);
    obj.rectangle171:setStrokeColor("white");
    obj.rectangle171:setCornerType("round");
    obj.rectangle171:setName("rectangle171");

    obj.textEditor35 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor35:setParent(obj.rectangle171);
    obj.textEditor35:setAlign("client");
    obj.textEditor35:setField("progressao_pesquisa");
    obj.textEditor35:setTransparent(true);
    obj.textEditor35:setReadOnly(true);
    obj.textEditor35:setName("textEditor35");

    obj.btn_mod_fabricacao = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_mod_fabricacao:setParent(obj.rectangle12);
    obj.btn_mod_fabricacao:setName("btn_mod_fabricacao");
    obj.btn_mod_fabricacao:setText("Ir para Modificadores de Fabricação");
    obj.btn_mod_fabricacao:setFontSize(20);
    obj.btn_mod_fabricacao.grid.role = "col";
    obj.btn_mod_fabricacao.grid.width = 6;
    obj.btn_mod_fabricacao:setFontFamily("Wishes Script Caps Display");
    obj.btn_mod_fabricacao:setHorzTextAlign("center");
    obj.btn_mod_fabricacao:setVertTextAlign("leading");
    obj.btn_mod_fabricacao:setFontColor("white");
    obj.btn_mod_fabricacao:setAlign("bottom");
    obj.btn_mod_fabricacao:setMargins({bottom=10,right=10,left=10});

    obj.rectangle172 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle172:setParent(obj.scrollBox2);
    obj.rectangle172:setColor("#150e16");
    obj.rectangle172:setStrokeSize(2);
    obj.rectangle172:setStrokeColor("white");
    obj.rectangle172.grid.role = "col";
    obj.rectangle172.grid.width = 4;
    obj.rectangle172.grid["max-width"] = 1080;
    obj.rectangle172.grid["min-width"] = 400;
    obj.rectangle172.grid["min-height"] = 550;
    obj.rectangle172.grid["max-height"] = 1080;
    obj.rectangle172:setMargins({top=15});
    obj.rectangle172:setName("rectangle172");

    obj.label189 = GUI.fromHandle(_obj_newObject("label"));
    obj.label189:setParent(obj.rectangle172);
    obj.label189:setHeight(25);
    obj.label189:setText("Background");
    obj.label189:setFontSize(50);
    obj.label189.grid.role = "col";
    obj.label189.grid.width = 12;
    obj.label189:setFontFamily("Wishes Script Caps Display");
    obj.label189:setHorzTextAlign("center");
    obj.label189:setMargins({top=15});
    obj.label189:setName("label189");

    obj.label190 = GUI.fromHandle(_obj_newObject("label"));
    obj.label190:setParent(obj.rectangle172);
    obj.label190:setHeight(25);
    obj.label190:setText("Origem:");
    obj.label190:setFontSize(15);
    obj.label190.grid.role = "col";
    obj.label190.grid.width = 4;
    obj.label190:setFontFamily("Wishes Script Caps Display");
    obj.label190:setHorzTextAlign("center");
    obj.label190:setMargins({top=10,left=10});
    obj.label190:setName("label190");

    obj.rectangle173 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle173:setParent(obj.rectangle172);
    obj.rectangle173:setHeight(25);
    obj.rectangle173:setColor("black");
    obj.rectangle173:setCornerType("round");
    obj.rectangle173.grid.role = "col";
    obj.rectangle173.grid.width = 8;
    obj.rectangle173:setStrokeSize(1);
    obj.rectangle173:setStrokeColor("white");
    obj.rectangle173:setXradius(5);
    obj.rectangle173:setYradius(5);
    obj.rectangle173:setMargins({top=10,right=10});
    obj.rectangle173:setName("rectangle173");

    obj.edit109 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit109:setParent(obj.rectangle173);
    obj.edit109:setHeight(30);
    obj.edit109:setField("origem");
    obj.edit109:setFontSize(25);
    obj.edit109.grid.role = "col";
    obj.edit109.grid.width = 12;
    obj.edit109:setFontFamily("Wishes Script Caps Display");
    obj.edit109:setTransparent(true);
    obj.edit109:setHorzTextAlign("center");
    obj.edit109:setName("edit109");

    obj.dataLink60 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink60:setParent(obj.rectangle173);
    obj.dataLink60:setField("origem");
    obj.dataLink60:setDefaultValue("Fazendeiro");
    obj.dataLink60:setName("dataLink60");

    obj.label191 = GUI.fromHandle(_obj_newObject("label"));
    obj.label191:setParent(obj.rectangle172);
    obj.label191:setHeight(25);
    obj.label191:setText("Tipo de Personagem:");
    obj.label191:setFontSize(15);
    obj.label191.grid.role = "col";
    obj.label191.grid.width = 4;
    obj.label191:setFontFamily("Wishes Script Caps Display");
    obj.label191:setHorzTextAlign("center");
    obj.label191:setMargins({top=5});
    obj.label191:setName("label191");

    obj.rectangle174 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle174:setParent(obj.rectangle172);
    obj.rectangle174:setHeight(25);
    obj.rectangle174:setColor("black");
    obj.rectangle174:setCornerType("round");
    obj.rectangle174.grid.role = "col";
    obj.rectangle174.grid.width = 8;
    obj.rectangle174:setStrokeSize(1);
    obj.rectangle174:setStrokeColor("white");
    obj.rectangle174:setXradius(5);
    obj.rectangle174:setYradius(5);
    obj.rectangle174:setMargins({top=5,right=10});
    obj.rectangle174:setName("rectangle174");

    obj.comboBox17 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox17:setParent(obj.rectangle174);
    obj.comboBox17:setField("tipodepersonagem");
    obj.comboBox17.grid.role = "col";
    obj.comboBox17.grid.width = 12;
    obj.comboBox17:setHeight(30);
    obj.comboBox17:setHorzTextAlign("center");
    obj.comboBox17:setFontFamily("Wishes Script Caps Display");
    obj.comboBox17:setTransparent(true);
    obj.comboBox17:setFontSize(20);
    obj.comboBox17:setItems({'Jogador', 'Nativo'});
    obj.comboBox17:setMargins({left=3,right=3});
    obj.comboBox17:setName("comboBox17");

    obj.dataLink61 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink61:setParent(obj.rectangle174);
    obj.dataLink61:setFields({'tipodepersonagem'});
    obj.dataLink61:setDefaultValues({'Nativo'});
    obj.dataLink61:setName("dataLink61");

    obj.rectangle175 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle175:setParent(obj.rectangle172);
    obj.rectangle175:setHeight(425);
    obj.rectangle175:setColor("black");
    obj.rectangle175:setCornerType("round");
    obj.rectangle175.grid.role = "col";
    obj.rectangle175.grid.width = 12;
    obj.rectangle175:setStrokeSize(1);
    obj.rectangle175:setStrokeColor("white");
    obj.rectangle175:setXradius(5);
    obj.rectangle175:setYradius(5);
    obj.rectangle175:setMargins({top=10,right=10,left=10});
    obj.rectangle175:setName("rectangle175");

    obj.richEdit1 = GUI.fromHandle(_obj_newObject("richEdit"));
    obj.richEdit1:setParent(obj.rectangle175);
    obj.richEdit1:setAlign("client");
    obj.richEdit1:setField("bg");
    obj.richEdit1.backgroundColor = "#000000";
    obj.richEdit1.defaultFontColor = "white";
    obj.richEdit1.hideSelection = true;
    obj.richEdit1.defaultFontSize = 16;
    obj.richEdit1.animateImages = true;
    obj.richEdit1:setMargins({top=3,right=3,left=3,bottom=3});
    obj.richEdit1:setName("richEdit1");

    obj.aba_skills = GUI.fromHandle(_obj_newObject("tab"));
    obj.aba_skills:setParent(obj.ficha);
    obj.aba_skills:setName("aba_skills");
    obj.aba_skills:setTitle("Skills");

    obj.rectangle176 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle176:setParent(obj.aba_skills);
    obj.rectangle176:setAlign("client");
    obj.rectangle176:setColor("black");
    obj.rectangle176:setName("rectangle176");

    obj.scrollBox5 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox5:setParent(obj.rectangle176);
    obj.scrollBox5:setAlign("client");
    obj.scrollBox5:setMargins({left=5,right=5});
    obj.scrollBox5:setName("scrollBox5");

    obj.rectangle177 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle177:setParent(obj.scrollBox5);
    obj.rectangle177:setColor("#150e16");
    obj.rectangle177:setStrokeSize(2);
    obj.rectangle177:setStrokeColor("white");
    obj.rectangle177.grid.role = "col";
    obj.rectangle177.grid.width = 4;
    obj.rectangle177.grid["max-width"] = 340;
    obj.rectangle177.grid["min-width"] = 300;
    obj.rectangle177.grid["min-height"] = 550;
    obj.rectangle177.grid["max-height"] = 1080;
    obj.rectangle177:setMargins({top=15});
    obj.rectangle177:setName("rectangle177");

    obj.label192 = GUI.fromHandle(_obj_newObject("label"));
    obj.label192:setParent(obj.rectangle177);
    obj.label192:setHeight(25);
    obj.label192:setText("Skills");
    obj.label192:setFontSize(50);
    obj.label192.grid.role = "col";
    obj.label192.grid.width = 12;
    obj.label192:setFontFamily("Wishes Script Caps Display");
    obj.label192:setHorzTextAlign("center");
    obj.label192:setMargins({top=15});
    obj.label192:setName("label192");

    obj.btnNovaSkill = GUI.fromHandle(_obj_newObject("button"));
    obj.btnNovaSkill:setParent(obj.rectangle177);
    obj.btnNovaSkill:setName("btnNovaSkill");
    obj.btnNovaSkill:setText("Adicionar Skill");
    obj.btnNovaSkill:setHeight(30);
    obj.btnNovaSkill.grid.role = "col";
    obj.btnNovaSkill.grid.width = 12;
    obj.btnNovaSkill:setMargins({top=5,right=5,left=5});


                        local filterSkillsArgument = "";
                        
                        local function prepFilterSkills(inputStr)
                            return string.lower(Utils.removerAcentos(inputStr or ""));
                        end;
                        
                        local function runSkillsFilter()           
                            filterSkillsArgument = prepFilterSkills(self.edtFiltroSkills.text);
                            self.listaskills:reorganize();
                        end;        
                        
                        local function checkSkillsFilter() 
                            local newArg = prepFilterSkills(self.edtFiltroSkills.text);
                            if newArg ~= filterSkillsArgument then
                                runSkillsFilter();
                            end;
                        end;
                    


    obj.tmrFiltroSkills = GUI.fromHandle(_obj_newObject("timer"));
    obj.tmrFiltroSkills:setParent(obj.rectangle177);
    obj.tmrFiltroSkills:setName("tmrFiltroSkills");
    obj.tmrFiltroSkills:setInterval(1000);

    obj.edtFiltroSkills = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtFiltroSkills:setParent(obj.rectangle177);
    obj.edtFiltroSkills.grid.role = "row";
    obj.edtFiltroSkills.grid["min-height"] = 25;
    obj.edtFiltroSkills:setTextPrompt("Buscar skill...");
    obj.edtFiltroSkills:setName("edtFiltroSkills");
    obj.edtFiltroSkills:setMargins({top=5,right=5,left=5});
    obj.edtFiltroSkills:setHint("Buscar skill ou tag...");

    obj.scrollBox6 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox6:setParent(obj.rectangle177);
    obj.scrollBox6.grid.role = "row";
    obj.scrollBox6.grid["vert-tile"] = true;
    obj.scrollBox6:setMargins({top=5,right=2,left=2,bottom=2});
    obj.scrollBox6.grid["cnt-gutter"] = 1;
    obj.scrollBox6:setName("scrollBox6");

    obj.listaskills = GUI.fromHandle(_obj_newObject("gridRecordList"));
    obj.listaskills:setParent(obj.scrollBox6);
    obj.listaskills:setName("listaskills");
    obj.listaskills.field = "itensSkills";
    obj.listaskills.templateForm = "templateSkills";
    obj.listaskills.minQt = 0;
    obj.listaskills.selectable = true;
    obj.listaskills:setHeight(600);
    obj.listaskills.grid.role = "col";
    obj.listaskills.grid.width = 12;


                            -- Função de reordenação específica para a nova lista
                            local function reordenarSkills()
                                local nodes = NDB.getChildNodes(sheet.itensSkills)
                                table.sort(nodes, function(a, b)
                                    return (tonumber(a.ordemSkill) or 0) < (tonumber(b.ordemSkill) or 0)
                                end)
                                self.listaskills:reorganize()
                            end

                            -- Configuração do botão de adicionar
                            self.btnNovaSkill.onClick = function()
                                local novo = self.listaskills:append()
                                if novo then
                                    novo.nomeSkill = "Nova Skill"
                                    novo.maestriaSkill = "Básica"
                                    novo.ordemSkill = #NDB.getChildNodes(sheet.itensSkills) + 1
                                    reordenarSkills()
                                end
                            end

                            -- Lógica de seleção: agora aponta para o dataScopeBox 'detalheSkill'
                            self.listaskills.onSelect = function()
                                local node = self.listaskills.selectedNode;
                                self.detalheSkill:setNodeObject(node);
                                self.detalheSkill.visible = (node ~= nil);

                                self.abertoPeloSlot = false;

                            
                            end;
                        


    obj.rectangle178 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle178:setParent(obj.scrollBox5);
    obj.rectangle178:setColor("#150e16");
    obj.rectangle178:setStrokeSize(2);
    obj.rectangle178:setStrokeColor("white");
    obj.rectangle178.grid.role = "col";
    obj.rectangle178.grid.width = 8;
    obj.rectangle178.grid["max-width"] = 1920;
    obj.rectangle178.grid["min-width"] = 400;
    obj.rectangle178.grid["min-height"] = 550;
    obj.rectangle178.grid["max-height"] = 1080;
    obj.rectangle178:setMargins({top=15});
    obj.rectangle178:setName("rectangle178");

    obj.detalheSkill = GUI.fromHandle(_obj_newObject("dataScopeBox"));
    obj.detalheSkill:setParent(obj.rectangle178);
    obj.detalheSkill:setName("detalheSkill");
    obj.detalheSkill:setAlign("client");
    obj.detalheSkill:setVisible(false);

    obj.label193 = GUI.fromHandle(_obj_newObject("label"));
    obj.label193:setParent(obj.detalheSkill);
    obj.label193:setText("Maetria:");
    obj.label193.grid.role = "col";
    obj.label193.grid.width = 1;
    obj.label193:setFontSize(10);
    obj.label193:setHeight(20);
    obj.label193:setHorzTextAlign("trailing");
    obj.label193:setFontFamily("Wishes Script Caps Display");
    obj.label193:setMargins({top=10,left=5});
    obj.label193:setName("label193");

    obj.rectangle179 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle179:setParent(obj.detalheSkill);
    obj.rectangle179:setHeight(20);
    obj.rectangle179:setColor("black");
    obj.rectangle179:setCornerType("round");
    obj.rectangle179.grid.role = "col";
    obj.rectangle179.grid.width = 2;
    obj.rectangle179:setStrokeSize(1);
    obj.rectangle179:setStrokeColor("white");
    obj.rectangle179:setXradius(5);
    obj.rectangle179:setYradius(5);
    obj.rectangle179:setMargins({top=5});
    obj.rectangle179:setName("rectangle179");

    obj.comboBox18 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox18:setParent(obj.rectangle179);
    obj.comboBox18:setField("maestriaSkill");
    obj.comboBox18.grid.role = "col";
    obj.comboBox18.grid.width = 12;
    obj.comboBox18:setHeight(18);
    obj.comboBox18:setHorzTextAlign("center");
    obj.comboBox18:setFontFamily("Cinzel");
    obj.comboBox18:setTransparent(true);
    obj.comboBox18:setFontSize(15);
    obj.comboBox18:setItems({'Básica','Intermediária','Avançada', 'Mestra', 'Suprema'});
    obj.comboBox18:setMargins({right=3});
    obj.comboBox18:setName("comboBox18");

    obj.label194 = GUI.fromHandle(_obj_newObject("label"));
    obj.label194:setParent(obj.detalheSkill);
    obj.label194:setHeight(20);
    obj.label194:setText("Nome:");
    obj.label194:setFontSize(15);
    obj.label194.grid.role = "col";
    obj.label194.grid.width = 1;
    obj.label194:setFontFamily("Wishes Script Caps Display");
    obj.label194:setHorzTextAlign("trailing");
    obj.label194:setMargins({top=10});
    obj.label194:setName("label194");

    obj.rectangle180 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle180:setParent(obj.detalheSkill);
    obj.rectangle180:setHeight(20);
    obj.rectangle180:setColor("black");
    obj.rectangle180:setCornerType("round");
    obj.rectangle180.grid.role = "col";
    obj.rectangle180.grid.width = 8;
    obj.rectangle180:setStrokeSize(1);
    obj.rectangle180:setStrokeColor("white");
    obj.rectangle180:setXradius(5);
    obj.rectangle180:setYradius(5);
    obj.rectangle180:setMargins({top=5});
    obj.rectangle180:setName("rectangle180");

    obj.edit110 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit110:setParent(obj.rectangle180);
    obj.edit110:setField("nomeSkill");
    obj.edit110.grid.role = "col";
    obj.edit110.grid.width = 12;
    obj.edit110:setTransparent(true);
    obj.edit110:setFontSize(15);
    obj.edit110:setHeight(21);
    obj.edit110:setVertTextAlign("center");
    obj.edit110:setHorzTextAlign("center");
    obj.edit110:setFontFamily("Wishes Script Caps Display");
    obj.edit110:setName("edit110");

    obj.rectangle181 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle181:setParent(obj.detalheSkill);
    obj.rectangle181:setHeight(20);
    obj.rectangle181:setColor("black");
    obj.rectangle181:setCornerType("round");
    obj.rectangle181.grid.role = "col";
    obj.rectangle181.grid.width = 12;
    obj.rectangle181:setStrokeSize(1);
    obj.rectangle181:setStrokeColor("white");
    obj.rectangle181:setXradius(5);
    obj.rectangle181:setYradius(5);
    obj.rectangle181:setMargins({top=5});
    obj.rectangle181:setName("rectangle181");

    obj.tagsSkill = GUI.fromHandle(_obj_newObject("edit"));
    obj.tagsSkill:setParent(obj.rectangle181);
    obj.tagsSkill:setName("tagsSkill");
    obj.tagsSkill:setField("tagsSkill");
    obj.tagsSkill.grid.role = "col";
    obj.tagsSkill.grid.width = 12;
    obj.tagsSkill:setTransparent(true);
    obj.tagsSkill:setFontSize(14);
    obj.tagsSkill:setHeight(20);
    obj.tagsSkill:setHorzTextAlign("center");
    obj.tagsSkill:setFontFamily("Wishes Script Caps Display");

    obj.dataLink62 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink62:setParent(obj.detalheSkill);
    obj.dataLink62:setField("tagsSkill");
    obj.dataLink62:setDefaultValue("Tags");
    obj.dataLink62:setName("dataLink62");

    obj.richEdit2 = GUI.fromHandle(_obj_newObject("richEdit"));
    obj.richEdit2:setParent(obj.detalheSkill);
    obj.richEdit2:setField("descricaoLongaSkill");
    obj.richEdit2:setAlign("client");
    obj.richEdit2.backgroundColor = "#000000";
    obj.richEdit2.defaultFontColor = "white";
    obj.richEdit2.hideSelection = true;
    obj.richEdit2.defaultFontSize = 14;
    obj.richEdit2.animateImages = true;
    obj.richEdit2:setMargins({top=60,right=4,left=4,bottom=4});
    obj.richEdit2:setName("richEdit2");

    obj.aba_inventario = GUI.fromHandle(_obj_newObject("tab"));
    obj.aba_inventario:setParent(obj.ficha);
    obj.aba_inventario:setName("aba_inventario");
    obj.aba_inventario:setTitle("Inventario");

    obj.rectangle182 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle182:setParent(obj.aba_inventario);
    obj.rectangle182:setAlign("client");
    obj.rectangle182:setColor("black");
    obj.rectangle182:setName("rectangle182");

    obj.scrollBox7 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox7:setParent(obj.rectangle182);
    obj.scrollBox7:setAlign("client");
    obj.scrollBox7:setMargins({left=5,right=5});
    obj.scrollBox7:setName("scrollBox7");

    obj.rectangle183 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle183:setParent(obj.scrollBox7);
    obj.rectangle183:setColor("#150e16");
    obj.rectangle183:setStrokeSize(2);
    obj.rectangle183:setStrokeColor("white");
    obj.rectangle183.grid.role = "col";
    obj.rectangle183.grid.width = 4;
    obj.rectangle183.grid["max-width"] = 340;
    obj.rectangle183.grid["min-width"] = 300;
    obj.rectangle183.grid["min-height"] = 550;
    obj.rectangle183.grid["max-height"] = 1080;
    obj.rectangle183:setMargins({top=15});
    obj.rectangle183:setName("rectangle183");

    obj.equipamentos_equipados = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.equipamentos_equipados:setParent(obj.rectangle183);
    obj.equipamentos_equipados:setColor("none");
    obj.equipamentos_equipados:setName("equipamentos_equipados");
    obj.equipamentos_equipados.grid.role = "col";
    obj.equipamentos_equipados.grid.width = 12;
    obj.equipamentos_equipados:setHeight(510);

    obj.image17 = GUI.fromHandle(_obj_newObject("image"));
    obj.image17:setParent(obj.equipamentos_equipados);
    obj.image17:setField("fundoequips");
    obj.image17:setEditable(false);
    obj.image17.animate = false;
    obj.image17:setStyle("proportional");
    obj.image17.grid.role = "col";
    obj.image17.grid.width = 12;
    obj.image17:setHeight(520);
    obj.image17:setSRC("https://blob.firecast.com.br/blobs/TNKACCID_4300210/07.png");
    obj.image17:setMargins({left=10, top=10, right=10,bottom=15});
    obj.image17:setName("image17");

    obj.rectangle184 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle184:setParent(obj.image17);
    obj.rectangle184:setHeight(70);
    obj.rectangle184:setColor("#150e16");
    obj.rectangle184:setCornerType("round");
    obj.rectangle184.grid.role = "col";
    obj.rectangle184.grid.width = 3;
    obj.rectangle184:setStrokeSize(1);
    obj.rectangle184:setStrokeColor("white");
    obj.rectangle184:setXradius(5);
    obj.rectangle184:setYradius(5);
    obj.rectangle184:setMargins({top=5,right=10,left=10});
    obj.rectangle184:setName("rectangle184");

    obj.btn_cabecaequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_cabecaequip:setParent(obj.rectangle184);
    obj.btn_cabecaequip:setAlign("client");
    obj.btn_cabecaequip:setName("btn_cabecaequip");
    obj.btn_cabecaequip.grid.role = "col";
    obj.btn_cabecaequip.grid.width = 12;
    obj.btn_cabecaequip:setHeight(64);
    obj.btn_cabecaequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image18 = GUI.fromHandle(_obj_newObject("image"));
    obj.image18:setParent(obj.btn_cabecaequip);
    obj.image18:setField("cabecaequip");
    obj.image18:setEditable(false);
    obj.image18.animate = true;
    obj.image18:setStyle("proportional");
    obj.image18.grid.role = "col";
    obj.image18.grid.width = 12;
    obj.image18:setHeight(64);
    obj.image18:setName("image18");

    obj.d1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d1:setParent(obj.image18);
    obj.d1:setName("d1");
    obj.d1:setField("d1");
    obj.d1:setVisible(false);
    obj.d1.grid.role = "col";
    obj.d1.grid.width = 12;
    obj.d1:setHeight(24);
    obj.d1:setFontSize(10);
    obj.d1:setHorzTextAlign("center");
    obj.d1:setMargins({left=5, top=20, right=5,bottom=20});

    obj.label195 = GUI.fromHandle(_obj_newObject("label"));
    obj.label195:setParent(obj.image17);
    obj.label195:setHeight(15);
    obj.label195.grid.role = "col";
    obj.label195.grid.width = 1;
    obj.label195:setMargins({top=10,left=10});
    obj.label195:setName("label195");

    obj.rectangle185 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle185:setParent(obj.image17);
    obj.rectangle185:setHeight(30);
    obj.rectangle185:setColor("#150e16");
    obj.rectangle185:setCornerType("round");
    obj.rectangle185.grid.role = "col";
    obj.rectangle185.grid.width = 4;
    obj.rectangle185:setStrokeSize(1);
    obj.rectangle185:setStrokeColor("white");
    obj.rectangle185:setXradius(5);
    obj.rectangle185:setYradius(5);
    obj.rectangle185:setName("rectangle185");

    obj.button15 = GUI.fromHandle(_obj_newObject("button"));
    obj.button15:setParent(obj.rectangle185);
    obj.button15:setAlign("client");
    obj.button15:setText("Durabilidades");
    obj.button15.grid.role = "col";
    obj.button15.grid.width = 12;
    obj.button15:setHeight(24);
    obj.button15:setFontSize(12);
    obj.button15:setMargins({left=3, top=3, right=3, bottom=3});
    obj.button15:setName("button15");

    obj.dataLink63 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink63:setParent(obj.rectangle185);
    obj.dataLink63:setFields({'d1', 'd2', 'd3', 'd4', 'd5', 'd6', 'd7', 'd8', 'd9', 'd10', 'd11', 'd12', 'd13', 'd14'});
    obj.dataLink63:setDefaultValues({'100%', '100%', '100%', '100%', '100%', '100%', '100%', '100%', '100%', '100%', '100%', '100%', '100%', '100%'});
    obj.dataLink63:setName("dataLink63");

    obj.dataLink64 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink64:setParent(obj.rectangle185);
    obj.dataLink64:setFields({'cabecaequip', 'maoesquerdaequip', 'ombroequip', 'pescocoequip', 'torsoequip', 'costasequip', 'maodireitaequip', 'cintoequip', 'armadireitaequip', 'armaesquerdaequip', 'botaequip', 'pernaequip', 'acessorio1equip', 'acessorio2equip'});
    obj.dataLink64:setDefaultValues({'http://blob.firecast.com.br/blobs/VSBKJVLE_3196991/capacete.png', 'http://blob.firecast.com.br/blobs/MHJOGVIJ_3197013/mao_esquerda.png', 'http://blob.firecast.com.br/blobs/VWWCJLAI_3197011/ombros.png', 'http://blob.firecast.com.br/blobs/KQTJSRMC_3196994/colar.png', 'http://blob.firecast.com.br/blobs/BHSFRPKJ_3197012/torso.png', 'http://blob.firecast.com.br/blobs/PFNJLMSL_3196996/costas.png', 'http://blob.firecast.com.br/blobs/KAOFDIWM_3196998/mao_direita.png', 'http://blob.firecast.com.br/blobs/VIKSJTAS_3196995/cinto.png', 'http://blob.firecast.com.br/blobs/MRUHMKWV_3196993/arma_direita.png', 'http://blob.firecast.com.br/blobs/QQBQUNJS_3196992/arma_esqueda.png', 'http://blob.firecast.com.br/blobs/ODHJPRVJ_3196989/bota.png', 'http://blob.firecast.com.br/blobs/ADULDOEJ_3196997/cal_a.png', 'http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png', 'http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png'});
    obj.dataLink64:setName("dataLink64");

    obj.label196 = GUI.fromHandle(_obj_newObject("label"));
    obj.label196:setParent(obj.image17);
    obj.label196:setHeight(15);
    obj.label196.grid.role = "col";
    obj.label196.grid.width = 1;
    obj.label196:setMargins({top=10,left=10});
    obj.label196:setName("label196");

    obj.rectangle186 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle186:setParent(obj.image17);
    obj.rectangle186:setHeight(70);
    obj.rectangle186:setColor("#150e16");
    obj.rectangle186:setCornerType("round");
    obj.rectangle186.grid.role = "col";
    obj.rectangle186.grid.width = 3;
    obj.rectangle186:setStrokeSize(1);
    obj.rectangle186:setStrokeColor("white");
    obj.rectangle186:setXradius(5);
    obj.rectangle186:setYradius(5);
    obj.rectangle186:setMargins({top=5,right=10,left=10});
    obj.rectangle186:setName("rectangle186");

    obj.btn_maoesquerdaequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_maoesquerdaequip:setParent(obj.rectangle186);
    obj.btn_maoesquerdaequip:setAlign("client");
    obj.btn_maoesquerdaequip:setName("btn_maoesquerdaequip");
    obj.btn_maoesquerdaequip.grid.role = "col";
    obj.btn_maoesquerdaequip.grid.width = 12;
    obj.btn_maoesquerdaequip:setHeight(64);
    obj.btn_maoesquerdaequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image19 = GUI.fromHandle(_obj_newObject("image"));
    obj.image19:setParent(obj.btn_maoesquerdaequip);
    obj.image19:setField("maoesquerdaequip");
    obj.image19:setEditable(false);
    obj.image19.animate = true;
    obj.image19:setStyle("proportional");
    obj.image19.grid.role = "col";
    obj.image19.grid.width = 12;
    obj.image19:setHeight(64);
    obj.image19:setName("image19");

    obj.d2 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d2:setParent(obj.image19);
    obj.d2:setName("d2");
    obj.d2:setField("d2");
    obj.d2:setVisible(false);
    obj.d2.grid.role = "col";
    obj.d2.grid.width = 12;
    obj.d2:setHeight(24);
    obj.d2:setFontSize(10);
    obj.d2:setHorzTextAlign("center");
    obj.d2:setMargins({left=5, top=20, right=5,bottom=20});

    obj.rectangle187 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle187:setParent(obj.image17);
    obj.rectangle187:setHeight(70);
    obj.rectangle187:setColor("#150e16");
    obj.rectangle187:setCornerType("round");
    obj.rectangle187.grid.role = "col";
    obj.rectangle187.grid.width = 3;
    obj.rectangle187:setStrokeSize(1);
    obj.rectangle187:setStrokeColor("white");
    obj.rectangle187:setXradius(5);
    obj.rectangle187:setYradius(5);
    obj.rectangle187:setMargins({top=5,right=10,left=10});
    obj.rectangle187:setName("rectangle187");

    obj.btn_ombroequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_ombroequip:setParent(obj.rectangle187);
    obj.btn_ombroequip:setAlign("client");
    obj.btn_ombroequip:setName("btn_ombroequip");
    obj.btn_ombroequip.grid.role = "col";
    obj.btn_ombroequip.grid.width = 12;
    obj.btn_ombroequip:setHeight(64);
    obj.btn_ombroequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image20 = GUI.fromHandle(_obj_newObject("image"));
    obj.image20:setParent(obj.btn_ombroequip);
    obj.image20:setField("ombroequip");
    obj.image20:setEditable(false);
    obj.image20.animate = true;
    obj.image20:setStyle("proportional");
    obj.image20.grid.role = "col";
    obj.image20.grid.width = 12;
    obj.image20:setHeight(64);
    obj.image20:setName("image20");

    obj.d3 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d3:setParent(obj.image20);
    obj.d3:setName("d3");
    obj.d3:setField("d3");
    obj.d3:setVisible(false);
    obj.d3.grid.role = "col";
    obj.d3.grid.width = 12;
    obj.d3:setHeight(24);
    obj.d3:setFontSize(10);
    obj.d3:setHorzTextAlign("center");
    obj.d3:setMargins({left=5, top=20, right=5,bottom=20});

    obj.label197 = GUI.fromHandle(_obj_newObject("label"));
    obj.label197:setParent(obj.image17);
    obj.label197:setHeight(15);
    obj.label197.grid.role = "col";
    obj.label197.grid.width = 6;
    obj.label197:setMargins({top=10,left=10});
    obj.label197:setName("label197");

    obj.rectangle188 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle188:setParent(obj.image17);
    obj.rectangle188:setHeight(70);
    obj.rectangle188:setColor("#150e16");
    obj.rectangle188:setCornerType("round");
    obj.rectangle188.grid.role = "col";
    obj.rectangle188.grid.width = 3;
    obj.rectangle188:setStrokeSize(1);
    obj.rectangle188:setStrokeColor("white");
    obj.rectangle188:setXradius(5);
    obj.rectangle188:setYradius(5);
    obj.rectangle188:setMargins({top=5,right=10,left=10});
    obj.rectangle188:setName("rectangle188");

    obj.btn_pescocoequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_pescocoequip:setParent(obj.rectangle188);
    obj.btn_pescocoequip:setAlign("client");
    obj.btn_pescocoequip:setName("btn_pescocoequip");
    obj.btn_pescocoequip.grid.role = "col";
    obj.btn_pescocoequip.grid.width = 12;
    obj.btn_pescocoequip:setHeight(64);
    obj.btn_pescocoequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image21 = GUI.fromHandle(_obj_newObject("image"));
    obj.image21:setParent(obj.btn_pescocoequip);
    obj.image21:setField("pescocoequip");
    obj.image21:setEditable(false);
    obj.image21.animate = true;
    obj.image21:setStyle("proportional");
    obj.image21.grid.role = "col";
    obj.image21.grid.width = 12;
    obj.image21:setHeight(64);
    obj.image21:setName("image21");

    obj.d4 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d4:setParent(obj.image21);
    obj.d4:setName("d4");
    obj.d4:setField("d4");
    obj.d4:setVisible(false);
    obj.d4.grid.role = "col";
    obj.d4.grid.width = 12;
    obj.d4:setHeight(24);
    obj.d4:setFontSize(10);
    obj.d4:setHorzTextAlign("center");
    obj.d4:setMargins({left=5, top=20, right=5,bottom=20});

    obj.rectangle189 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle189:setParent(obj.image17);
    obj.rectangle189:setHeight(70);
    obj.rectangle189:setColor("#150e16");
    obj.rectangle189:setCornerType("round");
    obj.rectangle189.grid.role = "col";
    obj.rectangle189.grid.width = 3;
    obj.rectangle189:setStrokeSize(1);
    obj.rectangle189:setStrokeColor("white");
    obj.rectangle189:setXradius(5);
    obj.rectangle189:setYradius(5);
    obj.rectangle189:setMargins({top=5,right=10,left=10});
    obj.rectangle189:setName("rectangle189");

    obj.btn_torsoequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_torsoequip:setParent(obj.rectangle189);
    obj.btn_torsoequip:setAlign("client");
    obj.btn_torsoequip:setName("btn_torsoequip");
    obj.btn_torsoequip.grid.role = "col";
    obj.btn_torsoequip.grid.width = 12;
    obj.btn_torsoequip:setHeight(64);
    obj.btn_torsoequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image22 = GUI.fromHandle(_obj_newObject("image"));
    obj.image22:setParent(obj.btn_torsoequip);
    obj.image22:setField("torsoequip");
    obj.image22:setEditable(false);
    obj.image22.animate = true;
    obj.image22:setStyle("proportional");
    obj.image22.grid.role = "col";
    obj.image22.grid.width = 12;
    obj.image22:setHeight(64);
    obj.image22:setName("image22");

    obj.d5 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d5:setParent(obj.image22);
    obj.d5:setName("d5");
    obj.d5:setField("d5");
    obj.d5:setVisible(false);
    obj.d5.grid.role = "col";
    obj.d5.grid.width = 12;
    obj.d5:setHeight(24);
    obj.d5:setFontSize(10);
    obj.d5:setHorzTextAlign("center");
    obj.d5:setMargins({left=5, top=20, right=5,bottom=20});

    obj.label198 = GUI.fromHandle(_obj_newObject("label"));
    obj.label198:setParent(obj.image17);
    obj.label198:setHeight(15);
    obj.label198.grid.role = "col";
    obj.label198.grid.width = 6;
    obj.label198:setMargins({top=10,left=10});
    obj.label198:setName("label198");

    obj.rectangle190 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle190:setParent(obj.image17);
    obj.rectangle190:setHeight(70);
    obj.rectangle190:setColor("#150e16");
    obj.rectangle190:setCornerType("round");
    obj.rectangle190.grid.role = "col";
    obj.rectangle190.grid.width = 3;
    obj.rectangle190:setStrokeSize(1);
    obj.rectangle190:setStrokeColor("white");
    obj.rectangle190:setXradius(5);
    obj.rectangle190:setYradius(5);
    obj.rectangle190:setMargins({top=5,right=10,left=10});
    obj.rectangle190:setName("rectangle190");

    obj.btn_costasequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_costasequip:setParent(obj.rectangle190);
    obj.btn_costasequip:setAlign("client");
    obj.btn_costasequip:setName("btn_costasequip");
    obj.btn_costasequip.grid.role = "col";
    obj.btn_costasequip.grid.width = 12;
    obj.btn_costasequip:setHeight(64);
    obj.btn_costasequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image23 = GUI.fromHandle(_obj_newObject("image"));
    obj.image23:setParent(obj.btn_costasequip);
    obj.image23:setField("costasequip");
    obj.image23:setEditable(false);
    obj.image23.animate = true;
    obj.image23:setStyle("proportional");
    obj.image23.grid.role = "col";
    obj.image23.grid.width = 12;
    obj.image23:setHeight(64);
    obj.image23:setName("image23");

    obj.d6 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d6:setParent(obj.image23);
    obj.d6:setName("d6");
    obj.d6:setField("d6");
    obj.d6:setVisible(false);
    obj.d6.grid.role = "col";
    obj.d6.grid.width = 12;
    obj.d6:setHeight(24);
    obj.d6:setFontSize(10);
    obj.d6:setHorzTextAlign("center");
    obj.d6:setMargins({left=5, top=20, right=5,bottom=20});

    obj.rectangle191 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle191:setParent(obj.image17);
    obj.rectangle191:setHeight(70);
    obj.rectangle191:setColor("#150e16");
    obj.rectangle191:setCornerType("round");
    obj.rectangle191.grid.role = "col";
    obj.rectangle191.grid.width = 3;
    obj.rectangle191:setStrokeSize(1);
    obj.rectangle191:setStrokeColor("white");
    obj.rectangle191:setXradius(5);
    obj.rectangle191:setYradius(5);
    obj.rectangle191:setMargins({top=5,right=10,left=10});
    obj.rectangle191:setName("rectangle191");

    obj.btn_maodireitaequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_maodireitaequip:setParent(obj.rectangle191);
    obj.btn_maodireitaequip:setAlign("client");
    obj.btn_maodireitaequip:setName("btn_maodireitaequip");
    obj.btn_maodireitaequip.grid.role = "col";
    obj.btn_maodireitaequip.grid.width = 12;
    obj.btn_maodireitaequip:setHeight(64);
    obj.btn_maodireitaequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image24 = GUI.fromHandle(_obj_newObject("image"));
    obj.image24:setParent(obj.btn_maodireitaequip);
    obj.image24:setField("maodireitaequip");
    obj.image24:setEditable(false);
    obj.image24.animate = true;
    obj.image24:setStyle("proportional");
    obj.image24.grid.role = "col";
    obj.image24.grid.width = 12;
    obj.image24:setHeight(64);
    obj.image24:setName("image24");

    obj.d7 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d7:setParent(obj.image24);
    obj.d7:setName("d7");
    obj.d7:setField("d7");
    obj.d7:setVisible(false);
    obj.d7.grid.role = "col";
    obj.d7.grid.width = 12;
    obj.d7:setHeight(24);
    obj.d7:setFontSize(10);
    obj.d7:setHorzTextAlign("center");
    obj.d7:setMargins({left=5, top=20, right=5,bottom=20});

    obj.label199 = GUI.fromHandle(_obj_newObject("label"));
    obj.label199:setParent(obj.image17);
    obj.label199:setHeight(15);
    obj.label199.grid.role = "col";
    obj.label199.grid.width = 6;
    obj.label199:setMargins({top=10,left=10});
    obj.label199:setName("label199");

    obj.rectangle192 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle192:setParent(obj.image17);
    obj.rectangle192:setHeight(70);
    obj.rectangle192:setColor("#150e16");
    obj.rectangle192:setCornerType("round");
    obj.rectangle192.grid.role = "col";
    obj.rectangle192.grid.width = 3;
    obj.rectangle192:setStrokeSize(1);
    obj.rectangle192:setStrokeColor("white");
    obj.rectangle192:setXradius(5);
    obj.rectangle192:setYradius(5);
    obj.rectangle192:setMargins({top=5,right=10,left=10});
    obj.rectangle192:setName("rectangle192");

    obj.btn_cintoequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_cintoequip:setParent(obj.rectangle192);
    obj.btn_cintoequip:setAlign("client");
    obj.btn_cintoequip:setName("btn_cintoequip");
    obj.btn_cintoequip.grid.role = "col";
    obj.btn_cintoequip.grid.width = 12;
    obj.btn_cintoequip:setHeight(64);
    obj.btn_cintoequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image25 = GUI.fromHandle(_obj_newObject("image"));
    obj.image25:setParent(obj.btn_cintoequip);
    obj.image25:setField("cintoequip");
    obj.image25:setEditable(false);
    obj.image25.animate = true;
    obj.image25:setStyle("proportional");
    obj.image25.grid.role = "col";
    obj.image25.grid.width = 12;
    obj.image25:setHeight(64);
    obj.image25:setName("image25");

    obj.d8 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d8:setParent(obj.image25);
    obj.d8:setName("d8");
    obj.d8:setField("d8");
    obj.d8:setVisible(false);
    obj.d8.grid.role = "col";
    obj.d8.grid.width = 12;
    obj.d8:setHeight(24);
    obj.d8:setFontSize(10);
    obj.d8:setHorzTextAlign("center");
    obj.d8:setMargins({left=5, top=20, right=5,bottom=20});

    obj.rectangle193 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle193:setParent(obj.image17);
    obj.rectangle193:setHeight(70);
    obj.rectangle193:setColor("#150e16");
    obj.rectangle193:setCornerType("round");
    obj.rectangle193.grid.role = "col";
    obj.rectangle193.grid.width = 3;
    obj.rectangle193:setStrokeSize(1);
    obj.rectangle193:setStrokeColor("white");
    obj.rectangle193:setXradius(5);
    obj.rectangle193:setYradius(5);
    obj.rectangle193:setMargins({top=5,right=10,left=10});
    obj.rectangle193:setName("rectangle193");

    obj.btn_armadireitaequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_armadireitaequip:setParent(obj.rectangle193);
    obj.btn_armadireitaequip:setAlign("client");
    obj.btn_armadireitaequip:setName("btn_armadireitaequip");
    obj.btn_armadireitaequip.grid.role = "col";
    obj.btn_armadireitaequip.grid.width = 12;
    obj.btn_armadireitaequip:setHeight(64);
    obj.btn_armadireitaequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image26 = GUI.fromHandle(_obj_newObject("image"));
    obj.image26:setParent(obj.btn_armadireitaequip);
    obj.image26:setField("armadireitaequip");
    obj.image26:setEditable(false);
    obj.image26.animate = true;
    obj.image26:setStyle("proportional");
    obj.image26.grid.role = "col";
    obj.image26.grid.width = 12;
    obj.image26:setHeight(64);
    obj.image26:setName("image26");

    obj.d9 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d9:setParent(obj.image26);
    obj.d9:setName("d9");
    obj.d9:setField("d9");
    obj.d9:setVisible(false);
    obj.d9.grid.role = "col";
    obj.d9.grid.width = 12;
    obj.d9:setHeight(24);
    obj.d9:setFontSize(10);
    obj.d9:setHorzTextAlign("center");
    obj.d9:setMargins({left=5, top=20, right=5,bottom=20});

    obj.label200 = GUI.fromHandle(_obj_newObject("label"));
    obj.label200:setParent(obj.image17);
    obj.label200:setHeight(15);
    obj.label200.grid.role = "col";
    obj.label200.grid.width = 6;
    obj.label200:setMargins({top=10,left=10});
    obj.label200:setName("label200");

    obj.rectangle194 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle194:setParent(obj.image17);
    obj.rectangle194:setHeight(70);
    obj.rectangle194:setColor("#150e16");
    obj.rectangle194:setCornerType("round");
    obj.rectangle194.grid.role = "col";
    obj.rectangle194.grid.width = 3;
    obj.rectangle194:setStrokeSize(1);
    obj.rectangle194:setStrokeColor("white");
    obj.rectangle194:setXradius(5);
    obj.rectangle194:setYradius(5);
    obj.rectangle194:setMargins({top=5,right=10,left=10});
    obj.rectangle194:setName("rectangle194");

    obj.btn_armaesquerdaequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_armaesquerdaequip:setParent(obj.rectangle194);
    obj.btn_armaesquerdaequip:setAlign("client");
    obj.btn_armaesquerdaequip:setName("btn_armaesquerdaequip");
    obj.btn_armaesquerdaequip.grid.role = "col";
    obj.btn_armaesquerdaequip.grid.width = 12;
    obj.btn_armaesquerdaequip:setHeight(64);
    obj.btn_armaesquerdaequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image27 = GUI.fromHandle(_obj_newObject("image"));
    obj.image27:setParent(obj.btn_armaesquerdaequip);
    obj.image27:setField("armaesquerdaequip");
    obj.image27:setEditable(false);
    obj.image27.animate = true;
    obj.image27:setStyle("proportional");
    obj.image27.grid.role = "col";
    obj.image27.grid.width = 12;
    obj.image27:setHeight(64);
    obj.image27:setName("image27");

    obj.d10 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d10:setParent(obj.image27);
    obj.d10:setName("d10");
    obj.d10:setField("d10");
    obj.d10:setVisible(false);
    obj.d10.grid.role = "col";
    obj.d10.grid.width = 12;
    obj.d10:setHeight(24);
    obj.d10:setFontSize(10);
    obj.d10:setHorzTextAlign("center");
    obj.d10:setMargins({left=5, top=20, right=5,bottom=20});

    obj.rectangle195 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle195:setParent(obj.image17);
    obj.rectangle195:setHeight(70);
    obj.rectangle195:setColor("#150e16");
    obj.rectangle195:setCornerType("round");
    obj.rectangle195.grid.role = "col";
    obj.rectangle195.grid.width = 3;
    obj.rectangle195:setStrokeSize(1);
    obj.rectangle195:setStrokeColor("white");
    obj.rectangle195:setXradius(5);
    obj.rectangle195:setYradius(5);
    obj.rectangle195:setMargins({top=5,right=10,left=10});
    obj.rectangle195:setName("rectangle195");

    obj.btn_botaequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_botaequip:setParent(obj.rectangle195);
    obj.btn_botaequip:setAlign("client");
    obj.btn_botaequip:setName("btn_botaequip");
    obj.btn_botaequip.grid.role = "col";
    obj.btn_botaequip.grid.width = 12;
    obj.btn_botaequip:setHeight(64);
    obj.btn_botaequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image28 = GUI.fromHandle(_obj_newObject("image"));
    obj.image28:setParent(obj.btn_botaequip);
    obj.image28:setField("botaequip");
    obj.image28:setEditable(false);
    obj.image28.animate = true;
    obj.image28:setStyle("proportional");
    obj.image28.grid.role = "col";
    obj.image28.grid.width = 12;
    obj.image28:setHeight(64);
    obj.image28:setName("image28");

    obj.d11 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d11:setParent(obj.image28);
    obj.d11:setName("d11");
    obj.d11:setField("d11");
    obj.d11:setVisible(false);
    obj.d11.grid.role = "col";
    obj.d11.grid.width = 12;
    obj.d11:setHeight(24);
    obj.d11:setFontSize(10);
    obj.d11:setHorzTextAlign("center");
    obj.d11:setMargins({left=5, top=20, right=5,bottom=20});

    obj.label201 = GUI.fromHandle(_obj_newObject("label"));
    obj.label201:setParent(obj.image17);
    obj.label201:setHeight(15);
    obj.label201.grid.role = "col";
    obj.label201.grid.width = 6;
    obj.label201:setMargins({top=10,left=10});
    obj.label201:setName("label201");

    obj.rectangle196 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle196:setParent(obj.image17);
    obj.rectangle196:setHeight(70);
    obj.rectangle196:setColor("#150e16");
    obj.rectangle196:setCornerType("round");
    obj.rectangle196.grid.role = "col";
    obj.rectangle196.grid.width = 3;
    obj.rectangle196:setStrokeSize(1);
    obj.rectangle196:setStrokeColor("white");
    obj.rectangle196:setXradius(5);
    obj.rectangle196:setYradius(5);
    obj.rectangle196:setMargins({top=5,right=10,left=10});
    obj.rectangle196:setName("rectangle196");

    obj.btn_pernaequip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_pernaequip:setParent(obj.rectangle196);
    obj.btn_pernaequip:setAlign("client");
    obj.btn_pernaequip:setName("btn_pernaequip");
    obj.btn_pernaequip.grid.role = "col";
    obj.btn_pernaequip.grid.width = 12;
    obj.btn_pernaequip:setHeight(64);
    obj.btn_pernaequip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image29 = GUI.fromHandle(_obj_newObject("image"));
    obj.image29:setParent(obj.btn_pernaequip);
    obj.image29:setField("pernaequip");
    obj.image29:setEditable(false);
    obj.image29.animate = true;
    obj.image29:setStyle("proportional");
    obj.image29.grid.role = "col";
    obj.image29.grid.width = 12;
    obj.image29:setHeight(64);
    obj.image29:setName("image29");

    obj.d12 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d12:setParent(obj.image29);
    obj.d12:setName("d12");
    obj.d12:setField("d12");
    obj.d12:setVisible(false);
    obj.d12.grid.role = "col";
    obj.d12.grid.width = 12;
    obj.d12:setHeight(24);
    obj.d12:setFontSize(10);
    obj.d12:setHorzTextAlign("center");
    obj.d12:setMargins({left=5, top=20, right=5,bottom=20});

    obj.rectangle197 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle197:setParent(obj.image17);
    obj.rectangle197:setHeight(70);
    obj.rectangle197:setColor("#150e16");
    obj.rectangle197:setCornerType("round");
    obj.rectangle197.grid.role = "col";
    obj.rectangle197.grid.width = 3;
    obj.rectangle197:setStrokeSize(1);
    obj.rectangle197:setStrokeColor("white");
    obj.rectangle197:setXradius(5);
    obj.rectangle197:setYradius(5);
    obj.rectangle197:setMargins({top=5,right=10,left=10});
    obj.rectangle197:setName("rectangle197");

    obj.btn_acessorio1equip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_acessorio1equip:setParent(obj.rectangle197);
    obj.btn_acessorio1equip:setAlign("client");
    obj.btn_acessorio1equip:setName("btn_acessorio1equip");
    obj.btn_acessorio1equip.grid.role = "col";
    obj.btn_acessorio1equip.grid.width = 12;
    obj.btn_acessorio1equip:setHeight(64);
    obj.btn_acessorio1equip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image30 = GUI.fromHandle(_obj_newObject("image"));
    obj.image30:setParent(obj.btn_acessorio1equip);
    obj.image30:setField("acessorio1equip");
    obj.image30:setEditable(false);
    obj.image30.animate = true;
    obj.image30:setStyle("proportional");
    obj.image30.grid.role = "col";
    obj.image30.grid.width = 12;
    obj.image30:setHeight(64);
    obj.image30:setName("image30");

    obj.d13 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d13:setParent(obj.image30);
    obj.d13:setName("d13");
    obj.d13:setField("d13");
    obj.d13:setVisible(false);
    obj.d13.grid.role = "col";
    obj.d13.grid.width = 12;
    obj.d13:setHeight(24);
    obj.d13:setFontSize(10);
    obj.d13:setHorzTextAlign("center");
    obj.d13:setMargins({left=5, top=20, right=5,bottom=20});

    obj.label202 = GUI.fromHandle(_obj_newObject("label"));
    obj.label202:setParent(obj.image17);
    obj.label202:setHeight(15);
    obj.label202.grid.role = "col";
    obj.label202.grid.width = 6;
    obj.label202:setMargins({top=10,left=10});
    obj.label202:setName("label202");

    obj.rectangle198 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle198:setParent(obj.image17);
    obj.rectangle198:setHeight(70);
    obj.rectangle198:setColor("#150e16");
    obj.rectangle198:setCornerType("round");
    obj.rectangle198.grid.role = "col";
    obj.rectangle198.grid.width = 3;
    obj.rectangle198:setStrokeSize(1);
    obj.rectangle198:setStrokeColor("white");
    obj.rectangle198:setXradius(5);
    obj.rectangle198:setYradius(5);
    obj.rectangle198:setMargins({top=5,right=10,left=10});
    obj.rectangle198:setName("rectangle198");

    obj.btn_acessorio2equip = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_acessorio2equip:setParent(obj.rectangle198);
    obj.btn_acessorio2equip:setAlign("client");
    obj.btn_acessorio2equip:setName("btn_acessorio2equip");
    obj.btn_acessorio2equip.grid.role = "col";
    obj.btn_acessorio2equip.grid.width = 12;
    obj.btn_acessorio2equip:setHeight(64);
    obj.btn_acessorio2equip:setMargins({left=3, top=3, right=3,bottom=3});

    obj.image31 = GUI.fromHandle(_obj_newObject("image"));
    obj.image31:setParent(obj.btn_acessorio2equip);
    obj.image31:setField("acessorio2equip");
    obj.image31:setEditable(false);
    obj.image31.animate = true;
    obj.image31:setStyle("proportional");
    obj.image31.grid.role = "col";
    obj.image31.grid.width = 12;
    obj.image31:setHeight(64);
    obj.image31:setName("image31");

    obj.d14 = GUI.fromHandle(_obj_newObject("edit"));
    obj.d14:setParent(obj.image31);
    obj.d14:setName("d14");
    obj.d14:setField("d14");
    obj.d14:setVisible(false);
    obj.d14.grid.role = "col";
    obj.d14.grid.width = 12;
    obj.d14:setHeight(24);
    obj.d14:setFontSize(10);
    obj.d14:setHorzTextAlign("center");
    obj.d14:setMargins({left=5, top=20, right=5,bottom=20});

    obj.lista_equipamentos = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.lista_equipamentos:setParent(obj.rectangle183);
    obj.lista_equipamentos:setColor("none");
    obj.lista_equipamentos:setName("lista_equipamentos");
    obj.lista_equipamentos.grid.role = "col";
    obj.lista_equipamentos.grid.width = 12;
    obj.lista_equipamentos:setHeight(510);
    obj.lista_equipamentos:setVisible(false);

    obj.label203 = GUI.fromHandle(_obj_newObject("label"));
    obj.label203:setParent(obj.lista_equipamentos);
    obj.label203:setHeight(25);
    obj.label203:setText("Inventário");
    obj.label203:setFontSize(50);
    obj.label203.grid.role = "col";
    obj.label203.grid.width = 12;
    obj.label203:setFontFamily("Wishes Script Caps Display");
    obj.label203:setHorzTextAlign("center");
    obj.label203:setMargins({top=15});
    obj.label203:setName("label203");

    obj.btnNovoEquipamento = GUI.fromHandle(_obj_newObject("button"));
    obj.btnNovoEquipamento:setParent(obj.lista_equipamentos);
    obj.btnNovoEquipamento:setName("btnNovoEquipamento");
    obj.btnNovoEquipamento:setText("Adicionar Item");
    obj.btnNovoEquipamento:setHeight(30);
    obj.btnNovoEquipamento.grid.role = "col";
    obj.btnNovoEquipamento.grid.width = 12;
    obj.btnNovoEquipamento:setMargins({top=5,right=5,left=5});


                        local filterEquipArgument = "";
                        
                        local function prepFilterEquip(inputStr)
                            return string.lower(Utils.removerAcentos(inputStr or ""));
                        end;
                        
                        local function runEquipFilter()           
                            filterEquipArgument = prepFilterEquip(self.edtFiltroEquipamentos.text);
                            self.listaequipamento:reorganize();
                        end;        
                        
                        local function checkEquipFilter() 
                            local newArg = prepFilterEquip(self.edtFiltroEquipamentos.text);
                            if newArg ~= filterEquipArgument then
                                runEquipFilter();
                            end;
                        end;
                    


    obj.tmrFiltroEquipamentos = GUI.fromHandle(_obj_newObject("timer"));
    obj.tmrFiltroEquipamentos:setParent(obj.lista_equipamentos);
    obj.tmrFiltroEquipamentos:setName("tmrFiltroEquipamentos");
    obj.tmrFiltroEquipamentos:setInterval(1000);

    obj.edtFiltroEquipamentos = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtFiltroEquipamentos:setParent(obj.lista_equipamentos);
    obj.edtFiltroEquipamentos.grid.role = "row";
    obj.edtFiltroEquipamentos.grid["min-height"] = 25;
    obj.edtFiltroEquipamentos:setTextPrompt("Buscar equipamento...");
    obj.edtFiltroEquipamentos:setName("edtFiltroEquipamentos");
    obj.edtFiltroEquipamentos:setMargins({top=5,right=5,left=5});
    obj.edtFiltroEquipamentos:setHint("Buscar item ou tag...");

    obj.scrollBox8 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox8:setParent(obj.lista_equipamentos);
    obj.scrollBox8.grid.role = "row";
    obj.scrollBox8.grid["vert-tile"] = true;
    obj.scrollBox8:setMargins({top=5,right=2,left=2,bottom=2});
    obj.scrollBox8.grid["cnt-gutter"] = 1;
    obj.scrollBox8:setName("scrollBox8");

    obj.listaequipamento = GUI.fromHandle(_obj_newObject("gridRecordList"));
    obj.listaequipamento:setParent(obj.scrollBox8);
    obj.listaequipamento:setName("listaequipamento");
    obj.listaequipamento.field = "itensEquipamento";
    obj.listaequipamento.templateForm = "templateEquipamentoItem";
    obj.listaequipamento.minQt = 0;
    obj.listaequipamento.selectable = true;
    obj.listaequipamento:setHeight(550);
    obj.listaequipamento.grid.role = "col";
    obj.listaequipamento.grid.width = 12;


                            -- Função de reordenação específica para a nova lista
                            local function reordenarEquips()
                                local nodes = NDB.getChildNodes(sheet.itensEquipamento)
                                table.sort(nodes, function(a, b)
                                    return (tonumber(a.ordemEquip) or 0) < (tonumber(b.ordemEquip) or 0)
                                end)
                                self.listaequipamento:reorganize()
                            end

                            -- Configuração do botão de adicionar
                            self.btnNovoEquipamento.onClick = function()
                                local novo = self.listaequipamento:append()
                                if novo then
                                    novo.nomeEquip = "Novo Equipamento"
                                    novo.qtdEquip = "1x"
                                    novo.rankEquip = "F-"
                                    novo.ordemEquip = #NDB.getChildNodes(sheet.itensEquipamento) + 1
                                    reordenarEquips()
                                end
                            end

                            -- Lógica de seleção: agora aponta para o dataScopeBox 'detalheEquipamento'
                            self.listaequipamento.onSelect = function()
                                local node = self.listaequipamento.selectedNode;
                                self.detalheEquipamento:setNodeObject(node);
                                self.detalheEquipamento.visible = (node ~= nil);

                                self.abertoPeloSlot = false;

                                atualizarVisibilidadeSlots()
                            end;

                            
                        


    obj.label204 = GUI.fromHandle(_obj_newObject("label"));
    obj.label204:setParent(obj.rectangle183);
    obj.label204.grid.role = "col";
    obj.label204.grid.width = 3;
    obj.label204:setHeight(10);
    obj.label204:setName("label204");

    obj.btn_lista_equipamentos = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_lista_equipamentos:setParent(obj.rectangle183);
    obj.btn_lista_equipamentos:setName("btn_lista_equipamentos");
    obj.btn_lista_equipamentos:setText("Ir para Lista de Itens");
    obj.btn_lista_equipamentos:setFontSize(18);
    obj.btn_lista_equipamentos.grid.role = "col";
    obj.btn_lista_equipamentos.grid.width = 6;
    obj.btn_lista_equipamentos:setFontFamily("Wishes Script Caps Display");
    obj.btn_lista_equipamentos:setHorzTextAlign("center");
    obj.btn_lista_equipamentos:setVertTextAlign("leading");
    obj.btn_lista_equipamentos:setFontColor("white");
    obj.btn_lista_equipamentos:setMargins({top=10,bottom=10,right=10,left=10});

    obj.label205 = GUI.fromHandle(_obj_newObject("label"));
    obj.label205:setParent(obj.rectangle183);
    obj.label205.grid.role = "col";
    obj.label205.grid.width = 3;
    obj.label205:setHeight(10);
    obj.label205:setName("label205");

    obj.rectangle199 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle199:setParent(obj.scrollBox7);
    obj.rectangle199:setColor("#150e16");
    obj.rectangle199:setStrokeSize(2);
    obj.rectangle199:setStrokeColor("white");
    obj.rectangle199.grid.role = "col";
    obj.rectangle199.grid.width = 8;
    obj.rectangle199.grid["max-width"] = 1920;
    obj.rectangle199.grid["min-width"] = 400;
    obj.rectangle199.grid["min-height"] = 550;
    obj.rectangle199.grid["max-height"] = 1080;
    obj.rectangle199:setMargins({top=15});
    obj.rectangle199:setName("rectangle199");

    obj.detalheEquipamento = GUI.fromHandle(_obj_newObject("dataScopeBox"));
    obj.detalheEquipamento:setParent(obj.rectangle199);
    obj.detalheEquipamento:setName("detalheEquipamento");
    obj.detalheEquipamento:setAlign("client");
    obj.detalheEquipamento:setVisible(false);


                        function atualizarVisibilidadeSlots()
                            -- Garantimos que estamos pegando o node do item detalhado
                            local node = self.detalheEquipamento.node;
                            if node == nil then return end;

                            local mesa = Firecast.getMesaDe(node);
                            if mesa == nil or mesa.meuJogador == nil then return end;

                            local isMestre = mesa.meuJogador.isMestre;

                            local campos = {
                                "cabeca","maoesquerda","ombro","pescoco","torso","costas",
                                "maodireita","cinto","armadireita","armaesquerda",
                                "bota","perna","acessorio1","acessorio2"
                            };

                            for _, campo in ipairs(campos) do
                                local chk = self:findControlByName("chk_" .. campo);
                                if chk ~= nil then
                                    -- Verifica se o campo está marcado no item
                                    local marcado = (node["vis_" .. campo] == true) or (node["vis_" .. campo] == "true");

                                    if isMestre then
                                        -- Mestre vê tudo e pode editar
                                        chk.visible = true;
                                        chk.enabled = true; -- Garante interação
                                        chk.autoChange = true;
                                    else
                                        -- Jogador vê apenas se estiver marcado e não pode alterar
                                        chk.visible = marcado;
                                        chk.autoChange = false;
                                        chk.enabled = true; -- Bloqueia o clique visualmente e funcionalmente
                                    end;
                                end;
                            end;
                        end;
                    


    obj.btn_equipar_acao = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_equipar_acao:setParent(obj.detalheEquipamento);
    obj.btn_equipar_acao:setName("btn_equipar_acao");
    obj.btn_equipar_acao:setText("Equipar");
    obj.btn_equipar_acao.grid.role = "col";
    obj.btn_equipar_acao.grid.width = 1;
    obj.btn_equipar_acao:setHeight(20);
    obj.btn_equipar_acao:setFontSize(10);
    obj.btn_equipar_acao:setMargins({top=5});
    obj.btn_equipar_acao:setVisible(true);

    obj.btn_desequipar_acao = GUI.fromHandle(_obj_newObject("button"));
    obj.btn_desequipar_acao:setParent(obj.detalheEquipamento);
    obj.btn_desequipar_acao:setName("btn_desequipar_acao");
    obj.btn_desequipar_acao:setText("Desequipar");
    obj.btn_desequipar_acao.grid.role = "col";
    obj.btn_desequipar_acao.grid.width = 1;
    obj.btn_desequipar_acao:setHeight(20);
    obj.btn_desequipar_acao:setFontSize(10);
    obj.btn_desequipar_acao:setMargins({top=5});
    obj.btn_desequipar_acao:setFontColor("red");
    obj.btn_desequipar_acao:setVisible(false);

    obj.dataLink65 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink65:setParent(obj.detalheEquipamento);
    obj.dataLink65:setField("isEquipado");
    obj.dataLink65:setName("dataLink65");

    obj.label206 = GUI.fromHandle(_obj_newObject("label"));
    obj.label206:setParent(obj.detalheEquipamento);
    obj.label206:setText("Durabilidade:");
    obj.label206.grid.role = "col";
    obj.label206.grid.width = 1;
    obj.label206:setFontSize(10);
    obj.label206:setHeight(20);
    obj.label206:setHorzTextAlign("trailing");
    obj.label206:setFontFamily("Wishes Script Caps Display");
    obj.label206:setMargins({top=10,left=5});
    obj.label206:setName("label206");

    obj.rectangle200 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle200:setParent(obj.detalheEquipamento);
    obj.rectangle200:setHeight(20);
    obj.rectangle200:setColor("black");
    obj.rectangle200:setCornerType("round");
    obj.rectangle200.grid.role = "col";
    obj.rectangle200.grid.width = 1;
    obj.rectangle200:setStrokeSize(1);
    obj.rectangle200:setStrokeColor("white");
    obj.rectangle200:setXradius(5);
    obj.rectangle200:setYradius(5);
    obj.rectangle200:setMargins({top=5});
    obj.rectangle200:setName("rectangle200");

    obj.edit111 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit111:setParent(obj.rectangle200);
    obj.edit111:setField("durabilidadeItem");
    obj.edit111.grid.role = "col";
    obj.edit111.grid.width = 12;
    obj.edit111:setTransparent(true);
    obj.edit111:setFontSize(14);
    obj.edit111:setHeight(20);
    obj.edit111:setHorzTextAlign("center");
    obj.edit111:setFontFamily("Wishes Script Caps Display");
    obj.edit111:setName("edit111");

    obj.dataLink66 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink66:setParent(obj.rectangle200);
    obj.dataLink66:setField("durabilidadeItem");
    obj.dataLink66:setDefaultValue("100%");
    obj.dataLink66:setName("dataLink66");

    obj.label207 = GUI.fromHandle(_obj_newObject("label"));
    obj.label207:setParent(obj.detalheEquipamento);
    obj.label207:setHeight(20);
    obj.label207:setText("Nome:");
    obj.label207:setFontSize(15);
    obj.label207.grid.role = "col";
    obj.label207.grid.width = 1;
    obj.label207:setFontFamily("Wishes Script Caps Display");
    obj.label207:setHorzTextAlign("trailing");
    obj.label207:setMargins({top=10});
    obj.label207:setName("label207");

    obj.rectangle201 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle201:setParent(obj.detalheEquipamento);
    obj.rectangle201:setHeight(20);
    obj.rectangle201:setColor("black");
    obj.rectangle201:setCornerType("round");
    obj.rectangle201.grid.role = "col";
    obj.rectangle201.grid.width = 6;
    obj.rectangle201:setStrokeSize(1);
    obj.rectangle201:setStrokeColor("white");
    obj.rectangle201:setXradius(5);
    obj.rectangle201:setYradius(5);
    obj.rectangle201:setMargins({top=5});
    obj.rectangle201:setName("rectangle201");

    obj.edit112 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit112:setParent(obj.rectangle201);
    obj.edit112:setField("nomeEquip");
    obj.edit112.grid.role = "col";
    obj.edit112.grid.width = 12;
    obj.edit112:setTransparent(true);
    obj.edit112:setFontSize(15);
    obj.edit112:setHeight(21);
    obj.edit112:setVertTextAlign("center");
    obj.edit112:setHorzTextAlign("center");
    obj.edit112:setFontFamily("Wishes Script Caps Display");
    obj.edit112:setName("edit112");

    obj.label208 = GUI.fromHandle(_obj_newObject("label"));
    obj.label208:setParent(obj.detalheEquipamento);
    obj.label208:setHeight(20);
    obj.label208:setText("Rank:");
    obj.label208:setFontSize(15);
    obj.label208.grid.role = "col";
    obj.label208.grid.width = 1;
    obj.label208:setFontFamily("Wishes Script Caps Display");
    obj.label208:setHorzTextAlign("trailing");
    obj.label208:setMargins({top=10});
    obj.label208:setName("label208");

    obj.rectangle202 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle202:setParent(obj.detalheEquipamento);
    obj.rectangle202:setHeight(20);
    obj.rectangle202:setColor("black");
    obj.rectangle202:setCornerType("round");
    obj.rectangle202.grid.role = "col";
    obj.rectangle202.grid.width = 1;
    obj.rectangle202:setStrokeSize(1);
    obj.rectangle202:setStrokeColor("white");
    obj.rectangle202:setXradius(5);
    obj.rectangle202:setYradius(5);
    obj.rectangle202:setMargins({top=5,right=10});
    obj.rectangle202:setName("rectangle202");

    obj.comboBox19 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox19:setParent(obj.rectangle202);
    obj.comboBox19:setField("rankEquip");
    obj.comboBox19.grid.role = "col";
    obj.comboBox19.grid.width = 12;
    obj.comboBox19:setHeight(18);
    obj.comboBox19:setHorzTextAlign("center");
    obj.comboBox19:setFontFamily("Cinzel");
    obj.comboBox19:setTransparent(true);
    obj.comboBox19:setFontSize(20);
    obj.comboBox19:setItems({'F-', 'F', 'F+', 'E-', 'E', 'E+', 'D-', 'D', 'D+', 'C-', 'C', 'C+', 'B-', 'B', 'B+', 'A-', 'A', 'A+', 'S-', 'S', 'S+'});
    obj.comboBox19:setMargins({right=3});
    obj.comboBox19:setName("comboBox19");

    obj.dataLink67 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink67:setParent(obj.rectangle202);
    obj.dataLink67:setField("rankEquip");
    obj.dataLink67:setDefaultValue("F-");
    obj.dataLink67:setName("dataLink67");

    obj.layout1 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout1:setParent(obj.detalheEquipamento);
    obj.layout1.grid.role = "col";
    obj.layout1.grid.width = 6;
    obj.layout1:setHeight(30);
    obj.layout1:setMargins({top=0,left=5});
    obj.layout1:setName("layout1");

    obj.chk_cabeca = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_cabeca:setParent(obj.layout1);
    obj.chk_cabeca:setName("chk_cabeca");
    obj.chk_cabeca:setField("vis_cabeca");
    obj.chk_cabeca:setImageChecked("http://blob.firecast.com.br/blobs/VSBKJVLE_3196991/capacete.png");
    obj.chk_cabeca:setImageUnchecked("https://blob.firecast.com.br/blobs/OVOHAVFD_4303223/capacete_X.png");
    obj.chk_cabeca.grid.role = "col";
    obj.chk_cabeca.grid.width = 1;
    obj.chk_cabeca:setHeight(20);
    obj.chk_cabeca:setMargins({top=5,right=2,left=2});
    obj.chk_cabeca:setHint("Slot: Cabeça");
    obj.chk_cabeca:setAutoChange(false);

    obj.chk_maoesquerda = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_maoesquerda:setParent(obj.layout1);
    obj.chk_maoesquerda:setName("chk_maoesquerda");
    obj.chk_maoesquerda:setField("vis_maoesquerda");
    obj.chk_maoesquerda:setImageChecked("http://blob.firecast.com.br/blobs/MHJOGVIJ_3197013/mao_esquerda.png");
    obj.chk_maoesquerda:setImageUnchecked("https://blob.firecast.com.br/blobs/AVBWCAOG_4303232/mao_esquerda_X.png");
    obj.chk_maoesquerda.grid.role = "col";
    obj.chk_maoesquerda.grid.width = 1;
    obj.chk_maoesquerda:setHeight(20);
    obj.chk_maoesquerda:setMargins({top=5,right=2,left=2});
    obj.chk_maoesquerda:setHint("Slot: Mão Esquerda");
    obj.chk_maoesquerda:setAutoChange(false);

    obj.chk_ombro = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_ombro:setParent(obj.layout1);
    obj.chk_ombro:setName("chk_ombro");
    obj.chk_ombro:setField("vis_ombro");
    obj.chk_ombro:setImageChecked("http://blob.firecast.com.br/blobs/VWWCJLAI_3197011/ombros.png");
    obj.chk_ombro:setImageUnchecked("https://blob.firecast.com.br/blobs/RWLIUDVN_4303221/ombros_X.png");
    obj.chk_ombro.grid.role = "col";
    obj.chk_ombro.grid.width = 1;
    obj.chk_ombro:setHeight(20);
    obj.chk_ombro:setMargins({top=5,right=2,left=2});
    obj.chk_ombro:setHint("Slot: Ombro");
    obj.chk_ombro:setAutoChange(false);

    obj.chk_pescoco = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_pescoco:setParent(obj.layout1);
    obj.chk_pescoco:setName("chk_pescoco");
    obj.chk_pescoco:setField("vis_pescoco");
    obj.chk_pescoco:setImageChecked("http://blob.firecast.com.br/blobs/KQTJSRMC_3196994/colar.png");
    obj.chk_pescoco:setImageUnchecked("https://blob.firecast.com.br/blobs/TGABTBWI_4303225/colar_X.png");
    obj.chk_pescoco.grid.role = "col";
    obj.chk_pescoco.grid.width = 1;
    obj.chk_pescoco:setHeight(20);
    obj.chk_pescoco:setMargins({top=5,right=2,left=2});
    obj.chk_pescoco:setHint("Slot: Pescoço");
    obj.chk_pescoco:setAutoChange(false);

    obj.chk_torso = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_torso:setParent(obj.layout1);
    obj.chk_torso:setName("chk_torso");
    obj.chk_torso:setField("vis_torso");
    obj.chk_torso:setImageChecked("http://blob.firecast.com.br/blobs/BHSFRPKJ_3197012/torso.png");
    obj.chk_torso:setImageUnchecked("https://blob.firecast.com.br/blobs/QGPFTRWO_4303228/torso_X.png");
    obj.chk_torso.grid.role = "col";
    obj.chk_torso.grid.width = 1;
    obj.chk_torso:setHeight(20);
    obj.chk_torso:setMargins({top=5,right=2,left=2});
    obj.chk_torso:setHint("Slot: Torso");
    obj.chk_torso:setAutoChange(false);

    obj.chk_costas = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_costas:setParent(obj.layout1);
    obj.chk_costas:setName("chk_costas");
    obj.chk_costas:setField("vis_costas");
    obj.chk_costas:setImageChecked("http://blob.firecast.com.br/blobs/PFNJLMSL_3196996/costas.png");
    obj.chk_costas:setImageUnchecked("https://blob.firecast.com.br/blobs/WOHHHWVR_4303227/costas_X.png");
    obj.chk_costas.grid.role = "col";
    obj.chk_costas.grid.width = 1;
    obj.chk_costas:setHeight(20);
    obj.chk_costas:setMargins({top=5,right=2,left=2});
    obj.chk_costas:setHint("Slot: Costas");
    obj.chk_costas:setAutoChange(false);

    obj.chk_maodireita = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_maodireita:setParent(obj.layout1);
    obj.chk_maodireita:setName("chk_maodireita");
    obj.chk_maodireita:setField("vis_maodireita");
    obj.chk_maodireita:setImageChecked("http://blob.firecast.com.br/blobs/KAOFDIWM_3196998/mao_direita.png");
    obj.chk_maodireita:setImageUnchecked("https://blob.firecast.com.br/blobs/QWTUSKTH_4303231/mao_direita_X.png");
    obj.chk_maodireita.grid.role = "col";
    obj.chk_maodireita.grid.width = 1;
    obj.chk_maodireita:setHeight(20);
    obj.chk_maodireita:setMargins({top=5,right=2,left=2});
    obj.chk_maodireita:setHint("Slot: Mão Direita");
    obj.chk_maodireita:setAutoChange(false);

    obj.chk_cinto = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_cinto:setParent(obj.layout1);
    obj.chk_cinto:setName("chk_cinto");
    obj.chk_cinto:setField("vis_cinto");
    obj.chk_cinto:setImageChecked("http://blob.firecast.com.br/blobs/VIKSJTAS_3196995/cinto.png");
    obj.chk_cinto:setImageUnchecked("https://blob.firecast.com.br/blobs/VPNEFCFI_4303224/cinto_X.png");
    obj.chk_cinto.grid.role = "col";
    obj.chk_cinto.grid.width = 1;
    obj.chk_cinto:setHeight(20);
    obj.chk_cinto:setMargins({top=5,right=2,left=2});
    obj.chk_cinto:setHint("Slot: Cinto");
    obj.chk_cinto:setAutoChange(false);

    obj.chk_armadireita = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_armadireita:setParent(obj.layout1);
    obj.chk_armadireita:setName("chk_armadireita");
    obj.chk_armadireita:setField("vis_armadireita");
    obj.chk_armadireita:setImageChecked("http://blob.firecast.com.br/blobs/MRUHMKWV_3196993/arma_direita.png");
    obj.chk_armadireita:setImageUnchecked("https://blob.firecast.com.br/blobs/MCLDERJU_4303226/arma_direita_X.png");
    obj.chk_armadireita.grid.role = "col";
    obj.chk_armadireita.grid.width = 1;
    obj.chk_armadireita:setHeight(20);
    obj.chk_armadireita:setMargins({top=5,right=2,left=2});
    obj.chk_armadireita:setHint("Slot: Arma Direita");
    obj.chk_armadireita:setAutoChange(false);

    obj.chk_armaesquerda = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_armaesquerda:setParent(obj.layout1);
    obj.chk_armaesquerda:setName("chk_armaesquerda");
    obj.chk_armaesquerda:setField("vis_armaesquerda");
    obj.chk_armaesquerda:setImageChecked("http://blob.firecast.com.br/blobs/QQBQUNJS_3196992/arma_esqueda.png");
    obj.chk_armaesquerda:setImageUnchecked("https://blob.firecast.com.br/blobs/KCTLNRCM_4303230/arma_esqueda_X.png");
    obj.chk_armaesquerda.grid.role = "col";
    obj.chk_armaesquerda.grid.width = 1;
    obj.chk_armaesquerda:setHeight(20);
    obj.chk_armaesquerda:setMargins({top=5,right=2,left=2});
    obj.chk_armaesquerda:setHint("Slot: Arma Esquerda");
    obj.chk_armaesquerda:setAutoChange(false);

    obj.chk_bota = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_bota:setParent(obj.layout1);
    obj.chk_bota:setName("chk_bota");
    obj.chk_bota:setField("vis_bota");
    obj.chk_bota:setImageChecked("http://blob.firecast.com.br/blobs/ODHJPRVJ_3196989/bota.png");
    obj.chk_bota:setImageUnchecked("https://blob.firecast.com.br/blobs/TFSALMUR_4303219/bota_X.png");
    obj.chk_bota.grid.role = "col";
    obj.chk_bota.grid.width = 1;
    obj.chk_bota:setHeight(20);
    obj.chk_bota:setMargins({top=5,right=2,left=2});
    obj.chk_bota:setHint("Slot: Bota");
    obj.chk_bota:setAutoChange(false);

    obj.chk_perna = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_perna:setParent(obj.layout1);
    obj.chk_perna:setName("chk_perna");
    obj.chk_perna:setField("vis_perna");
    obj.chk_perna:setImageChecked("http://blob.firecast.com.br/blobs/ADULDOEJ_3196997/cal_a.png");
    obj.chk_perna:setImageUnchecked("https://blob.firecast.com.br/blobs/FJBJSVUK_4303222/cal_a_X.png");
    obj.chk_perna.grid.role = "col";
    obj.chk_perna.grid.width = 1;
    obj.chk_perna:setHeight(20);
    obj.chk_perna:setMargins({top=5,right=2,left=2});
    obj.chk_perna:setHint("Slot: Perna");
    obj.chk_perna:setAutoChange(false);

    obj.layout2 = GUI.fromHandle(_obj_newObject("layout"));
    obj.layout2:setParent(obj.detalheEquipamento);
    obj.layout2.grid.role = "col";
    obj.layout2.grid.width = 6;
    obj.layout2:setHeight(30);
    obj.layout2:setMargins({top=0,right=5});
    obj.layout2:setName("layout2");

    obj.chk_acessorio1 = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_acessorio1:setParent(obj.layout2);
    obj.chk_acessorio1:setName("chk_acessorio1");
    obj.chk_acessorio1:setField("vis_acessorio1");
    obj.chk_acessorio1:setImageChecked("http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png");
    obj.chk_acessorio1:setImageUnchecked("https://blob.firecast.com.br/blobs/EWPDLRLM_4303220/acessorio_X.png");
    obj.chk_acessorio1.grid.role = "col";
    obj.chk_acessorio1.grid.width = 1;
    obj.chk_acessorio1:setHeight(20);
    obj.chk_acessorio1:setMargins({top=5,right=2,left=2});
    obj.chk_acessorio1:setHint("Slot: Acessório 1");
    obj.chk_acessorio1:setAutoChange(false);

    obj.chk_acessorio2 = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_acessorio2:setParent(obj.layout2);
    obj.chk_acessorio2:setName("chk_acessorio2");
    obj.chk_acessorio2:setField("vis_acessorio2");
    obj.chk_acessorio2:setImageChecked("http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png");
    obj.chk_acessorio2:setImageUnchecked("https://blob.firecast.com.br/blobs/EWPDLRLM_4303220/acessorio_X.png");
    obj.chk_acessorio2.grid.role = "col";
    obj.chk_acessorio2.grid.width = 1;
    obj.chk_acessorio2:setHeight(20);
    obj.chk_acessorio2:setMargins({top=5,right=2,left=2});
    obj.chk_acessorio2:setHint("Slot: Acessório 2");
    obj.chk_acessorio2:setAutoChange(false);

    obj.rectangle203 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle203:setParent(obj.layout2);
    obj.rectangle203:setHeight(20);
    obj.rectangle203:setColor("black");
    obj.rectangle203:setCornerType("round");
    obj.rectangle203.grid.role = "col";
    obj.rectangle203.grid.width = 10;
    obj.rectangle203:setStrokeSize(1);
    obj.rectangle203:setStrokeColor("white");
    obj.rectangle203:setXradius(5);
    obj.rectangle203:setYradius(5);
    obj.rectangle203:setMargins({top=5});
    obj.rectangle203:setName("rectangle203");

    obj.tags_equip = GUI.fromHandle(_obj_newObject("edit"));
    obj.tags_equip:setParent(obj.rectangle203);
    obj.tags_equip:setName("tags_equip");
    obj.tags_equip:setField("tags_equip");
    obj.tags_equip.grid.role = "col";
    obj.tags_equip.grid.width = 12;
    obj.tags_equip:setTransparent(true);
    obj.tags_equip:setFontSize(14);
    obj.tags_equip:setHeight(20);
    obj.tags_equip:setHorzTextAlign("center");
    obj.tags_equip:setFontFamily("Wishes Script Caps Display");

    obj.dataLink68 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink68:setParent(obj.layout2);
    obj.dataLink68:setField("tags_equip");
    obj.dataLink68:setDefaultValue("Tags");
    obj.dataLink68:setName("dataLink68");

    obj.richEdit3 = GUI.fromHandle(_obj_newObject("richEdit"));
    obj.richEdit3:setParent(obj.detalheEquipamento);
    obj.richEdit3:setField("descricaoLongaEquip");
    obj.richEdit3:setAlign("client");
    obj.richEdit3.backgroundColor = "#000000";
    obj.richEdit3.defaultFontColor = "white";
    obj.richEdit3.hideSelection = true;
    obj.richEdit3.defaultFontSize = 14;
    obj.richEdit3.animateImages = true;
    obj.richEdit3:setMargins({top=60,right=4,left=4,bottom=4});
    obj.richEdit3:setName("richEdit3");

    obj.aba_aura_magia = GUI.fromHandle(_obj_newObject("tab"));
    obj.aba_aura_magia:setParent(obj.ficha);
    obj.aba_aura_magia:setName("aba_aura_magia");
    obj.aba_aura_magia:setTitle("Magia");

    obj.rectangle204 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle204:setParent(obj.aba_aura_magia);
    obj.rectangle204:setAlign("client");
    obj.rectangle204:setColor("black");
    obj.rectangle204:setName("rectangle204");

    obj.scrollBox9 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox9:setParent(obj.rectangle204);
    obj.scrollBox9:setAlign("client");
    obj.scrollBox9:setMargins({left=5,right=5});
    obj.scrollBox9:setName("scrollBox9");

    obj.rectangle205 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle205:setParent(obj.scrollBox9);
    obj.rectangle205:setColor("#150e16");
    obj.rectangle205:setStrokeSize(2);
    obj.rectangle205:setStrokeColor("white");
    obj.rectangle205.grid.role = "col";
    obj.rectangle205.grid.width = 3;
    obj.rectangle205.grid["max-width"] = 1080;
    obj.rectangle205.grid["min-width"] = 300;
    obj.rectangle205.grid["min-height"] = 550;
    obj.rectangle205.grid["max-height"] = 1080;
    obj.rectangle205:setMargins({top=15});
    obj.rectangle205:setName("rectangle205");

    obj.titulo_aura_magia = GUI.fromHandle(_obj_newObject("label"));
    obj.titulo_aura_magia:setParent(obj.rectangle205);
    obj.titulo_aura_magia:setName("titulo_aura_magia");
    obj.titulo_aura_magia:setHeight(25);
    obj.titulo_aura_magia:setFontSize(50);
    obj.titulo_aura_magia.grid.role = "col";
    obj.titulo_aura_magia.grid.width = 12;
    obj.titulo_aura_magia:setFontFamily("Wishes Script Caps Display");
    obj.titulo_aura_magia:setHorzTextAlign("center");
    obj.titulo_aura_magia:setMargins({top=15});

    obj.label209 = GUI.fromHandle(_obj_newObject("label"));
    obj.label209:setParent(obj.titulo_aura_magia);
    obj.label209.grid.role = "col";
    obj.label209.grid.width = 10;
    obj.label209:setName("label209");

    obj.btnNova_Aura_Magia = GUI.fromHandle(_obj_newObject("button"));
    obj.btnNova_Aura_Magia:setParent(obj.titulo_aura_magia);
    obj.btnNova_Aura_Magia:setName("btnNova_Aura_Magia");
    obj.btnNova_Aura_Magia:setText("+");
    obj.btnNova_Aura_Magia:setHeight(30);
    obj.btnNova_Aura_Magia.grid.role = "col";
    obj.btnNova_Aura_Magia.grid.width = 2;
    obj.btnNova_Aura_Magia:setMargins({right=5, top=-10});


                        local filter_Aura_MagiaArgument = "";
                        
                        local function prepFilter_Aura_Magia(inputStr)
                            return string.lower(Utils.removerAcentos(inputStr or ""));
                        end;
                        
                        local function run_Aura_MagiaFilter()           
                            filter_Aura_MagiaArgument = prepFilter_Aura_Magia(self.edtFiltro_Aura_Magia.text);
                            self.lista_aura_magia:reorganize();
                        end;        
                        
                        local function check_Aura_MagiaFilter() 
                            local newArg = prepFilter_Aura_Magia(self.edtFiltro_Aura_Magia.text);
                            if newArg ~= filter_Aura_MagiaArgument then
                                run_Aura_MagiaFilter();
                            end;
                        end;
                    


    obj.tmrFiltro_Aura_Magia = GUI.fromHandle(_obj_newObject("timer"));
    obj.tmrFiltro_Aura_Magia:setParent(obj.rectangle205);
    obj.tmrFiltro_Aura_Magia:setName("tmrFiltro_Aura_Magia");
    obj.tmrFiltro_Aura_Magia:setInterval(1000);

    obj.edtFiltro_Aura_Magia = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtFiltro_Aura_Magia:setParent(obj.rectangle205);
    obj.edtFiltro_Aura_Magia.grid.role = "row";
    obj.edtFiltro_Aura_Magia.grid["min-height"] = 25;
    obj.edtFiltro_Aura_Magia:setTextPrompt("Buscar Item...");
    obj.edtFiltro_Aura_Magia:setName("edtFiltro_Aura_Magia");
    obj.edtFiltro_Aura_Magia:setMargins({top=5,right=5,left=5});
    obj.edtFiltro_Aura_Magia:setHint("Buscar Item ou Tag...");

    obj.scrollBox10 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox10:setParent(obj.rectangle205);
    obj.scrollBox10.grid.role = "row";
    obj.scrollBox10.grid["vert-tile"] = true;
    obj.scrollBox10:setMargins({top=5,right=2,left=2,bottom=2});
    obj.scrollBox10.grid["cnt-gutter"] = 1;
    obj.scrollBox10:setName("scrollBox10");

    obj.lista_aura_magia = GUI.fromHandle(_obj_newObject("gridRecordList"));
    obj.lista_aura_magia:setParent(obj.scrollBox10);
    obj.lista_aura_magia:setName("lista_aura_magia");
    obj.lista_aura_magia.field = "itens_Aura_Magia";
    obj.lista_aura_magia.templateForm = "template_Aura_Magia";
    obj.lista_aura_magia.minQt = 0;
    obj.lista_aura_magia.selectable = true;
    obj.lista_aura_magia:setHeight(600);
    obj.lista_aura_magia.grid.role = "col";
    obj.lista_aura_magia.grid.width = 12;


                            -- Função de reordenação específica para a nova lista
                            local function reordenar_Aura_Magia()
                                local nodes = NDB.getChildNodes(sheet.itens_Aura_Magia)
                                table.sort(nodes, function(a, b)
                                    return (tonumber(a.ordem_Aura_Magia) or 0) < (tonumber(b.ordem_Aura_Magia) or 0)
                                end)
                                self.lista_aura_magia:reorganize()
                            end

                            -- Configuração do botão de adicionar
                            self.btnNova_Aura_Magia.onClick = function()
                                local novo = self.lista_aura_magia:append()
                                if novo then
                                    novo.nome_Aura_Magia = "Novo Item"
                                    novo.ordem_Aura_Magia = #NDB.getChildNodes(sheet.itens_Aura_Magia) + 1
                                    reordenar_Aura_Magia()
                                end
                            end
                            -- Lógica de seleção: agora aponta para o dataScopeBox 'detalheSkill'
                            self.lista_aura_magia.onSelect = function()
                                local node = self.lista_aura_magia.selectedNode;
                                self.detalhe_aura_magia:setNodeObject(node);
                                self.detalhe_aura_magia.visible = (node ~= nil);

                                self.abertoPeloSlot = false;

                            
                            end;
                        


    obj.rectangle206 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle206:setParent(obj.scrollBox9);
    obj.rectangle206:setColor("#150e16");
    obj.rectangle206:setStrokeSize(2);
    obj.rectangle206:setStrokeColor("white");
    obj.rectangle206.grid.role = "col";
    obj.rectangle206.grid.width = 5;
    obj.rectangle206.grid["max-width"] = 1080;
    obj.rectangle206.grid["min-width"] = 300;
    obj.rectangle206.grid["min-height"] = 550;
    obj.rectangle206.grid["max-height"] = 1080;
    obj.rectangle206:setMargins({top=15});
    obj.rectangle206:setName("rectangle206");

    obj.detalhe_aura_magia = GUI.fromHandle(_obj_newObject("dataScopeBox"));
    obj.detalhe_aura_magia:setParent(obj.rectangle206);
    obj.detalhe_aura_magia:setName("detalhe_aura_magia");
    obj.detalhe_aura_magia:setAlign("client");
    obj.detalhe_aura_magia:setVisible(false);

    obj.label210 = GUI.fromHandle(_obj_newObject("label"));
    obj.label210:setParent(obj.detalhe_aura_magia);
    obj.label210:setHeight(20);
    obj.label210:setText("Nome:");
    obj.label210:setFontSize(15);
    obj.label210.grid.role = "col";
    obj.label210.grid.width = 1;
    obj.label210:setFontFamily("Wishes Script Caps Display");
    obj.label210:setHorzTextAlign("trailing");
    obj.label210:setMargins({top=10});
    obj.label210:setName("label210");

    obj.rectangle207 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle207:setParent(obj.detalhe_aura_magia);
    obj.rectangle207:setHeight(30);
    obj.rectangle207:setColor("black");
    obj.rectangle207:setCornerType("round");
    obj.rectangle207.grid.role = "col";
    obj.rectangle207.grid.width = 8;
    obj.rectangle207:setStrokeSize(1);
    obj.rectangle207:setStrokeColor("white");
    obj.rectangle207:setXradius(5);
    obj.rectangle207:setYradius(5);
    obj.rectangle207:setMargins({top=5});
    obj.rectangle207:setName("rectangle207");

    obj.edit113 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit113:setParent(obj.rectangle207);
    obj.edit113:setField("nome_Aura_Magia");
    obj.edit113:setAlign("client");
    obj.edit113:setTransparent(true);
    obj.edit113:setFontSize(22);
    obj.edit113:setVertTextAlign("center");
    obj.edit113:setHorzTextAlign("center");
    obj.edit113:setFontFamily("Wishes Script Caps Display");
    obj.edit113:setName("edit113");

    obj.rectangle208 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle208:setParent(obj.detalhe_aura_magia);
    obj.rectangle208:setHeight(20);
    obj.rectangle208:setColor("black");
    obj.rectangle208:setCornerType("round");
    obj.rectangle208.grid.role = "col";
    obj.rectangle208.grid.width = 3;
    obj.rectangle208:setStrokeSize(1);
    obj.rectangle208:setStrokeColor("white");
    obj.rectangle208:setXradius(5);
    obj.rectangle208:setYradius(5);
    obj.rectangle208:setMargins({top=8});
    obj.rectangle208:setName("rectangle208");

    obj.comboBox20 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox20:setParent(obj.rectangle208);
    obj.comboBox20.grid.role = "col";
    obj.comboBox20.grid.width = 12;
    obj.comboBox20:setHeight(25);
    obj.comboBox20:setField("cor_Aura_Magia");
    obj.comboBox20:setItems({'AliceBlue', 'AntiqueWhite', 'Aqua', 'Aquamarine', 'Azure', 'Beige', 'Bisque', 'Black', 'BlanchedAlmond', 'Blue', 'BlueViolet', 'Brown', 'BurlyWood', 'CadetBlue', 'Chartreuse', 'Chocolate', 'Coral', 'CornflowerBlue', 'Cornsilk', 'Crimson', 'Cyan', 'DarkBlue', 'DarkCyan', 'DarkGoldenRod', 'DarkGray', 'DarkGreen', 'DarkKhaki', 'DarkMagenta', 'DarkOliveGreen', 'DarkOrange', 'DarkOrchid', 'DarkRed', 'DarkSalmon', 'DarkSeaGreen', 'DarkSlateBlue', 'DarkSlateGray', 'DarkTurquoise', 'DarkViolet', 'DeepPink', 'DeepSkyBlue', 'DimGray', 'DodgerBlue', 'FireBrick', 'FloralWhite', 'ForestGreen', 'Fuchsia', 'Gainsboro', 'GhostWhite', 'Gold', 'GoldenRod', 'Gray', 'Green', 'GreenYellow', 'HoneyDew', 'HotPink', 'IndianRed', 'Indigo', 'Ivory', 'Khaki', 'Lavender', 'LavenderBlush', 'LawnGreen', 'LemonChiffon', 'LightBlue', 'LightCoral', 'LightCyan', 'LightGoldenRodYellow', 'LightGray', 'LightGreen', 'LightPink', 'LightSalmon', 'LightSeaGreen', 'LightSkyBlue', 'LightSlateGray', 'LightSteelBlue', 'LightYellow', 'Lime', 'LimeGreen', 'Linen', 'Magenta', 'Maroon', 'MediumAquaMarine', 'MediumBlue', 'MediumOrchid', 'MediumPurple', 'MediumSeaGreen', 'MediumSlateBlue', 'MediumSpringGreen', 'MediumTurquoise', 'MediumVioletRed', 'MidnightBlue', 'MintCream', 'MistyRose', 'Moccasin', 'NavajoWhite', 'Navy', 'OldLace', 'Olive', 'OliveDrab', 'Orange', 'OrangeRed', 'Orchid', 'PaleGoldenRod', 'PaleGreen', 'PaleTurquoise', 'PaleVioletRed', 'PapayaWhip', 'PeachPuff', 'Peru', 'Pink', 'Plum', 'PowderBlue', 'Purple', 'RebeccaPurple', 'Red', 'RosyBrown', 'RoyalBlue', 'SaddleBrown', 'Salmon', 'SandyBrown', 'SeaGreen', 'SeaShell', 'Sienna', 'Silver', 'SkyBlue', 'SlateBlue', 'SlateGray', 'Snow', 'SpringGreen', 'SteelBlue', 'Tan', 'Teal', 'Thistle', 'Tomato', 'Turquoise', 'Violet', 'Wheat', 'White', 'WhiteSmoke', 'Yellow', 'YellowGreen'});
    obj.comboBox20:setValues({'#F0F8FF', '#FAEBD7', '#00FFFF', '#7FFFD4', '#F0FFFF', '#F5F5DC', '#FFE4C4', '#000000', '#FFEBCD', '#0000FF', '#8A2BE2', '#A52A2A', '#DEB887', '#5F9EA0', '#7FFF00', '#D2691E', '#FF7F50', '#6495ED', '#FFF8DC', '#DC143C', '#00FFFF', '#00008B', '#008B8B', '#B8860B', '#A9A9A9', '#006400', '#BDB76B', '#8B008B', '#556B2F', '#FF8C00', '#9932CC', '#8B0000', '#E9967A', '#8FBC8F', '#483D8B', '#2F4F4F', '#00CED1', '#9400D3', '#FF1493', '#00BFFF', '#696969', '#1E90FF', '#B22222', '#FFFAF0', '#228B22', '#FF00FF', '#DCDCDC', '#F8F8FF', '#FFD700', '#DAA520', '#808080', '#008000', '#ADFF2F', '#F0FFF0', '#FF69B4', '#CD5C5C', '#4B0082', '#FFFFF0', '#F0E68C', '#E6E6FA', '#FFF0F5', '#7CFC00', '#FFFACD', '#ADD8E6', '#F08080', '#E0FFFF', '#FAFAD2', '#D3D3D3', '#90EE90', '#FFB6C1', '#FFA07A', '#20B2AA', '#87CEFA', '#778899', '#B0C4DE', '#FFFFE0', '#00FF00', '#32CD32', '#FAF0E6', '#FF00FF', '#800000', '#66CDAA', '#0000CD', '#BA55D3', '#9370DB', '#3CB371', '#7B68EE', '#00FA9A', '#48D1CC', '#C71585', '#191970', '#F5FFFA', '#FFE4E1', '#FFE4B5', '#FFDEAD', '#000080', '#FDF5E6', '#808000', '#6B8E23', '#FFA500', '#FF4500', '#DA70D6', '#EEE8AA', '#98FB98', '#AFEEEE', '#DB7093', '#FFEFD5', '#FFDAB9', '#CD853F', '#FFC0CB', '#DDA0DD', '#B0E0E6', '#800080', '#663399', '#FF0000', '#BC8F8F', '#4169E1', '#8B4513', '#FA8072', '#F4A460', '#2E8B57', '#FFF5EE', '#A0522D', '#C0C0C0', '#87CEEB', '#6A5ACD', '#708090', '#FFFAFA', '#00FF7F', '#4682B4', '#D2B48C', '#008080', '#D8BFD8', '#FF6347', '#40E0D0', '#EE82EE', '#F5DEB3', '#FFFFFF', '#F5F5F5', '#FFFF00', '#9ACD32'});
    obj.comboBox20:setName("comboBox20");

    obj.rectangle209 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle209:setParent(obj.detalhe_aura_magia);
    obj.rectangle209:setHeight(20);
    obj.rectangle209:setColor("black");
    obj.rectangle209:setCornerType("round");
    obj.rectangle209.grid.role = "col";
    obj.rectangle209.grid.width = 12;
    obj.rectangle209:setStrokeSize(1);
    obj.rectangle209:setStrokeColor("white");
    obj.rectangle209:setXradius(5);
    obj.rectangle209:setYradius(5);
    obj.rectangle209:setMargins({top=5});
    obj.rectangle209:setName("rectangle209");

    obj.tags_Aura_Magia = GUI.fromHandle(_obj_newObject("edit"));
    obj.tags_Aura_Magia:setParent(obj.rectangle209);
    obj.tags_Aura_Magia:setName("tags_Aura_Magia");
    obj.tags_Aura_Magia:setField("tags_Aura_Magia");
    obj.tags_Aura_Magia.grid.role = "col";
    obj.tags_Aura_Magia.grid.width = 12;
    obj.tags_Aura_Magia:setTransparent(true);
    obj.tags_Aura_Magia:setFontSize(14);
    obj.tags_Aura_Magia:setHeight(20);
    obj.tags_Aura_Magia:setHorzTextAlign("center");
    obj.tags_Aura_Magia:setFontFamily("Wishes Script Caps Display");

    obj.dataLink69 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink69:setParent(obj.detalhe_aura_magia);
    obj.dataLink69:setField("tags_Aura_Magia");
    obj.dataLink69:setDefaultValue("Tags");
    obj.dataLink69:setName("dataLink69");

    obj.richEdit4 = GUI.fromHandle(_obj_newObject("richEdit"));
    obj.richEdit4:setParent(obj.detalhe_aura_magia);
    obj.richEdit4:setField("descricaoLongaSkill");
    obj.richEdit4:setAlign("client");
    obj.richEdit4.backgroundColor = "#000000";
    obj.richEdit4.defaultFontColor = "white";
    obj.richEdit4.hideSelection = true;
    obj.richEdit4.defaultFontSize = 14;
    obj.richEdit4.animateImages = true;
    obj.richEdit4:setMargins({top=65,right=4,left=4,bottom=4});
    obj.richEdit4:setName("richEdit4");

    obj.rectangle210 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle210:setParent(obj.scrollBox9);
    obj.rectangle210:setColor("#150e16");
    obj.rectangle210:setStrokeSize(2);
    obj.rectangle210:setStrokeColor("white");
    obj.rectangle210.grid.role = "col";
    obj.rectangle210.grid.width = 4;
    obj.rectangle210.grid["max-width"] = 1080;
    obj.rectangle210.grid["min-width"] = 300;
    obj.rectangle210.grid["min-height"] = 550;
    obj.rectangle210.grid["max-height"] = 1080;
    obj.rectangle210:setMargins({top=15});
    obj.rectangle210:setName("rectangle210");

    obj.rectangle211 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle211:setParent(obj.rectangle210);
    obj.rectangle211:setHeight(40);
    obj.rectangle211:setColor("black");
    obj.rectangle211:setCornerType("round");
    obj.rectangle211.grid.role = "col";
    obj.rectangle211.grid.width = 12;
    obj.rectangle211:setStrokeSize(1);
    obj.rectangle211:setStrokeColor("white");
    obj.rectangle211:setXradius(5);
    obj.rectangle211:setYradius(5);
    obj.rectangle211:setMargins({top=10,right=5,left=5});
    obj.rectangle211:setName("rectangle211");

    obj.aptitudemagia = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.aptitudemagia:setParent(obj.rectangle211);
    obj.aptitudemagia:setField("aptitudemagia");
    obj.aptitudemagia:setName("aptitudemagia");
    obj.aptitudemagia:setAlign("client");
    obj.aptitudemagia:setHorzTextAlign("center");
    obj.aptitudemagia:setFontFamily("Cinzel");
    obj.aptitudemagia:setTransparent(true);
    obj.aptitudemagia:setFontSize(20);
    obj.aptitudemagia:setItems({'Escolha...', 'Divina', 'Clarevidência',	'Mental', 'Produção', 'Demoniaca', 'Invocação', 'Elemental', 'Espiritual'});

    obj.aptitudeaura = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.aptitudeaura:setParent(obj.rectangle211);
    obj.aptitudeaura:setField("aptitudeaura");
    obj.aptitudeaura:setName("aptitudeaura");
    obj.aptitudeaura:setAlign("client");
    obj.aptitudeaura:setHorzTextAlign("center");
    obj.aptitudeaura:setFontFamily("Cinzel");
    obj.aptitudeaura:setTransparent(true);
    obj.aptitudeaura:setFontSize(20);
    obj.aptitudeaura:setItems({'Escolha...', 'Reforço Fisico', 'Transmutação', 'Conjuração', 'Reforço Mental', 'Manipulação', 'Emissão'});

    obj.dataLink70 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink70:setParent(obj.rectangle210);
    obj.dataLink70:setFields({'aptitudemagia', 'afdivina', 'afclarevidencia', 'afespiritual', 'afmental', 'afelemental', 'afproducao', 'afinvocacao', 'afdemoniaca'});
    obj.dataLink70:setDefaultValues({'Escolha...', 'Padrão', 'Padrão', 'Padrão', 'Padrão', 'Padrão', 'Padrão', 'Padrão', 'Padrão'});
    obj.dataLink70:setName("dataLink70");

    obj.dataLink71 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink71:setParent(obj.rectangle210);
    obj.dataLink71:setFields({'aptitudeaura', 'afreforcof', 'aftransmutacao', 'afconjuracao', 'afreforcom', 'afmanipulacao', 'afemissao'});
    obj.dataLink71:setDefaultValues({'Escolha...', 'Padrão', 'Padrão', 'Padrão', 'Padrão', 'Padrão', 'Padrão'});
    obj.dataLink71:setName("dataLink71");

    obj.label211 = GUI.fromHandle(_obj_newObject("label"));
    obj.label211:setParent(obj.rectangle210);
    obj.label211.grid.role = "col";
    obj.label211.grid.width = 11;
    obj.label211:setName("label211");

    obj.button16 = GUI.fromHandle(_obj_newObject("button"));
    obj.button16:setParent(obj.rectangle210);
    obj.button16:setText("?");
    obj.button16.grid.role = "col";
    obj.button16.grid.width = 1;
    obj.button16:setHeight(25);
    obj.button16:setFontSize(11);
    obj.button16:setFontFamily("Wishes Script Caps Display");
    obj.button16:setHorzTextAlign("center");
    obj.button16:setVertTextAlign("center");
    obj.button16:setMargins({top=5,right=5});
    obj.button16:setName("button16");

    obj.cores_afinidades = GUI.fromHandle(_obj_newObject("popup"));
    obj.cores_afinidades:setParent(obj.rectangle210);
    obj.cores_afinidades:setName("cores_afinidades");
    obj.cores_afinidades:setWidth(400);
    obj.cores_afinidades:setHeight(400);
    obj.cores_afinidades:setBackOpacity(0.5);

    obj.rectangle212 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle212:setParent(obj.cores_afinidades);
    obj.rectangle212:setColor("black");
    obj.rectangle212:setLeft(-5);
    obj.rectangle212:setTop(-5);
    obj.rectangle212:setWidth(410);
    obj.rectangle212:setHeight(410);
    obj.rectangle212:setName("rectangle212");

    obj.rectangle213 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle213:setParent(obj.cores_afinidades);
    obj.rectangle213:setColor("#150e16");
    obj.rectangle213:setStrokeSize(2);
    obj.rectangle213:setStrokeColor("white");
    obj.rectangle213:setLeft(5);
    obj.rectangle213:setTop(5);
    obj.rectangle213:setWidth(390);
    obj.rectangle213:setHeight(390);
    obj.rectangle213:setCornerType("round");
    obj.rectangle213:setXradius(5);
    obj.rectangle213:setYradius(5);
    obj.rectangle213:setName("rectangle213");

    obj.label212 = GUI.fromHandle(_obj_newObject("label"));
    obj.label212:setParent(obj.rectangle213);
    obj.label212:setText("Cores e Afinidades");
    obj.label212:setHeight(30);
    obj.label212:setFontSize(25);
    obj.label212.grid.role = "col";
    obj.label212.grid.width = 12;
    obj.label212:setFontFamily("Wishes Script Caps Display");
    obj.label212:setHorzTextAlign("center");
    obj.label212:setVertTextAlign("center");
    obj.label212:setMargins({top=10});
    obj.label212:setName("label212");

    obj.rectangle214 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle214:setParent(obj.rectangle213);
    obj.rectangle214:setHeight(25);
    obj.rectangle214:setColor("#00ffff");
    obj.rectangle214:setCornerType("round");
    obj.rectangle214.grid.role = "col";
    obj.rectangle214.grid.width = 12;
    obj.rectangle214:setStrokeSize(1);
    obj.rectangle214:setStrokeColor("white");
    obj.rectangle214:setXradius(5);
    obj.rectangle214:setYradius(5);
    obj.rectangle214:setMargins({top=15});
    obj.rectangle214:setName("rectangle214");

    obj.label213 = GUI.fromHandle(_obj_newObject("label"));
    obj.label213:setParent(obj.rectangle214);
    obj.label213:setText("S - 130% - Sinergia Perfeita");
    obj.label213:setFontColor("#003636");
    obj.label213.grid.role = "col";
    obj.label213.grid.width = 12;
    obj.label213:setHeight(25);
    obj.label213:setHorzTextAlign("center");
    obj.label213:setFontSize(12);
    obj.label213:setName("label213");

    obj.rectangle215 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle215:setParent(obj.rectangle213);
    obj.rectangle215:setHeight(25);
    obj.rectangle215:setColor("#0000ff");
    obj.rectangle215:setCornerType("round");
    obj.rectangle215.grid.role = "col";
    obj.rectangle215.grid.width = 12;
    obj.rectangle215:setStrokeSize(1);
    obj.rectangle215:setStrokeColor("white");
    obj.rectangle215:setXradius(5);
    obj.rectangle215:setYradius(5);
    obj.rectangle215:setMargins({top=15});
    obj.rectangle215:setName("rectangle215");

    obj.label214 = GUI.fromHandle(_obj_newObject("label"));
    obj.label214:setParent(obj.rectangle215);
    obj.label214:setText("A - 100% - Harmonia Natural");
    obj.label214:setFontColor("#9c9cff");
    obj.label214.grid.role = "col";
    obj.label214.grid.width = 12;
    obj.label214:setHeight(25);
    obj.label214:setHorzTextAlign("center");
    obj.label214:setFontSize(12);
    obj.label214:setName("label214");

    obj.rectangle216 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle216:setParent(obj.rectangle213);
    obj.rectangle216:setHeight(25);
    obj.rectangle216:setColor("#00ff00");
    obj.rectangle216:setCornerType("round");
    obj.rectangle216.grid.role = "col";
    obj.rectangle216.grid.width = 12;
    obj.rectangle216:setStrokeSize(1);
    obj.rectangle216:setStrokeColor("white");
    obj.rectangle216:setXradius(5);
    obj.rectangle216:setYradius(5);
    obj.rectangle216:setMargins({top=15});
    obj.rectangle216:setName("rectangle216");

    obj.label215 = GUI.fromHandle(_obj_newObject("label"));
    obj.label215:setParent(obj.rectangle216);
    obj.label215:setText("B - 70% - Talento Desenvolvido");
    obj.label215:setFontColor("#003600");
    obj.label215.grid.role = "col";
    obj.label215.grid.width = 12;
    obj.label215:setHeight(25);
    obj.label215:setHorzTextAlign("center");
    obj.label215:setFontSize(12);
    obj.label215:setName("label215");

    obj.rectangle217 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle217:setParent(obj.rectangle213);
    obj.rectangle217:setHeight(25);
    obj.rectangle217:setColor("#ffff00");
    obj.rectangle217:setCornerType("round");
    obj.rectangle217.grid.role = "col";
    obj.rectangle217.grid.width = 12;
    obj.rectangle217:setStrokeSize(1);
    obj.rectangle217:setStrokeColor("white");
    obj.rectangle217:setXradius(5);
    obj.rectangle217:setYradius(5);
    obj.rectangle217:setMargins({top=15});
    obj.rectangle217:setName("rectangle217");

    obj.label216 = GUI.fromHandle(_obj_newObject("label"));
    obj.label216:setParent(obj.rectangle217);
    obj.label216:setText("C - 50% - Ajuste");
    obj.label216:setFontColor("#3b3b00");
    obj.label216.grid.role = "col";
    obj.label216.grid.width = 12;
    obj.label216:setHeight(25);
    obj.label216:setHorzTextAlign("center");
    obj.label216:setFontSize(12);
    obj.label216:setName("label216");

    obj.rectangle218 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle218:setParent(obj.rectangle213);
    obj.rectangle218:setHeight(25);
    obj.rectangle218:setColor("#ff7c00");
    obj.rectangle218:setCornerType("round");
    obj.rectangle218.grid.role = "col";
    obj.rectangle218.grid.width = 12;
    obj.rectangle218:setStrokeSize(1);
    obj.rectangle218:setStrokeColor("white");
    obj.rectangle218:setXradius(5);
    obj.rectangle218:setYradius(5);
    obj.rectangle218:setMargins({top=15});
    obj.rectangle218:setName("rectangle218");

    obj.label217 = GUI.fromHandle(_obj_newObject("label"));
    obj.label217:setParent(obj.rectangle218);
    obj.label217:setText("D - 30% - Resistência");
    obj.label217:setFontColor("#5c2c00");
    obj.label217.grid.role = "col";
    obj.label217.grid.width = 12;
    obj.label217:setHeight(25);
    obj.label217:setHorzTextAlign("center");
    obj.label217:setFontSize(12);
    obj.label217:setName("label217");

    obj.rectangle219 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle219:setParent(obj.rectangle213);
    obj.rectangle219:setHeight(25);
    obj.rectangle219:setColor("#ff0000");
    obj.rectangle219:setCornerType("round");
    obj.rectangle219.grid.role = "col";
    obj.rectangle219.grid.width = 12;
    obj.rectangle219:setStrokeSize(1);
    obj.rectangle219:setStrokeColor("white");
    obj.rectangle219:setXradius(5);
    obj.rectangle219:setYradius(5);
    obj.rectangle219:setMargins({top=15});
    obj.rectangle219:setName("rectangle219");

    obj.label218 = GUI.fromHandle(_obj_newObject("label"));
    obj.label218:setParent(obj.rectangle219);
    obj.label218:setText("E - 10% - Rejeição");
    obj.label218:setFontColor("#ff9898");
    obj.label218.grid.role = "col";
    obj.label218.grid.width = 12;
    obj.label218:setHeight(25);
    obj.label218:setHorzTextAlign("center");
    obj.label218:setFontSize(12);
    obj.label218:setName("label218");

    obj.rectangle220 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle220:setParent(obj.rectangle213);
    obj.rectangle220:setHeight(25);
    obj.rectangle220:setColor("#000000");
    obj.rectangle220:setCornerType("round");
    obj.rectangle220.grid.role = "col";
    obj.rectangle220.grid.width = 12;
    obj.rectangle220:setStrokeSize(1);
    obj.rectangle220:setStrokeColor("white");
    obj.rectangle220:setXradius(5);
    obj.rectangle220:setYradius(5);
    obj.rectangle220:setMargins({top=15});
    obj.rectangle220:setName("rectangle220");

    obj.label219 = GUI.fromHandle(_obj_newObject("label"));
    obj.label219:setParent(obj.rectangle220);
    obj.label219:setText("F - 00% - Inversão");
    obj.label219:setFontColor("#fcfcfc");
    obj.label219.grid.role = "col";
    obj.label219.grid.width = 12;
    obj.label219:setHeight(25);
    obj.label219:setHorzTextAlign("center");
    obj.label219:setFontSize(12);
    obj.label219:setName("label219");

    obj.afinidadesmagia = GUI.fromHandle(_obj_newObject("image"));
    obj.afinidadesmagia:setParent(obj.rectangle210);
    obj.afinidadesmagia:setStyle("proportional");
    obj.afinidadesmagia:setAlign("client");
    obj.afinidadesmagia:setHeight(530);
    obj.afinidadesmagia:setName("afinidadesmagia");
    obj.afinidadesmagia:setSRC("/Imagens/03 - Afinidades/unico - mana.png");
    obj.afinidadesmagia:setMargins({left=10, top=10, right=10,bottom=15});
    obj.afinidadesmagia:setVisible(false);

    obj.apdivina = GUI.fromHandle(_obj_newObject("image"));
    obj.apdivina:setParent(obj.afinidadesmagia);
    obj.apdivina:setStyle("proportional");
    obj.apdivina:setAlign("client");
    obj.apdivina:setHeight(530);
    obj.apdivina:setName("apdivina");
    obj.apdivina:setField("apdivina");

    obj.apclarevidencia = GUI.fromHandle(_obj_newObject("image"));
    obj.apclarevidencia:setParent(obj.afinidadesmagia);
    obj.apclarevidencia:setStyle("proportional");
    obj.apclarevidencia:setAlign("client");
    obj.apclarevidencia:setHeight(530);
    obj.apclarevidencia:setName("apclarevidencia");
    obj.apclarevidencia:setField("apclarevidencia");

    obj.apespiritual = GUI.fromHandle(_obj_newObject("image"));
    obj.apespiritual:setParent(obj.afinidadesmagia);
    obj.apespiritual:setStyle("proportional");
    obj.apespiritual:setAlign("client");
    obj.apespiritual:setHeight(530);
    obj.apespiritual:setName("apespiritual");
    obj.apespiritual:setField("apespiritual");

    obj.apmental = GUI.fromHandle(_obj_newObject("image"));
    obj.apmental:setParent(obj.afinidadesmagia);
    obj.apmental:setStyle("proportional");
    obj.apmental:setAlign("client");
    obj.apmental:setHeight(530);
    obj.apmental:setName("apmental");
    obj.apmental:setField("apmental");

    obj.apelemental = GUI.fromHandle(_obj_newObject("image"));
    obj.apelemental:setParent(obj.afinidadesmagia);
    obj.apelemental:setStyle("proportional");
    obj.apelemental:setAlign("client");
    obj.apelemental:setHeight(530);
    obj.apelemental:setName("apelemental");
    obj.apelemental:setField("apelemental");

    obj.approducao = GUI.fromHandle(_obj_newObject("image"));
    obj.approducao:setParent(obj.afinidadesmagia);
    obj.approducao:setStyle("proportional");
    obj.approducao:setAlign("client");
    obj.approducao:setHeight(530);
    obj.approducao:setName("approducao");
    obj.approducao:setField("approducao");

    obj.apinvocacao = GUI.fromHandle(_obj_newObject("image"));
    obj.apinvocacao:setParent(obj.afinidadesmagia);
    obj.apinvocacao:setStyle("proportional");
    obj.apinvocacao:setAlign("client");
    obj.apinvocacao:setHeight(530);
    obj.apinvocacao:setName("apinvocacao");
    obj.apinvocacao:setField("apinvocacao");

    obj.apdemoniaca = GUI.fromHandle(_obj_newObject("image"));
    obj.apdemoniaca:setParent(obj.afinidadesmagia);
    obj.apdemoniaca:setStyle("proportional");
    obj.apdemoniaca:setAlign("client");
    obj.apdemoniaca:setHeight(530);
    obj.apdemoniaca:setName("apdemoniaca");
    obj.apdemoniaca:setField("apdemoniaca");

    obj.afinidadesaura = GUI.fromHandle(_obj_newObject("image"));
    obj.afinidadesaura:setParent(obj.rectangle210);
    obj.afinidadesaura:setStyle("proportional");
    obj.afinidadesaura:setAlign("client");
    obj.afinidadesaura:setHeight(530);
    obj.afinidadesaura:setName("afinidadesaura");
    obj.afinidadesaura:setSRC("/Imagens/03 - Afinidades/unico - aura.png");
    obj.afinidadesaura:setMargins({left=10, top=10, right=10,bottom=15});
    obj.afinidadesaura:setVisible(false);

    obj.apreforcofisico = GUI.fromHandle(_obj_newObject("image"));
    obj.apreforcofisico:setParent(obj.afinidadesaura);
    obj.apreforcofisico:setStyle("proportional");
    obj.apreforcofisico:setAlign("client");
    obj.apreforcofisico:setHeight(530);
    obj.apreforcofisico:setName("apreforcofisico");
    obj.apreforcofisico:setField("apreforcofisico");

    obj.aptransmutacao = GUI.fromHandle(_obj_newObject("image"));
    obj.aptransmutacao:setParent(obj.afinidadesaura);
    obj.aptransmutacao:setStyle("proportional");
    obj.aptransmutacao:setAlign("client");
    obj.aptransmutacao:setHeight(530);
    obj.aptransmutacao:setName("aptransmutacao");
    obj.aptransmutacao:setField("aptransmutacao");

    obj.apconjuracao = GUI.fromHandle(_obj_newObject("image"));
    obj.apconjuracao:setParent(obj.afinidadesaura);
    obj.apconjuracao:setStyle("proportional");
    obj.apconjuracao:setAlign("client");
    obj.apconjuracao:setHeight(530);
    obj.apconjuracao:setName("apconjuracao");
    obj.apconjuracao:setField("apconjuracao");

    obj.apreforcomental = GUI.fromHandle(_obj_newObject("image"));
    obj.apreforcomental:setParent(obj.afinidadesaura);
    obj.apreforcomental:setStyle("proportional");
    obj.apreforcomental:setAlign("client");
    obj.apreforcomental:setHeight(530);
    obj.apreforcomental:setName("apreforcomental");
    obj.apreforcomental:setField("apreforcomental");

    obj.apmanipulacao = GUI.fromHandle(_obj_newObject("image"));
    obj.apmanipulacao:setParent(obj.afinidadesaura);
    obj.apmanipulacao:setStyle("proportional");
    obj.apmanipulacao:setAlign("client");
    obj.apmanipulacao:setHeight(530);
    obj.apmanipulacao:setName("apmanipulacao");
    obj.apmanipulacao:setField("apmanipulacao");

    obj.apemissao = GUI.fromHandle(_obj_newObject("image"));
    obj.apemissao:setParent(obj.afinidadesaura);
    obj.apemissao:setStyle("proportional");
    obj.apemissao:setAlign("client");
    obj.apemissao:setHeight(530);
    obj.apemissao:setName("apemissao");
    obj.apemissao:setField("apemissao");

    obj.botaocondicao = GUI.fromHandle(_obj_newObject("button"));
    obj.botaocondicao:setParent(obj.rectangle210);
    obj.botaocondicao:setName("botaocondicao");
    obj.botaocondicao:setAlign("bottom");
    obj.botaocondicao:setText("Alterar");
    obj.botaocondicao:setLeft(10);
    obj.botaocondicao:setTop(10);
    obj.botaocondicao:setHeight(20);
    obj.botaocondicao:setWidth(10);
    obj.botaocondicao:setMargins({left=10, right=10,bottom=10});

    obj.condicoescorpo = GUI.fromHandle(_obj_newObject("popup"));
    obj.condicoescorpo:setParent(obj.rectangle210);
    obj.condicoescorpo:setName("condicoescorpo");
    obj.condicoescorpo:setWidth(400);
    obj.condicoescorpo:setHeight(400);

    obj.afmagias = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.afmagias:setParent(obj.condicoescorpo);
    obj.afmagias:setName("afmagias");
    obj.afmagias:setHeight(200);
    obj.afmagias:setColor("none");
    obj.afmagias:setCornerType("round");
    obj.afmagias.grid.role = "col";
    obj.afmagias.grid.width = 12;
    obj.afmagias:setStrokeSize(1);
    obj.afmagias:setStrokeColor("white");
    obj.afmagias:setXradius(5);
    obj.afmagias:setYradius(5);
    obj.afmagias:setMargins({left=15, right=15, top=20});

    obj.label220 = GUI.fromHandle(_obj_newObject("label"));
    obj.label220:setParent(obj.afmagias);
    obj.label220.grid.role = "col";
    obj.label220.grid.width = 2;
    obj.label220:setName("label220");

    obj.rectangle221 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle221:setParent(obj.afmagias);
    obj.rectangle221:setHeight(25);
    obj.rectangle221:setColor("none");
    obj.rectangle221:setCornerType("round");
    obj.rectangle221.grid.role = "col";
    obj.rectangle221.grid.width = 4;
    obj.rectangle221:setStrokeSize(1);
    obj.rectangle221:setStrokeColor("white");
    obj.rectangle221:setXradius(5);
    obj.rectangle221:setYradius(5);
    obj.rectangle221:setMargins({top=15});
    obj.rectangle221:setName("rectangle221");

    obj.comboBox21 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox21:setParent(obj.rectangle221);
    obj.comboBox21:setField("afdivina");
    obj.comboBox21.grid.role = "col";
    obj.comboBox21.grid.width = 12;
    obj.comboBox21:setHeight(25);
    obj.comboBox21:setHorzTextAlign("center");
    obj.comboBox21:setFontFamily("Cinzel");
    obj.comboBox21:setTransparent(true);
    obj.comboBox21:setFontSize(12);
    obj.comboBox21:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox21:setName("comboBox21");

    obj.label221 = GUI.fromHandle(_obj_newObject("label"));
    obj.label221:setParent(obj.afmagias);
    obj.label221.grid.role = "col";
    obj.label221.grid.width = 1;
    obj.label221:setName("label221");

    obj.rectangle222 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle222:setParent(obj.afmagias);
    obj.rectangle222:setHeight(25);
    obj.rectangle222:setColor("none");
    obj.rectangle222:setCornerType("round");
    obj.rectangle222.grid.role = "col";
    obj.rectangle222.grid.width = 4;
    obj.rectangle222:setStrokeSize(1);
    obj.rectangle222:setStrokeColor("white");
    obj.rectangle222:setXradius(5);
    obj.rectangle222:setYradius(5);
    obj.rectangle222:setMargins({top=15});
    obj.rectangle222:setName("rectangle222");

    obj.comboBox22 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox22:setParent(obj.rectangle222);
    obj.comboBox22:setField("afclarevidencia");
    obj.comboBox22.grid.role = "col";
    obj.comboBox22.grid.width = 12;
    obj.comboBox22:setHeight(25);
    obj.comboBox22:setHorzTextAlign("center");
    obj.comboBox22:setFontFamily("Cinzel");
    obj.comboBox22:setTransparent(true);
    obj.comboBox22:setFontSize(12);
    obj.comboBox22:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox22:setName("comboBox22");

    obj.rectangle223 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle223:setParent(obj.afmagias);
    obj.rectangle223:setHeight(25);
    obj.rectangle223:setColor("none");
    obj.rectangle223:setCornerType("round");
    obj.rectangle223.grid.role = "col";
    obj.rectangle223.grid.width = 4;
    obj.rectangle223:setStrokeSize(1);
    obj.rectangle223:setStrokeColor("white");
    obj.rectangle223:setXradius(5);
    obj.rectangle223:setYradius(5);
    obj.rectangle223:setMargins({top=15});
    obj.rectangle223:setName("rectangle223");

    obj.comboBox23 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox23:setParent(obj.rectangle223);
    obj.comboBox23:setField("afespiritual");
    obj.comboBox23.grid.role = "col";
    obj.comboBox23.grid.width = 12;
    obj.comboBox23:setHeight(25);
    obj.comboBox23:setHorzTextAlign("center");
    obj.comboBox23:setFontFamily("Cinzel");
    obj.comboBox23:setTransparent(true);
    obj.comboBox23:setFontSize(12);
    obj.comboBox23:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox23:setName("comboBox23");

    obj.label222 = GUI.fromHandle(_obj_newObject("label"));
    obj.label222:setParent(obj.afmagias);
    obj.label222.grid.role = "col";
    obj.label222.grid.width = 4;
    obj.label222:setName("label222");

    obj.rectangle224 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle224:setParent(obj.afmagias);
    obj.rectangle224:setHeight(25);
    obj.rectangle224:setColor("none");
    obj.rectangle224:setCornerType("round");
    obj.rectangle224.grid.role = "col";
    obj.rectangle224.grid.width = 4;
    obj.rectangle224:setStrokeSize(1);
    obj.rectangle224:setStrokeColor("white");
    obj.rectangle224:setXradius(5);
    obj.rectangle224:setYradius(5);
    obj.rectangle224:setMargins({top=15});
    obj.rectangle224:setName("rectangle224");

    obj.comboBox24 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox24:setParent(obj.rectangle224);
    obj.comboBox24:setField("afmental");
    obj.comboBox24.grid.role = "col";
    obj.comboBox24.grid.width = 12;
    obj.comboBox24:setHeight(25);
    obj.comboBox24:setHorzTextAlign("center");
    obj.comboBox24:setFontFamily("Cinzel");
    obj.comboBox24:setTransparent(true);
    obj.comboBox24:setFontSize(12);
    obj.comboBox24:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox24:setName("comboBox24");

    obj.rectangle225 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle225:setParent(obj.afmagias);
    obj.rectangle225:setHeight(25);
    obj.rectangle225:setColor("none");
    obj.rectangle225:setCornerType("round");
    obj.rectangle225.grid.role = "col";
    obj.rectangle225.grid.width = 4;
    obj.rectangle225:setStrokeSize(1);
    obj.rectangle225:setStrokeColor("white");
    obj.rectangle225:setXradius(5);
    obj.rectangle225:setYradius(5);
    obj.rectangle225:setMargins({top=15});
    obj.rectangle225:setName("rectangle225");

    obj.comboBox25 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox25:setParent(obj.rectangle225);
    obj.comboBox25:setField("afelemental");
    obj.comboBox25.grid.role = "col";
    obj.comboBox25.grid.width = 12;
    obj.comboBox25:setHeight(25);
    obj.comboBox25:setHorzTextAlign("center");
    obj.comboBox25:setFontFamily("Cinzel");
    obj.comboBox25:setTransparent(true);
    obj.comboBox25:setFontSize(12);
    obj.comboBox25:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox25:setName("comboBox25");

    obj.label223 = GUI.fromHandle(_obj_newObject("label"));
    obj.label223:setParent(obj.afmagias);
    obj.label223.grid.role = "col";
    obj.label223.grid.width = 4;
    obj.label223:setName("label223");

    obj.rectangle226 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle226:setParent(obj.afmagias);
    obj.rectangle226:setHeight(25);
    obj.rectangle226:setColor("none");
    obj.rectangle226:setCornerType("round");
    obj.rectangle226.grid.role = "col";
    obj.rectangle226.grid.width = 4;
    obj.rectangle226:setStrokeSize(1);
    obj.rectangle226:setStrokeColor("white");
    obj.rectangle226:setXradius(5);
    obj.rectangle226:setYradius(5);
    obj.rectangle226:setMargins({top=15});
    obj.rectangle226:setName("rectangle226");

    obj.comboBox26 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox26:setParent(obj.rectangle226);
    obj.comboBox26:setField("afproducao");
    obj.comboBox26.grid.role = "col";
    obj.comboBox26.grid.width = 12;
    obj.comboBox26:setHeight(25);
    obj.comboBox26:setHorzTextAlign("center");
    obj.comboBox26:setFontFamily("Cinzel");
    obj.comboBox26:setTransparent(true);
    obj.comboBox26:setFontSize(12);
    obj.comboBox26:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox26:setName("comboBox26");

    obj.label224 = GUI.fromHandle(_obj_newObject("label"));
    obj.label224:setParent(obj.afmagias);
    obj.label224.grid.role = "col";
    obj.label224.grid.width = 2;
    obj.label224:setName("label224");

    obj.rectangle227 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle227:setParent(obj.afmagias);
    obj.rectangle227:setHeight(25);
    obj.rectangle227:setColor("none");
    obj.rectangle227:setCornerType("round");
    obj.rectangle227.grid.role = "col";
    obj.rectangle227.grid.width = 4;
    obj.rectangle227:setStrokeSize(1);
    obj.rectangle227:setStrokeColor("white");
    obj.rectangle227:setXradius(5);
    obj.rectangle227:setYradius(5);
    obj.rectangle227:setMargins({top=15});
    obj.rectangle227:setName("rectangle227");

    obj.comboBox27 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox27:setParent(obj.rectangle227);
    obj.comboBox27:setField("afinvocacao");
    obj.comboBox27.grid.role = "col";
    obj.comboBox27.grid.width = 12;
    obj.comboBox27:setHeight(25);
    obj.comboBox27:setHorzTextAlign("center");
    obj.comboBox27:setFontFamily("Cinzel");
    obj.comboBox27:setTransparent(true);
    obj.comboBox27:setFontSize(12);
    obj.comboBox27:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox27:setName("comboBox27");

    obj.label225 = GUI.fromHandle(_obj_newObject("label"));
    obj.label225:setParent(obj.afmagias);
    obj.label225.grid.role = "col";
    obj.label225.grid.width = 1;
    obj.label225:setName("label225");

    obj.rectangle228 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle228:setParent(obj.afmagias);
    obj.rectangle228:setHeight(25);
    obj.rectangle228:setColor("none");
    obj.rectangle228:setCornerType("round");
    obj.rectangle228.grid.role = "col";
    obj.rectangle228.grid.width = 4;
    obj.rectangle228:setStrokeSize(1);
    obj.rectangle228:setStrokeColor("white");
    obj.rectangle228:setXradius(5);
    obj.rectangle228:setYradius(5);
    obj.rectangle228:setMargins({top=15});
    obj.rectangle228:setName("rectangle228");

    obj.comboBox28 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox28:setParent(obj.rectangle228);
    obj.comboBox28:setField("afdemoniaca");
    obj.comboBox28.grid.role = "col";
    obj.comboBox28.grid.width = 12;
    obj.comboBox28:setHeight(25);
    obj.comboBox28:setHorzTextAlign("center");
    obj.comboBox28:setFontFamily("Cinzel");
    obj.comboBox28:setTransparent(true);
    obj.comboBox28:setFontSize(12);
    obj.comboBox28:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox28:setName("comboBox28");

    obj.afauras = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.afauras:setParent(obj.condicoescorpo);
    obj.afauras:setName("afauras");
    obj.afauras:setHeight(200);
    obj.afauras:setColor("none");
    obj.afauras:setCornerType("round");
    obj.afauras.grid.role = "col";
    obj.afauras.grid.width = 12;
    obj.afauras:setStrokeSize(1);
    obj.afauras:setStrokeColor("white");
    obj.afauras:setXradius(5);
    obj.afauras:setYradius(5);
    obj.afauras:setMargins({left=15, right=15, top=10});

    obj.label226 = GUI.fromHandle(_obj_newObject("label"));
    obj.label226:setParent(obj.afauras);
    obj.label226.grid.role = "col";
    obj.label226.grid.width = 4;
    obj.label226:setName("label226");

    obj.rectangle229 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle229:setParent(obj.afauras);
    obj.rectangle229:setHeight(25);
    obj.rectangle229:setColor("none");
    obj.rectangle229:setCornerType("round");
    obj.rectangle229.grid.role = "col";
    obj.rectangle229.grid.width = 4;
    obj.rectangle229:setStrokeSize(1);
    obj.rectangle229:setStrokeColor("white");
    obj.rectangle229:setXradius(5);
    obj.rectangle229:setYradius(5);
    obj.rectangle229:setMargins({top=15});
    obj.rectangle229:setName("rectangle229");

    obj.comboBox29 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox29:setParent(obj.rectangle229);
    obj.comboBox29:setField("afreforcof");
    obj.comboBox29.grid.role = "col";
    obj.comboBox29.grid.width = 12;
    obj.comboBox29:setHeight(25);
    obj.comboBox29:setHorzTextAlign("center");
    obj.comboBox29:setFontFamily("Cinzel");
    obj.comboBox29:setTransparent(true);
    obj.comboBox29:setFontSize(12);
    obj.comboBox29:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox29:setName("comboBox29");

    obj.label227 = GUI.fromHandle(_obj_newObject("label"));
    obj.label227:setParent(obj.afauras);
    obj.label227.grid.role = "col";
    obj.label227.grid.width = 4;
    obj.label227:setName("label227");

    obj.rectangle230 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle230:setParent(obj.afauras);
    obj.rectangle230:setHeight(25);
    obj.rectangle230:setColor("none");
    obj.rectangle230:setCornerType("round");
    obj.rectangle230.grid.role = "col";
    obj.rectangle230.grid.width = 4;
    obj.rectangle230:setStrokeSize(1);
    obj.rectangle230:setStrokeColor("white");
    obj.rectangle230:setXradius(5);
    obj.rectangle230:setYradius(5);
    obj.rectangle230:setMargins({top=15});
    obj.rectangle230:setName("rectangle230");

    obj.comboBox30 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox30:setParent(obj.rectangle230);
    obj.comboBox30:setField("afemissao");
    obj.comboBox30.grid.role = "col";
    obj.comboBox30.grid.width = 12;
    obj.comboBox30:setHeight(25);
    obj.comboBox30:setHorzTextAlign("center");
    obj.comboBox30:setFontFamily("Cinzel");
    obj.comboBox30:setTransparent(true);
    obj.comboBox30:setFontSize(12);
    obj.comboBox30:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox30:setName("comboBox30");

    obj.label228 = GUI.fromHandle(_obj_newObject("label"));
    obj.label228:setParent(obj.afauras);
    obj.label228.grid.role = "col";
    obj.label228.grid.width = 4;
    obj.label228:setName("label228");

    obj.rectangle231 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle231:setParent(obj.afauras);
    obj.rectangle231:setHeight(25);
    obj.rectangle231:setColor("none");
    obj.rectangle231:setCornerType("round");
    obj.rectangle231.grid.role = "col";
    obj.rectangle231.grid.width = 4;
    obj.rectangle231:setStrokeSize(1);
    obj.rectangle231:setStrokeColor("white");
    obj.rectangle231:setXradius(5);
    obj.rectangle231:setYradius(5);
    obj.rectangle231:setMargins({top=15});
    obj.rectangle231:setName("rectangle231");

    obj.comboBox31 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox31:setParent(obj.rectangle231);
    obj.comboBox31:setField("aftransmutacao");
    obj.comboBox31.grid.role = "col";
    obj.comboBox31.grid.width = 12;
    obj.comboBox31:setHeight(25);
    obj.comboBox31:setHorzTextAlign("center");
    obj.comboBox31:setFontFamily("Cinzel");
    obj.comboBox31:setTransparent(true);
    obj.comboBox31:setFontSize(12);
    obj.comboBox31:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox31:setName("comboBox31");

    obj.rectangle232 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle232:setParent(obj.afauras);
    obj.rectangle232:setHeight(25);
    obj.rectangle232:setColor("none");
    obj.rectangle232:setCornerType("round");
    obj.rectangle232.grid.role = "col";
    obj.rectangle232.grid.width = 4;
    obj.rectangle232:setStrokeSize(1);
    obj.rectangle232:setStrokeColor("white");
    obj.rectangle232:setXradius(5);
    obj.rectangle232:setYradius(5);
    obj.rectangle232:setMargins({top=15});
    obj.rectangle232:setName("rectangle232");

    obj.comboBox32 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox32:setParent(obj.rectangle232);
    obj.comboBox32:setField("afmanipulacao");
    obj.comboBox32.grid.role = "col";
    obj.comboBox32.grid.width = 12;
    obj.comboBox32:setHeight(25);
    obj.comboBox32:setHorzTextAlign("center");
    obj.comboBox32:setFontFamily("Cinzel");
    obj.comboBox32:setTransparent(true);
    obj.comboBox32:setFontSize(12);
    obj.comboBox32:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox32:setName("comboBox32");

    obj.label229 = GUI.fromHandle(_obj_newObject("label"));
    obj.label229:setParent(obj.afauras);
    obj.label229.grid.role = "col";
    obj.label229.grid.width = 4;
    obj.label229:setName("label229");

    obj.rectangle233 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle233:setParent(obj.afauras);
    obj.rectangle233:setHeight(25);
    obj.rectangle233:setColor("none");
    obj.rectangle233:setCornerType("round");
    obj.rectangle233.grid.role = "col";
    obj.rectangle233.grid.width = 4;
    obj.rectangle233:setStrokeSize(1);
    obj.rectangle233:setStrokeColor("white");
    obj.rectangle233:setXradius(5);
    obj.rectangle233:setYradius(5);
    obj.rectangle233:setMargins({top=15});
    obj.rectangle233:setName("rectangle233");

    obj.comboBox33 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox33:setParent(obj.rectangle233);
    obj.comboBox33:setField("afconjuracao");
    obj.comboBox33.grid.role = "col";
    obj.comboBox33.grid.width = 12;
    obj.comboBox33:setHeight(25);
    obj.comboBox33:setHorzTextAlign("center");
    obj.comboBox33:setFontFamily("Cinzel");
    obj.comboBox33:setTransparent(true);
    obj.comboBox33:setFontSize(12);
    obj.comboBox33:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox33:setName("comboBox33");

    obj.label230 = GUI.fromHandle(_obj_newObject("label"));
    obj.label230:setParent(obj.afauras);
    obj.label230.grid.role = "col";
    obj.label230.grid.width = 4;
    obj.label230:setName("label230");

    obj.rectangle234 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle234:setParent(obj.afauras);
    obj.rectangle234:setHeight(25);
    obj.rectangle234:setColor("none");
    obj.rectangle234:setCornerType("round");
    obj.rectangle234.grid.role = "col";
    obj.rectangle234.grid.width = 4;
    obj.rectangle234:setStrokeSize(1);
    obj.rectangle234:setStrokeColor("white");
    obj.rectangle234:setXradius(5);
    obj.rectangle234:setYradius(5);
    obj.rectangle234:setMargins({top=15});
    obj.rectangle234:setName("rectangle234");

    obj.comboBox34 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox34:setParent(obj.rectangle234);
    obj.comboBox34:setField("afreforcom");
    obj.comboBox34.grid.role = "col";
    obj.comboBox34.grid.width = 12;
    obj.comboBox34:setHeight(25);
    obj.comboBox34:setHorzTextAlign("center");
    obj.comboBox34:setFontFamily("Cinzel");
    obj.comboBox34:setTransparent(true);
    obj.comboBox34:setFontSize(12);
    obj.comboBox34:setItems({'Padrão', 'S', 'A', 'B', 'C', 'D', 'E', 'F'});
    obj.comboBox34:setName("comboBox34");

    obj.aba_raca = GUI.fromHandle(_obj_newObject("tab"));
    obj.aba_raca:setParent(obj.ficha);
    obj.aba_raca:setName("aba_raca");
    obj.aba_raca:setTitle("Raça");

    obj.rectangle235 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle235:setParent(obj.aba_raca);
    obj.rectangle235:setAlign("client");
    obj.rectangle235:setColor("black");
    obj.rectangle235:setName("rectangle235");

    obj.scrollBox11 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox11:setParent(obj.rectangle235);
    obj.scrollBox11:setAlign("client");
    obj.scrollBox11:setMargins({left=5,right=5});
    obj.scrollBox11:setName("scrollBox11");

    obj.rectangle236 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle236:setParent(obj.scrollBox11);
    obj.rectangle236:setColor("#150e16");
    obj.rectangle236:setStrokeSize(2);
    obj.rectangle236:setStrokeColor("white");
    obj.rectangle236.grid.role = "col";
    obj.rectangle236.grid.width = 5;
    obj.rectangle236.grid["max-width"] = 1080;
    obj.rectangle236.grid["min-width"] = 400;
    obj.rectangle236.grid["min-height"] = 550;
    obj.rectangle236.grid["max-height"] = 1080;
    obj.rectangle236:setMargins({top=15});
    obj.rectangle236:setName("rectangle236");

    obj.label231 = GUI.fromHandle(_obj_newObject("label"));
    obj.label231:setParent(obj.rectangle236);
    obj.label231:setHeight(25);
    obj.label231:setText("As Raças");
    obj.label231:setFontSize(50);
    obj.label231.grid.role = "col";
    obj.label231.grid.width = 12;
    obj.label231:setFontFamily("Wishes Script Caps Display");
    obj.label231:setHorzTextAlign("center");
    obj.label231:setMargins({top=15});
    obj.label231:setName("label231");

    obj.label232 = GUI.fromHandle(_obj_newObject("label"));
    obj.label232:setParent(obj.label231);
    obj.label232.grid.role = "col";
    obj.label232.grid.width = 11;
    obj.label232:setName("label232");

    obj.button17 = GUI.fromHandle(_obj_newObject("button"));
    obj.button17:setParent(obj.label231);
    obj.button17.grid.role = "col";
    obj.button17.grid.width = 1;
    obj.button17:setText("?");
    obj.button17:setMargins({right=5});
    obj.button17:setName("button17");

    obj.rectangle237 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle237:setParent(obj.rectangle236);
    obj.rectangle237:setHeight(25);
    obj.rectangle237:setColor("black");
    obj.rectangle237.grid.role = "col";
    obj.rectangle237.grid.width = 12;
    obj.rectangle237:setStrokeSize(1);
    obj.rectangle237:setStrokeColor("white");
    obj.rectangle237:setCornerType("round");
    obj.rectangle237:setXradius(5);
    obj.rectangle237:setYradius(5);
    obj.rectangle237:setMargins({top=5,right=5,left=5});
    obj.rectangle237:setName("rectangle237");

    obj.combo_racas_gerais = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.combo_racas_gerais:setParent(obj.rectangle237);
    obj.combo_racas_gerais:setName("combo_racas_gerais");
    obj.combo_racas_gerais:setField("racas_gerais");
    obj.combo_racas_gerais.grid.role = "col";
    obj.combo_racas_gerais.grid.width = 12;
    obj.combo_racas_gerais:setHeight(30);
    obj.combo_racas_gerais:setFontFamily("Wishes Script Caps Display");
    obj.combo_racas_gerais:setTransparent(true);
    obj.combo_racas_gerais:setFontSize(20);
    obj.combo_racas_gerais:setHorzTextAlign("center");
    obj.combo_racas_gerais:setVertTextAlign("center");
    obj.combo_racas_gerais:setItems({'Humanos','Altos Humanos','Anões','Aveanos','Brotelis','Elfos', 'Insectoides', 'Merfolk', 'Reptideos', 'Stoneliths', 'Werebeasts', 'Wixilis'});

    obj.image32 = GUI.fromHandle(_obj_newObject("image"));
    obj.image32:setParent(obj.rectangle236);
    obj.image32:setField("imagem_raca");
    obj.image32.grid.role = "col";
    obj.image32.grid.width = 12;
    obj.image32:setHeight(140);
    obj.image32:setStyle("proportional");
    obj.image32:setEditable(false);
    obj.image32:setMargins({top=5,right=5,left=5});
    obj.image32:setName("image32");

    obj.dataLink72 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink72:setParent(obj.rectangle236);
    obj.dataLink72:setField("racas_gerais");
    obj.dataLink72:setDefaultValue("Humanos");
    obj.dataLink72:setName("dataLink72");

    obj.label233 = GUI.fromHandle(_obj_newObject("label"));
    obj.label233:setParent(obj.rectangle236);
    obj.label233:setText("Informações:");
    obj.label233.grid.role = "col";
    obj.label233.grid.width = 12;
    obj.label233:setHeight(20);
    obj.label233:setFontSize(12);
    obj.label233:setFontFamily("Wishes Script Caps Display");
    obj.label233:setMargins({left=10});
    obj.label233:setName("label233");

    obj.rectangle238 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle238:setParent(obj.rectangle236);
    obj.rectangle238:setHeight(150);
    obj.rectangle238:setColor("black");
    obj.rectangle238.grid.role = "col";
    obj.rectangle238.grid.width = 12;
    obj.rectangle238:setStrokeSize(1);
    obj.rectangle238:setStrokeColor("white");
    obj.rectangle238:setCornerType("round");
    obj.rectangle238:setXradius(5);
    obj.rectangle238:setYradius(5);
    obj.rectangle238:setMargins({left=10,right=10});
    obj.rectangle238:setName("rectangle238");

    obj.textEditor36 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor36:setParent(obj.rectangle238);
    obj.textEditor36:setReadOnly(true);
    obj.textEditor36:setField("infos");
    obj.textEditor36:setFontSize(12);
    obj.textEditor36:setAlign("client");
    obj.textEditor36:setTransparent(true);
    obj.textEditor36:setName("textEditor36");

    obj.label234 = GUI.fromHandle(_obj_newObject("label"));
    obj.label234:setParent(obj.rectangle236);
    obj.label234:setText("Condição de Conquista:");
    obj.label234.grid.role = "col";
    obj.label234.grid.width = 6;
    obj.label234:setHeight(20);
    obj.label234:setFontSize(12);
    obj.label234:setFontFamily("Wishes Script Caps Display");
    obj.label234:setMargins({left=10,top=5});
    obj.label234:setName("label234");

    obj.rectangle239 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle239:setParent(obj.rectangle236);
    obj.rectangle239:setHeight(70);
    obj.rectangle239:setColor("black");
    obj.rectangle239.grid.role = "col";
    obj.rectangle239.grid.width = 12;
    obj.rectangle239:setStrokeSize(1);
    obj.rectangle239:setStrokeColor("white");
    obj.rectangle239:setCornerType("round");
    obj.rectangle239:setXradius(5);
    obj.rectangle239:setYradius(5);
    obj.rectangle239:setMargins({left=10,right=10});
    obj.rectangle239:setName("rectangle239");

    obj.textEditor37 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor37:setParent(obj.rectangle239);
    obj.textEditor37:setReadOnly(true);
    obj.textEditor37:setField("condicao_conquista");
    obj.textEditor37:setFontSize(12);
    obj.textEditor37:setAlign("client");
    obj.textEditor37:setTransparent(true);
    obj.textEditor37:setName("textEditor37");

    obj.label235 = GUI.fromHandle(_obj_newObject("label"));
    obj.label235:setParent(obj.rectangle236);
    obj.label235:setText("Subespécies:");
    obj.label235.grid.role = "col";
    obj.label235.grid.width = 6;
    obj.label235:setHeight(20);
    obj.label235:setFontSize(12);
    obj.label235:setFontFamily("Wishes Script Caps Display");
    obj.label235:setMargins({left=10,top=5});
    obj.label235:setName("label235");

    obj.rectangle240 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle240:setParent(obj.rectangle236);
    obj.rectangle240:setHeight(37);
    obj.rectangle240:setColor("black");
    obj.rectangle240.grid.role = "col";
    obj.rectangle240.grid.width = 12;
    obj.rectangle240:setStrokeSize(1);
    obj.rectangle240:setStrokeColor("white");
    obj.rectangle240:setCornerType("round");
    obj.rectangle240:setXradius(5);
    obj.rectangle240:setYradius(5);
    obj.rectangle240:setMargins({left=10,right=10});
    obj.rectangle240:setName("rectangle240");

    obj.textEditor38 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor38:setParent(obj.rectangle240);
    obj.textEditor38:setReadOnly(true);
    obj.textEditor38:setField("subespecies");
    obj.textEditor38:setFontSize(12);
    obj.textEditor38:setAlign("client");
    obj.textEditor38:setTransparent(true);
    obj.textEditor38:setName("textEditor38");

    obj.explicacao_raca = GUI.fromHandle(_obj_newObject("popup"));
    obj.explicacao_raca:setParent(obj.rectangle236);
    obj.explicacao_raca:setName("explicacao_raca");
    obj.explicacao_raca:setWidth(400);
    obj.explicacao_raca:setHeight(600);
    obj.explicacao_raca:setBackOpacity(0.5);

    obj.rectangle241 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle241:setParent(obj.explicacao_raca);
    obj.rectangle241:setColor("black");
    obj.rectangle241:setLeft(-5);
    obj.rectangle241:setTop(-5);
    obj.rectangle241:setWidth(410);
    obj.rectangle241:setHeight(610);
    obj.rectangle241:setName("rectangle241");

    obj.rectangle242 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle242:setParent(obj.explicacao_raca);
    obj.rectangle242:setColor("#150e16");
    obj.rectangle242:setStrokeSize(2);
    obj.rectangle242:setStrokeColor("white");
    obj.rectangle242:setLeft(5);
    obj.rectangle242:setTop(5);
    obj.rectangle242:setWidth(390);
    obj.rectangle242:setHeight(590);
    obj.rectangle242:setCornerType("round");
    obj.rectangle242:setXradius(5);
    obj.rectangle242:setYradius(5);
    obj.rectangle242:setName("rectangle242");

    obj.label236 = GUI.fromHandle(_obj_newObject("label"));
    obj.label236:setParent(obj.explicacao_raca);
    obj.label236:setText("Conquistas de Raça");
    obj.label236:setHeight(30);
    obj.label236:setFontSize(25);
    obj.label236.grid.role = "col";
    obj.label236.grid.width = 12;
    obj.label236:setFontFamily("Wishes Script Caps Display");
    obj.label236:setHorzTextAlign("center");
    obj.label236:setVertTextAlign("center");
    obj.label236:setMargins({top=10});
    obj.label236:setName("label236");

    obj.label237 = GUI.fromHandle(_obj_newObject("label"));
    obj.label237:setParent(obj.explicacao_raca);
    obj.label237:setText("Seu primeiro personagem?");
    obj.label237.grid.role = "col";
    obj.label237.grid.width = 12;
    obj.label237:setHeight(20);
    obj.label237:setFontSize(20);
    obj.label237:setFontFamily("Wishes Script Caps Display");
    obj.label237:setMargins({left=10,top=10});
    obj.label237:setName("label237");

    obj.rectangle243 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle243:setParent(obj.explicacao_raca);
    obj.rectangle243:setHeight(40);
    obj.rectangle243:setColor("black");
    obj.rectangle243.grid.role = "col";
    obj.rectangle243.grid.width = 12;
    obj.rectangle243:setStrokeSize(1);
    obj.rectangle243:setStrokeColor("white");
    obj.rectangle243:setCornerType("round");
    obj.rectangle243:setXradius(5);
    obj.rectangle243:setYradius(5);
    obj.rectangle243:setMargins({left=10,right=10});
    obj.rectangle243:setName("rectangle243");

    obj.textEditor39 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor39:setParent(obj.rectangle243);
    obj.textEditor39:setReadOnly(true);
    obj.textEditor39:setText("O seu primeiro personagem será sempre um humano.");
    obj.textEditor39:setFontSize(12);
    obj.textEditor39:setAlign("client");
    obj.textEditor39:setTransparent(true);
    obj.textEditor39:setName("textEditor39");

    obj.label238 = GUI.fromHandle(_obj_newObject("label"));
    obj.label238:setParent(obj.explicacao_raca);
    obj.label238:setText("Como Desbloquear uma Raça?");
    obj.label238.grid.role = "col";
    obj.label238.grid.width = 12;
    obj.label238:setHeight(20);
    obj.label238:setFontSize(20);
    obj.label238:setFontFamily("Wishes Script Caps Display");
    obj.label238:setMargins({left=10,top=10});
    obj.label238:setName("label238");

    obj.rectangle244 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle244:setParent(obj.explicacao_raca);
    obj.rectangle244:setHeight(120);
    obj.rectangle244:setColor("black");
    obj.rectangle244.grid.role = "col";
    obj.rectangle244.grid.width = 12;
    obj.rectangle244:setStrokeSize(1);
    obj.rectangle244:setStrokeColor("white");
    obj.rectangle244:setCornerType("round");
    obj.rectangle244:setXradius(5);
    obj.rectangle244:setYradius(5);
    obj.rectangle244:setMargins({left=10,right=10});
    obj.rectangle244:setName("rectangle244");

    obj.textEditor40 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor40:setParent(obj.rectangle244);
    obj.textEditor40:setReadOnly(true);
    obj.textEditor40:setText("Novas raças são desbloqueadas através de um sistema de conquistas.\n\nFunciona da seguinte maneira: \nVocê precisa cumprir  in game um requisito específico pré-definido. Após cumprir esse requisito, você desbloqueia a raça. \nA conquista da raça é individual e intransferível.");
    obj.textEditor40:setFontSize(12);
    obj.textEditor40:setAlign("client");
    obj.textEditor40:setTransparent(true);
    obj.textEditor40:setName("textEditor40");

    obj.label239 = GUI.fromHandle(_obj_newObject("label"));
    obj.label239:setParent(obj.explicacao_raca);
    obj.label239:setText("Quando pode usar as Raça que já desbloqueou?");
    obj.label239.grid.role = "col";
    obj.label239.grid.width = 12;
    obj.label239:setHeight(20);
    obj.label239:setFontSize(18);
    obj.label239:setFontFamily("Wishes Script Caps Display");
    obj.label239:setMargins({left=10,top=10});
    obj.label239:setName("label239");

    obj.rectangle245 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle245:setParent(obj.explicacao_raca);
    obj.rectangle245:setHeight(100);
    obj.rectangle245:setColor("black");
    obj.rectangle245.grid.role = "col";
    obj.rectangle245.grid.width = 12;
    obj.rectangle245:setStrokeSize(1);
    obj.rectangle245:setStrokeColor("white");
    obj.rectangle245:setCornerType("round");
    obj.rectangle245:setXradius(5);
    obj.rectangle245:setYradius(5);
    obj.rectangle245:setMargins({left=10,right=10});
    obj.rectangle245:setName("rectangle245");

    obj.textEditor41 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor41:setParent(obj.rectangle245);
    obj.textEditor41:setReadOnly(true);
    obj.textEditor41:setText("Quando  você morrer, assim como quando criou sua primeira ficha, irá rolar as invocações novamente para ver a origem e estrelas do novo personagem. Adicionalmente pode escolher a raça do seu personagem entre humano e as raças que tiver conquistado.");
    obj.textEditor41:setFontSize(12);
    obj.textEditor41:setAlign("client");
    obj.textEditor41:setTransparent(true);
    obj.textEditor41:setName("textEditor41");

    obj.label240 = GUI.fromHandle(_obj_newObject("label"));
    obj.label240:setParent(obj.explicacao_raca);
    obj.label240:setText("⚠Importante⚠ Aparência:");
    obj.label240.grid.role = "col";
    obj.label240.grid.width = 12;
    obj.label240:setHeight(20);
    obj.label240:setFontSize(20);
    obj.label240:setFontFamily("Wishes Script Caps Display");
    obj.label240:setMargins({left=10,top=10});
    obj.label240:setName("label240");

    obj.rectangle246 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle246:setParent(obj.explicacao_raca);
    obj.rectangle246:setHeight(120);
    obj.rectangle246:setColor("black");
    obj.rectangle246.grid.role = "col";
    obj.rectangle246.grid.width = 12;
    obj.rectangle246:setStrokeSize(1);
    obj.rectangle246:setStrokeColor("white");
    obj.rectangle246:setCornerType("round");
    obj.rectangle246:setXradius(5);
    obj.rectangle246:setYradius(5);
    obj.rectangle246:setMargins({left=10,right=10});
    obj.rectangle246:setName("rectangle246");

    obj.textEditor42 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor42:setParent(obj.rectangle246);
    obj.textEditor42:setReadOnly(true);
    obj.textEditor42:setText("As demais especies não tem aperência humana, um werebeast por exemplo jamais terá a aparencia de um humano normal com apenas caracteristicas animais como orelhas e garras, eles tem a aparência de animais, porém bipedes. \nA unica raça que tem a aparência de um humano misturado com outro animal são as subespecies de Alto Humano.");
    obj.textEditor42:setFontSize(12);
    obj.textEditor42:setAlign("client");
    obj.textEditor42:setTransparent(true);
    obj.textEditor42:setName("textEditor42");

    obj.rectangle247 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle247:setParent(obj.scrollBox11);
    obj.rectangle247:setColor("#150e16");
    obj.rectangle247:setStrokeSize(2);
    obj.rectangle247:setStrokeColor("white");
    obj.rectangle247.grid.role = "col";
    obj.rectangle247.grid.width = 7;
    obj.rectangle247.grid["max-width"] = 1080;
    obj.rectangle247.grid["min-width"] = 400;
    obj.rectangle247.grid["min-height"] = 550;
    obj.rectangle247.grid["max-height"] = 1080;
    obj.rectangle247:setMargins({top=15});
    obj.rectangle247:setName("rectangle247");

    obj.label241 = GUI.fromHandle(_obj_newObject("label"));
    obj.label241:setParent(obj.rectangle247);
    obj.label241:setHeight(25);
    obj.label241:setText("Raças Conquistadas");
    obj.label241:setFontSize(30);
    obj.label241.grid.role = "col";
    obj.label241.grid.width = 12;
    obj.label241:setFontFamily("Wishes Script Caps Display");
    obj.label241:setHorzTextAlign("center");
    obj.label241:setMargins({top=10});
    obj.label241:setName("label241");

    obj.chk_raca_humano = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_humano:setParent(obj.rectangle247);
    obj.chk_raca_humano:setName("chk_raca_humano");
    obj.chk_raca_humano:setField("vis_raca_humano");
    obj.chk_raca_humano:setImageChecked("https://blob.firecast.com.br/blobs/WGIORNEU_4308186/humano.png");
    obj.chk_raca_humano:setImageUnchecked("https://blob.firecast.com.br/blobs/CASFNBMF_4308184/humano_x.png");
    obj.chk_raca_humano.grid.role = "col";
    obj.chk_raca_humano.grid.width = 1;
    obj.chk_raca_humano:setHeight(60);
    obj.chk_raca_humano:setMargins({top=0,right=2,left=2});
    obj.chk_raca_humano:setHint("Humanos");
    obj.chk_raca_humano:setAutoChange(false);

    obj.chk_raca_alto_humano = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_alto_humano:setParent(obj.rectangle247);
    obj.chk_raca_alto_humano:setName("chk_raca_alto_humano");
    obj.chk_raca_alto_humano:setField("vis_raca_alto_humano");
    obj.chk_raca_alto_humano:setImageChecked("https://blob.firecast.com.br/blobs/CVCBOWEB_4308181/alto_humano.png");
    obj.chk_raca_alto_humano:setImageUnchecked("https://blob.firecast.com.br/blobs/OBQOVTFF_4308182/alto_humano_x.png");
    obj.chk_raca_alto_humano.grid.role = "col";
    obj.chk_raca_alto_humano.grid.width = 1;
    obj.chk_raca_alto_humano:setHeight(60);
    obj.chk_raca_alto_humano:setMargins({top=0,right=2,left=2});
    obj.chk_raca_alto_humano:setHint("Altos Humanos");
    obj.chk_raca_alto_humano:setAutoChange(false);

    obj.chk_raca_anao = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_anao:setParent(obj.rectangle247);
    obj.chk_raca_anao:setName("chk_raca_anao");
    obj.chk_raca_anao:setField("vis_raca_anao");
    obj.chk_raca_anao:setImageChecked("https://blob.firecast.com.br/blobs/HHPDGOWP_4310951/an_o.png");
    obj.chk_raca_anao:setImageUnchecked("https://blob.firecast.com.br/blobs/DEOWMAEQ_4310954/an_o_x.png");
    obj.chk_raca_anao.grid.role = "col";
    obj.chk_raca_anao.grid.width = 1;
    obj.chk_raca_anao:setHeight(60);
    obj.chk_raca_anao:setMargins({top=0,right=2,left=2});
    obj.chk_raca_anao:setHint("Anões");
    obj.chk_raca_anao:setAutoChange(false);

    obj.chk_raca_aveano = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_aveano:setParent(obj.rectangle247);
    obj.chk_raca_aveano:setName("chk_raca_aveano");
    obj.chk_raca_aveano:setField("vis_raca_aveano");
    obj.chk_raca_aveano:setImageChecked("https://blob.firecast.com.br/blobs/PIWWCSTD_4307911/aveano.png");
    obj.chk_raca_aveano:setImageUnchecked("https://blob.firecast.com.br/blobs/HQWQURGL_4307910/aveano_x.png");
    obj.chk_raca_aveano.grid.role = "col";
    obj.chk_raca_aveano.grid.width = 1;
    obj.chk_raca_aveano:setHeight(60);
    obj.chk_raca_aveano:setMargins({top=0,right=2,left=2});
    obj.chk_raca_aveano:setHint("Aveanos");
    obj.chk_raca_aveano:setAutoChange(false);

    obj.chk_raca_broteli = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_broteli:setParent(obj.rectangle247);
    obj.chk_raca_broteli:setName("chk_raca_broteli");
    obj.chk_raca_broteli:setField("vis_raca_broteli");
    obj.chk_raca_broteli:setImageChecked("https://blob.firecast.com.br/blobs/WJPCLBOF_4307896/brotelis.png");
    obj.chk_raca_broteli:setImageUnchecked("https://blob.firecast.com.br/blobs/WRARQURB_4307895/brotelis_x.png");
    obj.chk_raca_broteli.grid.role = "col";
    obj.chk_raca_broteli.grid.width = 1;
    obj.chk_raca_broteli:setHeight(60);
    obj.chk_raca_broteli:setMargins({top=0,right=2,left=2});
    obj.chk_raca_broteli:setHint("Brotelis");
    obj.chk_raca_broteli:setAutoChange(false);

    obj.chk_raca_elfo = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_elfo:setParent(obj.rectangle247);
    obj.chk_raca_elfo:setName("chk_raca_elfo");
    obj.chk_raca_elfo:setField("vis_raca_elfo");
    obj.chk_raca_elfo:setImageChecked("https://blob.firecast.com.br/blobs/GJWBMMJE_4310952/elfo.png");
    obj.chk_raca_elfo:setImageUnchecked("https://blob.firecast.com.br/blobs/VNOEDWBP_4310953/elfo_x.png");
    obj.chk_raca_elfo.grid.role = "col";
    obj.chk_raca_elfo.grid.width = 1;
    obj.chk_raca_elfo:setHeight(60);
    obj.chk_raca_elfo:setMargins({top=0,right=2,left=2});
    obj.chk_raca_elfo:setHint("Elfos");
    obj.chk_raca_elfo:setAutoChange(false);

    obj.chk_raca_insectoide = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_insectoide:setParent(obj.rectangle247);
    obj.chk_raca_insectoide:setName("chk_raca_insectoide");
    obj.chk_raca_insectoide:setField("vis_raca_insectoide");
    obj.chk_raca_insectoide:setImageChecked("https://blob.firecast.com.br/blobs/OQHGVCWS_4307879/insectoide.png");
    obj.chk_raca_insectoide:setImageUnchecked("https://blob.firecast.com.br/blobs/THKNSWRW_4307880/insectoide_x.png");
    obj.chk_raca_insectoide.grid.role = "col";
    obj.chk_raca_insectoide.grid.width = 1;
    obj.chk_raca_insectoide:setHeight(60);
    obj.chk_raca_insectoide:setMargins({top=0,right=2,left=2});
    obj.chk_raca_insectoide:setHint("Insectoides");
    obj.chk_raca_insectoide:setAutoChange(false);

    obj.chk_raca_merfolk = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_merfolk:setParent(obj.rectangle247);
    obj.chk_raca_merfolk:setName("chk_raca_merfolk");
    obj.chk_raca_merfolk:setField("vis_raca_merfolk");
    obj.chk_raca_merfolk:setImageChecked("https://blob.firecast.com.br/blobs/EBFMVAIF_4307905/merfork.png");
    obj.chk_raca_merfolk:setImageUnchecked("https://blob.firecast.com.br/blobs/VMSABNLH_4307903/merfork_x.png");
    obj.chk_raca_merfolk.grid.role = "col";
    obj.chk_raca_merfolk.grid.width = 1;
    obj.chk_raca_merfolk:setHeight(60);
    obj.chk_raca_merfolk:setMargins({top=0,right=2,left=2});
    obj.chk_raca_merfolk:setHint("Merfolk");
    obj.chk_raca_merfolk:setAutoChange(false);

    obj.chk_raca_reptideo = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_reptideo:setParent(obj.rectangle247);
    obj.chk_raca_reptideo:setName("chk_raca_reptideo");
    obj.chk_raca_reptideo:setField("vis_raca_reptideo");
    obj.chk_raca_reptideo:setImageChecked("https://blob.firecast.com.br/blobs/DJVWTBWP_4307914/reptidio.png");
    obj.chk_raca_reptideo:setImageUnchecked("https://blob.firecast.com.br/blobs/MTSEHCFM_4307915/reptidio_x.png");
    obj.chk_raca_reptideo.grid.role = "col";
    obj.chk_raca_reptideo.grid.width = 1;
    obj.chk_raca_reptideo:setHeight(60);
    obj.chk_raca_reptideo:setMargins({top=0,right=2,left=2});
    obj.chk_raca_reptideo:setHint("Reptídios");
    obj.chk_raca_reptideo:setAutoChange(false);

    obj.chk_raca_stonelith = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_stonelith:setParent(obj.rectangle247);
    obj.chk_raca_stonelith:setName("chk_raca_stonelith");
    obj.chk_raca_stonelith:setField("vis_raca_stonelith");
    obj.chk_raca_stonelith:setImageChecked("https://blob.firecast.com.br/blobs/STJGSDMU_4308185/stonelith.png");
    obj.chk_raca_stonelith:setImageUnchecked("https://blob.firecast.com.br/blobs/OKIRBPLM_4308183/stonelith_x.png");
    obj.chk_raca_stonelith.grid.role = "col";
    obj.chk_raca_stonelith.grid.width = 1;
    obj.chk_raca_stonelith:setHeight(60);
    obj.chk_raca_stonelith:setMargins({top=0,right=2,left=2});
    obj.chk_raca_stonelith:setHint("Stoneliths");
    obj.chk_raca_stonelith:setAutoChange(false);

    obj.chk_raca_werebeast = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_werebeast:setParent(obj.rectangle247);
    obj.chk_raca_werebeast:setName("chk_raca_werebeast");
    obj.chk_raca_werebeast:setField("vis_raca_werebeast");
    obj.chk_raca_werebeast:setImageChecked("https://blob.firecast.com.br/blobs/JBCJRJAC_4307920/werebeasts.png");
    obj.chk_raca_werebeast:setImageUnchecked("https://blob.firecast.com.br/blobs/DDAETAID_4307921/werebeasts_x.png");
    obj.chk_raca_werebeast.grid.role = "col";
    obj.chk_raca_werebeast.grid.width = 1;
    obj.chk_raca_werebeast:setHeight(60);
    obj.chk_raca_werebeast:setMargins({top=0,right=2,left=2});
    obj.chk_raca_werebeast:setHint("Werebeasts");
    obj.chk_raca_werebeast:setAutoChange(false);

    obj.chk_raca_wixili = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.chk_raca_wixili:setParent(obj.rectangle247);
    obj.chk_raca_wixili:setName("chk_raca_wixili");
    obj.chk_raca_wixili:setField("vis_raca_wixili");
    obj.chk_raca_wixili:setImageChecked("https://blob.firecast.com.br/blobs/QWJLVUNW_4311851/wixili.png");
    obj.chk_raca_wixili:setImageUnchecked("https://blob.firecast.com.br/blobs/PNQWJUNT_4311850/wixili_x.png");
    obj.chk_raca_wixili.grid.role = "col";
    obj.chk_raca_wixili.grid.width = 1;
    obj.chk_raca_wixili:setHeight(60);
    obj.chk_raca_wixili:setMargins({top=0,right=2,left=2});
    obj.chk_raca_wixili:setHint("Wixilis");
    obj.chk_raca_wixili:setAutoChange(false);


                    local function atualizarVisibilidadeRacas()
                        local mesa = Firecast.getMesaDe(sheet);
                        if mesa == nil or mesa.meuJogador == nil then return end;

                        local isMestre = mesa.meuJogador.isMestre;

                        local racas = {
                            "humano","alto_humano","anao","aveano","broteli",
                            "elfo","insectoide","merfolk","reptideo",
                            "stonelith","werebeast","wixili"
                        };

                        for i=1, #racas do
                            local r = racas[i];
                            local chk = self:findControlByName("chk_raca_" .. r);

                            if chk ~= nil then
                                local marcado = (sheet["vis_raca_" .. r] == true);

                                if isMestre then
                                    chk.visible = true;
                                    chk.enabled = true;
                                    chk.autoChange = true;
                                else
                                    chk.visible = marcado;
                                    chk.enabled = true;
                                    chk.autoChange = false;
                                end;
                            end;
                        end;
                    end;
                


    obj.dataLink73 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink73:setParent(obj.rectangle247);
    obj.dataLink73:setFields({'vis_raca_humano', 'vis_raca_alto_humano', 'vis_raca_anao', 'vis_raca_aveano', 'vis_raca_broteli', 'vis_raca_elfo', 'vis_raca_insectoide', 'vis_raca_merfolk', 'vis_raca_reptideo', 'vis_raca_stonelith', 'vis_raca_werebeast', 'vis_raca_wixili'});
    obj.dataLink73:setDefaultValues({'true', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'false'});
    obj.dataLink73:setName("dataLink73");

    obj.label242 = GUI.fromHandle(_obj_newObject("label"));
    obj.label242:setParent(obj.rectangle247);
    obj.label242:setHeight(25);
    obj.label242:setText("Sua Raça");
    obj.label242:setFontSize(50);
    obj.label242.grid.role = "col";
    obj.label242.grid.width = 12;
    obj.label242:setFontFamily("Wishes Script Caps Display");
    obj.label242:setHorzTextAlign("center");
    obj.label242:setMargins({top=10});
    obj.label242:setName("label242");

    obj.rectangle248 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle248:setParent(obj.rectangle247);
    obj.rectangle248:setHeight(25);
    obj.rectangle248:setColor("black");
    obj.rectangle248.grid.role = "col";
    obj.rectangle248.grid.width = 12;
    obj.rectangle248:setStrokeSize(1);
    obj.rectangle248:setStrokeColor("white");
    obj.rectangle248:setCornerType("round");
    obj.rectangle248:setXradius(5);
    obj.rectangle248:setYradius(5);
    obj.rectangle248:setMargins({top=5,right=10,left=10});
    obj.rectangle248:setName("rectangle248");

    obj.combo_raca = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.combo_raca:setParent(obj.rectangle248);
    obj.combo_raca:setName("combo_raca");
    obj.combo_raca:setField("raca_atual");
    obj.combo_raca:setAlign("client");
    obj.combo_raca:setFontFamily("Wishes Script Caps Display");
    obj.combo_raca:setTransparent(true);
    obj.combo_raca:setFontSize(20);
    obj.combo_raca:setHorzTextAlign("center");
    obj.combo_raca:setVertTextAlign("center");
    obj.combo_raca:setText("Humano");

    obj.dataLink74 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink74:setParent(obj.rectangle248);
    obj.dataLink74:setField("raca_atual");
    obj.dataLink74:setDefaultValue("Humano");
    obj.dataLink74:setName("dataLink74");

    obj.rectangle249 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle249:setParent(obj.rectangle247);
    obj.rectangle249:setHeight(380);
    obj.rectangle249:setColor("black");
    obj.rectangle249.grid.role = "col";
    obj.rectangle249.grid.width = 12;
    obj.rectangle249:setStrokeSize(1);
    obj.rectangle249:setStrokeColor("white");
    obj.rectangle249:setCornerType("round");
    obj.rectangle249:setXradius(5);
    obj.rectangle249:setYradius(5);
    obj.rectangle249:setMargins({top=5,left=10,right=10});
    obj.rectangle249:setName("rectangle249");

    obj.richEdit5 = GUI.fromHandle(_obj_newObject("richEdit"));
    obj.richEdit5:setParent(obj.rectangle249);
    obj.richEdit5:setField("descricao_raca");
    obj.richEdit5:setAlign("client");
    obj.richEdit5.backgroundColor = "#000000";
    obj.richEdit5.defaultFontColor = "white";
    obj.richEdit5.hideSelection = true;
    obj.richEdit5.defaultFontSize = 14;
    obj.richEdit5.animateImages = true;
    obj.richEdit5:setMargins({top=4,right=4,left=4,bottom=4});
    obj.richEdit5:setName("richEdit5");

    obj.aba_classe = GUI.fromHandle(_obj_newObject("tab"));
    obj.aba_classe:setParent(obj.ficha);
    obj.aba_classe:setName("aba_classe");
    obj.aba_classe:setTitle("Classe");

    obj.rectangle250 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle250:setParent(obj.aba_classe);
    obj.rectangle250:setAlign("client");
    obj.rectangle250:setColor("black");
    obj.rectangle250:setName("rectangle250");

    obj.scrollBox12 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox12:setParent(obj.rectangle250);
    obj.scrollBox12:setAlign("client");
    obj.scrollBox12:setMargins({left=5,right=5});
    obj.scrollBox12:setName("scrollBox12");

    obj.rectangle251 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle251:setParent(obj.scrollBox12);
    obj.rectangle251:setColor("#150e16");
    obj.rectangle251:setStrokeSize(2);
    obj.rectangle251:setStrokeColor("white");
    obj.rectangle251.grid.role = "col";
    obj.rectangle251.grid.width = 12;
    obj.rectangle251.grid["max-width"] = 1080;
    obj.rectangle251.grid["min-width"] = 400;
    obj.rectangle251.grid["min-height"] = 550;
    obj.rectangle251.grid["max-height"] = 1080;
    obj.rectangle251:setMargins({top=15});
    obj.rectangle251:setName("rectangle251");

    obj.label243 = GUI.fromHandle(_obj_newObject("label"));
    obj.label243:setParent(obj.rectangle251);
    obj.label243:setAlign("client");
    obj.label243:setText("Ainda em desenvolvimento. \nEm breve na atualização do sistema.");
    obj.label243:setFontSize(50);
    obj.label243.grid.role = "col";
    obj.label243.grid.width = 12;
    obj.label243:setFontFamily("Wishes Script Caps Display");
    obj.label243:setHorzTextAlign("center");
    obj.label243:setVertTextAlign("center");
    obj.label243:setMargins({top=15});
    obj.label243:setName("label243");

    obj.aba_minigames = GUI.fromHandle(_obj_newObject("tab"));
    obj.aba_minigames:setParent(obj.ficha);
    obj.aba_minigames:setName("aba_minigames");
    obj.aba_minigames:setTitle("Minigames");

    obj.rectangle252 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle252:setParent(obj.aba_minigames);
    obj.rectangle252:setAlign("client");
    obj.rectangle252:setColor("black");
    obj.rectangle252:setName("rectangle252");

    obj.scrollBox13 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox13:setParent(obj.rectangle252);
    obj.scrollBox13:setAlign("client");
    obj.scrollBox13:setMargins({left=5,right=5});
    obj.scrollBox13:setName("scrollBox13");

    obj.rectangle253 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle253:setParent(obj.scrollBox13);
    obj.rectangle253:setColor("#150e16");
    obj.rectangle253:setStrokeSize(2);
    obj.rectangle253:setStrokeColor("white");
    obj.rectangle253.grid.role = "col";
    obj.rectangle253.grid.width = 5;
    obj.rectangle253.grid["max-width"] = 1080;
    obj.rectangle253.grid["min-width"] = 400;
    obj.rectangle253.grid["min-height"] = 550;
    obj.rectangle253.grid["max-height"] = 1080;
    obj.rectangle253:setMargins({top=15});
    obj.rectangle253:setName("rectangle253");

    obj.label244 = GUI.fromHandle(_obj_newObject("label"));
    obj.label244:setParent(obj.rectangle253);
    obj.label244:setHeight(25);
    obj.label244:setText("Experiência em Jogos");
    obj.label244:setFontSize(50);
    obj.label244.grid.role = "col";
    obj.label244.grid.width = 12;
    obj.label244:setFontFamily("Wishes Script Caps Display");
    obj.label244:setHorzTextAlign("center");
    obj.label244:setMargins({top=20});
    obj.label244:setName("label244");

    obj.label245 = GUI.fromHandle(_obj_newObject("label"));
    obj.label245:setParent(obj.rectangle253);
    obj.label245:setHeight(25);
    obj.label245:setText("O que é:");
    obj.label245:setFontSize(18);
    obj.label245.grid.role = "col";
    obj.label245.grid.width = 12;
    obj.label245:setFontFamily("Wishes Script Caps Display");
    obj.label245:setHorzTextAlign("leading");
    obj.label245:setMargins({top=15,left=10});
    obj.label245:setName("label245");

    obj.rectangle254 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle254:setParent(obj.rectangle253);
    obj.rectangle254:setHeight(150);
    obj.rectangle254:setColor("black");
    obj.rectangle254:setCornerType("round");
    obj.rectangle254.grid.role = "col";
    obj.rectangle254.grid.width = 12;
    obj.rectangle254:setStrokeSize(1);
    obj.rectangle254:setStrokeColor("white");
    obj.rectangle254:setXradius(5);
    obj.rectangle254:setYradius(5);
    obj.rectangle254:setMargins({right=10,left=10});
    obj.rectangle254:setName("rectangle254");

    obj.textEditor43 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor43:setParent(obj.rectangle254);
    obj.textEditor43:setAlign("client");
    obj.textEditor43:setField("explicacaoxpjogos");
    obj.textEditor43:setFontSize(15);
    obj.textEditor43:setFontFamily("Wishes Script Caps Display");
    obj.textEditor43:setTransparent(true);
    obj.textEditor43:setHorzTextAlign("center");
    obj.textEditor43:setReadOnly(true);
    obj.textEditor43:setMargins({top=5,bottom=5,right=5,left=5});
    obj.textEditor43:setName("textEditor43");

    obj.dataLink75 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink75:setParent(obj.rectangle254);
    obj.dataLink75:setField("explicacaoxpjogos");
    obj.dataLink75:setDefaultValue("Essa é uma mecanica exclusiva dos Jogarores, uma vez que apenas eles tem acesso ao sistema. Essa mecanica é usada para interagir com o sistema de Minigames, onde os Jogadores podem fazer jogos para auxiliar na produção de um item ou equipamento. Essa mecanica demonstra a experiência do jogodor com cada um dos 20 minigames, assim como a possibilidade de melhorar neles. A experienia em cada jogo representa a capacidade que um Jogador possue naquele jogo especifico, facilitando o sucesso no resultado deles quanto maior ela for.");
    obj.dataLink75:setName("dataLink75");

    obj.label246 = GUI.fromHandle(_obj_newObject("label"));
    obj.label246:setParent(obj.rectangle253);
    obj.label246:setHeight(25);
    obj.label246:setText("Modificador:");
    obj.label246:setFontSize(18);
    obj.label246.grid.role = "col";
    obj.label246.grid.width = 12;
    obj.label246:setFontFamily("Wishes Script Caps Display");
    obj.label246:setHorzTextAlign("leading");
    obj.label246:setMargins({top=15,left=10});
    obj.label246:setName("label246");

    obj.rectangle255 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle255:setParent(obj.rectangle253);
    obj.rectangle255:setHeight(65);
    obj.rectangle255:setColor("black");
    obj.rectangle255:setCornerType("round");
    obj.rectangle255.grid.role = "col";
    obj.rectangle255.grid.width = 12;
    obj.rectangle255:setStrokeSize(1);
    obj.rectangle255:setStrokeColor("white");
    obj.rectangle255:setXradius(5);
    obj.rectangle255:setYradius(5);
    obj.rectangle255:setMargins({right=10,left=10});
    obj.rectangle255:setName("rectangle255");

    obj.textEditor44 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor44:setParent(obj.rectangle255);
    obj.textEditor44:setAlign("client");
    obj.textEditor44:setField("modxpjogos");
    obj.textEditor44:setFontSize(15);
    obj.textEditor44:setFontFamily("Wishes Script Caps Display");
    obj.textEditor44:setTransparent(true);
    obj.textEditor44:setHorzTextAlign("center");
    obj.textEditor44:setReadOnly(true);
    obj.textEditor44:setMargins({top=5,bottom=5,right=5,left=5});
    obj.textEditor44:setName("textEditor44");

    obj.dataLink76 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink76:setParent(obj.rectangle255);
    obj.dataLink76:setField("modxpjogos");
    obj.dataLink76:setDefaultValue("Os modificadores de cada minigame são contados separadamente e aumenta em +1 para cada 10 pontos de XP.");
    obj.dataLink76:setName("dataLink76");

    obj.label247 = GUI.fromHandle(_obj_newObject("label"));
    obj.label247:setParent(obj.rectangle253);
    obj.label247:setHeight(25);
    obj.label247:setText("Como funciona:");
    obj.label247:setFontSize(18);
    obj.label247.grid.role = "col";
    obj.label247.grid.width = 12;
    obj.label247:setFontFamily("Wishes Script Caps Display");
    obj.label247:setHorzTextAlign("leading");
    obj.label247:setMargins({top=15,left=10});
    obj.label247:setName("label247");

    obj.rectangle256 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle256:setParent(obj.rectangle253);
    obj.rectangle256:setHeight(115);
    obj.rectangle256:setColor("black");
    obj.rectangle256:setCornerType("round");
    obj.rectangle256.grid.role = "col";
    obj.rectangle256.grid.width = 12;
    obj.rectangle256:setStrokeSize(1);
    obj.rectangle256:setStrokeColor("white");
    obj.rectangle256:setXradius(5);
    obj.rectangle256:setYradius(5);
    obj.rectangle256:setMargins({right=10,left=10});
    obj.rectangle256:setName("rectangle256");

    obj.textEditor45 = GUI.fromHandle(_obj_newObject("textEditor"));
    obj.textEditor45:setParent(obj.rectangle256);
    obj.textEditor45:setAlign("client");
    obj.textEditor45:setField("sistematicaxpjogos");
    obj.textEditor45:setFontSize(15);
    obj.textEditor45:setFontFamily("Wishes Script Caps Display");
    obj.textEditor45:setTransparent(true);
    obj.textEditor45:setHorzTextAlign("center");
    obj.textEditor45:setReadOnly(true);
    obj.textEditor45:setMargins({top=5,bottom=5,right=5,left=5});
    obj.textEditor45:setName("textEditor45");

    obj.dataLink77 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink77:setParent(obj.rectangle256);
    obj.dataLink77:setField("sistematicaxpjogos");
    obj.dataLink77:setDefaultValue("O jogador tem 40 pontos de experiencia iniciais para distribuir entre os 20 minigames, \nrepresentando sua experiencia antes de ser invocado. \n \nVitorias concedem +2xp no minigame jogado, derrotas concedem +1xp. \nCada 10 pontos em um minigame aumentam o modificador ao realizar ele em +1. ");
    obj.dataLink77:setName("dataLink77");

    obj.rectangle257 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle257:setParent(obj.scrollBox13);
    obj.rectangle257:setColor("#150e16");
    obj.rectangle257:setStrokeSize(2);
    obj.rectangle257:setStrokeColor("white");
    obj.rectangle257.grid.role = "col";
    obj.rectangle257.grid.width = 7;
    obj.rectangle257.grid["max-width"] = 1080;
    obj.rectangle257.grid["min-width"] = 400;
    obj.rectangle257.grid["min-height"] = 550;
    obj.rectangle257.grid["max-height"] = 1080;
    obj.rectangle257:setMargins({top=15});
    obj.rectangle257:setName("rectangle257");

    obj.label248 = GUI.fromHandle(_obj_newObject("label"));
    obj.label248:setParent(obj.rectangle257);
    obj.label248:setHeight(30);
    obj.label248:setText("Jogo");
    obj.label248:setFontSize(20);
    obj.label248.grid.role = "col";
    obj.label248.grid.width = 3;
    obj.label248:setFontFamily("Wishes Script Caps Display");
    obj.label248:setHorzTextAlign("center");
    obj.label248:setVertTextAlign("center");
    obj.label248:setMargins({top=5});
    obj.label248:setName("label248");

    obj.rectangle258 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle258:setParent(obj.rectangle257);
    obj.rectangle258:setHeight(30);
    obj.rectangle258:setColor("none");
    obj.rectangle258:setCornerType("round");
    obj.rectangle258.grid.role = "col";
    obj.rectangle258.grid.width = 3;
    obj.rectangle258:setMargins({top=5});
    obj.rectangle258:setName("rectangle258");

    obj.label249 = GUI.fromHandle(_obj_newObject("label"));
    obj.label249:setParent(obj.rectangle258);
    obj.label249:setHeight(20);
    obj.label249:setText("Experiencia");
    obj.label249:setFontSize(12);
    obj.label249.grid.role = "col";
    obj.label249.grid.width = 6;
    obj.label249:setFontFamily("Wishes Script Caps Display");
    obj.label249:setHorzTextAlign("center");
    obj.label249:setVertTextAlign("center");
    obj.label249:setMargins({top=5});
    obj.label249:setName("label249");

    obj.label250 = GUI.fromHandle(_obj_newObject("label"));
    obj.label250:setParent(obj.rectangle258);
    obj.label250:setHeight(20);
    obj.label250:setText("Mod");
    obj.label250:setFontSize(12);
    obj.label250.grid.role = "col";
    obj.label250.grid.width = 6;
    obj.label250:setFontFamily("Wishes Script Caps Display");
    obj.label250:setHorzTextAlign("center");
    obj.label250:setVertTextAlign("center");
    obj.label250:setMargins({top=5});
    obj.label250:setName("label250");

    obj.label251 = GUI.fromHandle(_obj_newObject("label"));
    obj.label251:setParent(obj.rectangle257);
    obj.label251:setHeight(30);
    obj.label251:setText("Jogo");
    obj.label251:setFontSize(20);
    obj.label251.grid.role = "col";
    obj.label251.grid.width = 3;
    obj.label251:setFontFamily("Wishes Script Caps Display");
    obj.label251:setHorzTextAlign("center");
    obj.label251:setVertTextAlign("center");
    obj.label251:setMargins({top=5});
    obj.label251:setName("label251");

    obj.rectangle259 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle259:setParent(obj.rectangle257);
    obj.rectangle259:setHeight(30);
    obj.rectangle259:setColor("none");
    obj.rectangle259:setCornerType("round");
    obj.rectangle259.grid.role = "col";
    obj.rectangle259.grid.width = 3;
    obj.rectangle259:setMargins({top=5});
    obj.rectangle259:setName("rectangle259");

    obj.label252 = GUI.fromHandle(_obj_newObject("label"));
    obj.label252:setParent(obj.rectangle259);
    obj.label252:setHeight(20);
    obj.label252:setText("Experiencia");
    obj.label252:setFontSize(12);
    obj.label252.grid.role = "col";
    obj.label252.grid.width = 6;
    obj.label252:setFontFamily("Wishes Script Caps Display");
    obj.label252:setHorzTextAlign("center");
    obj.label252:setVertTextAlign("center");
    obj.label252:setMargins({top=5});
    obj.label252:setName("label252");

    obj.label253 = GUI.fromHandle(_obj_newObject("label"));
    obj.label253:setParent(obj.rectangle259);
    obj.label253:setHeight(20);
    obj.label253:setText("Mod");
    obj.label253:setFontSize(12);
    obj.label253.grid.role = "col";
    obj.label253.grid.width = 6;
    obj.label253:setFontFamily("Wishes Script Caps Display");
    obj.label253:setHorzTextAlign("center");
    obj.label253:setVertTextAlign("center");
    obj.label253:setMargins({top=5});
    obj.label253:setName("label253");

    obj.label254 = GUI.fromHandle(_obj_newObject("label"));
    obj.label254:setParent(obj.rectangle257);
    obj.label254:setHeight(30);
    obj.label254:setText("2048");
    obj.label254:setFontSize(22);
    obj.label254.grid.role = "col";
    obj.label254.grid.width = 3;
    obj.label254:setFontFamily("Wishes Script Caps Display");
    obj.label254:setHorzTextAlign("center");
    obj.label254:setVertTextAlign("center");
    obj.label254:setMargins({top=10});
    obj.label254:setName("label254");

    obj.rectangle260 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle260:setParent(obj.rectangle257);
    obj.rectangle260:setHeight(35);
    obj.rectangle260:setColor("black");
    obj.rectangle260:setCornerType("round");
    obj.rectangle260.grid.role = "col";
    obj.rectangle260.grid.width = 3;
    obj.rectangle260:setStrokeSize(1);
    obj.rectangle260:setStrokeColor("white");
    obj.rectangle260:setXradius(5);
    obj.rectangle260:setYradius(5);
    obj.rectangle260:setMargins({top=10});
    obj.rectangle260:setName("rectangle260");

    obj.xp2048 = GUI.fromHandle(_obj_newObject("edit"));
    obj.xp2048:setParent(obj.rectangle260);
    obj.xp2048:setHeight(42);
    obj.xp2048:setField("xp2048");
    obj.xp2048:setFontSize(35);
    obj.xp2048.grid.role = "col";
    obj.xp2048.grid.width = 6;
    obj.xp2048:setFontFamily("Wishes Script Caps Display");
    obj.xp2048:setHorzTextAlign("center");
    obj.xp2048:setTransparent(true);
    obj.xp2048:setName("xp2048");

    obj.mod2048 = GUI.fromHandle(_obj_newObject("edit"));
    obj.mod2048:setParent(obj.rectangle260);
    obj.mod2048:setHeight(42);
    obj.mod2048:setField("mod2048");
    obj.mod2048:setFontSize(35);
    obj.mod2048.grid.role = "col";
    obj.mod2048.grid.width = 6;
    obj.mod2048:setFontFamily("Wishes Script Caps Display");
    obj.mod2048:setHorzTextAlign("center");
    obj.mod2048:setTransparent(true);
    obj.mod2048:setName("mod2048");
    obj.mod2048:setReadOnly(true);

    obj.label255 = GUI.fromHandle(_obj_newObject("label"));
    obj.label255:setParent(obj.rectangle257);
    obj.label255:setHeight(30);
    obj.label255:setText("Batalha Naval");
    obj.label255:setFontSize(18);
    obj.label255.grid.role = "col";
    obj.label255.grid.width = 3;
    obj.label255:setFontFamily("Wishes Script Caps Display");
    obj.label255:setHorzTextAlign("center");
    obj.label255:setVertTextAlign("center");
    obj.label255:setMargins({top=10});
    obj.label255:setName("label255");

    obj.rectangle261 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle261:setParent(obj.rectangle257);
    obj.rectangle261:setHeight(35);
    obj.rectangle261:setColor("black");
    obj.rectangle261:setCornerType("round");
    obj.rectangle261.grid.role = "col";
    obj.rectangle261.grid.width = 3;
    obj.rectangle261:setStrokeSize(1);
    obj.rectangle261:setStrokeColor("white");
    obj.rectangle261:setXradius(5);
    obj.rectangle261:setYradius(5);
    obj.rectangle261:setMargins({top=10,right=10});
    obj.rectangle261:setName("rectangle261");

    obj.xpbnaval = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpbnaval:setParent(obj.rectangle261);
    obj.xpbnaval:setHeight(42);
    obj.xpbnaval:setField("xpbnaval");
    obj.xpbnaval:setFontSize(35);
    obj.xpbnaval.grid.role = "col";
    obj.xpbnaval.grid.width = 6;
    obj.xpbnaval:setFontFamily("Wishes Script Caps Display");
    obj.xpbnaval:setHorzTextAlign("center");
    obj.xpbnaval:setTransparent(true);
    obj.xpbnaval:setName("xpbnaval");

    obj.modbnaval = GUI.fromHandle(_obj_newObject("edit"));
    obj.modbnaval:setParent(obj.rectangle261);
    obj.modbnaval:setHeight(42);
    obj.modbnaval:setField("modbnaval");
    obj.modbnaval:setFontSize(35);
    obj.modbnaval.grid.role = "col";
    obj.modbnaval.grid.width = 6;
    obj.modbnaval:setFontFamily("Wishes Script Caps Display");
    obj.modbnaval:setHorzTextAlign("center");
    obj.modbnaval:setTransparent(true);
    obj.modbnaval:setName("modbnaval");
    obj.modbnaval:setReadOnly(true);

    obj.label256 = GUI.fromHandle(_obj_newObject("label"));
    obj.label256:setParent(obj.rectangle257);
    obj.label256:setHeight(30);
    obj.label256:setText("Bejeweled");
    obj.label256:setFontSize(18);
    obj.label256.grid.role = "col";
    obj.label256.grid.width = 3;
    obj.label256:setFontFamily("Wishes Script Caps Display");
    obj.label256:setHorzTextAlign("center");
    obj.label256:setVertTextAlign("center");
    obj.label256:setMargins({top=10});
    obj.label256:setName("label256");

    obj.rectangle262 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle262:setParent(obj.rectangle257);
    obj.rectangle262:setHeight(35);
    obj.rectangle262:setColor("black");
    obj.rectangle262:setCornerType("round");
    obj.rectangle262.grid.role = "col";
    obj.rectangle262.grid.width = 3;
    obj.rectangle262:setStrokeSize(1);
    obj.rectangle262:setStrokeColor("white");
    obj.rectangle262:setXradius(5);
    obj.rectangle262:setYradius(5);
    obj.rectangle262:setMargins({top=10});
    obj.rectangle262:setName("rectangle262");

    obj.xpbejeweled = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpbejeweled:setParent(obj.rectangle262);
    obj.xpbejeweled:setHeight(42);
    obj.xpbejeweled:setField("xpbejeweled");
    obj.xpbejeweled:setFontSize(35);
    obj.xpbejeweled.grid.role = "col";
    obj.xpbejeweled.grid.width = 6;
    obj.xpbejeweled:setFontFamily("Wishes Script Caps Display");
    obj.xpbejeweled:setHorzTextAlign("center");
    obj.xpbejeweled:setTransparent(true);
    obj.xpbejeweled:setName("xpbejeweled");

    obj.modbejeweled = GUI.fromHandle(_obj_newObject("edit"));
    obj.modbejeweled:setParent(obj.rectangle262);
    obj.modbejeweled:setHeight(42);
    obj.modbejeweled:setField("modbejeweled");
    obj.modbejeweled:setFontSize(35);
    obj.modbejeweled.grid.role = "col";
    obj.modbejeweled.grid.width = 6;
    obj.modbejeweled:setFontFamily("Wishes Script Caps Display");
    obj.modbejeweled:setHorzTextAlign("center");
    obj.modbejeweled:setTransparent(true);
    obj.modbejeweled:setName("modbejeweled");
    obj.modbejeweled:setReadOnly(true);

    obj.label257 = GUI.fromHandle(_obj_newObject("label"));
    obj.label257:setParent(obj.rectangle257);
    obj.label257:setHeight(30);
    obj.label257:setText("Campo Minado");
    obj.label257:setFontSize(18);
    obj.label257.grid.role = "col";
    obj.label257.grid.width = 3;
    obj.label257:setFontFamily("Wishes Script Caps Display");
    obj.label257:setHorzTextAlign("center");
    obj.label257:setVertTextAlign("center");
    obj.label257:setMargins({top=10});
    obj.label257:setName("label257");

    obj.rectangle263 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle263:setParent(obj.rectangle257);
    obj.rectangle263:setHeight(35);
    obj.rectangle263:setColor("black");
    obj.rectangle263:setCornerType("round");
    obj.rectangle263.grid.role = "col";
    obj.rectangle263.grid.width = 3;
    obj.rectangle263:setStrokeSize(1);
    obj.rectangle263:setStrokeColor("white");
    obj.rectangle263:setXradius(5);
    obj.rectangle263:setYradius(5);
    obj.rectangle263:setMargins({top=10,right=10});
    obj.rectangle263:setName("rectangle263");

    obj.xpcminado = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpcminado:setParent(obj.rectangle263);
    obj.xpcminado:setHeight(42);
    obj.xpcminado:setField("xpcminado");
    obj.xpcminado:setFontSize(35);
    obj.xpcminado.grid.role = "col";
    obj.xpcminado.grid.width = 6;
    obj.xpcminado:setFontFamily("Wishes Script Caps Display");
    obj.xpcminado:setHorzTextAlign("center");
    obj.xpcminado:setTransparent(true);
    obj.xpcminado:setName("xpcminado");

    obj.modcminado = GUI.fromHandle(_obj_newObject("edit"));
    obj.modcminado:setParent(obj.rectangle263);
    obj.modcminado:setHeight(42);
    obj.modcminado:setField("modcminado");
    obj.modcminado:setFontSize(35);
    obj.modcminado.grid.role = "col";
    obj.modcminado.grid.width = 6;
    obj.modcminado:setFontFamily("Wishes Script Caps Display");
    obj.modcminado:setHorzTextAlign("center");
    obj.modcminado:setTransparent(true);
    obj.modcminado:setName("modcminado");
    obj.modcminado:setReadOnly(true);

    obj.label258 = GUI.fromHandle(_obj_newObject("label"));
    obj.label258:setParent(obj.rectangle257);
    obj.label258:setHeight(30);
    obj.label258:setText("Cubo Mágico");
    obj.label258:setFontSize(18);
    obj.label258.grid.role = "col";
    obj.label258.grid.width = 3;
    obj.label258:setFontFamily("Wishes Script Caps Display");
    obj.label258:setHorzTextAlign("center");
    obj.label258:setVertTextAlign("center");
    obj.label258:setMargins({top=10});
    obj.label258:setName("label258");

    obj.rectangle264 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle264:setParent(obj.rectangle257);
    obj.rectangle264:setHeight(35);
    obj.rectangle264:setColor("black");
    obj.rectangle264:setCornerType("round");
    obj.rectangle264.grid.role = "col";
    obj.rectangle264.grid.width = 3;
    obj.rectangle264:setStrokeSize(1);
    obj.rectangle264:setStrokeColor("white");
    obj.rectangle264:setXradius(5);
    obj.rectangle264:setYradius(5);
    obj.rectangle264:setMargins({top=10});
    obj.rectangle264:setName("rectangle264");

    obj.xpcmagico = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpcmagico:setParent(obj.rectangle264);
    obj.xpcmagico:setHeight(42);
    obj.xpcmagico:setField("xpcmagico");
    obj.xpcmagico:setFontSize(35);
    obj.xpcmagico.grid.role = "col";
    obj.xpcmagico.grid.width = 6;
    obj.xpcmagico:setFontFamily("Wishes Script Caps Display");
    obj.xpcmagico:setHorzTextAlign("center");
    obj.xpcmagico:setTransparent(true);
    obj.xpcmagico:setName("xpcmagico");

    obj.modcmagico = GUI.fromHandle(_obj_newObject("edit"));
    obj.modcmagico:setParent(obj.rectangle264);
    obj.modcmagico:setHeight(42);
    obj.modcmagico:setField("modcmagico");
    obj.modcmagico:setFontSize(35);
    obj.modcmagico.grid.role = "col";
    obj.modcmagico.grid.width = 6;
    obj.modcmagico:setFontFamily("Wishes Script Caps Display");
    obj.modcmagico:setHorzTextAlign("center");
    obj.modcmagico:setTransparent(true);
    obj.modcmagico:setName("modcmagico");
    obj.modcmagico:setReadOnly(true);

    obj.label259 = GUI.fromHandle(_obj_newObject("label"));
    obj.label259:setParent(obj.rectangle257);
    obj.label259:setHeight(30);
    obj.label259:setText("Genius");
    obj.label259:setFontSize(18);
    obj.label259.grid.role = "col";
    obj.label259.grid.width = 3;
    obj.label259:setFontFamily("Wishes Script Caps Display");
    obj.label259:setHorzTextAlign("center");
    obj.label259:setVertTextAlign("center");
    obj.label259:setMargins({top=10});
    obj.label259:setName("label259");

    obj.rectangle265 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle265:setParent(obj.rectangle257);
    obj.rectangle265:setHeight(35);
    obj.rectangle265:setColor("black");
    obj.rectangle265:setCornerType("round");
    obj.rectangle265.grid.role = "col";
    obj.rectangle265.grid.width = 3;
    obj.rectangle265:setStrokeSize(1);
    obj.rectangle265:setStrokeColor("white");
    obj.rectangle265:setXradius(5);
    obj.rectangle265:setYradius(5);
    obj.rectangle265:setMargins({top=10,right=10});
    obj.rectangle265:setName("rectangle265");

    obj.xpgenius = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpgenius:setParent(obj.rectangle265);
    obj.xpgenius:setHeight(42);
    obj.xpgenius:setField("xpgenius");
    obj.xpgenius:setFontSize(35);
    obj.xpgenius.grid.role = "col";
    obj.xpgenius.grid.width = 6;
    obj.xpgenius:setFontFamily("Wishes Script Caps Display");
    obj.xpgenius:setHorzTextAlign("center");
    obj.xpgenius:setTransparent(true);
    obj.xpgenius:setName("xpgenius");

    obj.modgenius = GUI.fromHandle(_obj_newObject("edit"));
    obj.modgenius:setParent(obj.rectangle265);
    obj.modgenius:setHeight(42);
    obj.modgenius:setField("modgenius");
    obj.modgenius:setFontSize(35);
    obj.modgenius.grid.role = "col";
    obj.modgenius.grid.width = 6;
    obj.modgenius:setFontFamily("Wishes Script Caps Display");
    obj.modgenius:setHorzTextAlign("center");
    obj.modgenius:setTransparent(true);
    obj.modgenius:setName("modgenius");
    obj.modgenius:setReadOnly(true);

    obj.label260 = GUI.fromHandle(_obj_newObject("label"));
    obj.label260:setParent(obj.rectangle257);
    obj.label260:setHeight(30);
    obj.label260:setText("Jogo da Cobrinha");
    obj.label260:setFontSize(18);
    obj.label260.grid.role = "col";
    obj.label260.grid.width = 3;
    obj.label260:setFontFamily("Wishes Script Caps Display");
    obj.label260:setHorzTextAlign("center");
    obj.label260:setVertTextAlign("center");
    obj.label260:setMargins({top=10});
    obj.label260:setName("label260");

    obj.rectangle266 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle266:setParent(obj.rectangle257);
    obj.rectangle266:setHeight(35);
    obj.rectangle266:setColor("black");
    obj.rectangle266:setCornerType("round");
    obj.rectangle266.grid.role = "col";
    obj.rectangle266.grid.width = 3;
    obj.rectangle266:setStrokeSize(1);
    obj.rectangle266:setStrokeColor("white");
    obj.rectangle266:setXradius(5);
    obj.rectangle266:setYradius(5);
    obj.rectangle266:setMargins({top=10});
    obj.rectangle266:setName("rectangle266");

    obj.xpjcobrinha = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpjcobrinha:setParent(obj.rectangle266);
    obj.xpjcobrinha:setHeight(42);
    obj.xpjcobrinha:setField("xpjcobrinha");
    obj.xpjcobrinha:setFontSize(35);
    obj.xpjcobrinha.grid.role = "col";
    obj.xpjcobrinha.grid.width = 6;
    obj.xpjcobrinha:setFontFamily("Wishes Script Caps Display");
    obj.xpjcobrinha:setHorzTextAlign("center");
    obj.xpjcobrinha:setTransparent(true);
    obj.xpjcobrinha:setName("xpjcobrinha");

    obj.modjcobrinha = GUI.fromHandle(_obj_newObject("edit"));
    obj.modjcobrinha:setParent(obj.rectangle266);
    obj.modjcobrinha:setHeight(42);
    obj.modjcobrinha:setField("modjcobrinha");
    obj.modjcobrinha:setFontSize(35);
    obj.modjcobrinha.grid.role = "col";
    obj.modjcobrinha.grid.width = 6;
    obj.modjcobrinha:setFontFamily("Wishes Script Caps Display");
    obj.modjcobrinha:setHorzTextAlign("center");
    obj.modjcobrinha:setTransparent(true);
    obj.modjcobrinha:setName("modjcobrinha");
    obj.modjcobrinha:setReadOnly(true);

    obj.label261 = GUI.fromHandle(_obj_newObject("label"));
    obj.label261:setParent(obj.rectangle257);
    obj.label261:setHeight(30);
    obj.label261:setText("Lights Out");
    obj.label261:setFontSize(18);
    obj.label261.grid.role = "col";
    obj.label261.grid.width = 3;
    obj.label261:setFontFamily("Wishes Script Caps Display");
    obj.label261:setHorzTextAlign("center");
    obj.label261:setVertTextAlign("center");
    obj.label261:setMargins({top=10});
    obj.label261:setName("label261");

    obj.rectangle267 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle267:setParent(obj.rectangle257);
    obj.rectangle267:setHeight(35);
    obj.rectangle267:setColor("black");
    obj.rectangle267:setCornerType("round");
    obj.rectangle267.grid.role = "col";
    obj.rectangle267.grid.width = 3;
    obj.rectangle267:setStrokeSize(1);
    obj.rectangle267:setStrokeColor("white");
    obj.rectangle267:setXradius(5);
    obj.rectangle267:setYradius(5);
    obj.rectangle267:setMargins({top=10,right=10});
    obj.rectangle267:setName("rectangle267");

    obj.xplout = GUI.fromHandle(_obj_newObject("edit"));
    obj.xplout:setParent(obj.rectangle267);
    obj.xplout:setHeight(42);
    obj.xplout:setField("xplout");
    obj.xplout:setFontSize(35);
    obj.xplout.grid.role = "col";
    obj.xplout.grid.width = 6;
    obj.xplout:setFontFamily("Wishes Script Caps Display");
    obj.xplout:setHorzTextAlign("center");
    obj.xplout:setTransparent(true);
    obj.xplout:setName("xplout");

    obj.modlout = GUI.fromHandle(_obj_newObject("edit"));
    obj.modlout:setParent(obj.rectangle267);
    obj.modlout:setHeight(42);
    obj.modlout:setField("modlout");
    obj.modlout:setFontSize(35);
    obj.modlout.grid.role = "col";
    obj.modlout.grid.width = 6;
    obj.modlout:setFontFamily("Wishes Script Caps Display");
    obj.modlout:setHorzTextAlign("center");
    obj.modlout:setTransparent(true);
    obj.modlout:setName("modlout");
    obj.modlout:setReadOnly(true);

    obj.label262 = GUI.fromHandle(_obj_newObject("label"));
    obj.label262:setParent(obj.rectangle257);
    obj.label262:setHeight(30);
    obj.label262:setText("Mahjong");
    obj.label262:setFontSize(18);
    obj.label262.grid.role = "col";
    obj.label262.grid.width = 3;
    obj.label262:setFontFamily("Wishes Script Caps Display");
    obj.label262:setHorzTextAlign("center");
    obj.label262:setVertTextAlign("center");
    obj.label262:setMargins({top=10});
    obj.label262:setName("label262");

    obj.rectangle268 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle268:setParent(obj.rectangle257);
    obj.rectangle268:setHeight(35);
    obj.rectangle268:setColor("black");
    obj.rectangle268:setCornerType("round");
    obj.rectangle268.grid.role = "col";
    obj.rectangle268.grid.width = 3;
    obj.rectangle268:setStrokeSize(1);
    obj.rectangle268:setStrokeColor("white");
    obj.rectangle268:setXradius(5);
    obj.rectangle268:setYradius(5);
    obj.rectangle268:setMargins({top=10});
    obj.rectangle268:setName("rectangle268");

    obj.xpmahjong = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpmahjong:setParent(obj.rectangle268);
    obj.xpmahjong:setHeight(42);
    obj.xpmahjong:setField("xpmahjong");
    obj.xpmahjong:setFontSize(35);
    obj.xpmahjong.grid.role = "col";
    obj.xpmahjong.grid.width = 6;
    obj.xpmahjong:setFontFamily("Wishes Script Caps Display");
    obj.xpmahjong:setHorzTextAlign("center");
    obj.xpmahjong:setTransparent(true);
    obj.xpmahjong:setName("xpmahjong");

    obj.modmahjong = GUI.fromHandle(_obj_newObject("edit"));
    obj.modmahjong:setParent(obj.rectangle268);
    obj.modmahjong:setHeight(42);
    obj.modmahjong:setField("modmahjong");
    obj.modmahjong:setFontSize(35);
    obj.modmahjong.grid.role = "col";
    obj.modmahjong.grid.width = 6;
    obj.modmahjong:setFontFamily("Wishes Script Caps Display");
    obj.modmahjong:setHorzTextAlign("center");
    obj.modmahjong:setTransparent(true);
    obj.modmahjong:setName("modmahjong");
    obj.modmahjong:setReadOnly(true);

    obj.label263 = GUI.fromHandle(_obj_newObject("label"));
    obj.label263:setParent(obj.rectangle257);
    obj.label263:setHeight(30);
    obj.label263:setText("Marble Maze");
    obj.label263:setFontSize(18);
    obj.label263.grid.role = "col";
    obj.label263.grid.width = 3;
    obj.label263:setFontFamily("Wishes Script Caps Display");
    obj.label263:setHorzTextAlign("center");
    obj.label263:setVertTextAlign("center");
    obj.label263:setMargins({top=10});
    obj.label263:setName("label263");

    obj.rectangle269 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle269:setParent(obj.rectangle257);
    obj.rectangle269:setHeight(35);
    obj.rectangle269:setColor("black");
    obj.rectangle269:setCornerType("round");
    obj.rectangle269.grid.role = "col";
    obj.rectangle269.grid.width = 3;
    obj.rectangle269:setStrokeSize(1);
    obj.rectangle269:setStrokeColor("white");
    obj.rectangle269:setXradius(5);
    obj.rectangle269:setYradius(5);
    obj.rectangle269:setMargins({top=10,right=10});
    obj.rectangle269:setName("rectangle269");

    obj.xpmmaze = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpmmaze:setParent(obj.rectangle269);
    obj.xpmmaze:setHeight(42);
    obj.xpmmaze:setField("xpmmaze");
    obj.xpmmaze:setFontSize(35);
    obj.xpmmaze.grid.role = "col";
    obj.xpmmaze.grid.width = 6;
    obj.xpmmaze:setFontFamily("Wishes Script Caps Display");
    obj.xpmmaze:setHorzTextAlign("center");
    obj.xpmmaze:setTransparent(true);
    obj.xpmmaze:setName("xpmmaze");

    obj.modmmaze = GUI.fromHandle(_obj_newObject("edit"));
    obj.modmmaze:setParent(obj.rectangle269);
    obj.modmmaze:setHeight(42);
    obj.modmmaze:setField("modmmaze");
    obj.modmmaze:setFontSize(35);
    obj.modmmaze.grid.role = "col";
    obj.modmmaze.grid.width = 6;
    obj.modmmaze:setFontFamily("Wishes Script Caps Display");
    obj.modmmaze:setHorzTextAlign("center");
    obj.modmmaze:setTransparent(true);
    obj.modmmaze:setName("modmmaze");
    obj.modmmaze:setReadOnly(true);

    obj.label264 = GUI.fromHandle(_obj_newObject("label"));
    obj.label264:setParent(obj.rectangle257);
    obj.label264:setHeight(30);
    obj.label264:setText("Mastermind");
    obj.label264:setFontSize(18);
    obj.label264.grid.role = "col";
    obj.label264.grid.width = 3;
    obj.label264:setFontFamily("Wishes Script Caps Display");
    obj.label264:setHorzTextAlign("center");
    obj.label264:setVertTextAlign("center");
    obj.label264:setMargins({top=10});
    obj.label264:setName("label264");

    obj.rectangle270 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle270:setParent(obj.rectangle257);
    obj.rectangle270:setHeight(35);
    obj.rectangle270:setColor("black");
    obj.rectangle270:setCornerType("round");
    obj.rectangle270.grid.role = "col";
    obj.rectangle270.grid.width = 3;
    obj.rectangle270:setStrokeSize(1);
    obj.rectangle270:setStrokeColor("white");
    obj.rectangle270:setXradius(5);
    obj.rectangle270:setYradius(5);
    obj.rectangle270:setMargins({top=10});
    obj.rectangle270:setName("rectangle270");

    obj.xpmastermind = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpmastermind:setParent(obj.rectangle270);
    obj.xpmastermind:setHeight(42);
    obj.xpmastermind:setField("xpmmind");
    obj.xpmastermind:setFontSize(35);
    obj.xpmastermind.grid.role = "col";
    obj.xpmastermind.grid.width = 6;
    obj.xpmastermind:setFontFamily("Wishes Script Caps Display");
    obj.xpmastermind:setHorzTextAlign("center");
    obj.xpmastermind:setTransparent(true);
    obj.xpmastermind:setName("xpmastermind");

    obj.modmastermind = GUI.fromHandle(_obj_newObject("edit"));
    obj.modmastermind:setParent(obj.rectangle270);
    obj.modmastermind:setHeight(42);
    obj.modmastermind:setField("modmmind");
    obj.modmastermind:setFontSize(35);
    obj.modmastermind.grid.role = "col";
    obj.modmastermind.grid.width = 6;
    obj.modmastermind:setFontFamily("Wishes Script Caps Display");
    obj.modmastermind:setHorzTextAlign("center");
    obj.modmastermind:setTransparent(true);
    obj.modmastermind:setName("modmastermind");
    obj.modmastermind:setReadOnly(true);

    obj.label265 = GUI.fromHandle(_obj_newObject("label"));
    obj.label265:setParent(obj.rectangle257);
    obj.label265:setHeight(30);
    obj.label265:setText("Pac-Man");
    obj.label265:setFontSize(18);
    obj.label265.grid.role = "col";
    obj.label265.grid.width = 3;
    obj.label265:setFontFamily("Wishes Script Caps Display");
    obj.label265:setHorzTextAlign("center");
    obj.label265:setVertTextAlign("center");
    obj.label265:setMargins({top=10});
    obj.label265:setName("label265");

    obj.rectangle271 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle271:setParent(obj.rectangle257);
    obj.rectangle271:setHeight(35);
    obj.rectangle271:setColor("black");
    obj.rectangle271:setCornerType("round");
    obj.rectangle271.grid.role = "col";
    obj.rectangle271.grid.width = 3;
    obj.rectangle271:setStrokeSize(1);
    obj.rectangle271:setStrokeColor("white");
    obj.rectangle271:setXradius(5);
    obj.rectangle271:setYradius(5);
    obj.rectangle271:setMargins({top=10,right=10});
    obj.rectangle271:setName("rectangle271");

    obj.xppman = GUI.fromHandle(_obj_newObject("edit"));
    obj.xppman:setParent(obj.rectangle271);
    obj.xppman:setHeight(42);
    obj.xppman:setField("xppman");
    obj.xppman:setFontSize(35);
    obj.xppman.grid.role = "col";
    obj.xppman.grid.width = 6;
    obj.xppman:setFontFamily("Wishes Script Caps Display");
    obj.xppman:setHorzTextAlign("center");
    obj.xppman:setTransparent(true);
    obj.xppman:setName("xppman");

    obj.modpman = GUI.fromHandle(_obj_newObject("edit"));
    obj.modpman:setParent(obj.rectangle271);
    obj.modpman:setHeight(42);
    obj.modpman:setField("modpman");
    obj.modpman:setFontSize(35);
    obj.modpman.grid.role = "col";
    obj.modpman.grid.width = 6;
    obj.modpman:setFontFamily("Wishes Script Caps Display");
    obj.modpman:setHorzTextAlign("center");
    obj.modpman:setTransparent(true);
    obj.modpman:setName("modpman");
    obj.modpman:setReadOnly(true);

    obj.label266 = GUI.fromHandle(_obj_newObject("label"));
    obj.label266:setParent(obj.rectangle257);
    obj.label266:setHeight(30);
    obj.label266:setText("Paciência");
    obj.label266:setFontSize(18);
    obj.label266.grid.role = "col";
    obj.label266.grid.width = 3;
    obj.label266:setFontFamily("Wishes Script Caps Display");
    obj.label266:setHorzTextAlign("center");
    obj.label266:setVertTextAlign("center");
    obj.label266:setMargins({top=10});
    obj.label266:setName("label266");

    obj.rectangle272 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle272:setParent(obj.rectangle257);
    obj.rectangle272:setHeight(35);
    obj.rectangle272:setColor("black");
    obj.rectangle272:setCornerType("round");
    obj.rectangle272.grid.role = "col";
    obj.rectangle272.grid.width = 3;
    obj.rectangle272:setStrokeSize(1);
    obj.rectangle272:setStrokeColor("white");
    obj.rectangle272:setXradius(5);
    obj.rectangle272:setYradius(5);
    obj.rectangle272:setMargins({top=10});
    obj.rectangle272:setName("rectangle272");

    obj.xppaciencia = GUI.fromHandle(_obj_newObject("edit"));
    obj.xppaciencia:setParent(obj.rectangle272);
    obj.xppaciencia:setHeight(42);
    obj.xppaciencia:setField("xppaciencia");
    obj.xppaciencia:setFontSize(35);
    obj.xppaciencia.grid.role = "col";
    obj.xppaciencia.grid.width = 6;
    obj.xppaciencia:setFontFamily("Wishes Script Caps Display");
    obj.xppaciencia:setHorzTextAlign("center");
    obj.xppaciencia:setTransparent(true);
    obj.xppaciencia:setName("xppaciencia");

    obj.modpaciencia = GUI.fromHandle(_obj_newObject("edit"));
    obj.modpaciencia:setParent(obj.rectangle272);
    obj.modpaciencia:setHeight(42);
    obj.modpaciencia:setField("modpaciencia");
    obj.modpaciencia:setFontSize(35);
    obj.modpaciencia.grid.role = "col";
    obj.modpaciencia.grid.width = 6;
    obj.modpaciencia:setFontFamily("Wishes Script Caps Display");
    obj.modpaciencia:setHorzTextAlign("center");
    obj.modpaciencia:setTransparent(true);
    obj.modpaciencia:setName("modpaciencia");
    obj.modpaciencia:setReadOnly(true);

    obj.label267 = GUI.fromHandle(_obj_newObject("label"));
    obj.label267:setParent(obj.rectangle257);
    obj.label267:setHeight(30);
    obj.label267:setText("Piano Tiles");
    obj.label267:setFontSize(18);
    obj.label267.grid.role = "col";
    obj.label267.grid.width = 3;
    obj.label267:setFontFamily("Wishes Script Caps Display");
    obj.label267:setHorzTextAlign("center");
    obj.label267:setVertTextAlign("center");
    obj.label267:setMargins({top=10});
    obj.label267:setName("label267");

    obj.rectangle273 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle273:setParent(obj.rectangle257);
    obj.rectangle273:setHeight(35);
    obj.rectangle273:setColor("black");
    obj.rectangle273:setCornerType("round");
    obj.rectangle273.grid.role = "col";
    obj.rectangle273.grid.width = 3;
    obj.rectangle273:setStrokeSize(1);
    obj.rectangle273:setStrokeColor("white");
    obj.rectangle273:setXradius(5);
    obj.rectangle273:setYradius(5);
    obj.rectangle273:setMargins({top=10,right=10});
    obj.rectangle273:setName("rectangle273");

    obj.xpptiles = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpptiles:setParent(obj.rectangle273);
    obj.xpptiles:setHeight(42);
    obj.xpptiles:setField("xpptiles");
    obj.xpptiles:setFontSize(35);
    obj.xpptiles.grid.role = "col";
    obj.xpptiles.grid.width = 6;
    obj.xpptiles:setFontFamily("Wishes Script Caps Display");
    obj.xpptiles:setHorzTextAlign("center");
    obj.xpptiles:setTransparent(true);
    obj.xpptiles:setName("xpptiles");

    obj.modptiles = GUI.fromHandle(_obj_newObject("edit"));
    obj.modptiles:setParent(obj.rectangle273);
    obj.modptiles:setHeight(42);
    obj.modptiles:setField("modptiles");
    obj.modptiles:setFontSize(35);
    obj.modptiles.grid.role = "col";
    obj.modptiles.grid.width = 6;
    obj.modptiles:setFontFamily("Wishes Script Caps Display");
    obj.modptiles:setHorzTextAlign("center");
    obj.modptiles:setTransparent(true);
    obj.modptiles:setName("modptiles");
    obj.modptiles:setReadOnly(true);

    obj.label268 = GUI.fromHandle(_obj_newObject("label"));
    obj.label268:setParent(obj.rectangle257);
    obj.label268:setHeight(30);
    obj.label268:setText("Quebra-Cabeça");
    obj.label268:setFontSize(18);
    obj.label268.grid.role = "col";
    obj.label268.grid.width = 3;
    obj.label268:setFontFamily("Wishes Script Caps Display");
    obj.label268:setHorzTextAlign("center");
    obj.label268:setVertTextAlign("center");
    obj.label268:setMargins({top=10});
    obj.label268:setName("label268");

    obj.rectangle274 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle274:setParent(obj.rectangle257);
    obj.rectangle274:setHeight(35);
    obj.rectangle274:setColor("black");
    obj.rectangle274:setCornerType("round");
    obj.rectangle274.grid.role = "col";
    obj.rectangle274.grid.width = 3;
    obj.rectangle274:setStrokeSize(1);
    obj.rectangle274:setStrokeColor("white");
    obj.rectangle274:setXradius(5);
    obj.rectangle274:setYradius(5);
    obj.rectangle274:setMargins({top=10});
    obj.rectangle274:setName("rectangle274");

    obj.xpqcabeca = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpqcabeca:setParent(obj.rectangle274);
    obj.xpqcabeca:setHeight(42);
    obj.xpqcabeca:setField("xpqcabeca");
    obj.xpqcabeca:setFontSize(35);
    obj.xpqcabeca.grid.role = "col";
    obj.xpqcabeca.grid.width = 6;
    obj.xpqcabeca:setFontFamily("Wishes Script Caps Display");
    obj.xpqcabeca:setHorzTextAlign("center");
    obj.xpqcabeca:setTransparent(true);
    obj.xpqcabeca:setName("xpqcabeca");

    obj.modqcabeca = GUI.fromHandle(_obj_newObject("edit"));
    obj.modqcabeca:setParent(obj.rectangle274);
    obj.modqcabeca:setHeight(42);
    obj.modqcabeca:setField("modqcabeca");
    obj.modqcabeca:setFontSize(35);
    obj.modqcabeca.grid.role = "col";
    obj.modqcabeca.grid.width = 6;
    obj.modqcabeca:setFontFamily("Wishes Script Caps Display");
    obj.modqcabeca:setHorzTextAlign("center");
    obj.modqcabeca:setTransparent(true);
    obj.modqcabeca:setName("modqcabeca");
    obj.modqcabeca:setReadOnly(true);

    obj.label269 = GUI.fromHandle(_obj_newObject("label"));
    obj.label269:setParent(obj.rectangle257);
    obj.label269:setHeight(30);
    obj.label269:setText("Rush Hour");
    obj.label269:setFontSize(18);
    obj.label269.grid.role = "col";
    obj.label269.grid.width = 3;
    obj.label269:setFontFamily("Wishes Script Caps Display");
    obj.label269:setHorzTextAlign("center");
    obj.label269:setVertTextAlign("center");
    obj.label269:setMargins({top=10});
    obj.label269:setName("label269");

    obj.rectangle275 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle275:setParent(obj.rectangle257);
    obj.rectangle275:setHeight(35);
    obj.rectangle275:setColor("black");
    obj.rectangle275:setCornerType("round");
    obj.rectangle275.grid.role = "col";
    obj.rectangle275.grid.width = 3;
    obj.rectangle275:setStrokeSize(1);
    obj.rectangle275:setStrokeColor("white");
    obj.rectangle275:setXradius(5);
    obj.rectangle275:setYradius(5);
    obj.rectangle275:setMargins({top=10,right=10});
    obj.rectangle275:setName("rectangle275");

    obj.xprhour = GUI.fromHandle(_obj_newObject("edit"));
    obj.xprhour:setParent(obj.rectangle275);
    obj.xprhour:setHeight(42);
    obj.xprhour:setField("xprhour");
    obj.xprhour:setFontSize(35);
    obj.xprhour.grid.role = "col";
    obj.xprhour.grid.width = 6;
    obj.xprhour:setFontFamily("Wishes Script Caps Display");
    obj.xprhour:setHorzTextAlign("center");
    obj.xprhour:setTransparent(true);
    obj.xprhour:setName("xprhour");

    obj.modrhour = GUI.fromHandle(_obj_newObject("edit"));
    obj.modrhour:setParent(obj.rectangle275);
    obj.modrhour:setHeight(42);
    obj.modrhour:setField("modrhour");
    obj.modrhour:setFontSize(35);
    obj.modrhour.grid.role = "col";
    obj.modrhour.grid.width = 6;
    obj.modrhour:setFontFamily("Wishes Script Caps Display");
    obj.modrhour:setHorzTextAlign("center");
    obj.modrhour:setTransparent(true);
    obj.modrhour:setName("modrhour");
    obj.modrhour:setReadOnly(true);

    obj.label270 = GUI.fromHandle(_obj_newObject("label"));
    obj.label270:setParent(obj.rectangle257);
    obj.label270:setHeight(30);
    obj.label270:setText("Sliding Puzzle");
    obj.label270:setFontSize(18);
    obj.label270.grid.role = "col";
    obj.label270.grid.width = 3;
    obj.label270:setFontFamily("Wishes Script Caps Display");
    obj.label270:setHorzTextAlign("center");
    obj.label270:setVertTextAlign("center");
    obj.label270:setMargins({top=10});
    obj.label270:setName("label270");

    obj.rectangle276 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle276:setParent(obj.rectangle257);
    obj.rectangle276:setHeight(35);
    obj.rectangle276:setColor("black");
    obj.rectangle276:setCornerType("round");
    obj.rectangle276.grid.role = "col";
    obj.rectangle276.grid.width = 3;
    obj.rectangle276:setStrokeSize(1);
    obj.rectangle276:setStrokeColor("white");
    obj.rectangle276:setXradius(5);
    obj.rectangle276:setYradius(5);
    obj.rectangle276:setMargins({top=10});
    obj.rectangle276:setName("rectangle276");

    obj.xpspuzzle = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpspuzzle:setParent(obj.rectangle276);
    obj.xpspuzzle:setHeight(42);
    obj.xpspuzzle:setField("xpspuzzle");
    obj.xpspuzzle:setFontSize(35);
    obj.xpspuzzle.grid.role = "col";
    obj.xpspuzzle.grid.width = 6;
    obj.xpspuzzle:setFontFamily("Wishes Script Caps Display");
    obj.xpspuzzle:setHorzTextAlign("center");
    obj.xpspuzzle:setTransparent(true);
    obj.xpspuzzle:setName("xpspuzzle");

    obj.modspuzzle = GUI.fromHandle(_obj_newObject("edit"));
    obj.modspuzzle:setParent(obj.rectangle276);
    obj.modspuzzle:setHeight(42);
    obj.modspuzzle:setField("modspuzzle");
    obj.modspuzzle:setFontSize(35);
    obj.modspuzzle.grid.role = "col";
    obj.modspuzzle.grid.width = 6;
    obj.modspuzzle:setFontFamily("Wishes Script Caps Display");
    obj.modspuzzle:setHorzTextAlign("center");
    obj.modspuzzle:setTransparent(true);
    obj.modspuzzle:setName("modspuzzle");
    obj.modspuzzle:setReadOnly(true);

    obj.label271 = GUI.fromHandle(_obj_newObject("label"));
    obj.label271:setParent(obj.rectangle257);
    obj.label271:setHeight(30);
    obj.label271:setText("Sudoku");
    obj.label271:setFontSize(18);
    obj.label271.grid.role = "col";
    obj.label271.grid.width = 3;
    obj.label271:setFontFamily("Wishes Script Caps Display");
    obj.label271:setHorzTextAlign("center");
    obj.label271:setVertTextAlign("center");
    obj.label271:setMargins({top=10});
    obj.label271:setName("label271");

    obj.rectangle277 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle277:setParent(obj.rectangle257);
    obj.rectangle277:setHeight(35);
    obj.rectangle277:setColor("black");
    obj.rectangle277:setCornerType("round");
    obj.rectangle277.grid.role = "col";
    obj.rectangle277.grid.width = 3;
    obj.rectangle277:setStrokeSize(1);
    obj.rectangle277:setStrokeColor("white");
    obj.rectangle277:setXradius(5);
    obj.rectangle277:setYradius(5);
    obj.rectangle277:setMargins({top=10,right=10});
    obj.rectangle277:setName("rectangle277");

    obj.xpsudoku = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpsudoku:setParent(obj.rectangle277);
    obj.xpsudoku:setHeight(42);
    obj.xpsudoku:setField("xpsudoku");
    obj.xpsudoku:setFontSize(35);
    obj.xpsudoku.grid.role = "col";
    obj.xpsudoku.grid.width = 6;
    obj.xpsudoku:setFontFamily("Wishes Script Caps Display");
    obj.xpsudoku:setHorzTextAlign("center");
    obj.xpsudoku:setTransparent(true);
    obj.xpsudoku:setName("xpsudoku");

    obj.modsudoku = GUI.fromHandle(_obj_newObject("edit"));
    obj.modsudoku:setParent(obj.rectangle277);
    obj.modsudoku:setHeight(42);
    obj.modsudoku:setField("modsudoku");
    obj.modsudoku:setFontSize(35);
    obj.modsudoku.grid.role = "col";
    obj.modsudoku.grid.width = 6;
    obj.modsudoku:setFontFamily("Wishes Script Caps Display");
    obj.modsudoku:setHorzTextAlign("center");
    obj.modsudoku:setTransparent(true);
    obj.modsudoku:setName("modsudoku");
    obj.modsudoku:setReadOnly(true);

    obj.label272 = GUI.fromHandle(_obj_newObject("label"));
    obj.label272:setParent(obj.rectangle257);
    obj.label272:setHeight(30);
    obj.label272:setText("Tetrix");
    obj.label272:setFontSize(18);
    obj.label272.grid.role = "col";
    obj.label272.grid.width = 3;
    obj.label272:setFontFamily("Wishes Script Caps Display");
    obj.label272:setHorzTextAlign("center");
    obj.label272:setVertTextAlign("center");
    obj.label272:setMargins({top=10});
    obj.label272:setName("label272");

    obj.rectangle278 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle278:setParent(obj.rectangle257);
    obj.rectangle278:setHeight(35);
    obj.rectangle278:setColor("black");
    obj.rectangle278:setCornerType("round");
    obj.rectangle278.grid.role = "col";
    obj.rectangle278.grid.width = 3;
    obj.rectangle278:setStrokeSize(1);
    obj.rectangle278:setStrokeColor("white");
    obj.rectangle278:setXradius(5);
    obj.rectangle278:setYradius(5);
    obj.rectangle278:setMargins({top=10});
    obj.rectangle278:setName("rectangle278");

    obj.xptetrix = GUI.fromHandle(_obj_newObject("edit"));
    obj.xptetrix:setParent(obj.rectangle278);
    obj.xptetrix:setHeight(42);
    obj.xptetrix:setField("xptetrix");
    obj.xptetrix:setFontSize(35);
    obj.xptetrix.grid.role = "col";
    obj.xptetrix.grid.width = 6;
    obj.xptetrix:setFontFamily("Wishes Script Caps Display");
    obj.xptetrix:setHorzTextAlign("center");
    obj.xptetrix:setTransparent(true);
    obj.xptetrix:setName("xptetrix");

    obj.modtetrix = GUI.fromHandle(_obj_newObject("edit"));
    obj.modtetrix:setParent(obj.rectangle278);
    obj.modtetrix:setHeight(42);
    obj.modtetrix:setField("modtetrix");
    obj.modtetrix:setFontSize(35);
    obj.modtetrix.grid.role = "col";
    obj.modtetrix.grid.width = 6;
    obj.modtetrix:setFontFamily("Wishes Script Caps Display");
    obj.modtetrix:setHorzTextAlign("center");
    obj.modtetrix:setTransparent(true);
    obj.modtetrix:setName("modtetrix");
    obj.modtetrix:setReadOnly(true);

    obj.label273 = GUI.fromHandle(_obj_newObject("label"));
    obj.label273:setParent(obj.rectangle257);
    obj.label273:setHeight(30);
    obj.label273:setText("Torre de Hanói");
    obj.label273:setFontSize(18);
    obj.label273.grid.role = "col";
    obj.label273.grid.width = 3;
    obj.label273:setFontFamily("Wishes Script Caps Display");
    obj.label273:setHorzTextAlign("center");
    obj.label273:setVertTextAlign("center");
    obj.label273:setMargins({top=10});
    obj.label273:setName("label273");

    obj.rectangle279 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle279:setParent(obj.rectangle257);
    obj.rectangle279:setHeight(35);
    obj.rectangle279:setColor("black");
    obj.rectangle279:setCornerType("round");
    obj.rectangle279.grid.role = "col";
    obj.rectangle279.grid.width = 3;
    obj.rectangle279:setStrokeSize(1);
    obj.rectangle279:setStrokeColor("white");
    obj.rectangle279:setXradius(5);
    obj.rectangle279:setYradius(5);
    obj.rectangle279:setMargins({top=10,right=10});
    obj.rectangle279:setName("rectangle279");

    obj.xptdh = GUI.fromHandle(_obj_newObject("edit"));
    obj.xptdh:setParent(obj.rectangle279);
    obj.xptdh:setHeight(42);
    obj.xptdh:setField("xptdh");
    obj.xptdh:setFontSize(35);
    obj.xptdh.grid.role = "col";
    obj.xptdh.grid.width = 6;
    obj.xptdh:setFontFamily("Wishes Script Caps Display");
    obj.xptdh:setHorzTextAlign("center");
    obj.xptdh:setTransparent(true);
    obj.xptdh:setName("xptdh");

    obj.modtdh = GUI.fromHandle(_obj_newObject("edit"));
    obj.modtdh:setParent(obj.rectangle279);
    obj.modtdh:setHeight(42);
    obj.modtdh:setField("modtdh");
    obj.modtdh:setFontSize(35);
    obj.modtdh.grid.role = "col";
    obj.modtdh.grid.width = 6;
    obj.modtdh:setFontFamily("Wishes Script Caps Display");
    obj.modtdh:setHorzTextAlign("center");
    obj.modtdh:setTransparent(true);
    obj.modtdh:setName("modtdh");
    obj.modtdh:setReadOnly(true);

    obj.rectangle280 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle280:setParent(obj.rectangle257);
    obj.rectangle280:setHeight(30);
    obj.rectangle280:setColor("black");
    obj.rectangle280:setCornerType("round");
    obj.rectangle280.grid.role = "col";
    obj.rectangle280.grid.width = 12;
    obj.rectangle280:setStrokeSize(1);
    obj.rectangle280:setStrokeColor("white");
    obj.rectangle280:setXradius(5);
    obj.rectangle280:setYradius(5);
    obj.rectangle280:setMargins({top=25,right=10,left=10});
    obj.rectangle280:setName("rectangle280");

    obj.label274 = GUI.fromHandle(_obj_newObject("label"));
    obj.label274:setParent(obj.rectangle280);
    obj.label274:setHeight(25);
    obj.label274:setText("Disponível:");
    obj.label274:setFontSize(12);
    obj.label274.grid.role = "col";
    obj.label274.grid.width = 2;
    obj.label274:setFontFamily("Wishes Script Caps Display");
    obj.label274:setHorzTextAlign("trailing");
    obj.label274:setVertTextAlign("center");
    obj.label274:setMargins({top=3});
    obj.label274:setName("label274");

    obj.rectangle281 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle281:setParent(obj.rectangle280);
    obj.rectangle281:setHeight(23);
    obj.rectangle281:setColor("black");
    obj.rectangle281:setCornerType("round");
    obj.rectangle281.grid.role = "col";
    obj.rectangle281.grid.width = 1;
    obj.rectangle281:setStrokeSize(1);
    obj.rectangle281:setStrokeColor("white");
    obj.rectangle281:setXradius(5);
    obj.rectangle281:setYradius(5);
    obj.rectangle281:setMargins({top=3});
    obj.rectangle281:setName("rectangle281");

    obj.xpjogosdisponivel = GUI.fromHandle(_obj_newObject("edit"));
    obj.xpjogosdisponivel:setParent(obj.rectangle281);
    obj.xpjogosdisponivel:setHeight(23);
    obj.xpjogosdisponivel:setName("xpjogosdisponivel");
    obj.xpjogosdisponivel:setField("xpjogosdisponivel");
    obj.xpjogosdisponivel:setFontSize(15);
    obj.xpjogosdisponivel.grid.role = "col";
    obj.xpjogosdisponivel.grid.width = 12;
    obj.xpjogosdisponivel:setHorzTextAlign("center");
    obj.xpjogosdisponivel:setVertTextAlign("center");
    obj.xpjogosdisponivel:setTransparent(true);
    obj.xpjogosdisponivel:setReadOnly(true);

    obj.label275 = GUI.fromHandle(_obj_newObject("label"));
    obj.label275:setParent(obj.rectangle280);
    obj.label275:setHeight(25);
    obj.label275:setText("Totais:");
    obj.label275:setFontSize(10);
    obj.label275.grid.role = "col";
    obj.label275.grid.width = 1;
    obj.label275:setFontFamily("Wishes Script Caps Display");
    obj.label275:setHorzTextAlign("trailing");
    obj.label275:setVertTextAlign("center");
    obj.label275:setMargins({top=3});
    obj.label275:setName("label275");

    obj.rectangle282 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle282:setParent(obj.rectangle280);
    obj.rectangle282:setHeight(23);
    obj.rectangle282:setColor("black");
    obj.rectangle282:setCornerType("round");
    obj.rectangle282.grid.role = "col";
    obj.rectangle282.grid.width = 2;
    obj.rectangle282:setStrokeSize(1);
    obj.rectangle282:setStrokeColor("white");
    obj.rectangle282:setXradius(5);
    obj.rectangle282:setYradius(5);
    obj.rectangle282:setMargins({top=3});
    obj.rectangle282:setName("rectangle282");

    obj.xptotaljogos = GUI.fromHandle(_obj_newObject("edit"));
    obj.xptotaljogos:setParent(obj.rectangle282);
    obj.xptotaljogos:setHeight(23);
    obj.xptotaljogos:setName("xptotaljogos");
    obj.xptotaljogos:setField("xptotaljogos");
    obj.xptotaljogos:setFontSize(15);
    obj.xptotaljogos.grid.role = "col";
    obj.xptotaljogos.grid.width = 12;
    obj.xptotaljogos:setHorzTextAlign("center");
    obj.xptotaljogos:setVertTextAlign("center");
    obj.xptotaljogos:setTransparent(true);
    obj.xptotaljogos:setReadOnly(true);

    obj.label276 = GUI.fromHandle(_obj_newObject("label"));
    obj.label276:setParent(obj.rectangle280);
    obj.label276:setHeight(23);
    obj.label276:setText("Vezes Jogadas");
    obj.label276:setFontSize(15);
    obj.label276.grid.role = "col";
    obj.label276.grid.width = 3;
    obj.label276:setHorzTextAlign("center");
    obj.label276:setVertTextAlign("center");
    obj.label276:setName("label276");

    obj.rectangle283 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle283:setParent(obj.rectangle280);
    obj.rectangle283:setHeight(23);
    obj.rectangle283:setColor("black");
    obj.rectangle283:setCornerType("round");
    obj.rectangle283.grid.role = "col";
    obj.rectangle283.grid.width = 2;
    obj.rectangle283:setStrokeSize(1);
    obj.rectangle283:setStrokeColor("white");
    obj.rectangle283:setXradius(5);
    obj.rectangle283:setYradius(5);
    obj.rectangle283:setMargins({top=3});
    obj.rectangle283:setName("rectangle283");

    obj.vezesjogadas = GUI.fromHandle(_obj_newObject("edit"));
    obj.vezesjogadas:setParent(obj.rectangle283);
    obj.vezesjogadas:setHeight(23);
    obj.vezesjogadas:setName("vezesjogadas");
    obj.vezesjogadas:setField("vezesjogadas");
    obj.vezesjogadas:setFontSize(15);
    obj.vezesjogadas.grid.role = "col";
    obj.vezesjogadas.grid.width = 12;
    obj.vezesjogadas:setHorzTextAlign("center");
    obj.vezesjogadas:setVertTextAlign("center");
    obj.vezesjogadas:setTransparent(true);
    obj.vezesjogadas:setReadOnly(true);

    obj.dataLink78 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink78:setParent(obj.rectangle283);
    obj.dataLink78:setFields({'vezesjogadas'});
    obj.dataLink78:setDefaultValue("0");
    obj.dataLink78:setName("dataLink78");

    obj.dataLink79 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink79:setParent(obj.rectangle280);
    obj.dataLink79:setFields({'xpbnaval','xpbejeweled','xpcminado','xpcmagico','xpgenius','xpjcobrinha','xplout','xpmahjong','xpmmaze','xpmmind','xppman','xppaciencia','xpptiles','xpqcabeca','xprhour','xpspuzzle','xpsudoku','xptetrix','xptdh','xp2048'});
    obj.dataLink79:setDefaultValue("0");
    obj.dataLink79:setName("dataLink79");

    obj.aba_vinculos = GUI.fromHandle(_obj_newObject("tab"));
    obj.aba_vinculos:setParent(obj.ficha);
    obj.aba_vinculos:setName("aba_vinculos");
    obj.aba_vinculos:setTitle("Vínculos");

    obj.rectangle284 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle284:setParent(obj.aba_vinculos);
    obj.rectangle284:setAlign("client");
    obj.rectangle284:setColor("black");
    obj.rectangle284:setName("rectangle284");

    obj.scrollBox14 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox14:setParent(obj.rectangle284);
    obj.scrollBox14:setAlign("client");
    obj.scrollBox14:setMargins({left=5,right=5});
    obj.scrollBox14:setName("scrollBox14");

    obj.rectangle285 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle285:setParent(obj.scrollBox14);
    obj.rectangle285:setColor("#150e16");
    obj.rectangle285:setStrokeSize(2);
    obj.rectangle285:setStrokeColor("white");
    obj.rectangle285.grid.role = "col";
    obj.rectangle285.grid.width = 3;
    obj.rectangle285.grid["max-width"] = 340;
    obj.rectangle285.grid["min-width"] = 300;
    obj.rectangle285.grid["min-height"] = 550;
    obj.rectangle285.grid["max-height"] = 1080;
    obj.rectangle285:setMargins({top=15});
    obj.rectangle285:setName("rectangle285");

    obj.label277 = GUI.fromHandle(_obj_newObject("label"));
    obj.label277:setParent(obj.rectangle285);
    obj.label277:setHeight(25);
    obj.label277:setText("Grupos");
    obj.label277:setFontSize(50);
    obj.label277.grid.role = "col";
    obj.label277.grid.width = 12;
    obj.label277:setFontFamily("Wishes Script Caps Display");
    obj.label277:setHorzTextAlign("center");
    obj.label277:setMargins({top=15});
    obj.label277:setName("label277");

    obj.label278 = GUI.fromHandle(_obj_newObject("label"));
    obj.label278:setParent(obj.label277);
    obj.label278.grid.role = "col";
    obj.label278.grid.width = 10;
    obj.label278:setName("label278");

    obj.btnNovaVinculo_1 = GUI.fromHandle(_obj_newObject("button"));
    obj.btnNovaVinculo_1:setParent(obj.label277);
    obj.btnNovaVinculo_1:setName("btnNovaVinculo_1");
    obj.btnNovaVinculo_1:setText("+");
    obj.btnNovaVinculo_1:setHeight(30);
    obj.btnNovaVinculo_1.grid.role = "col";
    obj.btnNovaVinculo_1.grid.width = 2;
    obj.btnNovaVinculo_1:setMargins({right=5, top=-10});


                        local filterVinculo_1Argument = "";
                        
                        local function prepFilterVinculo_1(inputStr)
                            return string.lower(Utils.removerAcentos(inputStr or ""));
                        end;
                        
                        local function runVinculo_1Filter()           
                            filterVinculo_1Argument = prepFilterVinculo_1(self.edtFiltroVinculo_1.text);
                            self.listavinculo_1:reorganize();
                        end;        
                        
                        local function checkVinculo_1Filter() 
                            local newArg = prepFilterVinculo_1(self.edtFiltroVinculo_1.text);
                            if newArg ~= filterVinculo_1Argument then
                                runVinculo_1Filter();
                            end;
                        end;
                    


    obj.tmrFiltroVinculo_1 = GUI.fromHandle(_obj_newObject("timer"));
    obj.tmrFiltroVinculo_1:setParent(obj.rectangle285);
    obj.tmrFiltroVinculo_1:setName("tmrFiltroVinculo_1");
    obj.tmrFiltroVinculo_1:setInterval(1000);

    obj.edtFiltroVinculo_1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtFiltroVinculo_1:setParent(obj.rectangle285);
    obj.edtFiltroVinculo_1.grid.role = "row";
    obj.edtFiltroVinculo_1.grid["min-height"] = 25;
    obj.edtFiltroVinculo_1:setTextPrompt("Buscar Vinculo...");
    obj.edtFiltroVinculo_1:setName("edtFiltroVinculo_1");
    obj.edtFiltroVinculo_1:setMargins({top=5,right=5,left=5});
    obj.edtFiltroVinculo_1:setHint("Buscar Vinculo ou tag...");

    obj.scrollBox15 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox15:setParent(obj.rectangle285);
    obj.scrollBox15.grid.role = "row";
    obj.scrollBox15.grid["vert-tile"] = true;
    obj.scrollBox15:setMargins({top=5,right=2,left=2,bottom=2});
    obj.scrollBox15.grid["cnt-gutter"] = 1;
    obj.scrollBox15:setName("scrollBox15");

    obj.listavinculo_1 = GUI.fromHandle(_obj_newObject("gridRecordList"));
    obj.listavinculo_1:setParent(obj.scrollBox15);
    obj.listavinculo_1:setName("listavinculo_1");
    obj.listavinculo_1.field = "itensVinculo_1";
    obj.listavinculo_1.templateForm = "templateVinculo_1";
    obj.listavinculo_1.minQt = 0;
    obj.listavinculo_1.selectable = true;
    obj.listavinculo_1:setHeight(600);
    obj.listavinculo_1.grid.role = "col";
    obj.listavinculo_1.grid.width = 12;
    obj.listavinculo_1:setMargins({left=5,right=5});


                            -- Função de reordenação específica para a nova lista
                            local function reordenarVinculo_1()
                                local nodes = NDB.getChildNodes(sheet.itensVinculo_1)
                                table.sort(nodes, function(a, b)
                                    return (tonumber(a.ordemVinculo_1) or 0) < (tonumber(b.ordemVinculo_1) or 0)
                                end)
                                self.listavinculo_1:reorganize()
                            end

                            -- Configuração do botão de adicionar
                            self.btnNovaVinculo_1.onClick = function()
                                local novo = self.listavinculo_1:append()
                                if novo then
                                    novo.nomeVinculo_1 = "Novo Grupo"
                                    novo.ordemVinculo_1 = #NDB.getChildNodes(sheet.itensVinculo_1) + 1
                                    reordenarVinculo_1()
                                end
                            end

                            
                            -- Lógica de seleção: agora aponta para o dataScopeBox 'detalheSkill'
                            self.listavinculo_1.onSelect = function()
                                local node = self.listavinculo_1.selectedNode;
                                self.detalhe_vinculo_1:setNodeObject(node);
                                self.detalhe_vinculo_1.visible = (node ~= nil);

                                self.abertoPeloSlot = false;

                            
                            end;
                        


    obj.rectangle286 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle286:setParent(obj.scrollBox14);
    obj.rectangle286:setColor("#150e16");
    obj.rectangle286:setStrokeSize(2);
    obj.rectangle286:setStrokeColor("white");
    obj.rectangle286.grid.role = "col";
    obj.rectangle286.grid.width = 3;
    obj.rectangle286.grid["max-width"] = 1920;
    obj.rectangle286.grid["min-width"] = 300;
    obj.rectangle286.grid["min-height"] = 550;
    obj.rectangle286.grid["max-height"] = 1080;
    obj.rectangle286:setMargins({top=15});
    obj.rectangle286:setName("rectangle286");

    obj.detalhe_vinculo_1 = GUI.fromHandle(_obj_newObject("dataScopeBox"));
    obj.detalhe_vinculo_1:setParent(obj.rectangle286);
    obj.detalhe_vinculo_1:setName("detalhe_vinculo_1");
    obj.detalhe_vinculo_1:setAlign("client");
    obj.detalhe_vinculo_1:setVisible(false);

    obj.rectangle287 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle287:setParent(obj.detalhe_vinculo_1);
    obj.rectangle287:setHeight(30);
    obj.rectangle287:setColor("black");
    obj.rectangle287:setCornerType("round");
    obj.rectangle287.grid.role = "col";
    obj.rectangle287.grid.width = 10;
    obj.rectangle287:setStrokeSize(1);
    obj.rectangle287:setStrokeColor("white");
    obj.rectangle287:setXradius(5);
    obj.rectangle287:setYradius(5);
    obj.rectangle287:setMargins({top=5});
    obj.rectangle287:setName("rectangle287");

    obj.edit114 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit114:setParent(obj.rectangle287);
    obj.edit114:setField("nomeVinculo_1");
    obj.edit114:setAlign("client");
    obj.edit114:setTransparent(true);
    obj.edit114:setFontSize(22);
    obj.edit114:setVertTextAlign("center");
    obj.edit114:setHorzTextAlign("center");
    obj.edit114:setFontFamily("Wishes Script Caps Display");
    obj.edit114:setName("edit114");

    obj.btnNovaVinculo_2 = GUI.fromHandle(_obj_newObject("button"));
    obj.btnNovaVinculo_2:setParent(obj.detalhe_vinculo_1);
    obj.btnNovaVinculo_2:setName("btnNovaVinculo_2");
    obj.btnNovaVinculo_2:setText("+");
    obj.btnNovaVinculo_2:setHeight(30);
    obj.btnNovaVinculo_2.grid.role = "col";
    obj.btnNovaVinculo_2.grid.width = 2;
    obj.btnNovaVinculo_2:setMargins({right=0, top=5});


                        local filterVinculo_2Argument = "";
                        
                        local function prepFilterVinculo_2(inputStr)
                            return string.lower(Utils.removerAcentos(inputStr or ""));
                        end;
                        
                        local function runVinculo_2Filter()           
                            filterVinculo_2Argument = prepFilterVinculo_2(self.edtFiltroVinculo_2.text);
                            self.listavinculo_2:reorganize();
                        end;        
                        
                        local function checkVinculo_2Filter() 
                            local newArg = prepFilterVinculo_2(self.edtFiltroVinculo_2.text);
                            if newArg ~= filterVinculo_2Argument then
                                runVinculo_2Filter();
                            end;
                        end;
                    


    obj.tmrFiltroVinculo_2 = GUI.fromHandle(_obj_newObject("timer"));
    obj.tmrFiltroVinculo_2:setParent(obj.detalhe_vinculo_1);
    obj.tmrFiltroVinculo_2:setName("tmrFiltroVinculo_2");
    obj.tmrFiltroVinculo_2:setInterval(1000);

    obj.rectangle288 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle288:setParent(obj.detalhe_vinculo_1);
    obj.rectangle288:setHeight(20);
    obj.rectangle288:setColor("black");
    obj.rectangle288:setCornerType("round");
    obj.rectangle288.grid.role = "col";
    obj.rectangle288.grid.width = 8;
    obj.rectangle288:setStrokeSize(1);
    obj.rectangle288:setStrokeColor("white");
    obj.rectangle288:setXradius(5);
    obj.rectangle288:setYradius(5);
    obj.rectangle288:setMargins({top=5});
    obj.rectangle288:setName("rectangle288");

    obj.tagsVinculo_1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.tagsVinculo_1:setParent(obj.rectangle288);
    obj.tagsVinculo_1:setName("tagsVinculo_1");
    obj.tagsVinculo_1:setField("tagsVinculo_1");
    obj.tagsVinculo_1.grid.role = "col";
    obj.tagsVinculo_1.grid.width = 12;
    obj.tagsVinculo_1:setTransparent(true);
    obj.tagsVinculo_1:setFontSize(14);
    obj.tagsVinculo_1:setHeight(20);
    obj.tagsVinculo_1:setHorzTextAlign("center");
    obj.tagsVinculo_1:setFontFamily("Wishes Script Caps Display");

    obj.rectangle289 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle289:setParent(obj.detalhe_vinculo_1);
    obj.rectangle289:setHeight(20);
    obj.rectangle289:setColor("black");
    obj.rectangle289:setCornerType("round");
    obj.rectangle289.grid.role = "col";
    obj.rectangle289.grid.width = 4;
    obj.rectangle289:setStrokeSize(1);
    obj.rectangle289:setStrokeColor("white");
    obj.rectangle289:setXradius(5);
    obj.rectangle289:setYradius(5);
    obj.rectangle289:setMargins({top=3});
    obj.rectangle289:setName("rectangle289");

    obj.comboBox35 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox35:setParent(obj.rectangle289);
    obj.comboBox35.grid.role = "col";
    obj.comboBox35.grid.width = 12;
    obj.comboBox35:setHeight(25);
    obj.comboBox35:setField("corVinculo_1");
    obj.comboBox35:setItems({'AliceBlue', 'AntiqueWhite', 'Aqua', 'Aquamarine', 'Azure', 'Beige', 'Bisque', 'Black', 'BlanchedAlmond', 'Blue', 'BlueViolet', 'Brown', 'BurlyWood', 'CadetBlue', 'Chartreuse', 'Chocolate', 'Coral', 'CornflowerBlue', 'Cornsilk', 'Crimson', 'Cyan', 'DarkBlue', 'DarkCyan', 'DarkGoldenRod', 'DarkGray', 'DarkGreen', 'DarkKhaki', 'DarkMagenta', 'DarkOliveGreen', 'DarkOrange', 'DarkOrchid', 'DarkRed', 'DarkSalmon', 'DarkSeaGreen', 'DarkSlateBlue', 'DarkSlateGray', 'DarkTurquoise', 'DarkViolet', 'DeepPink', 'DeepSkyBlue', 'DimGray', 'DodgerBlue', 'FireBrick', 'FloralWhite', 'ForestGreen', 'Fuchsia', 'Gainsboro', 'GhostWhite', 'Gold', 'GoldenRod', 'Gray', 'Green', 'GreenYellow', 'HoneyDew', 'HotPink', 'IndianRed', 'Indigo', 'Ivory', 'Khaki', 'Lavender', 'LavenderBlush', 'LawnGreen', 'LemonChiffon', 'LightBlue', 'LightCoral', 'LightCyan', 'LightGoldenRodYellow', 'LightGray', 'LightGreen', 'LightPink', 'LightSalmon', 'LightSeaGreen', 'LightSkyBlue', 'LightSlateGray', 'LightSteelBlue', 'LightYellow', 'Lime', 'LimeGreen', 'Linen', 'Magenta', 'Maroon', 'MediumAquaMarine', 'MediumBlue', 'MediumOrchid', 'MediumPurple', 'MediumSeaGreen', 'MediumSlateBlue', 'MediumSpringGreen', 'MediumTurquoise', 'MediumVioletRed', 'MidnightBlue', 'MintCream', 'MistyRose', 'Moccasin', 'NavajoWhite', 'Navy', 'OldLace', 'Olive', 'OliveDrab', 'Orange', 'OrangeRed', 'Orchid', 'PaleGoldenRod', 'PaleGreen', 'PaleTurquoise', 'PaleVioletRed', 'PapayaWhip', 'PeachPuff', 'Peru', 'Pink', 'Plum', 'PowderBlue', 'Purple', 'RebeccaPurple', 'Red', 'RosyBrown', 'RoyalBlue', 'SaddleBrown', 'Salmon', 'SandyBrown', 'SeaGreen', 'SeaShell', 'Sienna', 'Silver', 'SkyBlue', 'SlateBlue', 'SlateGray', 'Snow', 'SpringGreen', 'SteelBlue', 'Tan', 'Teal', 'Thistle', 'Tomato', 'Turquoise', 'Violet', 'Wheat', 'White', 'WhiteSmoke', 'Yellow', 'YellowGreen'});
    obj.comboBox35:setValues({'#F0F8FF', '#FAEBD7', '#00FFFF', '#7FFFD4', '#F0FFFF', '#F5F5DC', '#FFE4C4', '#000000', '#FFEBCD', '#0000FF', '#8A2BE2', '#A52A2A', '#DEB887', '#5F9EA0', '#7FFF00', '#D2691E', '#FF7F50', '#6495ED', '#FFF8DC', '#DC143C', '#00FFFF', '#00008B', '#008B8B', '#B8860B', '#A9A9A9', '#006400', '#BDB76B', '#8B008B', '#556B2F', '#FF8C00', '#9932CC', '#8B0000', '#E9967A', '#8FBC8F', '#483D8B', '#2F4F4F', '#00CED1', '#9400D3', '#FF1493', '#00BFFF', '#696969', '#1E90FF', '#B22222', '#FFFAF0', '#228B22', '#FF00FF', '#DCDCDC', '#F8F8FF', '#FFD700', '#DAA520', '#808080', '#008000', '#ADFF2F', '#F0FFF0', '#FF69B4', '#CD5C5C', '#4B0082', '#FFFFF0', '#F0E68C', '#E6E6FA', '#FFF0F5', '#7CFC00', '#FFFACD', '#ADD8E6', '#F08080', '#E0FFFF', '#FAFAD2', '#D3D3D3', '#90EE90', '#FFB6C1', '#FFA07A', '#20B2AA', '#87CEFA', '#778899', '#B0C4DE', '#FFFFE0', '#00FF00', '#32CD32', '#FAF0E6', '#FF00FF', '#800000', '#66CDAA', '#0000CD', '#BA55D3', '#9370DB', '#3CB371', '#7B68EE', '#00FA9A', '#48D1CC', '#C71585', '#191970', '#F5FFFA', '#FFE4E1', '#FFE4B5', '#FFDEAD', '#000080', '#FDF5E6', '#808000', '#6B8E23', '#FFA500', '#FF4500', '#DA70D6', '#EEE8AA', '#98FB98', '#AFEEEE', '#DB7093', '#FFEFD5', '#FFDAB9', '#CD853F', '#FFC0CB', '#DDA0DD', '#B0E0E6', '#800080', '#663399', '#FF0000', '#BC8F8F', '#4169E1', '#8B4513', '#FA8072', '#F4A460', '#2E8B57', '#FFF5EE', '#A0522D', '#C0C0C0', '#87CEEB', '#6A5ACD', '#708090', '#FFFAFA', '#00FF7F', '#4682B4', '#D2B48C', '#008080', '#D8BFD8', '#FF6347', '#40E0D0', '#EE82EE', '#F5DEB3', '#FFFFFF', '#F5F5F5', '#FFFF00', '#9ACD32'});
    obj.comboBox35:setName("comboBox35");

    obj.edtFiltroVinculo_2 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtFiltroVinculo_2:setParent(obj.detalhe_vinculo_1);
    obj.edtFiltroVinculo_2.grid.role = "row";
    obj.edtFiltroVinculo_2.grid["min-height"] = 25;
    obj.edtFiltroVinculo_2:setTextPrompt("Buscar Item...");
    obj.edtFiltroVinculo_2:setName("edtFiltroVinculo_2");
    obj.edtFiltroVinculo_2:setMargins({top=5,right=5,left=5});
    obj.edtFiltroVinculo_2:setHint("Buscar Item ou Tag...");

    obj.dataLink80 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink80:setParent(obj.detalhe_vinculo_1);
    obj.dataLink80:setField("tagsVinculo_1");
    obj.dataLink80:setDefaultValue("Tags");
    obj.dataLink80:setName("dataLink80");

    obj.scrollBox16 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox16:setParent(obj.detalhe_vinculo_1);
    obj.scrollBox16.grid.role = "row";
    obj.scrollBox16.grid["vert-tile"] = true;
    obj.scrollBox16:setMargins({top=5,right=2,left=2,bottom=2});
    obj.scrollBox16.grid["cnt-gutter"] = 1;
    obj.scrollBox16:setName("scrollBox16");

    obj.listavinculo_2 = GUI.fromHandle(_obj_newObject("gridRecordList"));
    obj.listavinculo_2:setParent(obj.scrollBox16);
    obj.listavinculo_2:setName("listavinculo_2");
    obj.listavinculo_2.field = "itensVinculo_2";
    obj.listavinculo_2.templateForm = "templateVinculo_2";
    obj.listavinculo_2.minQt = 0;
    obj.listavinculo_2.selectable = true;
    obj.listavinculo_2:setHeight(600);
    obj.listavinculo_2.grid.role = "col";
    obj.listavinculo_2.grid.width = 12;


                            -- Função de reordenação específica para a nova lista
                            local function reordenarVinculo_2()
                                local nodes = NDB.getChildNodes(sheet.itensVinculo_2)
                                table.sort(nodes, function(a, b)
                                    return (tonumber(a.ordemVinculo_2) or 0) < (tonumber(b.ordemVinculo_2) or 0)
                                end)
                                self.listavinculo_2:reorganize()
                            end

                            -- Configuração do botão de adicionar
                            self.btnNovaVinculo_2.onClick = function()
                                local novo = self.listavinculo_2:append()
                                if novo then
                                    novo.nomeVinculo_2 = "Novo Item"
                                    novo.ordemVinculo_2 = #NDB.getChildNodes(sheet.itensVinculo_2) + 1
                                    reordenarVinculo_2()
                                end
                            end
                            -- Lógica de seleção: agora aponta para o dataScopeBox 'detalheSkill'
                            self.listavinculo_2.onSelect = function()
                                local node = self.listavinculo_2.selectedNode;
                                self.detalhe_vinculo_2:setNodeObject(node);
                                self.detalhe_vinculo_2.visible = (node ~= nil);

                                self.abertoPeloSlot = false;

                            
                            end;
                        


    obj.rectangle290 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle290:setParent(obj.scrollBox14);
    obj.rectangle290:setColor("#150e16");
    obj.rectangle290:setStrokeSize(2);
    obj.rectangle290:setStrokeColor("white");
    obj.rectangle290.grid.role = "col";
    obj.rectangle290.grid.width = 6;
    obj.rectangle290.grid["max-width"] = 1920;
    obj.rectangle290.grid["min-width"] = 300;
    obj.rectangle290.grid["min-height"] = 550;
    obj.rectangle290.grid["max-height"] = 1080;
    obj.rectangle290:setMargins({top=15});
    obj.rectangle290:setName("rectangle290");

    obj.detalhe_vinculo_2 = GUI.fromHandle(_obj_newObject("dataScopeBox"));
    obj.detalhe_vinculo_2:setParent(obj.rectangle290);
    obj.detalhe_vinculo_2:setName("detalhe_vinculo_2");
    obj.detalhe_vinculo_2:setAlign("client");
    obj.detalhe_vinculo_2:setVisible(false);

    obj.label279 = GUI.fromHandle(_obj_newObject("label"));
    obj.label279:setParent(obj.detalhe_vinculo_2);
    obj.label279:setHeight(20);
    obj.label279:setText("Nome:");
    obj.label279:setFontSize(15);
    obj.label279.grid.role = "col";
    obj.label279.grid.width = 1;
    obj.label279:setFontFamily("Wishes Script Caps Display");
    obj.label279:setHorzTextAlign("trailing");
    obj.label279:setMargins({top=10});
    obj.label279:setName("label279");

    obj.rectangle291 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle291:setParent(obj.detalhe_vinculo_2);
    obj.rectangle291:setHeight(30);
    obj.rectangle291:setColor("black");
    obj.rectangle291:setCornerType("round");
    obj.rectangle291.grid.role = "col";
    obj.rectangle291.grid.width = 8;
    obj.rectangle291:setStrokeSize(1);
    obj.rectangle291:setStrokeColor("white");
    obj.rectangle291:setXradius(5);
    obj.rectangle291:setYradius(5);
    obj.rectangle291:setMargins({top=5});
    obj.rectangle291:setName("rectangle291");

    obj.edit115 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit115:setParent(obj.rectangle291);
    obj.edit115:setField("nomeVinculo_2");
    obj.edit115:setAlign("client");
    obj.edit115:setTransparent(true);
    obj.edit115:setFontSize(22);
    obj.edit115:setVertTextAlign("center");
    obj.edit115:setHorzTextAlign("center");
    obj.edit115:setFontFamily("Wishes Script Caps Display");
    obj.edit115:setName("edit115");

    obj.rectangle292 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle292:setParent(obj.detalhe_vinculo_2);
    obj.rectangle292:setHeight(20);
    obj.rectangle292:setColor("black");
    obj.rectangle292:setCornerType("round");
    obj.rectangle292.grid.role = "col";
    obj.rectangle292.grid.width = 3;
    obj.rectangle292:setStrokeSize(1);
    obj.rectangle292:setStrokeColor("white");
    obj.rectangle292:setXradius(5);
    obj.rectangle292:setYradius(5);
    obj.rectangle292:setMargins({top=8});
    obj.rectangle292:setName("rectangle292");

    obj.comboBox36 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox36:setParent(obj.rectangle292);
    obj.comboBox36.grid.role = "col";
    obj.comboBox36.grid.width = 12;
    obj.comboBox36:setHeight(25);
    obj.comboBox36:setField("corVinculo_2");
    obj.comboBox36:setItems({'AliceBlue', 'AntiqueWhite', 'Aqua', 'Aquamarine', 'Azure', 'Beige', 'Bisque', 'Black', 'BlanchedAlmond', 'Blue', 'BlueViolet', 'Brown', 'BurlyWood', 'CadetBlue', 'Chartreuse', 'Chocolate', 'Coral', 'CornflowerBlue', 'Cornsilk', 'Crimson', 'Cyan', 'DarkBlue', 'DarkCyan', 'DarkGoldenRod', 'DarkGray', 'DarkGreen', 'DarkKhaki', 'DarkMagenta', 'DarkOliveGreen', 'DarkOrange', 'DarkOrchid', 'DarkRed', 'DarkSalmon', 'DarkSeaGreen', 'DarkSlateBlue', 'DarkSlateGray', 'DarkTurquoise', 'DarkViolet', 'DeepPink', 'DeepSkyBlue', 'DimGray', 'DodgerBlue', 'FireBrick', 'FloralWhite', 'ForestGreen', 'Fuchsia', 'Gainsboro', 'GhostWhite', 'Gold', 'GoldenRod', 'Gray', 'Green', 'GreenYellow', 'HoneyDew', 'HotPink', 'IndianRed', 'Indigo', 'Ivory', 'Khaki', 'Lavender', 'LavenderBlush', 'LawnGreen', 'LemonChiffon', 'LightBlue', 'LightCoral', 'LightCyan', 'LightGoldenRodYellow', 'LightGray', 'LightGreen', 'LightPink', 'LightSalmon', 'LightSeaGreen', 'LightSkyBlue', 'LightSlateGray', 'LightSteelBlue', 'LightYellow', 'Lime', 'LimeGreen', 'Linen', 'Magenta', 'Maroon', 'MediumAquaMarine', 'MediumBlue', 'MediumOrchid', 'MediumPurple', 'MediumSeaGreen', 'MediumSlateBlue', 'MediumSpringGreen', 'MediumTurquoise', 'MediumVioletRed', 'MidnightBlue', 'MintCream', 'MistyRose', 'Moccasin', 'NavajoWhite', 'Navy', 'OldLace', 'Olive', 'OliveDrab', 'Orange', 'OrangeRed', 'Orchid', 'PaleGoldenRod', 'PaleGreen', 'PaleTurquoise', 'PaleVioletRed', 'PapayaWhip', 'PeachPuff', 'Peru', 'Pink', 'Plum', 'PowderBlue', 'Purple', 'RebeccaPurple', 'Red', 'RosyBrown', 'RoyalBlue', 'SaddleBrown', 'Salmon', 'SandyBrown', 'SeaGreen', 'SeaShell', 'Sienna', 'Silver', 'SkyBlue', 'SlateBlue', 'SlateGray', 'Snow', 'SpringGreen', 'SteelBlue', 'Tan', 'Teal', 'Thistle', 'Tomato', 'Turquoise', 'Violet', 'Wheat', 'White', 'WhiteSmoke', 'Yellow', 'YellowGreen'});
    obj.comboBox36:setValues({'#F0F8FF', '#FAEBD7', '#00FFFF', '#7FFFD4', '#F0FFFF', '#F5F5DC', '#FFE4C4', '#000000', '#FFEBCD', '#0000FF', '#8A2BE2', '#A52A2A', '#DEB887', '#5F9EA0', '#7FFF00', '#D2691E', '#FF7F50', '#6495ED', '#FFF8DC', '#DC143C', '#00FFFF', '#00008B', '#008B8B', '#B8860B', '#A9A9A9', '#006400', '#BDB76B', '#8B008B', '#556B2F', '#FF8C00', '#9932CC', '#8B0000', '#E9967A', '#8FBC8F', '#483D8B', '#2F4F4F', '#00CED1', '#9400D3', '#FF1493', '#00BFFF', '#696969', '#1E90FF', '#B22222', '#FFFAF0', '#228B22', '#FF00FF', '#DCDCDC', '#F8F8FF', '#FFD700', '#DAA520', '#808080', '#008000', '#ADFF2F', '#F0FFF0', '#FF69B4', '#CD5C5C', '#4B0082', '#FFFFF0', '#F0E68C', '#E6E6FA', '#FFF0F5', '#7CFC00', '#FFFACD', '#ADD8E6', '#F08080', '#E0FFFF', '#FAFAD2', '#D3D3D3', '#90EE90', '#FFB6C1', '#FFA07A', '#20B2AA', '#87CEFA', '#778899', '#B0C4DE', '#FFFFE0', '#00FF00', '#32CD32', '#FAF0E6', '#FF00FF', '#800000', '#66CDAA', '#0000CD', '#BA55D3', '#9370DB', '#3CB371', '#7B68EE', '#00FA9A', '#48D1CC', '#C71585', '#191970', '#F5FFFA', '#FFE4E1', '#FFE4B5', '#FFDEAD', '#000080', '#FDF5E6', '#808000', '#6B8E23', '#FFA500', '#FF4500', '#DA70D6', '#EEE8AA', '#98FB98', '#AFEEEE', '#DB7093', '#FFEFD5', '#FFDAB9', '#CD853F', '#FFC0CB', '#DDA0DD', '#B0E0E6', '#800080', '#663399', '#FF0000', '#BC8F8F', '#4169E1', '#8B4513', '#FA8072', '#F4A460', '#2E8B57', '#FFF5EE', '#A0522D', '#C0C0C0', '#87CEEB', '#6A5ACD', '#708090', '#FFFAFA', '#00FF7F', '#4682B4', '#D2B48C', '#008080', '#D8BFD8', '#FF6347', '#40E0D0', '#EE82EE', '#F5DEB3', '#FFFFFF', '#F5F5F5', '#FFFF00', '#9ACD32'});
    obj.comboBox36:setName("comboBox36");

    obj.rectangle293 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle293:setParent(obj.detalhe_vinculo_2);
    obj.rectangle293:setHeight(20);
    obj.rectangle293:setColor("black");
    obj.rectangle293:setCornerType("round");
    obj.rectangle293.grid.role = "col";
    obj.rectangle293.grid.width = 12;
    obj.rectangle293:setStrokeSize(1);
    obj.rectangle293:setStrokeColor("white");
    obj.rectangle293:setXradius(5);
    obj.rectangle293:setYradius(5);
    obj.rectangle293:setMargins({top=5});
    obj.rectangle293:setName("rectangle293");

    obj.tagsVinculo_2 = GUI.fromHandle(_obj_newObject("edit"));
    obj.tagsVinculo_2:setParent(obj.rectangle293);
    obj.tagsVinculo_2:setName("tagsVinculo_2");
    obj.tagsVinculo_2:setField("tagsVinculo_2");
    obj.tagsVinculo_2.grid.role = "col";
    obj.tagsVinculo_2.grid.width = 12;
    obj.tagsVinculo_2:setTransparent(true);
    obj.tagsVinculo_2:setFontSize(14);
    obj.tagsVinculo_2:setHeight(20);
    obj.tagsVinculo_2:setHorzTextAlign("center");
    obj.tagsVinculo_2:setFontFamily("Wishes Script Caps Display");

    obj.dataLink81 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink81:setParent(obj.detalhe_vinculo_2);
    obj.dataLink81:setField("tagsVinculo_2");
    obj.dataLink81:setDefaultValue("Tags");
    obj.dataLink81:setName("dataLink81");

    obj.richEdit6 = GUI.fromHandle(_obj_newObject("richEdit"));
    obj.richEdit6:setParent(obj.detalhe_vinculo_2);
    obj.richEdit6:setField("descricaoLongaSkill");
    obj.richEdit6:setAlign("client");
    obj.richEdit6.backgroundColor = "#000000";
    obj.richEdit6.defaultFontColor = "white";
    obj.richEdit6.hideSelection = true;
    obj.richEdit6.defaultFontSize = 14;
    obj.richEdit6.animateImages = true;
    obj.richEdit6:setMargins({top=65,right=4,left=4,bottom=4});
    obj.richEdit6:setName("richEdit6");

    obj.texto = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.texto:setParent(obj.scrollBox1);
    obj.texto:setAlign("client");
    obj.texto:setName("texto");
    obj.texto:setColor("black");
    obj.texto:setVisible(false);
    obj.texto.grid["cnt-gutter"] = 10;

    obj.scrollBox17 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox17:setParent(obj.texto);
    obj.scrollBox17:setAlign("client");
    obj.scrollBox17:setMargins({left=5,right=5});
    obj.scrollBox17:setName("scrollBox17");

    obj.rectangle294 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle294:setParent(obj.scrollBox17);
    obj.rectangle294:setColor("#150e16");
    obj.rectangle294:setStrokeSize(2);
    obj.rectangle294:setStrokeColor("white");
    obj.rectangle294.grid.role = "col";
    obj.rectangle294.grid.width = 4;
    obj.rectangle294.grid["max-width"] = 1080;
    obj.rectangle294.grid["min-width"] = 400;
    obj.rectangle294.grid["min-height"] = 550;
    obj.rectangle294.grid["max-height"] = 1080;
    obj.rectangle294:setMargins({top=15});
    obj.rectangle294:setName("rectangle294");

    obj.btnNovoTexto = GUI.fromHandle(_obj_newObject("button"));
    obj.btnNovoTexto:setParent(obj.rectangle294);
    obj.btnNovoTexto:setName("btnNovoTexto");
    obj.btnNovoTexto:setText("Adicionar Texto");
    obj.btnNovoTexto:setHeight(30);
    obj.btnNovoTexto.grid.role = "col";
    obj.btnNovoTexto.grid.width = 12;
    obj.btnNovoTexto:setMargins({top=5,right=5,left=5});


                    local currentFilterTextos = "";
                    
                    local function prepareStrForFilterTextos(inputStr)
                        return string.lower(Utils.removerAcentos(inputStr or ""));
                    end;
                    
                    local function executeFilterTextos()
                        currentFilterTextos = prepareStrForFilterTextos(self.edtFiltroTextos.text);
                        self.listatextos:reorganize();
                    end;
                    
                    local function checkNeedExecuteFilterTextos()
                        local newFilterArgument = prepareStrForFilterTextos(self.edtFiltroTextos.text);
                        
                        if newFilterArgument ~= currentFilterTextos then
                            executeFilterTextos();
                        end;
                    end;
                


    obj.tmrFiltroTextos = GUI.fromHandle(_obj_newObject("timer"));
    obj.tmrFiltroTextos:setParent(obj.rectangle294);
    obj.tmrFiltroTextos:setName("tmrFiltroTextos");
    obj.tmrFiltroTextos:setInterval(1000);

    obj.edtFiltroTextos = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtFiltroTextos:setParent(obj.rectangle294);
    obj.edtFiltroTextos.grid.role = "row";
    obj.edtFiltroTextos.grid["min-height"] = 25;
    obj.edtFiltroTextos:setTextPrompt("Filtrar textos...");
    obj.edtFiltroTextos:setName("edtFiltroTextos");
    obj.edtFiltroTextos:setMargins({top=5,right=5,left=5});

    obj.scrollBox18 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox18:setParent(obj.rectangle294);
    obj.scrollBox18.grid.role = "row";
    obj.scrollBox18.grid["vert-tile"] = true;
    obj.scrollBox18:setMargins({top=5,right=2,left=2,bottom=2});
    obj.scrollBox18.grid["cnt-gutter"] = 1;
    obj.scrollBox18:setName("scrollBox18");

    obj.listatextos = GUI.fromHandle(_obj_newObject("gridRecordList"));
    obj.listatextos:setParent(obj.scrollBox18);
    obj.listatextos:setName("listatextos");
    obj.listatextos.field = "textos";
    obj.listatextos.templateForm = "templateTextos";
    obj.listatextos.minQt = 0;
    obj.listatextos.selectable = true;
    obj.listatextos:setHeight(550);
    obj.listatextos.grid.role = "col";
    obj.listatextos.grid.width = 12;


                        local function reordenarListaTextos()
                            local nodes = NDB.getChildNodes(sheet.textos)
                            table.sort(nodes, function(a, b)
                                return (tonumber(a.ordem) or 0) < (tonumber(b.ordem) or 0)
                            end)
                            self.listatextos:reorganize()
                        end

                        self.btnNovoTexto.onClick = function()
                            local novo = self.listatextos:append()
                            if novo then
                                novo.nome = "Novo Texto"
                                novo.Texto = "#150e16"
                                novo.ordem = #NDB.getChildNodes(sheet.textos) + 1
                                reordenarListaTextos()
                            end
                        end

                        self.listatextos.onSelect = function()
                            local node = self.listatextos.selectedNode
                            self.textodetalhes.node = node
                            self.textodetalhes.visible = (node ~= nil)
                        end
                    


    obj.rectangle295 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle295:setParent(obj.scrollBox17);
    obj.rectangle295:setColor("#150e16");
    obj.rectangle295:setStrokeSize(2);
    obj.rectangle295:setStrokeColor("white");
    obj.rectangle295.grid.role = "col";
    obj.rectangle295.grid.width = 8;
    obj.rectangle295.grid["max-width"] = 1920;
    obj.rectangle295.grid["min-width"] = 400;
    obj.rectangle295.grid["min-height"] = 550;
    obj.rectangle295.grid["max-height"] = 1080;
    obj.rectangle295:setMargins({top=15});
    obj.rectangle295:setName("rectangle295");

    obj.textodetalhes = GUI.fromHandle(_obj_newObject("dataScopeBox"));
    obj.textodetalhes:setParent(obj.rectangle295);
    obj.textodetalhes:setName("textodetalhes");
    obj.textodetalhes:setAlign("client");
    obj.textodetalhes:setVisible(false);

    obj.rectangle296 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle296:setParent(obj.textodetalhes);
    obj.rectangle296:setHeight(20);
    obj.rectangle296:setColor("black");
    obj.rectangle296:setCornerType("round");
    obj.rectangle296.grid.role = "col";
    obj.rectangle296.grid.width = 10;
    obj.rectangle296:setStrokeSize(1);
    obj.rectangle296:setStrokeColor("white");
    obj.rectangle296:setXradius(5);
    obj.rectangle296:setYradius(5);
    obj.rectangle296:setMargins({top=5,left=5});
    obj.rectangle296:setName("rectangle296");

    obj.nometexto = GUI.fromHandle(_obj_newObject("edit"));
    obj.nometexto:setParent(obj.rectangle296);
    obj.nometexto:setName("nometexto");
    obj.nometexto:setField("nome");
    obj.nometexto.grid.role = "col";
    obj.nometexto.grid.width = 12;
    obj.nometexto:setTransparent(true);
    obj.nometexto:setFontSize(14);
    obj.nometexto:setHeight(20);
    obj.nometexto:setHorzTextAlign("center");
    obj.nometexto:setFontFamily("Wishes Script Caps Display");

    obj.label280 = GUI.fromHandle(_obj_newObject("label"));
    obj.label280:setParent(obj.textodetalhes);
    obj.label280:setHeight(20);
    obj.label280:setText("Cor:");
    obj.label280:setFontSize(13);
    obj.label280.grid.role = "col";
    obj.label280.grid.width = 2;
    obj.label280:setFontFamily("Wishes Script Caps Display");
    obj.label280:setHorzTextAlign("trailing");
    obj.label280:setMargins({top=5,right=5});
    obj.label280:setName("label280");

    obj.comboBox37 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox37:setParent(obj.textodetalhes);
    obj.comboBox37:setField("Texto");
    obj.comboBox37.grid.role = "col";
    obj.comboBox37.grid.width = 12;
    obj.comboBox37:setHeight(25);
    obj.comboBox37:setMargins({top=5,right=5,left=5});
    obj.comboBox37:setItems({'AliceBlue', 'AntiqueWhite', 'Aqua', 'Aquamarine', 'Azure', 'Beige', 'Bisque', 'Black', 'BlanchedAlmond', 'Blue', 'BlueViolet', 'Brown', 'BurlyWood', 'CadetBlue', 'Chartreuse', 'Chocolate', 'Coral', 'CornflowerBlue', 'Cornsilk', 'Crimson', 'Cyan', 'DarkBlue', 'DarkCyan', 'DarkGoldenRod', 'DarkGray', 'DarkGreen', 'DarkKhaki', 'DarkMagenta', 'DarkOliveGreen', 'DarkOrange', 'DarkOrchid', 'DarkRed', 'DarkSalmon', 'DarkSeaGreen', 'DarkSlateBlue', 'DarkSlateGray', 'DarkTurquoise', 'DarkViolet', 'DeepPink', 'DeepSkyBlue', 'DimGray', 'DodgerBlue', 'FireBrick', 'FloralWhite', 'ForestGreen', 'Fuchsia', 'Gainsboro', 'GhostWhite', 'Gold', 'GoldenRod', 'Gray', 'Green', 'GreenYellow', 'HoneyDew', 'HotPink', 'IndianRed', 'Indigo', 'Ivory', 'Khaki', 'Lavender', 'LavenderBlush', 'LawnGreen', 'LemonChiffon', 'LightBlue', 'LightCoral', 'LightCyan', 'LightGoldenRodYellow', 'LightGray', 'LightGreen', 'LightPink', 'LightSalmon', 'LightSeaGreen', 'LightSkyBlue', 'LightSlateGray', 'LightSteelBlue', 'LightYellow', 'Lime', 'LimeGreen', 'Linen', 'Magenta', 'Maroon', 'MediumAquaMarine', 'MediumBlue', 'MediumOrchid', 'MediumPurple', 'MediumSeaGreen', 'MediumSlateBlue', 'MediumSpringGreen', 'MediumTurquoise', 'MediumVioletRed', 'MidnightBlue', 'MintCream', 'MistyRose', 'Moccasin', 'NavajoWhite', 'Navy', 'OldLace', 'Olive', 'OliveDrab', 'Orange', 'OrangeRed', 'Orchid', 'PaleGoldenRod', 'PaleGreen', 'PaleTurquoise', 'PaleVioletRed', 'PapayaWhip', 'PeachPuff', 'Peru', 'Pink', 'Plum', 'PowderBlue', 'Purple', 'RebeccaPurple', 'Red', 'RosyBrown', 'RoyalBlue', 'SaddleBrown', 'Salmon', 'SandyBrown', 'SeaGreen', 'SeaShell', 'Sienna', 'Silver', 'SkyBlue', 'SlateBlue', 'SlateGray', 'Snow', 'SpringGreen', 'SteelBlue', 'Tan', 'Teal', 'Thistle', 'Tomato', 'Turquoise', 'Violet', 'Wheat', 'White', 'WhiteSmoke', 'Yellow', 'YellowGreen'});
    obj.comboBox37:setValues({'#F0F8FF', '#FAEBD7', '#00FFFF', '#7FFFD4', '#F0FFFF', '#F5F5DC', '#FFE4C4', '#000000', '#FFEBCD', '#0000FF', '#8A2BE2', '#A52A2A', '#DEB887', '#5F9EA0', '#7FFF00', '#D2691E', '#FF7F50', '#6495ED', '#FFF8DC', '#DC143C', '#00FFFF', '#00008B', '#008B8B', '#B8860B', '#A9A9A9', '#006400', '#BDB76B', '#8B008B', '#556B2F', '#FF8C00', '#9932CC', '#8B0000', '#E9967A', '#8FBC8F', '#483D8B', '#2F4F4F', '#00CED1', '#9400D3', '#FF1493', '#00BFFF', '#696969', '#1E90FF', '#B22222', '#FFFAF0', '#228B22', '#FF00FF', '#DCDCDC', '#F8F8FF', '#FFD700', '#DAA520', '#808080', '#008000', '#ADFF2F', '#F0FFF0', '#FF69B4', '#CD5C5C', '#4B0082', '#FFFFF0', '#F0E68C', '#E6E6FA', '#FFF0F5', '#7CFC00', '#FFFACD', '#ADD8E6', '#F08080', '#E0FFFF', '#FAFAD2', '#D3D3D3', '#90EE90', '#FFB6C1', '#FFA07A', '#20B2AA', '#87CEFA', '#778899', '#B0C4DE', '#FFFFE0', '#00FF00', '#32CD32', '#FAF0E6', '#FF00FF', '#800000', '#66CDAA', '#0000CD', '#BA55D3', '#9370DB', '#3CB371', '#7B68EE', '#00FA9A', '#48D1CC', '#C71585', '#191970', '#F5FFFA', '#FFE4E1', '#FFE4B5', '#FFDEAD', '#000080', '#FDF5E6', '#808000', '#6B8E23', '#FFA500', '#FF4500', '#DA70D6', '#EEE8AA', '#98FB98', '#AFEEEE', '#DB7093', '#FFEFD5', '#FFDAB9', '#CD853F', '#FFC0CB', '#DDA0DD', '#B0E0E6', '#800080', '#663399', '#FF0000', '#BC8F8F', '#4169E1', '#8B4513', '#FA8072', '#F4A460', '#2E8B57', '#FFF5EE', '#A0522D', '#C0C0C0', '#87CEEB', '#6A5ACD', '#708090', '#FFFAFA', '#00FF7F', '#4682B4', '#D2B48C', '#008080', '#D8BFD8', '#FF6347', '#40E0D0', '#EE82EE', '#F5DEB3', '#FFFFFF', '#F5F5F5', '#FFFF00', '#9ACD32'});
    obj.comboBox37:setName("comboBox37");

    obj.richEdit7 = GUI.fromHandle(_obj_newObject("richEdit"));
    obj.richEdit7:setParent(obj.textodetalhes);
    obj.richEdit7:setField("texto_livre");
    obj.richEdit7:setAlign("client");
    obj.richEdit7.backgroundColor = "#000000";
    obj.richEdit7.defaultFontColor = "white";
    obj.richEdit7.hideSelection = true;
    obj.richEdit7.defaultFontSize = 14;
    obj.richEdit7.animateImages = true;
    obj.richEdit7:setMargins({top=5,right=4,left=4,bottom=4});
    obj.richEdit7:setName("richEdit7");

    obj.inventario = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.inventario:setParent(obj.scrollBox1);
    obj.inventario:setAlign("client");
    obj.inventario:setName("inventario");
    obj.inventario:setColor("black");
    obj.inventario:setVisible(false);
    obj.inventario.grid["cnt-gutter"] = 10;

    obj.scrollBox19 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox19:setParent(obj.inventario);
    obj.scrollBox19:setAlign("client");
    obj.scrollBox19:setMargins({left=5,right=5});
    obj.scrollBox19:setName("scrollBox19");

    obj.rectangle297 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle297:setParent(obj.scrollBox19);
    obj.rectangle297:setColor("#150e16");
    obj.rectangle297:setStrokeSize(2);
    obj.rectangle297:setStrokeColor("white");
    obj.rectangle297.grid.role = "col";
    obj.rectangle297.grid.width = 4;
    obj.rectangle297.grid["max-width"] = 1080;
    obj.rectangle297.grid["min-width"] = 400;
    obj.rectangle297.grid["min-height"] = 550;
    obj.rectangle297.grid["max-height"] = 1080;
    obj.rectangle297:setMargins({top=15});
    obj.rectangle297:setName("rectangle297");

    obj.bntNovacategoria = GUI.fromHandle(_obj_newObject("button"));
    obj.bntNovacategoria:setParent(obj.rectangle297);
    obj.bntNovacategoria:setName("bntNovacategoria");
    obj.bntNovacategoria:setText("Adicionar Item");
    obj.bntNovacategoria:setHeight(30);
    obj.bntNovacategoria.grid.role = "col";
    obj.bntNovacategoria.grid.width = 12;
    obj.bntNovacategoria:setMargins({top=5,right=5,left=5});


                    local currentFilterArgument = "";
                    
                    local function prepareStrForFilter(inputStr)
                        return string.lower(Utils.removerAcentos(inputStr or ""));
                    end;
                    
                    local function executeFilterNow()			
                        currentFilterArgument = prepareStrForFilter(self.edtFiltroCategorias.text);
                        self.listacategoria:reorganize();
                    end;		
                    
                    local function checkNeedExecuteFilter()	
                        local newFilterArgument = prepareStrForFilter(self.edtFiltroCategorias.text);
                        
                        if newFilterArgument ~= currentFilterArgument then
                            executeFilterNow();
                        end;
                    end;
                


    obj.tmrFiltroCategorias = GUI.fromHandle(_obj_newObject("timer"));
    obj.tmrFiltroCategorias:setParent(obj.rectangle297);
    obj.tmrFiltroCategorias:setName("tmrFiltroCategorias");
    obj.tmrFiltroCategorias:setInterval(1000);

    obj.edtFiltroCategorias = GUI.fromHandle(_obj_newObject("edit"));
    obj.edtFiltroCategorias:setParent(obj.rectangle297);
    obj.edtFiltroCategorias.grid.role = "row";
    obj.edtFiltroCategorias.grid["min-height"] = 25;
    obj.edtFiltroCategorias:setTextPrompt("Filtrar itens...");
    obj.edtFiltroCategorias:setName("edtFiltroCategorias");
    obj.edtFiltroCategorias:setMargins({top=5,right=5,left=5});

    obj.scrollBox20 = GUI.fromHandle(_obj_newObject("scrollBox"));
    obj.scrollBox20:setParent(obj.rectangle297);
    obj.scrollBox20.grid.role = "row";
    obj.scrollBox20.grid["vert-tile"] = true;
    obj.scrollBox20:setMargins({top=5,right=2,left=2,bottom=2});
    obj.scrollBox20.grid["cnt-gutter"] = 1;
    obj.scrollBox20:setName("scrollBox20");

    obj.listacategoria = GUI.fromHandle(_obj_newObject("gridRecordList"));
    obj.listacategoria:setParent(obj.scrollBox20);
    obj.listacategoria:setName("listacategoria");
    obj.listacategoria.field = "categorias";
    obj.listacategoria.templateForm = "templateCategoria";
    obj.listacategoria.minQt = 0;
    obj.listacategoria.selectable = true;
    obj.listacategoria:setHeight(550);
    obj.listacategoria.grid.role = "col";
    obj.listacategoria.grid.width = 12;


                        local function reordenarLista()
                        local nodes = NDB.getChildNodes(sheet.categorias)
                        table.sort(nodes, function(a, b)
                            return (tonumber(a.ordem) or 0) < (tonumber(b.ordem) or 0)
                        end)
                            self.listacategoria:reorganize()
                        end

                        -- Botão de adicionar item
                        self.bntNovacategoria.onClick = function()
                        local novo = self.listacategoria:append()
                        if novo then
                            novo.nome = "Novo Item"
                            novo.quantidade = "1x"
                            novo.rank = "F-"
                            novo.descricao = "tags"
                            novo.ordem = #NDB.getChildNodes(sheet.categorias) + 1
                            reordenarLista()
                        end
                        end

                        -- Quando um item é selecionado, mostra os dados no dataScopeBox
                        self.listacategoria.onSelect = function()
                        local node = self.listacategoria.selectedNode
                        self.textoinventario.node = node
                        self.textoinventario.visible = (node ~= nil)
                        end
                    


    obj.rectangle298 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle298:setParent(obj.scrollBox19);
    obj.rectangle298:setColor("#150e16");
    obj.rectangle298:setStrokeSize(2);
    obj.rectangle298:setStrokeColor("white");
    obj.rectangle298.grid.role = "col";
    obj.rectangle298.grid.width = 8;
    obj.rectangle298.grid["max-width"] = 1920;
    obj.rectangle298.grid["min-width"] = 400;
    obj.rectangle298.grid["min-height"] = 550;
    obj.rectangle298.grid["max-height"] = 1080;
    obj.rectangle298:setMargins({top=15});
    obj.rectangle298:setName("rectangle298");

    obj.textoinventario = GUI.fromHandle(_obj_newObject("dataScopeBox"));
    obj.textoinventario:setParent(obj.rectangle298);
    obj.textoinventario:setName("textoinventario");
    obj.textoinventario:setAlign("client");

    obj.rectangle299 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle299:setParent(obj.textoinventario);
    obj.rectangle299:setHeight(20);
    obj.rectangle299:setColor("black");
    obj.rectangle299:setCornerType("round");
    obj.rectangle299.grid.role = "col";
    obj.rectangle299.grid.width = 8;
    obj.rectangle299:setStrokeSize(1);
    obj.rectangle299:setStrokeColor("white");
    obj.rectangle299:setXradius(5);
    obj.rectangle299:setYradius(5);
    obj.rectangle299:setMargins({top=5});
    obj.rectangle299:setName("rectangle299");

    obj.descricao = GUI.fromHandle(_obj_newObject("edit"));
    obj.descricao:setParent(obj.rectangle299);
    obj.descricao:setName("descricao");
    obj.descricao:setField("descricao");
    obj.descricao.grid.role = "col";
    obj.descricao.grid.width = 12;
    obj.descricao:setTransparent(true);
    obj.descricao:setFontSize(14);
    obj.descricao:setHeight(20);
    obj.descricao:setHorzTextAlign("center");
    obj.descricao:setFontFamily("Wishes Script Caps Display");

    obj.dataLink82 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink82:setParent(obj.textoinventario);
    obj.dataLink82:setField("descricao");
    obj.dataLink82:setName("dataLink82");

    obj.label281 = GUI.fromHandle(_obj_newObject("label"));
    obj.label281:setParent(obj.textoinventario);
    obj.label281:setHeight(20);
    obj.label281:setText("Rank:");
    obj.label281:setFontSize(15);
    obj.label281.grid.role = "col";
    obj.label281.grid.width = 2;
    obj.label281:setFontFamily("Wishes Script Caps Display");
    obj.label281:setHorzTextAlign("trailing");
    obj.label281:setMargins({top=10,left=10});
    obj.label281:setName("label281");

    obj.rectangle300 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle300:setParent(obj.textoinventario);
    obj.rectangle300:setHeight(20);
    obj.rectangle300:setColor("black");
    obj.rectangle300:setCornerType("round");
    obj.rectangle300.grid.role = "col";
    obj.rectangle300.grid.width = 2;
    obj.rectangle300:setStrokeSize(1);
    obj.rectangle300:setStrokeColor("white");
    obj.rectangle300:setXradius(5);
    obj.rectangle300:setYradius(5);
    obj.rectangle300:setMargins({top=5,right=10});
    obj.rectangle300:setName("rectangle300");

    obj.comboBox38 = GUI.fromHandle(_obj_newObject("comboBox"));
    obj.comboBox38:setParent(obj.rectangle300);
    obj.comboBox38:setField("rank");
    obj.comboBox38.grid.role = "col";
    obj.comboBox38.grid.width = 12;
    obj.comboBox38:setHeight(18);
    obj.comboBox38:setHorzTextAlign("center");
    obj.comboBox38:setFontFamily("Cinzel");
    obj.comboBox38:setTransparent(true);
    obj.comboBox38:setFontSize(20);
    obj.comboBox38:setItems({'F-', 'F', 'F+', 'E-', 'E', 'E+', 'D-', 'D', 'D+', 'C-', 'C', 'C+', 'B-', 'B', 'B+', 'A-', 'A', 'A+', 'S-', 'S', 'S+'});
    obj.comboBox38:setMargins({right=3});
    obj.comboBox38:setName("comboBox38");

    obj.richEdit8 = GUI.fromHandle(_obj_newObject("richEdit"));
    obj.richEdit8:setParent(obj.textoinventario);
    obj.richEdit8:setField("texto_livre");
    obj.richEdit8:setAlign("client");
    obj.richEdit8.backgroundColor = "#000000";
    obj.richEdit8.defaultFontColor = "white";
    obj.richEdit8.hideSelection = true;
    obj.richEdit8.defaultFontSize = 14;
    obj.richEdit8.animateImages = true;
    obj.richEdit8:setMargins({top=30,right=4,left=4,bottom=4});
    obj.richEdit8:setName("richEdit8");


			local function atualizarVisibilidade()
                local mesa = Firecast.getMesaDe(sheet)

                -- Define as tags que representam os campos a serem travados/destravados
                local tags = {'vezesjogadas', 'forcasintese', 'destrezasintese', 'vigorsintese', 'inteligenciasintese', 'conscienciasintese', 'carismasintese', 'combatesintese', 'precisaosintese', 'xpbnaval', 'xpbejeweled', 'xpcminado', 'xpcmagico', 'xpgenius', 'xpjcobrinha', 'xplout', 'xpmahjong', 'xpmmaze', 'xpmmind', 'xppman', 'xppaciencia', 'xpptiles', 'xpqcabeca', 'xprhour', 'xpspuzzle', 'xpsudoku', 'xptetrix', 'xptdh', 'xp2048', 'funcao', 'origem', 'estrela_origem', 'classe'}
                
                -- Verifica se o jogador é mestre
                if mesa.meuJogador.isMestre then
                    -- Se for mestre, os elementos são revelados e os campos destravados
                    self.tipo_de_arquivo.visible = true;
                    self.botaocondicao.visivle = true;
                    
                    -- Destravar campos de texto
                    for _, tag in ipairs(tags) do
                        local control = self[tag]  -- Acessa o controle pelo nome da tag
                        if control then
                            control.readOnly = false  -- Destrava os campos
                        end
                    end
                else
                    -- Se não for mestre, os elementos são ocultados e os campos travados
                    self.tipo_de_arquivo.visible = false;
                    self.botaocondicao.visivle = false;

                    -- Travar campos de texto
                    for _, tag in ipairs(tags) do
                        local control = self[tag]  -- Acessa o controle pelo nome da tag
                        if control then
                            control.readOnly = true  -- Trava os campos
                        end
                    end
                end
            end;
		


    obj._e_event0 = obj:addEventListener("onScopeNodeChanged",
        function ()
            -- Desabilita o observer se já existir
            			if self.observer ~= nil then   
            				self.observer.enabled = false;
            				self.observer = nil;
            			end;
            
            			-- Cria o observer para verificar permissões e atualizar visibilidade
            			if sheet ~= nil then   
            				self.observer = NDB.newObserver(sheet);
            
            				self.observer.onPermissionListChanged = function(node)
            					atualizarVisibilidade();
            				end;
            
            				self.observer.onFinalPermissionsCouldBeChanged = function(node)
            					atualizarVisibilidade();
            				end;
            
            				-- Atualiza a visibilidade imediatamente ao carregar
            				atualizarVisibilidade();  
            			end;
        end);

    obj._e_event1 = obj.dataLink1:addEventListener("onChange",
        function (field, oldValue, newValue)
            if self.tipo_de_arquivo.value == "Ficha" then
                                            self.ficha.visible = true
                                            self.texto.visible = false
                                            self.inventario.visible = false
                                        elseif self.tipo_de_arquivo.value == "Texto" then
                                            self.ficha.visible = false
                                            self.texto.visible = true
                                            self.inventario.visible = false
                                        elseif self.tipo_de_arquivo.value == "Inventário" then
                                            self.ficha.visible = false
                                            self.texto.visible = false
                                            self.inventario.visible = true
                                        end;
        end);

    obj._e_event2 = obj.dataLink2:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet.personagem == nil then sheet.personagem = "https://images.vexels.com/media/users/3/220516/isolated/preview/7e7c120c190ae032e068975586d25279-silhueta-de-soldado-guerreiro-medieval.png";
                                    end;
                                    if sheet.nome == nil then sheet.nome = "Nome do Personagem";
                                    end;
                                    if sheet.nome == "Nome do Personagem" then
                                    self.edit_nome.fontColor = "gray";
                                    else self.edit_nome.fontColor = "white";
                                    end;
        end);

    obj._e_event3 = obj.dataLink4:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nv = tonumber(sheet.nv) or 1
                                            local estrela = tonumber(sheet.estrela_origem) or 1
            
                                            if nv < 1 then nv = 1 end
            
                                            local xp = 10
                                            local incremento = 10
            
                                            -- ajustes iniciais por estrela
                                            if estrela == 2 then
                                                xp = 15
                                                incremento = 15
                                            elseif estrela == 3 then
                                                xp = 20
                                                incremento = 20
                                            elseif estrela == 4 then
                                                xp = 25
                                                incremento = 25
                                            elseif estrela == 5 then
                                                xp = 30
                                                incremento = 30
                                            end
            
                                            -- calcula até o nível atual
                                            for i = 2, nv do
            
                                                -- definir incremento normal
                                                if estrela == 1 then
                                                    if i <= 10 then
                                                        incremento = 10
                                                    elseif i <= 20 then
                                                        incremento = 15
                                                    elseif i <= 40 then
                                                        incremento = 20
                                                    elseif i <= 60 then
                                                        incremento = 25
                                                    elseif i <= 80 then
                                                        incremento = 30
                                                    elseif i <= 99 then
                                                        incremento = 35
                                                    else
                                                        incremento = 40
                                                    end
            
                                                elseif estrela == 2 and i <= 20 then
                                                    incremento = 15
            
                                                elseif estrela == 3 and i <= 40 then
                                                    incremento = 20
            
                                                elseif estrela == 4 and i <= 60 then
                                                    incremento = 25
            
                                                elseif estrela == 5 and i <= 80 then
                                                    incremento = 30
                                                end
            
                                                xp = xp + incremento
                                            end
            
                                            sheet.xpmax = xp
        end);

    obj._e_event4 = obj.dataLink8:addEventListener("onChange",
        function (field, oldValue, newValue)
            if self.tipo_de_energia.value == "Ainda a procura do seu caminho" then
                                            self.aba_aura_magia.visible = false
                                        elseif self.tipo_de_energia.value == "Caminho da Aura" then
                                            self.aba_aura_magia.visible = true
                                            self.afinidadesmagia.visible = false
                                            self.afinidadesaura.visible = true
                                            self.afmagias.visible = false
                                            self.afauras.visible = true
                                            self.aptitudemagia.visible = false
                                            self.aptitudeaura.visible = true
                                            self.aba_aura_magia.title = "Aura"
                                            self.titulo_aura_magia.text = "Aura"
                                        elseif self.tipo_de_energia.value == "Caminho da Magia" then
                                            self.aba_aura_magia.visible = true
                                            self.afinidadesaura.visible = false
                                            self.afinidadesmagia.visible = true
                                            self.afmagias.visible = true
                                            self.afauras.visible = false
                                            self.aptitudemagia.visible = true
                                            self.aptitudeaura.visible = false
                                            self.aba_aura_magia.title = "Magia"
                                            self.titulo_aura_magia.text = "Magia"
                                        end;
        end);

    obj._e_event5 = obj.button1:addEventListener("onClick",
        function (event)
            self.explicacao_att:show()
        end);

    obj._e_event6 = obj.dataLink9:addEventListener("onChange",
        function (field, oldValue, newValue)
            local forca = 			(tonumber(sheet.forcabase)) + (tonumber(sheet.forcasintese)) + (tonumber(sheet.forcaequips)) + (tonumber(sheet.forcabuffs));
                                        local destreza = 		(tonumber(sheet.destrezabase)) + (tonumber(sheet.destrezasintese)) + (tonumber(sheet.destrezaequips)) + (tonumber(sheet.destrezabuffs));
                                        local vigor = 			(tonumber(sheet.vigorbase)) + (tonumber(sheet.vigorsintese)) + (tonumber(sheet.vigorequips)) + (tonumber(sheet.vigorbuffs));
                                        local inteligencia = 	(tonumber(sheet.inteligenciabase)) + (tonumber(sheet.inteligenciasintese)) + (tonumber(sheet.inteligenciaequips)) + (tonumber(sheet.inteligenciabuffs));
                                        local consciencia = 	(tonumber(sheet.conscienciabase)) + (tonumber(sheet.conscienciasintese)) + (tonumber(sheet.conscienciaequips)) + (tonumber(sheet.conscienciabuffs));
                                        local carisma = 		(tonumber(sheet.carismabase)) + (tonumber(sheet.carismasintese)) + (tonumber(sheet.carismaequips)) + (tonumber(sheet.carismabuffs));
                                        local combate = 		(tonumber(sheet.combatebase)) + (tonumber(sheet.combatesintese)) + (tonumber(sheet.combateequips)) + (tonumber(sheet.combatebuffs));
                                        local precisao = 		(tonumber(sheet.precisaobase)) + (tonumber(sheet.precisaosintese)) + (tonumber(sheet.precisaoequips)) + (tonumber(sheet.precisaobuffs));
                                                                    
                                        if 		sheet.condicao == "Medo" then
                                                sheet.forca = 	        math.floor(forca * 0.7);
                                                sheet.destreza = 	    math.floor(destreza * 0.7);                  
                                                sheet.vigor = 	        math.floor(vigor * 0.7);                  
                                                sheet.inteligencia = 	math.floor(inteligencia * 0.7);                  
                                                sheet.consciencia = 	math.floor(consciencia * 0.7);                  
                                                sheet.carisma = 	    math.floor(carisma * 0.7);      
                                                sheet.combate = 	    math.floor(combate * 0.7);
                                                sheet.precisao = 	    math.floor(precisao * 0.7);            
            
                                        elseif	sheet.condicao == "Pavor" then
                                                sheet.forca = 	        math.floor(forca * 0.5);
                                                sheet.destreza = 	    math.floor(destreza * 0.5);                  
                                                sheet.vigor = 	        math.floor(vigor * 0.5);                  
                                                sheet.inteligencia = 	math.floor(inteligencia * 0.5);                  
                                                sheet.consciencia = 	math.floor(consciencia * 0.5);   
                                                sheet.carisma = 	    math.floor(carisma * 0.5);   
                                                sheet.combate = 	    math.floor(combate * 0.5);
                                                sheet.precisao = 	    math.floor(precisao * 0.5);
                                                
                                        elseif	sheet.condicao == "Terror" then
                                                sheet.forca = 	        math.floor(forca * 0.2);
                                                sheet.destreza = 	    math.floor(destreza * 0.2);                  
                                                sheet.vigor = 	        math.floor(vigor * 0.2);                  
                                                sheet.inteligencia = 	math.floor(inteligencia * 0.2);                  
                                                sheet.consciencia = 	math.floor(consciencia * 0.2);   
                                                sheet.carisma = 	    math.floor(carisma * 0.2);   
                                                sheet.combate = 	    math.floor(combate * 0.2);
                                                sheet.precisao = 	    math.floor(precisao * 0.2);
            
                                        else	sheet.forca = 	        math.floor(forca);
                                                sheet.destreza = 	    math.floor(destreza);                  
                                                sheet.vigor = 	        math.floor(vigor);                  
                                                sheet.inteligencia = 	math.floor(inteligencia);                  
                                                sheet.consciencia = 	math.floor(consciencia);   					
                                                sheet.carisma = 	    math.floor(carisma);  
                                                sheet.combate = 	    math.floor(combate);
                                                sheet.precisao = 	    math.floor(precisao); 					
                                        end;
        end);

    obj._e_event7 = obj.dataLink10:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nv = tonumber(sheet.nv) or 1
                                                local estrela = tonumber(sheet.estrela_origem) or 1
            
                                                if nv < 1 then nv = 1 end
            
                                                local pontos = 0
            
                                                -- pontos iniciais
                                                if estrela == 1 then
                                                    pontos = 40
                                                elseif estrela == 2 then
                                                    pontos = 48
                                                elseif estrela == 3 then
                                                    pontos = 56
                                                elseif estrela == 4 then
                                                    pontos = 64
                                                elseif estrela == 5 then
                                                    pontos = 72
                                                end
            
                                                -- soma por nível (começa no 2)
                                                for i = 2, nv do
                                                    local ganho = 0
            
                                                    if estrela == 2 and i <= 20 then
                                                        ganho = 5
            
                                                    elseif estrela == 3 and i <= 40 then
                                                        ganho = 6
            
                                                    elseif estrela == 4 and i <= 60 then
                                                        ganho = 6
            
                                                    elseif estrela == 5 and i <= 80 then
                                                        ganho = 6
            
                                                    else
                                                        if i <= 10 then
                                                            ganho = 4
                                                        elseif i <= 20 then
                                                            ganho = 5
                                                        elseif i <= 40 then
                                                            ganho = 6
                                                        elseif i <= 60 then
                                                            ganho = 7
                                                        elseif i <= 80 then
                                                            ganho = 8
                                                        elseif i <= 99 then
                                                            ganho = 9
                                                        else
                                                            ganho = 10
                                                        end
                                                    end
            
                                                    pontos = pontos + ganho
                                                end
            
                                                sheet.distribuir = pontos - (sheet.forcabase + sheet.destrezabase + sheet.vigorbase + sheet.inteligenciabase + sheet.conscienciabase + sheet.carismabase + sheet.combatebase + sheet.precisaobase)
        end);

    obj._e_event8 = obj.dataLink11:addEventListener("onChange",
        function (field, oldValue, newValue)
            sheet.basetotal = 	((tonumber(sheet.forcabase) or 0) +
                                                                (tonumber(sheet.destrezabase) or 0) +
                                                                (tonumber(sheet.vigorbase) or 0) +
                                                                (tonumber(sheet.inteligenciabase) or 0) + 
                                                                (tonumber(sheet.conscienciabase) or 0) +
                                                                (tonumber(sheet.carismabase) or 0) + 
                                                                (tonumber(sheet.combatebase) or 0) +
                                                                (tonumber(sheet.precisaobase) or 0));
        end);

    obj._e_event9 = obj.dataLink12:addEventListener("onChange",
        function (field, oldValue, newValue)
            sheet.sintesetotal = 	(math.floor(tonumber(sheet.forcasintese) or 0) +
                                                                    math.floor(tonumber(sheet.destrezasintese) or 0) +
                                                                    math.floor(tonumber(sheet.vigorsintese) or 0) +
                                                                    math.floor(tonumber(sheet.inteligenciasintese) or 0) + 
                                                                    math.floor(tonumber(sheet.conscienciasintese) or 0) +
                                                                    math.floor(tonumber(sheet.carismasintese) or 0) +
                                                                    math.floor(tonumber(sheet.combatesintese) or 0) +
                                                                    math.floor(tonumber(sheet.precisaosintese) or 0));
        end);

    obj._e_event10 = obj.dataLink13:addEventListener("onChange",
        function (field, oldValue, newValue)
            sheet.equipstotal = ((tonumber(sheet.forcaequips) or 0) +
                                                                (tonumber(sheet.destrezaequips) or 0) +
                                                                (tonumber(sheet.vigorequips) or 0) +
                                                                (tonumber(sheet.inteligenciaequips) or 0) + 
                                                                (tonumber(sheet.conscienciaequips) or 0) +
                                                                (tonumber(sheet.carismaequips) or 0) + 
                                                                (tonumber(sheet.combateequips) or 0) +
                                                                (tonumber(sheet.precisaoequips) or 0));
        end);

    obj._e_event11 = obj.dataLink14:addEventListener("onChange",
        function (field, oldValue, newValue)
            sheet.total = 		((tonumber(sheet.forca) or 0) +
                                                                (tonumber(sheet.destreza) or 0) +
                                                                (tonumber(sheet.vigor) or 0) +
                                                                (tonumber(sheet.inteligencia) or 0) + 
                                                                (tonumber(sheet.consciencia) or 0) + 
                                                                (tonumber(sheet.carisma) or 0) + 
                                                                (tonumber(sheet.combate) or 0) +
                                                                (tonumber(sheet.precisao) or 0));
        end);

    obj._e_event12 = obj.dataLink15:addEventListener("onChange",
        function (field, oldValue, newValue)
            sheet.hptotal = 100 + (((tonumber(sheet.vigorbase)) + (math.floor(tonumber(sheet.vigorsintese))) + (tonumber(sheet.vigorequips))) * 24) + ((sheet.nv- 1)* 12);
        end);

    obj._e_event13 = obj.dataLink16:addEventListener("onChange",
        function (field, oldValue, newValue)
            sheet.sptotal = 130 + (((tonumber(sheet.vigorbase)) + (math.floor(tonumber(sheet.vigorsintese))) + (tonumber(sheet.vigorequips))) * 36) + math.floor(((sheet.nv)- 1)*18);
        end);

    obj._e_event14 = obj.dataLink17:addEventListener("onChange",
        function (field, oldValue, newValue)
            sheet.sancidadetotal = 8 + math.floor(((tonumber(sheet.conscienciabase)) + (math.floor(tonumber(sheet.conscienciasintese))) + (tonumber(sheet.conscienciaequips))) * 1.5 + ((sheet.nv)- 1));
        end);

    obj._e_event15 = obj.dataLink18:addEventListener("onChange",
        function (field, oldValue, newValue)
            if      sheet.tipo_de_energia == "Caminho da Magia" then
                                                    self.label_magia.visible = true
                                                    self.retangulo_magia.visible = true
                                                    sheet.mptotal = math.floor(((tonumber(sheet.inteligenciabase)) + (math.floor(tonumber(sheet.inteligenciasintese))) + (tonumber(sheet.inteligenciaequips))+ (tonumber(sheet.conscienciabase)) + (math.floor(tonumber(sheet.conscienciasintese))) + (tonumber(sheet.conscienciaequips))) * 7 + ((sheet.nv)- 1) * 5);
                                            else    self.label_magia.visible = false
                                                    self.retangulo_magia.visible = false
                                                    sheet.mptotal = 0;
                                            end
        end);

    obj._e_event16 = obj.dataLink19:addEventListener("onChange",
        function (field, oldValue, newValue)
            if      sheet.tipo_de_energia == "Caminho da Aura" then
                                                    self.label_aura.visible = true
                                                    self.retangulo_aura.visible = true
                                                    sheet.auratotal = math.floor(((tonumber(sheet.vigorbase)) + (math.floor(tonumber(sheet.vigorsintese))) + (tonumber(sheet.vigorequips)) + (tonumber(sheet.conscienciabase)) + (math.floor(tonumber(sheet.conscienciasintese))) + (tonumber(sheet.conscienciaequips))) * 7 + ((sheet.nv)- 1) * 5);
                                            else    self.label_aura.visible = false
                                                    self.retangulo_aura.visible = false
                                                    sheet.auratotal = 0;
                                            end
        end);

    obj._e_event17 = obj.dataLink20:addEventListener("onChange",
        function (field, oldValue, newValue)
            -- 1. Definição das Profissões e suas fórmulas de Atributos
                                            -- O cálculo aqui é a "Soma Ponderada" (ex: forca * 3 + vigor * 2...)
                                            local profs = {
                                                {id="forja",           desc="Utilizando os atributos Força, Vigor e Destreza, a Forja permite ao campeão criar itens e armas feitas a partir de metais.", formula = (sheet.vigor or 0)*2 + (sheet.forca or 0)*3 + (sheet.destreza or 0)*1},
                                                {id="carpintaria",     desc="Utilizando os atributos Inteligência, Força e Destreza, a Carpintaria permite ao campeão criar itens feitos de madeira com diversas finalidades, de escudos e flechas até cadeiras e mesas.", formula = (sheet.inteligencia or 0)*1 + (sheet.forca or 0)*2 + (sheet.destreza or 0)*3},
                                                {id="alquimia",        desc="Utilizando os atributos Destreza, Consciência e Inteligência, a Alquimia permite ao campeão preparar poções e elixires.", formula = (sheet.destreza or 0)*2 + (sheet.consciencia or 0)*1 + (sheet.inteligencia or 0)*3},
                                                {id="alfaiataria",     desc="Utilizando os atributos Inteligência, Consciência e Destreza, a Alfaiataria permite ao campeão criar vestimentas, sejam armaduras, capas, cintos ou similares.", formula = (sheet.inteligencia or 0)*1 + (sheet.consciencia or 0)*2 + (sheet.destreza or 0)*3},
                                                {id="culinaria",       desc="Utilizando os atributos Inteligência, Carisma e Destreza, a Culinária permite ao campeão preparar pratos e alimentos que concedem bonificações ou demeritos.", formula = (sheet.inteligencia or 0)*2 + (sheet.carisma or 0)*3 + (sheet.destreza or 0)*1},
                                                {id="joalheria",       desc="Utilizando os atributos Consciência, Carisma e Destreza, a Joalheria permite ao campeão lapidar gemas e criar acessórios.", formula = (sheet.consciencia or 0)*1 + (sheet.carisma or 0)*3 + (sheet.destreza or 0)*2},
                                                {id="ecomorfia",       desc="Utilizando os atributos Força, Consciência e Destreza, a Ecomorfia permite ao campeão processar materias organicas, como carapaças e chifres, e criar itens a partir deles.", formula = (sheet.forca or 0)*2 + (sheet.consciencia or 0)*2 + (sheet.destreza or 0)*2},
                                                {id="insetocultura",   desc="Utilizando os atributos Vigor, Consciência e Carisma, a Insetocultura permite ao campeão cuidar e criar insetos úteis.", formula = (sheet.vigor or 0)*1 + (sheet.consciencia or 0)*2 + (sheet.carisma or 0)*3},
                                                {id="agricultura",     desc="Utilizando os atributos Força, Vigor e Carisma, a Agricultura permite ao campeão cultivar plantas e colheitas.", formula = (sheet.forca or 0)*1 + (sheet.vigor or 0)*3 + (sheet.carisma or 0)*2},
                                                {id="pesca",           desc="Utilizando os atributos Destreza, Consciência e Carisma, a Pesca permite ao campeão conhecer e pescar peixes .", formula = (sheet.destreza or 0)*2 + (sheet.consciencia or 0)*3 + (sheet.carisma or 0)*1},
                                                {id="mineracao",       desc="Utilizando os atributos Força, Vigor e Consciência, a Mineração permite ao campeão extrair minérios.", formula = (sheet.forca or 0)*2 + (sheet.vigor or 0)*3 + (sheet.consciencia or 0)*1},
                                                {id="criacao_animal",  desc="Utilizando os atributos Consciência, Vigor e Carisma, a Criação de Animais permite ao campeão domesticar e criar animais.", formula = (sheet.consciencia or 0)*1 + (sheet.vigor or 0)*2 + (sheet.carisma or 0)*3},
                                                -- Pesquisa usa média simples (divisão por 2 no final), tratada no loop
                                                {id="pesquisa",        desc="Utilizando os atributos Inteligência e Consciência, a Pesquisa permite ao campeãoresolver problemas complexos no centro de pesquisas para arrecadar pontos de pesquisa.", formula = (sheet.inteligencia or 0) + (sheet.consciencia or 0), isPesquisa = true}
                                            }
            
                                            -- 2. Loop para processar cada profissão individualmente
                                            for _, prof in ipairs(profs) do
                                                local id = prof.id
                                                local maestria = sheet["maestria_" .. id] or "Básica"
                                                local nv = tonumber(sheet["nv_" .. id]) or 0
                                                local extra = tonumber(sheet["extra_" .. id]) or 0
                                                
                                                local mult = 0
                                                local bonusFixo = 0
                                                local rank = "F"
                                                local prog = ""
                                                local statusDesc = ""
            
                                                -- Cálculo da Base (Divisor 6 para comuns, Divisor 2 para Pesquisa)
                                                local divisor = prof.isPesquisa and 2 or 6
                                                local baseAtributos = prof.formula / divisor
            
                                                -- 3. Lógica de Maestria (Exatamente como a sua anterior)
                                                if maestria == "Sem Skill" then
                                                        mult, rank = 0.2, "F"
                                                        statusDesc = "Esse campeão não tem pratica o suficiente nesse ofício."
                                                        prog = "Nv 0: Modificador x0,2"
                                                elseif maestria == "Básica" and nv ~= 0 then
                                                        mult, rank, bonusFixo = 0.25, "E", math.floor((nv - 1) / 2)
                                                        statusDesc = "Esse campeão tem os fundamentos basicos desse ofício."
                                                        prog = "Nv 1: Modificador x0,25 \nNv 2: 2 slot de receita rank F ou 1 rank E \nNv 3: Aumento de modificador = +1 \nNv 4: 2 slot de receita rank F ou 1 rank E \nNv 5: Aumento de modificador = +2 \nNv 6: 2 slot de receita rank F ou 1 rank E \nNv 7: Aumento de modificador = +3 \nNv 8: 2 slot de receita rank F ou 1 rank E \nNv 9: Aumento de modificador = +4 \nNv 10: 2 slot de receita rank F ou 1 rank E"
                                                elseif maestria == "Intermediária" and nv ~= 0 then
                                                    mult, rank, bonusFixo = 0.33, "D", 4 + math.floor((nv - 1) / 2)
                                                    statusDesc = "Esse campeão tem habilidades consideráveis nesse ofício."
                                                    prog = "Nv 1: Modificador x0,33 e Aumento de modificador = +4 \nNv 2: 2 slot de receita rank E ou 1 rank D \nNv 3: Aumento de modificador = +5 \nNv 4: 2 slot de receita rank E ou 1 rank D \nNv 5: Aumento de modificador = +6 \nNv 6: 2 slot de receita rank E ou 1 rank D \nNv 7: Aumento de modificador = +7 \nNv 8: 2 slot de receita rank E ou 1 rank D \nNv 9: Aumento de modificador = +8 \nNv 10: 2 slot de receita rank E ou 1 rank D"
                                                elseif maestria == "Avançada" and nv ~= 0 then
                                                    mult, rank, bonusFixo = 0.5, "B", 8 + math.floor((nv - 1) / 2)
                                                    statusDesc = "Esse campeão é reconhecido como um artesão experiente desse ofício."
                                                    prog = "Nv 1: Modificador x0,5 e Aumento de modificador = +8 \nNv 2: 2 slot de receita rank C ou 1 rank B \nNv 3: Aumento de modificador = +9 \nNv 4: 2 slot de receita rank C ou 1 rank B \nNv 5: Aumento de modificador = +10 \nNv 6: 2 slot de receita rank C ou 1 rank B \nNv 7: Aumento de modificador = +11 \nNv 8: 2 slot de receita rank C ou 1 rank B \nNv 9: Aumento de modificador = +12 \nNv 10: 2 slot de receita rank C ou 1 rank B"
                                                elseif maestria == "Mestra" and nv ~= 0 then
                                                    mult, rank, bonusFixo = 0.75, "A", 12 + math.floor((nv - 1) / 2)
                                                    statusDesc = "Esse campeão tem um alto grau de maestria nesse ofício."
                                                    prog = "Nv 1: Modificador x0,75 e Aumento de modificador = +12 \nNv 2: 2 slot de receita rank B ou 1 rank A \nNv 3: Aumento de modificador = +13 \nNv 4: 2 slot de receita rank B ou 1 rank A \nNv 5: Aumento de modificador = +14 \nNv 6: 2 slot de receita rank B ou 1 rank A \nNv 7: Aumento de modificador = +15 \nNv 8: 2 slot de receita rank B ou 1 rank A \nNv 9: Aumento de modificador = +16 \nNv 10: 2 slot de receita rank B ou 1 rank A"
                                                elseif maestria == "Suprema" and nv ~= 0 then
                                                    mult, rank, bonusFixo = 1, "S", 16 + math.floor((nv - 1) / 2)
                                                    statusDesc = "Esse campeão chegou ao ápice desse ofício, sendo reconhecido como um de seus maiores artesãos vivos."
                                                    prog = "Nv 1: Modificador x1 e Aumento de modificador = +16 \nNv 2: 2 slot de receita rank A ou 1 rank S \nNv 3: Aumento de modificador = +17 \nNv 4: 2 slot de receita rank A ou 1 rank S \nNv 5: Aumento de modificador = +18 \nNv 6: 2 slot de receita rank A ou 1 rank S \nNv 7: Aumento de modificador = +19 \nNv 8: 2 slot de receita rank A ou 1 rank S \nNv 9: Aumento de modificador = +20 \nNv 10: 2 slot de receita rank A ou 1 rank S"
                                                end
            
                                                -- 4. Aplicação dos Resultados nos campos da Ficha
                                                local totalMod = math.floor(baseAtributos * mult) + bonusFixo + extra
                                                
                                                sheet["mod_" .. id] = "+" .. totalMod
                                                sheet["limite_" .. id] = "Itens Rank " .. rank
                                                sheet["progressao_" .. id] = prog
                                                
                                                -- Descrição dinâmica: Texto padrão + Descrição da Profissão + Status do Nível
                                                sheet["descricao_" .. id] = prof.desc .. " \n" .. statusDesc
                                            end
        end);

    obj._e_event18 = obj.dataLink21:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_agricultura"]
                                                        sheet["nvt_agricultura"] = sheet["nv_agricultura"]
        end);

    obj._e_event19 = obj.button2:addEventListener("onClick",
        function (event)
            self.detalhes_agricultura:show();
        end);

    obj._e_event20 = obj.dataLink23:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_agricultura"]
                                                local nv = sheet["nv_agricultura"]
            
                                                if maestria == "Básica" then
                                                    self["rec_agricultura"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_agricultura"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_agricultura"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_agricultura"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_agricultura"].color = "#ffd000"
                                                else
                                                    self["rec_agricultura"].color = "#000000"
                                                end
        end);

    obj._e_event21 = obj.dataLink24:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_alfaiataria"]
                                                        sheet["nvt_alfaiataria"] = sheet["nv_alfaiataria"]
        end);

    obj._e_event22 = obj.button3:addEventListener("onClick",
        function (event)
            self.detalhes_alfaiataria:show();
        end);

    obj._e_event23 = obj.dataLink26:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_alfaiataria"]
                                                local nv = sheet["nv_alfaiataria"]
            
                                                if maestria == "Básica" then
                                                    self["rec_alfaiataria"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_alfaiataria"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_alfaiataria"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_alfaiataria"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_alfaiataria"].color = "#ffd000"
                                                else
                                                    self["rec_alfaiataria"].color = "#000000"
                                                end
        end);

    obj._e_event24 = obj.dataLink27:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_alquimia"]
                                                        sheet["nvt_alquimia"] = sheet["nv_alquimia"]
        end);

    obj._e_event25 = obj.button4:addEventListener("onClick",
        function (event)
            self.detalhes_alquimia:show();
        end);

    obj._e_event26 = obj.dataLink29:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_alquimia"]
                                                local nv = sheet["nv_alquimia"]
            
                                                if maestria == "Básica" then
                                                    self["rec_alquimia"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_alquimia"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_alquimia"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_alquimia"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_alquimia"].color = "#ffd000"
                                                else
                                                    self["rec_alquimia"].color = "#000000"
                                                end
        end);

    obj._e_event27 = obj.dataLink30:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_carpintaria"]
                                                        sheet["nvt_carpintaria"] = sheet["nv_carpintaria"]
        end);

    obj._e_event28 = obj.button5:addEventListener("onClick",
        function (event)
            self.detalhes_carpintaria:show();
        end);

    obj._e_event29 = obj.dataLink32:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_carpintaria"]
                                                local nv = sheet["nv_carpintaria"]
            
                                                if maestria == "Básica" then
                                                    self["rec_carpintaria"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_carpintaria"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_carpintaria"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_carpintaria"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_carpintaria"].color = "#ffd000"
                                                else
                                                    self["rec_carpintaria"].color = "#000000"
                                                end
        end);

    obj._e_event30 = obj.dataLink33:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_criacao_animal"]
                                                        sheet["nvt_criacao_animal"] = sheet["nv_criacao_animal"]
        end);

    obj._e_event31 = obj.button6:addEventListener("onClick",
        function (event)
            self.detalhes_criacao_animal:show();
        end);

    obj._e_event32 = obj.dataLink35:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_criacao_animal"]
                                                local nv = sheet["nv_criacao_animal"]
            
                                                if maestria == "Básica" then
                                                    self["rec_criacao_animal"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_criacao_animal"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_criacao_animal"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_criacao_animal"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_criacao_animal"].color = "#ffd000"
                                                else
                                                    self["rec_criacao_animal"].color = "#000000"
                                                end
        end);

    obj._e_event33 = obj.dataLink36:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_culinaria"]
                                                        sheet["nvt_culinaria"] = sheet["nv_culinaria"]
        end);

    obj._e_event34 = obj.button7:addEventListener("onClick",
        function (event)
            self.detalhes_culinaria:show();
        end);

    obj._e_event35 = obj.dataLink38:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_culinaria"]
                                                local nv = sheet["nv_culinaria"]
            
                                                if maestria == "Básica" then
                                                    self["rec_culinaria"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_culinaria"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_culinaria"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_culinaria"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_culinaria"].color = "#ffd000"
                                                else
                                                    self["rec_culinaria"].color = "#000000"
                                                end
        end);

    obj._e_event36 = obj.dataLink39:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_ecomorfia"]
                                                        sheet["nvt_ecomorfia"] = sheet["nv_ecomorfia"]
        end);

    obj._e_event37 = obj.button8:addEventListener("onClick",
        function (event)
            self.detalhes_ecomorfia:show();
        end);

    obj._e_event38 = obj.dataLink41:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_ecomorfia"]
                                                local nv = sheet["nv_ecomorfia"]
            
                                                if maestria == "Básica" then
                                                    self["rec_ecomorfia"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_ecomorfia"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_ecomorfia"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_ecomorfia"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_ecomorfia"].color = "#ffd000"
                                                else
                                                    self["rec_ecomorfia"].color = "#000000"
                                                end
        end);

    obj._e_event39 = obj.dataLink42:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_forja"]
                                                        sheet["nvt_forja"] = sheet["nv_forja"]
        end);

    obj._e_event40 = obj.button9:addEventListener("onClick",
        function (event)
            self.detalhes_forja:show();
        end);

    obj._e_event41 = obj.dataLink44:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_forja"]
                                                local nv = sheet["nv_forja"]
            
                                                if maestria == "Básica" then
                                                    self["rec_forja"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_forja"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_forja"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_forja"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_forja"].color = "#ffd000"
                                                else
                                                    self["rec_forja"].color = "#000000"
                                                end
        end);

    obj._e_event42 = obj.dataLink45:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_insetocultura"]
                                                        sheet["nvt_insetocultura"] = sheet["nv_insetocultura"]
        end);

    obj._e_event43 = obj.button10:addEventListener("onClick",
        function (event)
            self.detalhes_insetocultura:show();
        end);

    obj._e_event44 = obj.dataLink47:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_insetocultura"]
                                                local nv = sheet["nv_insetocultura"]
            
                                                if maestria == "Básica" then
                                                    self["rec_insetocultura"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_insetocultura"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_insetocultura"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_insetocultura"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_insetocultura"].color = "#ffd000"
                                                else
                                                    self["rec_insetocultura"].color = "#000000"
                                                end
        end);

    obj._e_event45 = obj.dataLink48:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_joalheria"]
                                                        sheet["nvt_joalheria"] = sheet["nv_joalheria"]
        end);

    obj._e_event46 = obj.button11:addEventListener("onClick",
        function (event)
            self.detalhes_joalheria:show();
        end);

    obj._e_event47 = obj.dataLink50:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_joalheria"]
                                                local nv = sheet["nv_joalheria"]
            
                                                if maestria == "Básica" then
                                                    self["rec_joalheria"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_joalheria"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_joalheria"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_joalheria"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_joalheria"].color = "#ffd000"
                                                else
                                                    self["rec_joalheria"].color = "#000000"
                                                end
        end);

    obj._e_event48 = obj.dataLink51:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_mineracao"]
                                                        sheet["nvt_mineracao"] = sheet["nv_mineracao"]
        end);

    obj._e_event49 = obj.button12:addEventListener("onClick",
        function (event)
            self.detalhes_mineracao:show();
        end);

    obj._e_event50 = obj.dataLink53:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_mineracao"]
                                                local nv = sheet["nv_mineracao"]
            
                                                if maestria == "Básica" then
                                                    self["rec_mineracao"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_mineracao"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_mineracao"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_mineracao"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_mineracao"].color = "#ffd000"
                                                else
                                                    self["rec_mineracao"].color = "#000000"
                                                end
        end);

    obj._e_event51 = obj.dataLink54:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_pesca"]
                                                        sheet["nvt_pesca"] = sheet["nv_pesca"]
        end);

    obj._e_event52 = obj.button13:addEventListener("onClick",
        function (event)
            self.detalhes_pesca:show();
        end);

    obj._e_event53 = obj.dataLink56:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_pesca"]
                                                local nv = sheet["nv_pesca"]
            
                                                if maestria == "Básica" then
                                                    self["rec_pesca"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_pesca"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_pesca"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_pesca"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_pesca"].color = "#ffd000"
                                                else
                                                    self["rec_pesca"].color = "#000000"
                                                end
        end);

    obj._e_event54 = obj.dataLink57:addEventListener("onChange",
        function (field, oldValue, newValue)
            local nvt = sheet["nv_pesquisa"]
                                                        sheet["nvt_pesquisa"] = sheet["nv_pesquisa"]
        end);

    obj._e_event55 = obj.button14:addEventListener("onClick",
        function (event)
            self.detalhes_pesquisa:show();
        end);

    obj._e_event56 = obj.dataLink59:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet["maestria_pesquisa"]
                                                local nv = sheet["nv_pesquisa"]
            
                                                if maestria == "Básica" then
                                                    self["rec_pesquisa"].color = "#4e4e4e"
                                                elseif maestria == "Intermediária" then
                                                    self["rec_pesquisa"].color = "#00900c"
                                                elseif maestria == "Avançada" then
                                                    self["rec_pesquisa"].color = "#0032b0"
                                                elseif maestria == "Mestra" then
                                                    self["rec_pesquisa"].color = "#830285"
                                                elseif maestria == "Suprema" then
                                                    self["rec_pesquisa"].color = "#ffd000"
                                                else
                                                    self["rec_pesquisa"].color = "#000000"
                                                end
        end);

    obj._e_event57 = obj.btn_mod_fabricacao:addEventListener("onClick",
        function (event)
            if self.tabela_atributos.visible == false then
                                        self.tabela_atributos.visible = true
                                        self.tabela_mods_fabricacao.visible = false
                                        self.btn_mod_fabricacao.text = "Ir para Modificadores de Fabricação"
                                    else
                                        self.tabela_atributos.visible = false
                                        self.tabela_mods_fabricacao.visible = true
                                        self.btn_mod_fabricacao.text = "Ir para Atributos"
                                    end
        end);

    obj._e_event58 = obj.dataLink61:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet.tipodepersonagem == "Jogador" then self.aba_minigames.visible = true;
            						else self.aba_minigames.visible = false;
            						end;
        end);

    obj._e_event59 = obj.tmrFiltroSkills:addEventListener("onTimer",
        function ()
            checkSkillsFilter()
        end);

    obj._e_event60 = obj.edtFiltroSkills:addEventListener("onChange",
        function ()
            runSkillsFilter()
        end);

    obj._e_event61 = obj.listaskills:addEventListener("onCompare",
        function (left, right)
            return Utils.compareStringPtBr(left.nomeSkill or "", right.nomeSkill or "");
        end);

    obj._e_event62 = obj.listaskills:addEventListener("onFilter",
        function (node)
            if (filterSkillsArgument == nil) or (filterSkillsArgument == "") then
                                                return true;
                                            end;
            
                                            local nome = prepFilterSkills(node.nomeSkill);
                                            local descCura = prepFilterSkills(node.tagsSkill);
                                            local maestria = prepFilterSkills(node.maestriaSkill);
            
                                            return (nome ~= "" and string.find(nome, filterSkillsArgument, 1, true)) or 
                                                (descCura ~= "" and string.find(descCura, filterSkillsArgument, 1, true)) or
                                                (maestria ~= "" and string.find(maestria, filterSkillsArgument, 1, true));
        end);

    obj._e_event63 = obj.dataLink62:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet ~= nil then
                                            if sheet.tagsSkill == nil then
                                                sheet.tagsSkill = "Tags"
                                            end
                                        end
        end);

    obj._e_event64 = obj.btn_cabecaequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_cabecaequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_cabecaequip"] = nil;
                                                    end;
        end);

    obj._e_event65 = obj.button15:addEventListener("onClick",
        function (event)
            -- Inverte o estado de visibilidade baseado no primeiro elemento
                                                local novoEstado = not self.d1.visible;
                                                
                                                for i = 1, 14 do 
                                                    local campo = self["d" .. i];
                                                    if campo ~= nil then 
                                                        campo.visible = novoEstado;
                                                    end;
                                                end;
        end);

    obj._e_event66 = obj.dataLink63:addEventListener("onChange",
        function (field, oldValue, newValue)
            for i = 1, 14 do
                                                    local prop = "d" .. i;
                                                    if sheet[prop] == nil then 
                                                        sheet[prop] = "100%"; 
                                                    end;
                                                end;
        end);

    obj._e_event67 = obj.dataLink64:addEventListener("onChange",
        function (field, oldValue, newValue)
            -- Mapeamento exato dos campos que você usou nos EquipSlot e EquipPopup
                                                local icones = {
                                                    cabecaequip = "http://blob.firecast.com.br/blobs/VSBKJVLE_3196991/capacete.png",
                                                    maoesquerdaequip = "http://blob.firecast.com.br/blobs/MHJOGVIJ_3197013/mao_esquerda.png",
                                                    ombroequip = "http://blob.firecast.com.br/blobs/VWWCJLAI_3197011/ombros.png",
                                                    pescocoequip = "http://blob.firecast.com.br/blobs/KQTJSRMC_3196994/colar.png",
                                                    torsoequip = "http://blob.firecast.com.br/blobs/BHSFRPKJ_3197012/torso.png",
                                                    costasequip = "http://blob.firecast.com.br/blobs/PFNJLMSL_3196996/costas.png",
                                                    maodireitaequip = "http://blob.firecast.com.br/blobs/KAOFDIWM_3196998/mao_direita.png",
                                                    cintoequip = "http://blob.firecast.com.br/blobs/VIKSJTAS_3196995/cinto.png",
                                                    armadireitaequip = "http://blob.firecast.com.br/blobs/MRUHMKWV_3196993/arma_direita.png",
                                                    armaesquerdaequip = "http://blob.firecast.com.br/blobs/QQBQUNJS_3196992/arma_esqueda.png",
                                                    botaequip = "http://blob.firecast.com.br/blobs/ODHJPRVJ_3196989/bota.png",
                                                    pernaequip = "http://blob.firecast.com.br/blobs/ADULDOEJ_3196997/cal_a.png",
                                                    acessorio1equip = "http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png",
                                                    acessorio2equip = "http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png"
                                                }
            
                                                -- Verifica cada campo. Se estiver vazio (nil), coloca o ícone padrão.
                                                for nomeCampo, linkIcone in pairs(icones) do
                                                    if sheet[nomeCampo] == nil or sheet[nomeCampo] == "" then
                                                        sheet[nomeCampo] = linkIcone
                                                    end
                                                end
        end);

    obj._e_event68 = obj.btn_maoesquerdaequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_maoesquerdaequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_maoesquerdaequip"] = nil;
                                                    end;
        end);

    obj._e_event69 = obj.btn_ombroequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_ombroequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_ombroequip"] = nil;
                                                    end;
        end);

    obj._e_event70 = obj.btn_pescocoequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_pescocoequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_pescocoequip"] = nil;
                                                    end;
        end);

    obj._e_event71 = obj.btn_torsoequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_torsoequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_torsoequip"] = nil;
                                                    end;
        end);

    obj._e_event72 = obj.btn_costasequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_costasequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_costasequip"] = nil;
                                                    end;
        end);

    obj._e_event73 = obj.btn_maodireitaequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_maodireitaequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_maodireitaequip"] = nil;
                                                    end;
        end);

    obj._e_event74 = obj.btn_cintoequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_cintoequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_cintoequip"] = nil;
                                                    end;
        end);

    obj._e_event75 = obj.btn_armadireitaequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_armadireitaequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_armadireitaequip"] = nil;
                                                    end;
        end);

    obj._e_event76 = obj.btn_armaesquerdaequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_armaesquerdaequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_armaesquerdaequip"] = nil;
                                                    end;
        end);

    obj._e_event77 = obj.btn_botaequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_botaequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_botaequip"] = nil;
                                                    end;
        end);

    obj._e_event78 = obj.btn_pernaequip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_pernaequip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_pernaequip"] = nil;
                                                    end;
        end);

    obj._e_event79 = obj.btn_acessorio1equip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_acessorio1equip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_acessorio1equip"] = nil;
                                                    end;
        end);

    obj._e_event80 = obj.btn_acessorio2equip:addEventListener("onClick",
        function (event)
            local idx = sheet["id_acessorio2equip"];
                                                    local nodeReal = nil;
            
                                                    if idx ~= nil then
                                                        local nodes = NDB.getChildNodes(sheet.itensEquipamento);
                                                        nodeReal = nodes[idx];
                                                    end
            
                                                    if nodeReal ~= nil then                                             
                                                        self.detalheEquipamento:setNodeObject(nodeReal);
                                                        atualizarVisibilidadeSlots()
                                                        nodeReal.isEquipado = true; 
                                                        
                                                        self.detalheEquipamento.visible = true;
                                                        self.abertoPeloSlot = true;
                                                    else
                                                        showMessage("Não há nenhum item equipado neste slot ou o item foi deletado.");
                                                        sheet["id_acessorio2equip"] = nil;
                                                    end;
        end);

    obj._e_event81 = obj.tmrFiltroEquipamentos:addEventListener("onTimer",
        function ()
            checkEquipFilter()
        end);

    obj._e_event82 = obj.edtFiltroEquipamentos:addEventListener("onChange",
        function ()
            runEquipFilter()
        end);

    obj._e_event83 = obj.listaequipamento:addEventListener("onCompare",
        function (left, right)
            return Utils.compareStringPtBr(left.nomeEquip or "", right.nomeEquip or "");
        end);

    obj._e_event84 = obj.listaequipamento:addEventListener("onFilter",
        function (node)
            if (filterEquipArgument == nil) or (filterEquipArgument == "") then
                                                return true;
                                            end;
            
                                            local nome = prepFilterEquip(node.nomeEquip);
                                            local descCura = prepFilterEquip(node.tags_equip);
            
                                            return (nome ~= "" and string.find(nome, filterEquipArgument, 1, true)) or 
                                                (descCura ~= "" and string.find(descCura, filterEquipArgument, 1, true));
        end);

    obj._e_event85 = obj.btn_lista_equipamentos:addEventListener("onClick",
        function (event)
            if self.lista_equipamentos.visible == false then
                                        self.lista_equipamentos.visible = true
                                        self.equipamentos_equipados.visible = false
                                        self.btn_lista_equipamentos.text = "Ir para Itens Equipados"
                                    else
                                        self.lista_equipamentos.visible = false
                                        self.equipamentos_equipados.visible = true
                                        self.btn_lista_equipamentos.text = "Ir para Lista de Itens"
                                    end
        end);

    obj._e_event86 = obj.detalheEquipamento:addEventListener("onNodeReady",
        function ()
            atualizarVisibilidadeSlots();
        end);

    obj._e_event87 = obj.detalheEquipamento:addEventListener("onNodeChanged",
        function ()
            atualizarVisibilidadeSlots();
        end);

    obj._e_event88 = obj.btn_equipar_acao:addEventListener("onClick",
        function (event)
            local itemNode = self.detalheEquipamento.node;
                                        if itemNode == nil then return end;
            
                                        local ficha = NDB.getRoot(itemNode); 
            
                                        local mapa = {
                                            {c="cabeca", s="cabecaequip", d="d1", p="http://blob.firecast.com.br/blobs/VSBKJVLE_3196991/capacete.png"},
                                            {c="maoesquerda", s="maoesquerdaequip", d="d2", p="http://blob.firecast.com.br/blobs/MHJOGVIJ_3197013/mao_esquerda.png"},
                                            {c="ombro", s="ombroequip", d="d3", p="http://blob.firecast.com.br/blobs/VWWCJLAI_3197011/ombros.png"},
                                            {c="pescoco", s="pescocoequip", d="d4", p="http://blob.firecast.com.br/blobs/KQTJSRMC_3196994/colar.png"},
                                            {c="torso", s="torsoequip", d="d5", p="http://blob.firecast.com.br/blobs/BHSFRPKJ_3197012/torso.png"},
                                            {c="costas", s="costasequip", d="d6", p="http://blob.firecast.com.br/blobs/PFNJLMSL_3196996/costas.png"},
                                            {c="maodireita", s="maodireitaequip", d="d7", p="http://blob.firecast.com.br/blobs/KAOFDIWM_3196998/mao_direita.png"},
                                            {c="cinto", s="cintoequip", d="d8", p="http://blob.firecast.com.br/blobs/VIKSJTAS_3196995/cinto.png"},
                                            {c="armadireita", s="armadireitaequip", d="d9", p="http://blob.firecast.com.br/blobs/MRUHMKWV_3196993/arma_direita.png"},
                                            {c="armaesquerda", s="armaesquerdaequip", d="d10", p="http://blob.firecast.com.br/blobs/QQBQUNJS_3196992/arma_esqueda.png"},
                                            {c="bota", s="botaequip", d="d11", p="http://blob.firecast.com.br/blobs/ODHJPRVJ_3196989/bota.png"},
                                            {c="perna", s="pernaequip", d="d12", p="http://blob.firecast.com.br/blobs/ADULDOEJ_3196997/cal_a.png"},
                                            {c="acessorio1", s="acessorio1equip", d="d13", p="http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png"},
                                            {c="acessorio2", s="acessorio2equip", d="d14", p="http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png"}
                                        };
            
                                        local conflitos = {}
                                        local nodes = NDB.getChildNodes(ficha.itensEquipamento)
            
                                        -- detectar conflitos
                                        for i=1,#mapa do
                                            local m = mapa[i]
            
                                            if itemNode["vis_"..m.c] == true then
                                                local ocupado = ficha["id_"..m.s]
            
                                                if ocupado ~= nil then
                                                    local nodeAntigo = nodes[ocupado]
            
                                                    if nodeAntigo ~= nil and nodeAntigo ~= itemNode then
                                                        conflitos[nodeAntigo] = true
                                                    end
                                                end
                                            end
                                        end
            
                                        -- transformar em lista de nomes
                                        local nomes = {}
                                        for node,_ in pairs(conflitos) do
                                            table.insert(nomes, node.nomeEquip or "Item")
                                        end
            
                                        local function equiparItem()
            
                                            -- desequipar itens conflitantes
                                            for node,_ in pairs(conflitos) do
                                                node.isEquipado = false
            
                                                for i=1,#mapa do
                                                    local m = mapa[i]
            
                                                    if ficha["id_"..m.s] ~= nil then
                                                        if nodes[ficha["id_"..m.s]] == node then
                                                            ficha[m.s] = m.p
                                                            ficha["id_"..m.s] = nil
                                                        end
                                                    end
                                                end
                                            end
            
                                            -- equipar item novo
                                            local marcouAlgum = false
                                            itemNode.isEquipado = true
            
                                            for i=1,#mapa do
                                                local m = mapa[i]
            
                                                if itemNode["vis_"..m.c] == true then
                                                    ficha[m.s] = itemNode.imagemEquip or "https://rebrand.ly/firecast_default_icon"
                                                    ficha[m.d] = itemNode.durabilidadeItem or "100%"
            
                                                    for n=1,#nodes do
                                                        if nodes[n] == itemNode then
                                                            ficha["id_"..m.s] = n
                                                            break
                                                        end
                                                    end
            
                                                    marcouAlgum = true
                                                end
                                            end
            
                                            if not marcouAlgum then
                                                showMessage("Selecione os slots onde deseja equipar este item primeiro.")
                                                itemNode.isEquipado = false
                                            end
                                        end
            
                                        -- se não houver conflitos
                                        if #nomes == 0 then
                                            equiparItem()
                                        else
            
                                            local lista = table.concat(nomes, ", ")
            
                                            local msg = "Para que o item '" .. (itemNode.nomeEquip or "Item") ..
                                            "' seja equipado, os itens '" .. lista ..
                                            "' serão desequipados. Deseja continuar?"
            
                                            Dialogs.confirmYesNo(msg,
                                                function()
                                                    equiparItem()
                                                end,
                                                function()
                                                    -- cancelar
                                                end)
                                        end
        end);

    obj._e_event89 = obj.btn_desequipar_acao:addEventListener("onClick",
        function (event)
            local itemNode = self.detalheEquipamento.node;
                                        if itemNode == nil then return end;
                                        
                                        local ficha = NDB.getRoot(itemNode);
                                        local mapa = {
                                            {c="cabeca", s="cabecaequip", p="http://blob.firecast.com.br/blobs/VSBKJVLE_3196991/capacete.png"},
                                            {c="maoesquerda", s="maoesquerdaequip", p="http://blob.firecast.com.br/blobs/MHJOGVIJ_3197013/mao_esquerda.png"},
                                            {c="ombro", s="ombroequip", p="http://blob.firecast.com.br/blobs/VWWCJLAI_3197011/ombros.png"},
                                            {c="pescoco", s="pescocoequip", p="http://blob.firecast.com.br/blobs/KQTJSRMC_3196994/colar.png"},
                                            {c="torso", s="torsoequip", p="http://blob.firecast.com.br/blobs/BHSFRPKJ_3197012/torso.png"},
                                            {c="costas", s="costasequip", p="http://blob.firecast.com.br/blobs/PFNJLMSL_3196996/costas.png"},
                                            {c="maodireita", s="maodireitaequip", p="http://blob.firecast.com.br/blobs/KAOFDIWM_3196998/mao_direita.png"},
                                            {c="cinto", s="cintoequip", p="http://blob.firecast.com.br/blobs/VIKSJTAS_3196995/cinto.png"},
                                            {c="armadireita", s="armadireitaequip", p="http://blob.firecast.com.br/blobs/MRUHMKWV_3196993/arma_direita.png"},
                                            {c="armaesquerda", s="armaesquerdaequip", p="http://blob.firecast.com.br/blobs/QQBQUNJS_3196992/arma_esqueda.png"},
                                            {c="bota", s="botaequip", p="http://blob.firecast.com.br/blobs/ODHJPRVJ_3196989/bota.png"},
                                            {c="perna", s="pernaequip", p="http://blob.firecast.com.br/blobs/ADULDOEJ_3196997/cal_a.png"},
                                            {c="acessorio1", s="acessorio1equip", p="http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png"},
                                            {c="acessorio2", s="acessorio2equip", p="http://blob.firecast.com.br/blobs/NQCTGWQW_3196990/acessorio.png"}
                                        };
            
                                        -- 1. Limpar os Slots na ficha principal e remover os IDs de rastreio
                                        for i=1, #mapa do
                                            local m = mapa[i];
                                            if itemNode["vis_" .. m.c] == true then
                                                ficha[m.s] = m.p;
                                                ficha["id_" .. m.s] = nil; -- Remove o ID para o slot ficar vazio
                                            end;
                                        end;
            
                                        -- 2. Atualizar o estado do item diretamente (Sem busca manual!)
                                        itemNode.isEquipado = false;
            
                                        -- 3. Fechar o painel se foi aberto pelo slot
                                        if self.abertoPeloSlot then
                                            self.detalheEquipamento.visible = false;
                                            self.abertoPeloSlot = false;
                                        end;
                                        
                                        -- 4. Reorganizar apenas se você tiver um filtro de "Itens Equipados" na lista
                                        -- Caso contrário, pode remover esta linha para ganhar performance.
                                        self.listaequipamento:reorganize();
        end);

    obj._e_event90 = obj.dataLink65:addEventListener("onChange",
        function (field, oldValue, newValue)
            local node = self.detalheEquipamento.node;
                                        if node ~= nil then
                                            -- Se estiver equipado, o botão de EQUIPAR some e o de DESEQUIPAR aparece
                                            self.btn_equipar_acao.visible = not node.isEquipado;
                                            self.btn_desequipar_acao.visible = node.isEquipado;
                                        end;
        end);

    obj._e_event91 = obj.dataLink66:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet ~= nil then
                                                if sheet.durabilidadeItem == nil then 
                                                    sheet.durabilidadeItem = "100%";
                                                end;
                                            end;
        end);

    obj._e_event92 = obj.dataLink68:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet ~= nil then
                                                    if sheet.tags_equip == nil then
                                                        sheet.tags_equip = "Tags"
                                                    end
                                                end
        end);

    obj._e_event93 = obj.tmrFiltro_Aura_Magia:addEventListener("onTimer",
        function ()
            check_Aura_MagiaFilter()
        end);

    obj._e_event94 = obj.edtFiltro_Aura_Magia:addEventListener("onChange",
        function ()
            run_Aura_MagiaFilter()
        end);

    obj._e_event95 = obj.lista_aura_magia:addEventListener("onCompare",
        function (left, right)
            return Utils.compareStringPtBr(left.nome_Aura_Magia or "", right.nome_Aura_Magia or "");
        end);

    obj._e_event96 = obj.lista_aura_magia:addEventListener("onFilter",
        function (node)
            if (filter_Aura_MagiaArgument == nil) or (filter_Aura_MagiaArgument == "") then
                                                return true;
                                            end;
            
                                            local nome = prepFilter_Aura_Magia(node.nome_Aura_Magia);
                                            local descCura = prepFilter_Aura_Magia(node.tags_Aura_Magia);
            
                                            return (nome ~= "" and string.find(nome, filter_Aura_MagiaArgument, 1, true)) or 
                                                (descCura ~= "" and string.find(descCura, filter_Aura_MagiaArgument, 1, true));
        end);

    obj._e_event97 = obj.dataLink69:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet ~= nil then
                                            if sheet.tags_Aura_Magia == nil then
                                                sheet.tags_Aura_Magia = "Tags"
                                            end
                                        end
        end);

    obj._e_event98 = obj.dataLink70:addEventListener("onChange",
        function (field, oldValue, newValue)
            local base = "/Imagens/03 - Afinidades/"
            
                                    -- nomes oficiais
                                    local nomes = {
                                        divina="Divina",
                                        clarevidencia="Clarevidência",
                                        espiritual="Espiritual",
                                        mental="Mental",
                                        elemental="Elemental",
                                        producao="Produção",
                                        invocacao="Invocação",
                                        demoniaca="Demoniaca"
                                    }
            
                                    -- cores por rank
                                    local rankCor = {
                                        S="ciano",
                                        A="azul",
                                        B="verde",
                                        C="amarelo",
                                        D="laranja",
                                        E="vermelho",
                                        F="preto"
                                    }
            
                                    -- afinidade base por aptidão
                                    local afinidades = {
                                        ["Escolha..."] = {todos="branco"},
            
                                        ["Divina"] = {
                                            divina="azul", clarevidencia="verde", espiritual="verde", mental="amarelo",
                                            elemental="amarelo", producao="laranja", invocacao="laranja", demoniaca="vermelho"
                                        },
            
                                        ["Clarevidência"] = {
                                            clarevidencia="azul", mental="verde", divina="verde", producao="amarelo",
                                            espiritual="amarelo", elemental="laranja", demoniaca="laranja", invocacao="vermelho"
                                        },
            
                                        ["Mental"] = {
                                            mental="azul", producao="verde", clarevidencia="verde", demoniaca="amarelo",
                                            divina="amarelo", invocacao="laranja", espiritual="laranja", elemental="vermelho"
                                        },
            
                                        ["Produção"] = {
                                            producao="azul", mental="verde", demoniaca="verde", invocacao="amarelo",
                                            clarevidencia="amarelo", divina="laranja", elemental="laranja", espiritual="vermelho"
                                        },
            
                                        ["Demoniaca"] = {
                                            demoniaca="azul", invocacao="verde", producao="verde", elemental="amarelo",
                                            mental="amarelo", espiritual="laranja", clarevidencia="laranja", divina="vermelho"
                                        },
            
                                        ["Invocação"] = {
                                            invocacao="azul", elemental="verde", demoniaca="verde", espiritual="amarelo",
                                            producao="amarelo", divina="laranja", mental="laranja", clarevidencia="vermelho"
                                        },
            
                                        ["Elemental"] = {
                                            elemental="azul", invocacao="verde", espiritual="verde", demoniaca="amarelo",
                                            divina="amarelo", clarevidencia="laranja", producao="laranja", mental="vermelho"
                                        },
            
                                        ["Espiritual"] = {
                                            espiritual="azul", elemental="verde", divina="verde", invocacao="amarelo",
                                            clarevidencia="amarelo", mental="laranja", demoniaca="laranja", producao="vermelho"
                                        }
                                    }
            
                                    -- função pra montar caminho
                                    local function setImg(campo, cor)
                                        sheet["ap"..campo] = base .. cor .. "/" .. nomes[campo] .. " - .png"
                                    end
            
                                    local apt = sheet.aptitudemagia or "Escolha..."
                                    local tabela = afinidades[apt] or afinidades["Escolha..."]
            
                                    -- aplica base
                                    if tabela.todos then
                                        for campo in pairs(nomes) do
                                            setImg(campo, tabela.todos)
                                        end
                                    else
                                        for campo, cor in pairs(tabela) do
                                            setImg(campo, cor)
                                        end
                                    end
            
                                    -- override por rank
                                    for campo in pairs(nomes) do
                                        local rank = sheet["af"..campo]
                                        local cor = rankCor[rank]
            
                                        if cor then
                                            setImg(campo, cor)
                                        end
                                    end
        end);

    obj._e_event99 = obj.dataLink71:addEventListener("onChange",
        function (field, oldValue, newValue)
            local function getCorPorRank(rank)
                                    local cores = {
                                        S = "ciano",
                                        A = "azul",
                                        B = "verde",
                                        C = "amarelo",
                                        D = "laranja",
                                        E = "vermelho",
                                        F = "preto"
                                    }
                                    return cores[rank]
                                end
            
                                local function setImg(prop, nome, cor)
                                    sheet[prop] = "/Imagens/03 - Afinidades/" .. cor .. "/" .. nome .. " - .png"
                                end
            
                                -- ========================
                                -- BASE POR APTIDÃO
                                -- ========================
            
                                local base = {
                                    ["Escolha..."] = {
                                        reforcof="branco", transmutacao="branco", emissao="branco",
                                        conjuracao="branco", manipulacao="branco", reforcom="branco"
                                    },
            
                                    ["Reforço Fisico"] = {
                                        reforcof="azul", transmutacao="verde", emissao="verde",
                                        conjuracao="amarelo", manipulacao="amarelo", reforcom="vermelho"
                                    },
            
                                    ["Transmutação"] = {
                                        reforcof="verde", transmutacao="azul", emissao="amarelo",
                                        conjuracao="verde", manipulacao="vermelho", reforcom="amarelo"
                                    },
            
                                    ["Conjuração"] = {
                                        reforcof="amarelo", transmutacao="verde", emissao="vermelho",
                                        conjuracao="azul", manipulacao="amarelo", reforcom="verde"
                                    },
            
                                    ["Reforço Mental"] = {
                                        reforcof="vermelho", transmutacao="amarelo", emissao="amarelo",
                                        conjuracao="verde", manipulacao="verde", reforcom="azul"
                                    },
            
                                    ["Manipulação"] = {
                                        reforcof="amarelo", transmutacao="vermelho", emissao="verde",
                                        conjuracao="amarelo", manipulacao="azul", reforcom="verde"
                                    },
            
                                    ["Emissão"] = {
                                        reforcof="verde", transmutacao="amarelo", emissao="azul",
                                        conjuracao="vermelho", manipulacao="verde", reforcom="amarelo"
                                    }
                                }
            
                                local nomes = {
                                    reforcof = "Reforço Fisico",
                                    transmutacao = "Transmutação",
                                    emissao = "Emissão",
                                    conjuracao = "Conjuração",
                                    manipulacao = "Manipulação",
                                    reforcom = "Reforço Mental"
                                }
            
                                local props = {
                                    reforcof = "apreforcofisico",
                                    transmutacao = "aptransmutacao",
                                    emissao = "apemissao",
                                    conjuracao = "apconjuracao",
                                    manipulacao = "apmanipulacao",
                                    reforcom = "apreforcomental"
                                }
            
                                -- aplica base
                                local escolha = base[sheet.aptitudeaura] or base["Escolha..."]
            
                                for k, cor in pairs(escolha) do
                                    setImg(props[k], nomes[k], cor)
                                end
            
                                -- ========================
                                -- OVERRIDE POR RANK
                                -- ========================
            
                                local ranks = {
                                    reforcof = sheet.afreforcof,
                                    transmutacao = sheet.aftransmutacao,
                                    conjuracao = sheet.afconjuracao,
                                    reforcom = sheet.afreforcom,
                                    manipulacao = sheet.afmanipulacao,
                                    emissao = sheet.afemissao
                                }
            
                                for k, rank in pairs(ranks) do
                                    local cor = getCorPorRank(rank)
                                    if cor then
                                        setImg(props[k], nomes[k], cor)
                                    end
                                end
        end);

    obj._e_event100 = obj.button16:addEventListener("onClick",
        function (event)
            self.cores_afinidades:show();
        end);

    obj._e_event101 = obj.botaocondicao:addEventListener("onClick",
        function (event)
            self.condicoescorpo:show();
        end);

    obj._e_event102 = obj.button17:addEventListener("onClick",
        function (event)
            self.explicacao_raca:show()
        end);

    obj._e_event103 = obj.dataLink72:addEventListener("onChange",
        function (field, oldValue, newValue)
            -- Tabela com todos os dados das raças
                                    local dadosRacas = {
                                        ["Humanos"] = {
                                            img = "https://blob.firecast.com.br/blobs/SPLQWHDD_4311999/humano.png",
                                            infos = "Os humanos são uma das raças mais comuns e influentes em diversos mundos, com uma expectativa de vida que varia entre 50 e 100 anos. Sua maior força reside na adaptabilidade, permitindo-lhes prosperar em ambientes variados — desde as terras mais áridas até as cidades mais desenvolvidas. Dotados de uma curiosidade insaciável e uma ambição muitas vezes ilimitada, os humanos se destacam por sua capacidade de inovar e evoluir em campos como tecnologia, magia, combate e diplomacia. Essa versatilidade cultural e habilidade multifacetada os torna uma raça amplamente presente e decisiva na formação de histórias e sociedades. \n\nCulturalmente, os humanos exibem uma enorme diversidade, criando desde impérios poderosos até tribos isoladas, com sistemas políticos que vão do monarquismo à democracia e formas variadas de crenças e costumes. Em muitos locais, eles convivem em harmonia com outras raças, estabelecendo alianças e trocando conhecimentos, mas não raro a ambição humana leva a disputas por territórios e poder. Essa dualidade — entre a busca por coexistência pacífica e a propensão a conflitos — caracteriza a complexidade dos humanos, cuja história é marcada tanto por conquistas grandiosas quanto por momentos de destruição e caos.",
                                            cond = "Nenhuma",
                                            sub = "Não possuem subespécies, mas podem evoluir para Altos Humanos."
                                        },
                                        ["Altos Humanos"] = {
                                            img = "https://blob.firecast.com.br/blobs/UGLDNWNU_4311994/alto_humano.png",
                                            infos = "Os Alto Humanos são considerados uma “evolução” dos humanos comuns, alcançada quando um indivíduo completa certos requisitos especiais ainda envoltos em mistério. Apesar de não apresentarem diferenças físicas visíveis em relação aos humanos normais, os Alto Humanos possuem capacidades e potencialidades superiores, o que os torna raros e reverenciados em algumas culturas. Essa transformação representa um avanço significativo na espécie, elevando suas habilidades e compreensão do mundo. \n\nAlém disso, os Alto Humanos têm a capacidade única de evoluir novamente para subespécies distintas, adquirindo traços especiais, como Saurin, onde sua pele se torna parcialmente escamosa como de um reptil, ou Ventarin, que lhes concedem asas e a liberdade do voo, entre outras possibilidades. Sua expectativa de vida é significativamente aumentada, podendo alcançar até 200 anos, o que lhes permite acumular vasto conhecimento e experiência ao longo dos séculos. Essa linhagem especial simboliza um caminho de evolução, poder e mistério dentro da humanidade.",
                                            cond = "Conquistar qualquer outra raça. \nPara conquistar cada subespécie, é necessário cumprir requisitos em interações com a raça da subespécie desejada após se tornar um Alto Humano.",
                                            sub = "Ferrin, Ventarin, Florin, Faelarin, Chitin, Aquorin, Saurin, Petrin, Bestarin e Wixarin."
                                        },
                                        ["Anões"] = {
                                            img = "https://blob.firecast.com.br/blobs/RQTVSVGE_4311992/an_o.png",
                                            infos = "Os anões são uma raça resistente e determinada, reconhecida por sua força física impressionante, habilidades técnicas excepcionais e profundo apreço pela terra. Originários de vastas redes de montanhas e cavernas subterrâneas, eles se destacam como mestres em metalurgia e engenharia, criando armas, armaduras e estruturas que são admiradas por sua durabilidade e complexidade. Sua ética de trabalho incansável reflete um compromisso quase religioso com o aperfeiçoamento constante de suas habilidades, e sua lealdade aos clãs e tradições é inabalável. Sua afinidade com o subterrâneo os torna habitantes naturais de vastas cidades esculpidas diretamente nas profundezas das montanhas, onde cavaram e entalharam complexas fortalezas e forjas com impressionante precisão e durabilidade. \n\nCom uma expectativa de vida que varia entre 100 e 150 anos, os anões também são exímios guerreiros, treinados desde cedo para defender suas fortalezas subterrâneas contra invasores. No campo de batalha, são conhecidos por sua disciplina, resistência e determinação, sempre lutando lado a lado com seus irmãos de clã. Embora possam ser vistos como reservados ou até mesmo teimosos por outras raças, os anões cultivam um forte senso de comunidade e respeito pela tradição, transmitindo histórias e conhecimentos de geração em geração, mantendo vivas suas raízes e seu legado.",
                                            cond = "Demonstre a um NPC anão um conhecimento de fabricação que ele não possua.",
                                            sub = "Não possuem subespécies."
                                        },
                                        ["Aveanos"] = {
                                            img = "https://blob.firecast.com.br/blobs/FOGUFUOT_4311991/aveano.png",
                                            infos = "Os Aveanos são uma raça de humanoides aviários com uma impressionante diversidade de subespécies, como falcões, corujas, papagaios, pinguins, patos e outras aves, cada uma com traços únicos que influenciam tanto sua aparência quanto sua cultura. Apesar dessa variedade, compartilham traços comuns como ossos leves, olhos aguçados e sentidos apurados. Muitos possuem asas funcionais, enquanto outros, como os descendentes de aves aquáticas, adaptaram-se à terra e à água com igual habilidade. Em todas as suas formas, os birdpeople mantêm um profundo apreço pela sabedoria e pela contemplação. \n\nSua sociedade costuma valorizar intensamente o conhecimento, registrando história, magia e ciência em enormes bibliotecas suspensas ou em espirais de cristal que ecoam com cantos ancestrais. Suas cidades são frequentemente encontradas em picos montanhosos de difícil acesso ou até mesmo flutuando entre as nuvens, sustentadas por magia ou tecnologia arcana. A vida nas alturas reflete não só sua afinidade com o céu, mas também sua busca por perspectivas elevadas — físicas e filosóficas. Embora pacíficos por natureza, os birdpeople defendem ferozmente seus territórios e valores, especialmente contra aqueles que ameaçam o equilíbrio do saber. A expectativa de vida varia conforme a subespécie, indo geralmente de 70 a 120 anos, dependendo do tamanho, metabolismo e condições ambientais. A devoção à mente, aliada à leveza do corpo, faz deles uma raça reverenciada por sua visão ampla — tanto literal quanto espiritual.",
                                            cond = "Descubra uma informação esquecida ou perdida que seja relevante para o conhecimento dos Aveanos e retorne-a a um NPC aveano.",
                                            sub = "Qualquer espécie de ave. "
                                        },
                                        ["Brotelis"] = {
                                            img = "https://blob.firecast.com.br/blobs/CFOGIRNC_4311993/broteli.png",
                                            infos = "Os Brotelis são uma raça de humanoides vegetais que apresentam uma vasta diversidade de subespécies, abrangendo desde cogumelos e bambus até árvores majestosas e delicadas flores. Cada subespécie traz consigo características físicas e habilidades únicas, como resistência, camuflagem ou regeneração, que refletem a complexidade e a riqueza da vida natural que carregam em sua essência. Assim como as árvores mais antigas, muitos Brotelis possuem uma longevidade quase ilimitada, vivendo por eras enquanto testemunham as mudanças do mundo ao seu redor. \n\nSua sociedade é profundamente enraizada na busca pelo equilíbrio com a natureza, colocando a harmonia ecológica acima de ambições pessoais ou políticas. Eles cultivam suas comunidades em sinergia com o ambiente, integrando-se a florestas, pradarias ou pântanos sem jamais perturbar o ciclo natural. Ao contrário de outras raças, os Brotelis não têm uma inclinação universal para um único traço cultural ou filosófico; sua diversidade é refletida também em crenças e modos de vida variados, adaptados às particularidades de seus ecossistemas. Essa conexão visceral com o mundo natural torna os Brotelis guardiões silenciosos da terra, portadores da sabedoria antiga das plantas e da paciência implacável do crescimento.",
                                            cond = "Ajude um NPC Broteli a restaurar ou proteger um ecossistema natural importante",
                                            sub = "Qualquer espécie de planta."
                                        },
                                        ["Elfos"] = {
                                            img = "https://blob.firecast.com.br/blobs/DAWRLSOH_4311996/elfo.png",
                                            infos = "Os elfos são uma raça antiga e elegante, dividida em três subespécies principais: os Elfos Comuns, os Altos e os Negros. Os Elfos Comuns formam a maior parte da população, vivendo em diversas regiões e desempenhando papéis variados na sociedade. Os Altos, de linhagem sanguínea nobre e rara, são tradicionalmente vistos como a elite social e política, responsáveis por liderar e preservar os legados ancestrais. Já os Elfos Negros pertencem à linhagem dos guardiões, encarregados da proteção dos segredos, territórios e tradições élficas mais sagrados. Apesar dessa hierarquia — Altos no topo, seguidos pelos Negros e, por fim, os Comuns — a discriminação entre eles é incomum, sendo a divisão mais uma forma prática de organização do que um motivo de conflito. \n\nSua relação com a natureza é marcada por um equilíbrio cuidadoso: respeitam o ambiente ao seu redor, mas também o utilizam com sabedoria, extraindo seus recursos sem desperdiçar ou causar desequilíbrio. Essa filosofia é refletida em sua arquitetura, conhecida por sua elegância e sofisticação, com construções que harmonizam elementos naturais e artísticos, integrando árvores, pedras e cursos d’água em estruturas graciosas e funcionais. A sociedade é culturalmente rica e refinada, valorizando artes, magia e conhecimento, mantendo uma coexistência pacífica e harmoniosa tanto entre si quanto com o mundo natural que os cerca. A expectativa de vida dos elfos pode chegar a 200 anos, permitindo-lhes acumular conhecimento e experiência que alimentam sua cultura rica e duradoura.",
                                            cond = "Comum: Receba reconhecimento ou confiança verdadeiros de um NPC elfo.\nNegros: Receba reconhecimento ou confiança verdadeiros de um NPC Elfo Negro. \nAltos: Tenha uma façanha grandiosa o bastante para beneficiar a raça élfica como um todo reconhecida por um NPC Alto Elfo.",
                                            sub = "Elfos Comuns, Elfos Negros e Altos Elfos. \nCada subespécie deve ser desbloqueada separadamente."
                                        },
                                        ["Insectoides"] = {
                                            img = "https://blob.firecast.com.br/blobs/FIAIQPNS_4311998/insectoide.png",
                                            infos = "Os Insectoides são uma raça de insetos humanoides que apresentam uma vasta diversidade de subespécies, incluindo besouros, formigas, abelhas e muitas outras. Sua organização social costuma refletir os hábitos naturais de seus ancestrais insetos, vivendo em estruturas que reproduzem colônias, colmeias ou formigueiros, dimensionados para seus tamanhos e necessidades. Além disso, é comum que diferentes subespécies convivam juntas, formando cidades complexas e colaborativas, que às vezes até incluem membros de outras raças, criando uma rede social diversificada e multifuncional. \n\nA expectativa de vida dos Insectoides varia amplamente conforme a subespécie, indo de poucos anos, como 4 anos, até cerca de 60 anos, o que influencia diretamente suas funções e papéis dentro das colônias. Eles são conhecidos por sua disciplina, cooperação e eficiência, características essenciais para o funcionamento harmonioso de suas comunidades. Essa estrutura social coesa, aliada à adaptabilidade, permite que os Insectoides prosperem em diversos ambientes, mantendo um equilíbrio dinâmico entre suas tradições naturais e as exigências dos mundos que habitam.",
                                            cond = "Ajude um NPC insectoide significativamente para o crescimento de uma colônia insectoide",
                                            sub = "Qualquer espécie de inseto."
                                        },
                                        ["Merfolk"] = {
                                            img = "https://blob.firecast.com.br/blobs/POITRHKS_4311997/merfolk.png",
                                            infos = "Os Merfolk são uma raça de humanoides marinhos que apresentam uma vasta diversidade de subespécies, derivadas de diferentes criaturas do oceano, como peixes, tubarões, polvos, baleias, caranguejos e muitas outras. Cada linhagem manifesta características próprias de seu ancestral marinho: alguns possuem caudas poderosas para nadar com grande velocidade, outros apresentam tentáculos ágeis ou carapaças resistentes, enquanto certos grupos se destacam pelo tamanho ou pela força física impressionante. Apesar dessa variedade, todos compartilham uma profunda adaptação ao ambiente aquático, com corpos moldados para viver e se mover com naturalidade nas profundezas dos mares. \n\nA sociedade dos Merfolk valoriza intensamente a força, a coragem e um rígido senso de honra, princípios que guiam tanto seus líderes quanto seus guerreiros. A maior parte de suas cidades está localizada completamente submersa no fundo do oceano, construídas entre recifes, abismos marinhos ou grandes formações de coral, formando vastas metrópoles aquáticas. No entanto, muitos Merfolk também estabelecem cidades semi-submersas próximas às costas, projetadas para servir como pontos de contato e comércio com outras raças terrestres. Esses locais intermediários facilitam trocas culturais e diplomáticas, permitindo que os Merfolk mantenham relações com o mundo da superfície sem abandonar sua profunda conexão com o oceano.",
                                            cond = "Receba reconhecimento de um NPC líder ou guerreiro Merfolk por um ato de coragem abaixo d'água.",
                                            sub = "Qualquer espécie de animal marinho."
                                        },
                                        ["Reptideos"] = {
                                            img = "https://blob.firecast.com.br/blobs/COOSSWAH_4312000/reptideo.png",
                                            infos = "Os Reptideos são uma raça de lagartos humanoides que apresentam uma grande variedade de subespécies e linhagens ancestrais, as quais são altamente valorizadas e respeitadas dentro de sua sociedade. Essa diversidade genética e cultural confere aos Lizardmen uma riqueza histórica e social profunda, onde cada linhagem carrega tradições, poderes e responsabilidades específicas. Sua expectativa de vida é bastante ampla, variando de 80 até impressionantes 400 anos, permitindo que alguns indivíduos acumulem sabedoria e influência por séculos. \n\nSocialmente, os Lizardmen se organizam de formas variadas, indo desde tribos bárbaras e guerreiras que preservam costumes ancestrais, até cidades desenvolvidas com avanços tecnológicos e arquitetônicos próprios. Essa flexibilidade lhes permite adaptar-se a diferentes ambientes e desafios, mantendo sempre um forte senso de identidade e orgulho cultural. A reverência às suas origens ancestrais e a diversidade entre suas subespécies são pilares fundamentais que sustentam a complexa e dinâmica sociedade dos Reptideos.",
                                            cond = "Comum: Ajude um NPC Reptideo a recuperar um custume ancestral de seu povo. \nAncestral: Participe ou auxilie um NPC reptideo na realização de um ritual de uma linhagem ancestral reptídia.",
                                            sub = "Qualquer espécie de réptil. Além disso possuem variantes ancestrais desbloqueadas separadamente."
            
                                        },
                                        ["Stoneliths"] = {
                                            img = "https://blob.firecast.com.br/blobs/WQMETTEE_4311995/stonelith.png",
                                            infos = "Os Stoneliths são imponentes seres humanoides formados inteiramente de pedra, variando entre 4 e 10 metros de altura. De origem desconhecida — até mesmo para eles próprios — esses colossos despertam mais perguntas do que respostas, sendo frequentemente vistos como fragmentos vivos de antigas forças do mundo. Sua expectativa de vida é virtualmente ilimitada, resistindo enquanto a rocha que os compõe permanecer intacta, o que pode significar séculos ou até milênios de existência. \n\nDiferente da maioria das raças, os Stoneliths não formam sociedades. No máximo, pequenos grupos de até cinco indivíduos se unem por curtos períodos, geralmente por propósitos específicos ou afinidades raras. Muitos preferem vagar solitários pelo mundo ou se fixar em um único local, assumindo o papel de guardiões silenciosos — protegendo ruínas, florestas, montanhas ou locais sagrados sem buscar recompensa. Não são ambiciosos nem agressivos por natureza, mas possuem uma força formidável e são perfeitamente capazes de se defender quando ameaçados. Com sua presença monumental e natureza enigmática, os Stoneliths são vistos por muitos como ecos vivos da própria terra.",
                                            cond = "Descubra ou desperte um NPC Stonelith adormecido.",
                                            sub = "Não possuem subespécies."
                                        },
                                        ["Werebeasts"] = {
                                            img = "https://blob.firecast.com.br/blobs/AJWERKVJ_4312001/werebeast.png",
                                            infos = "Os Werebeats são uma espécie de mamíferos humanoides que exibem uma grande diversidade de subespécies, como cães, gatos, cangurus, coalas, raposas e muitos outros. Cada linhagem traz consigo traços físicos e habilidades distintas. Sua aparência são é marcada por suas pelagens e formas animais. \n\nEles tendem a viver em pequenas vilas tribais, onde o senso de comunidade e sobrevivência é forte. Entretanto, em alguns mundos, os Werebeasts já formaram grandes impérios, onde sua cultura de honra e força como guerreiros moldou civilizações poderosas. O respeito à força, à coragem no combate e à lealdade aos seus são os pilares de sua sociedade, e aqueles que demonstram grande habilidade em batalha ganham um status elevado entre seus pares. \n\nDe modo geral, os Werebeasts não possuem conflitos intrínsecos com outras raças, mantendo uma postura neutra na maioria dos casos. Sua inclinação natural a batalha, valorizando a força e a honra acima de tudo, embora sejam vistos como criaturas ferozes, a natureza guerreira dos Werebeasts é balanceada por sua noção de respeito e justiça dentro de suas tribos.",
                                            cond = "Prove sua força ou coragem diante de um NPC Werebeast em combate.",
                                            sub = "Qualquer espécie de mamífero terrestre."
                                        },
                                        ["Wixilis"] = {
                                            img = "https://blob.firecast.com.br/blobs/HVIGTESD_4312007/wixili.png",
                                            infos = "Os Wixilis são uma espécie de humanoides com pele amarela, que pode ser lisa ou coberta por pelos, e alguns indivíduos até apresentam chifres ou outras caracteristicas marcantes. Essa raça é tipicamente de baixa estatura, com altura máxima de 1,2m, e possui uma expectativa de vida de cerca de 50 anos, alcançando a maturidade aos 15 anos. \n\nA sociedade dos Wixilis é complexa e cada membro desempenha um papel importante. Desde o primeiro ano de vida, rituais tradicionais ajudam a descobrir os talentos individuais de cada um, permitindo que sejam treinados na especialidade que mais se adequa a eles. Sempre com um sorriso no rosto, os Wixilis acreditam que essa expressão traz alegria ao mundo e, assim, valorizam seu modo de vida e as tradições da tribo. \n\nEm geral, os Wixilis preferem manter-se afastados de assuntos que não os envolvem diretamente, resultando em uma sociedade um tanto isolada.",
                                            cond = "Vença de um NPC Wixili em um \"Ritual Profissional\" da especialidade dele.",
                                            sub = "Não possuem subespécies."
                                        }
                                    };
            
                                    local selecao = sheet.racas_gerais;
                                    local dados = dadosRacas[selecao];
            
                                    if dados ~= nil then
                                        -- Atualiza imagem (forçando refresh)
                                        sheet.imagem_raca = nil;
                                        sheet.imagem_raca = dados.img;
            
                                        -- Atualiza textos
                                        sheet.infos = dados.infos;
                                        sheet.condicao_conquista = dados.cond;
                                        sheet.subespecies = dados.sub;
                                    end;
        end);

    obj._e_event104 = obj.dataLink73:addEventListener("onChange",
        function (field, oldValue, newValue)
            atualizarVisibilidadeRacas();
            
                                    local novasOpcoes = {};
                                    local novosValores = {};
            
                                    local racaMapeamento = {
                                        {field = "vis_raca_humano",      nome = "Humano"},
                                        {field = "vis_raca_alto_humano", nome = "Alto Humano"},
                                        {field = "vis_raca_anao",        nome = "Anão"},
                                        {field = "vis_raca_aveano",      nome = "Aveano"},
                                        {field = "vis_raca_broteli",     nome = "Broteli"},
                                        {field = "vis_raca_elfo",        nome = "Elfo"},
                                        {field = "vis_raca_insectoide",  nome = "Insectoide"},
                                        {field = "vis_raca_merfolk",     nome = "Merfolk"},
                                        {field = "vis_raca_reptideo",    nome = "Reptídio"},
                                        {field = "vis_raca_stonelith",   nome = "Stonelith"},
                                        {field = "vis_raca_werebeast",   nome = "Werebeast"},
                                        {field = "vis_raca_wixili",      nome = "Wixili"}
                                    };
            
                                    for i=1, #racaMapeamento do
                                        local item = racaMapeamento[i];
                                        if sheet[item.field] == true then
                                            table.insert(novasOpcoes, item.nome);
                                            table.insert(novosValores, item.field);
                                        end
                                    end
            
                                    if #novasOpcoes == 0 then
                                        self.combo_raca.items  = {"Nenhuma raça disponível"};
                                        self.combo_raca.values = {"none"};
                                    else
                                        self.combo_raca.items  = novasOpcoes;
                                        self.combo_raca.values = novosValores;
                                    end;
            
                                    -- ✅ CORREÇÃO: restaura o valor salvo no NDB após remontar os itens
                                    if sheet.raca_atual ~= nil then
                                        self.combo_raca.value = sheet.raca_atual;
                                    else
                                        sheet.raca_atual = "vis_raca_humano";
                                        self.combo_raca.value = "vis_raca_humano";
                                    end;
        end);

    obj._e_event105 = obj.dataLink79:addEventListener("onChange",
        function (field, oldValue, newValue)
            local function xp(v)
                                            return tonumber(v) or 0
                                            end
            
                                            local function mod(v)
                                            return "+" .. tostring(math.floor(xp(v)/10))
                                            end
            
                                            local total =
                                            xp(sheet.xpbnaval) +
                                            xp(sheet.xpbejeweled) +
                                            xp(sheet.xpcminado) +
                                            xp(sheet.xpcmagico) +
                                            xp(sheet.xpgenius) +
                                            xp(sheet.xpjcobrinha) +
                                            xp(sheet.xplout) +
                                            xp(sheet.xpmahjong) +
                                            xp(sheet.xpmmaze) +
                                            xp(sheet.xpmmind) +
                                            xp(sheet.xppman) +
                                            xp(sheet.xppaciencia) +
                                            xp(sheet.xpptiles) +
                                            xp(sheet.xpqcabeca) +
                                            xp(sheet.xprhour) +
                                            xp(sheet.xpspuzzle) +
                                            xp(sheet.xpsudoku) +
                                            xp(sheet.xptetrix) +
                                            xp(sheet.xptdh) +
                                            xp(sheet.xp2048)
            
                                            sheet.xptotaljogos = total
                                            sheet.xpjogosdisponivel = math.max(0, 40 - total)
            
                                            sheet.modbnaval = mod(sheet.xpbnaval)
                                            sheet.modbejeweled = mod(sheet.xpbejeweled)
                                            sheet.modcminado = mod(sheet.xpcminado)
                                            sheet.modcmagico = mod(sheet.xpcmagico)
                                            sheet.modgenius = mod(sheet.xpgenius)
                                            sheet.modjcobrinha = mod(sheet.xpjcobrinha)
                                            sheet.modlout = mod(sheet.xplout)
                                            sheet.modmahjong = mod(sheet.xpmahjong)
                                            sheet.modmmaze = mod(sheet.xpmmaze)
                                            sheet.modmmind = mod(sheet.xpmmind)
                                            sheet.modpman = mod(sheet.xppman)
                                            sheet.modpaciencia = mod(sheet.xppaciencia)
                                            sheet.modptiles = mod(sheet.xpptiles)
                                            sheet.modqcabeca = mod(sheet.xpqcabeca)
                                            sheet.modrhour = mod(sheet.xprhour)
                                            sheet.modspuzzle = mod(sheet.xpspuzzle)
                                            sheet.modsudoku = mod(sheet.xpsudoku)
                                            sheet.modtetrix = mod(sheet.xptetrix)
                                            sheet.modtdh = mod(sheet.xptdh)
                                            sheet.mod2048 = mod(sheet.xp2048)
        end);

    obj._e_event106 = obj.tmrFiltroVinculo_1:addEventListener("onTimer",
        function ()
            checkVinculo_1Filter()
        end);

    obj._e_event107 = obj.edtFiltroVinculo_1:addEventListener("onChange",
        function ()
            runVinculo_1Filter()
        end);

    obj._e_event108 = obj.listavinculo_1:addEventListener("onCompare",
        function (left, right)
            return Utils.compareStringPtBr(left.nomeVinculo_1 or "", right.nomeVinculo_1 or "");
        end);

    obj._e_event109 = obj.listavinculo_1:addEventListener("onFilter",
        function (node)
            if (filterVinculo_1Argument == nil) or (filterVinculo_1Argument == "") then
                                                return true;
                                            end;
            
                                            local nome = prepFilterVinculo_1(node.nomeVinculo_1);
                                            local descCura = prepFilterVinculo_1(node.tagsVinculo_1);
            
                                            return (nome ~= "" and string.find(nome, filterVinculo_1Argument, 1, true)) or 
                                                (descCura ~= "" and string.find(descCura, filterVinculo_1Argument, 1, true));
        end);

    obj._e_event110 = obj.tmrFiltroVinculo_2:addEventListener("onTimer",
        function ()
            checkVinculo_2Filter()
        end);

    obj._e_event111 = obj.edtFiltroVinculo_2:addEventListener("onChange",
        function ()
            runVinculo_2Filter()
        end);

    obj._e_event112 = obj.dataLink80:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet ~= nil then
                                            if sheet.tagsVinculo_1 == nil then
                                                sheet.tagsVinculo_1 = "Tags"
                                            end
                                        end
        end);

    obj._e_event113 = obj.listavinculo_2:addEventListener("onCompare",
        function (left, right)
            return Utils.compareStringPtBr(left.nomeVinculo_2 or "", right.nomeVinculo_2 or "");
        end);

    obj._e_event114 = obj.listavinculo_2:addEventListener("onFilter",
        function (node)
            if (filterVinculo_2Argument == nil) or (filterVinculo_2Argument == "") then
                                                return true;
                                            end;
            
                                            local nome = prepFilterVinculo_2(node.nomeVinculo_2);
                                            local descCura = prepFilterVinculo_2(node.tagsVinculo_2);
            
                                            return (nome ~= "" and string.find(nome, filterVinculo_2Argument, 1, true)) or 
                                                (descCura ~= "" and string.find(descCura, filterVinculo_2Argument, 1, true));
        end);

    obj._e_event115 = obj.dataLink81:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet ~= nil then
                                            if sheet.tagsVinculo_2 == nil then
                                                sheet.tagsVinculo_2 = "Tags"
                                            end
                                        end
        end);

    obj._e_event116 = obj.tmrFiltroTextos:addEventListener("onTimer",
        function ()
            checkNeedExecuteFilterTextos()
        end);

    obj._e_event117 = obj.edtFiltroTextos:addEventListener("onChange",
        function ()
            executeFilterTextos()
        end);

    obj._e_event118 = obj.listatextos:addEventListener("onCompare",
        function (left, right)
            return Utils.compareStringPtBr(left.nome or "", right.nome or "");
        end);

    obj._e_event119 = obj.listatextos:addEventListener("onFilter",
        function (node)
            if (currentFilterTextos == nil) or (currentFilterTextos == "") then
                                            return true;
                                        end;
            
                                        local nome = prepareStrForFilterTextos(node.nome);
            
                                        return (nome ~= "" and string.find(nome, currentFilterTextos, 1, true) ~= nil);
        end);

    obj._e_event120 = obj.tmrFiltroCategorias:addEventListener("onTimer",
        function ()
            checkNeedExecuteFilter()
        end);

    obj._e_event121 = obj.edtFiltroCategorias:addEventListener("onChange",
        function ()
            executeFilterNow()
        end);

    obj._e_event122 = obj.listacategoria:addEventListener("onCompare",
        function (left, right)
            return Utils.compareStringPtBr(left.nome or "", right.nome or "");
        end);

    obj._e_event123 = obj.listacategoria:addEventListener("onFilter",
        function (node)
            if (currentFilterArgument == nil) or (currentFilterArgument == "") then
                                            return true;
                                        end;
            
                                        local nome = prepareStrForFilter(node.nome);
                                        local descricao = prepareStrForFilter(node.descricao);
            
                                        return (nome ~= "" and string.find(nome, currentFilterArgument, 1, true)) or 
                                            (descricao ~= "" and string.find(descricao, currentFilterArgument, 1, true));
        end);

    obj._e_event124 = obj.dataLink82:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet ~= nil then
                                            if sheet.descricao == nil then
                                                sheet.descricao = "Tags"
                                            end
                                        end
        end);

    function obj:_releaseEvents()
        __o_rrpgObjs.removeEventListenerById(self._e_event124);
        __o_rrpgObjs.removeEventListenerById(self._e_event123);
        __o_rrpgObjs.removeEventListenerById(self._e_event122);
        __o_rrpgObjs.removeEventListenerById(self._e_event121);
        __o_rrpgObjs.removeEventListenerById(self._e_event120);
        __o_rrpgObjs.removeEventListenerById(self._e_event119);
        __o_rrpgObjs.removeEventListenerById(self._e_event118);
        __o_rrpgObjs.removeEventListenerById(self._e_event117);
        __o_rrpgObjs.removeEventListenerById(self._e_event116);
        __o_rrpgObjs.removeEventListenerById(self._e_event115);
        __o_rrpgObjs.removeEventListenerById(self._e_event114);
        __o_rrpgObjs.removeEventListenerById(self._e_event113);
        __o_rrpgObjs.removeEventListenerById(self._e_event112);
        __o_rrpgObjs.removeEventListenerById(self._e_event111);
        __o_rrpgObjs.removeEventListenerById(self._e_event110);
        __o_rrpgObjs.removeEventListenerById(self._e_event109);
        __o_rrpgObjs.removeEventListenerById(self._e_event108);
        __o_rrpgObjs.removeEventListenerById(self._e_event107);
        __o_rrpgObjs.removeEventListenerById(self._e_event106);
        __o_rrpgObjs.removeEventListenerById(self._e_event105);
        __o_rrpgObjs.removeEventListenerById(self._e_event104);
        __o_rrpgObjs.removeEventListenerById(self._e_event103);
        __o_rrpgObjs.removeEventListenerById(self._e_event102);
        __o_rrpgObjs.removeEventListenerById(self._e_event101);
        __o_rrpgObjs.removeEventListenerById(self._e_event100);
        __o_rrpgObjs.removeEventListenerById(self._e_event99);
        __o_rrpgObjs.removeEventListenerById(self._e_event98);
        __o_rrpgObjs.removeEventListenerById(self._e_event97);
        __o_rrpgObjs.removeEventListenerById(self._e_event96);
        __o_rrpgObjs.removeEventListenerById(self._e_event95);
        __o_rrpgObjs.removeEventListenerById(self._e_event94);
        __o_rrpgObjs.removeEventListenerById(self._e_event93);
        __o_rrpgObjs.removeEventListenerById(self._e_event92);
        __o_rrpgObjs.removeEventListenerById(self._e_event91);
        __o_rrpgObjs.removeEventListenerById(self._e_event90);
        __o_rrpgObjs.removeEventListenerById(self._e_event89);
        __o_rrpgObjs.removeEventListenerById(self._e_event88);
        __o_rrpgObjs.removeEventListenerById(self._e_event87);
        __o_rrpgObjs.removeEventListenerById(self._e_event86);
        __o_rrpgObjs.removeEventListenerById(self._e_event85);
        __o_rrpgObjs.removeEventListenerById(self._e_event84);
        __o_rrpgObjs.removeEventListenerById(self._e_event83);
        __o_rrpgObjs.removeEventListenerById(self._e_event82);
        __o_rrpgObjs.removeEventListenerById(self._e_event81);
        __o_rrpgObjs.removeEventListenerById(self._e_event80);
        __o_rrpgObjs.removeEventListenerById(self._e_event79);
        __o_rrpgObjs.removeEventListenerById(self._e_event78);
        __o_rrpgObjs.removeEventListenerById(self._e_event77);
        __o_rrpgObjs.removeEventListenerById(self._e_event76);
        __o_rrpgObjs.removeEventListenerById(self._e_event75);
        __o_rrpgObjs.removeEventListenerById(self._e_event74);
        __o_rrpgObjs.removeEventListenerById(self._e_event73);
        __o_rrpgObjs.removeEventListenerById(self._e_event72);
        __o_rrpgObjs.removeEventListenerById(self._e_event71);
        __o_rrpgObjs.removeEventListenerById(self._e_event70);
        __o_rrpgObjs.removeEventListenerById(self._e_event69);
        __o_rrpgObjs.removeEventListenerById(self._e_event68);
        __o_rrpgObjs.removeEventListenerById(self._e_event67);
        __o_rrpgObjs.removeEventListenerById(self._e_event66);
        __o_rrpgObjs.removeEventListenerById(self._e_event65);
        __o_rrpgObjs.removeEventListenerById(self._e_event64);
        __o_rrpgObjs.removeEventListenerById(self._e_event63);
        __o_rrpgObjs.removeEventListenerById(self._e_event62);
        __o_rrpgObjs.removeEventListenerById(self._e_event61);
        __o_rrpgObjs.removeEventListenerById(self._e_event60);
        __o_rrpgObjs.removeEventListenerById(self._e_event59);
        __o_rrpgObjs.removeEventListenerById(self._e_event58);
        __o_rrpgObjs.removeEventListenerById(self._e_event57);
        __o_rrpgObjs.removeEventListenerById(self._e_event56);
        __o_rrpgObjs.removeEventListenerById(self._e_event55);
        __o_rrpgObjs.removeEventListenerById(self._e_event54);
        __o_rrpgObjs.removeEventListenerById(self._e_event53);
        __o_rrpgObjs.removeEventListenerById(self._e_event52);
        __o_rrpgObjs.removeEventListenerById(self._e_event51);
        __o_rrpgObjs.removeEventListenerById(self._e_event50);
        __o_rrpgObjs.removeEventListenerById(self._e_event49);
        __o_rrpgObjs.removeEventListenerById(self._e_event48);
        __o_rrpgObjs.removeEventListenerById(self._e_event47);
        __o_rrpgObjs.removeEventListenerById(self._e_event46);
        __o_rrpgObjs.removeEventListenerById(self._e_event45);
        __o_rrpgObjs.removeEventListenerById(self._e_event44);
        __o_rrpgObjs.removeEventListenerById(self._e_event43);
        __o_rrpgObjs.removeEventListenerById(self._e_event42);
        __o_rrpgObjs.removeEventListenerById(self._e_event41);
        __o_rrpgObjs.removeEventListenerById(self._e_event40);
        __o_rrpgObjs.removeEventListenerById(self._e_event39);
        __o_rrpgObjs.removeEventListenerById(self._e_event38);
        __o_rrpgObjs.removeEventListenerById(self._e_event37);
        __o_rrpgObjs.removeEventListenerById(self._e_event36);
        __o_rrpgObjs.removeEventListenerById(self._e_event35);
        __o_rrpgObjs.removeEventListenerById(self._e_event34);
        __o_rrpgObjs.removeEventListenerById(self._e_event33);
        __o_rrpgObjs.removeEventListenerById(self._e_event32);
        __o_rrpgObjs.removeEventListenerById(self._e_event31);
        __o_rrpgObjs.removeEventListenerById(self._e_event30);
        __o_rrpgObjs.removeEventListenerById(self._e_event29);
        __o_rrpgObjs.removeEventListenerById(self._e_event28);
        __o_rrpgObjs.removeEventListenerById(self._e_event27);
        __o_rrpgObjs.removeEventListenerById(self._e_event26);
        __o_rrpgObjs.removeEventListenerById(self._e_event25);
        __o_rrpgObjs.removeEventListenerById(self._e_event24);
        __o_rrpgObjs.removeEventListenerById(self._e_event23);
        __o_rrpgObjs.removeEventListenerById(self._e_event22);
        __o_rrpgObjs.removeEventListenerById(self._e_event21);
        __o_rrpgObjs.removeEventListenerById(self._e_event20);
        __o_rrpgObjs.removeEventListenerById(self._e_event19);
        __o_rrpgObjs.removeEventListenerById(self._e_event18);
        __o_rrpgObjs.removeEventListenerById(self._e_event17);
        __o_rrpgObjs.removeEventListenerById(self._e_event16);
        __o_rrpgObjs.removeEventListenerById(self._e_event15);
        __o_rrpgObjs.removeEventListenerById(self._e_event14);
        __o_rrpgObjs.removeEventListenerById(self._e_event13);
        __o_rrpgObjs.removeEventListenerById(self._e_event12);
        __o_rrpgObjs.removeEventListenerById(self._e_event11);
        __o_rrpgObjs.removeEventListenerById(self._e_event10);
        __o_rrpgObjs.removeEventListenerById(self._e_event9);
        __o_rrpgObjs.removeEventListenerById(self._e_event8);
        __o_rrpgObjs.removeEventListenerById(self._e_event7);
        __o_rrpgObjs.removeEventListenerById(self._e_event6);
        __o_rrpgObjs.removeEventListenerById(self._e_event5);
        __o_rrpgObjs.removeEventListenerById(self._e_event4);
        __o_rrpgObjs.removeEventListenerById(self._e_event3);
        __o_rrpgObjs.removeEventListenerById(self._e_event2);
        __o_rrpgObjs.removeEventListenerById(self._e_event1);
        __o_rrpgObjs.removeEventListenerById(self._e_event0);
    end;

    obj._oldLFMDestroy = obj.destroy;

    function obj:destroy() 
        self:_releaseEvents();

        if (self.handle ~= 0) and (self.setNodeDatabase ~= nil) then
          self:setNodeDatabase(nil);
        end;

        if self.scrollBox10 ~= nil then self.scrollBox10:destroy(); self.scrollBox10 = nil; end;
        if self.edit77 ~= nil then self.edit77:destroy(); self.edit77 = nil; end;
        if self.edit47 ~= nil then self.edit47:destroy(); self.edit47 = nil; end;
        if self.xpcminado ~= nil then self.xpcminado:destroy(); self.xpcminado = nil; end;
        if self.rectangle193 ~= nil then self.rectangle193:destroy(); self.rectangle193 = nil; end;
        if self.label164 ~= nil then self.label164:destroy(); self.label164 = nil; end;
        if self.label112 ~= nil then self.label112:destroy(); self.label112 = nil; end;
        if self.btn_lista_equipamentos ~= nil then self.btn_lista_equipamentos:destroy(); self.btn_lista_equipamentos = nil; end;
        if self.label245 ~= nil then self.label245:destroy(); self.label245 = nil; end;
        if self.label255 ~= nil then self.label255:destroy(); self.label255 = nil; end;
        if self.edit95 ~= nil then self.edit95:destroy(); self.edit95 = nil; end;
        if self.modgenius ~= nil then self.modgenius:destroy(); self.modgenius = nil; end;
        if self.rec_joalheria ~= nil then self.rec_joalheria:destroy(); self.rec_joalheria = nil; end;
        if self.rectangle71 ~= nil then self.rectangle71:destroy(); self.rectangle71 = nil; end;
        if self.comboBox14 ~= nil then self.comboBox14:destroy(); self.comboBox14 = nil; end;
        if self.modtdh ~= nil then self.modtdh:destroy(); self.modtdh = nil; end;
        if self.rectangle90 ~= nil then self.rectangle90:destroy(); self.rectangle90 = nil; end;
        if self.rectangle82 ~= nil then self.rectangle82:destroy(); self.rectangle82 = nil; end;
        if self.rec_agricultura ~= nil then self.rec_agricultura:destroy(); self.rec_agricultura = nil; end;
        if self.edit49 ~= nil then self.edit49:destroy(); self.edit49 = nil; end;
        if self.rectangle37 ~= nil then self.rectangle37:destroy(); self.rectangle37 = nil; end;
        if self.rectangle278 ~= nil then self.rectangle278:destroy(); self.rectangle278 = nil; end;
        if self.label67 ~= nil then self.label67:destroy(); self.label67 = nil; end;
        if self.label_aura ~= nil then self.label_aura:destroy(); self.label_aura = nil; end;
        if self.label118 ~= nil then self.label118:destroy(); self.label118 = nil; end;
        if self.label180 ~= nil then self.label180:destroy(); self.label180 = nil; end;
        if self.rectangle186 ~= nil then self.rectangle186:destroy(); self.rectangle186 = nil; end;
        if self.rectangle121 ~= nil then self.rectangle121:destroy(); self.rectangle121 = nil; end;
        if self.comboBox3 ~= nil then self.comboBox3:destroy(); self.comboBox3 = nil; end;
        if self.rectangle200 ~= nil then self.rectangle200:destroy(); self.rectangle200 = nil; end;
        if self.modrhour ~= nil then self.modrhour:destroy(); self.modrhour = nil; end;
        if self.aptitudemagia ~= nil then self.aptitudemagia:destroy(); self.aptitudemagia = nil; end;
        if self.rectangle156 ~= nil then self.rectangle156:destroy(); self.rectangle156 = nil; end;
        if self.label69 ~= nil then self.label69:destroy(); self.label69 = nil; end;
        if self.edit60 ~= nil then self.edit60:destroy(); self.edit60 = nil; end;
        if self.dataLink5 ~= nil then self.dataLink5:destroy(); self.dataLink5 = nil; end;
        if self.xptotaljogos ~= nil then self.xptotaljogos:destroy(); self.xptotaljogos = nil; end;
        if self.rectangle106 ~= nil then self.rectangle106:destroy(); self.rectangle106 = nil; end;
        if self.rectangle110 ~= nil then self.rectangle110:destroy(); self.rectangle110 = nil; end;
        if self.rectangle188 ~= nil then self.rectangle188:destroy(); self.rectangle188 = nil; end;
        if self.label173 ~= nil then self.label173:destroy(); self.label173 = nil; end;
        if self.d13 ~= nil then self.d13:destroy(); self.d13 = nil; end;
        if self.rectangle227 ~= nil then self.rectangle227:destroy(); self.rectangle227 = nil; end;
        if self.label39 ~= nil then self.label39:destroy(); self.label39 = nil; end;
        if self.rectangle257 ~= nil then self.rectangle257:destroy(); self.rectangle257 = nil; end;
        if self.label270 ~= nil then self.label270:destroy(); self.label270 = nil; end;
        if self.comboBox31 ~= nil then self.comboBox31:destroy(); self.comboBox31 = nil; end;
        if self.comboBox21 ~= nil then self.comboBox21:destroy(); self.comboBox21 = nil; end;
        if self.edit6 ~= nil then self.edit6:destroy(); self.edit6 = nil; end;
        if self.button3 ~= nil then self.button3:destroy(); self.button3 = nil; end;
        if self.dataLink41 ~= nil then self.dataLink41:destroy(); self.dataLink41 = nil; end;
        if self.dataLink51 ~= nil then self.dataLink51:destroy(); self.dataLink51 = nil; end;
        if self.image1 ~= nil then self.image1:destroy(); self.image1 = nil; end;
        if self.edit107 ~= nil then self.edit107:destroy(); self.edit107 = nil; end;
        if self.chk_bota ~= nil then self.chk_bota:destroy(); self.chk_bota = nil; end;
        if self.textodetalhes ~= nil then self.textodetalhes:destroy(); self.textodetalhes = nil; end;
        if self.label40 ~= nil then self.label40:destroy(); self.label40 = nil; end;
        if self.rectangle63 ~= nil then self.rectangle63:destroy(); self.rectangle63 = nil; end;
        if self.label33 ~= nil then self.label33:destroy(); self.label33 = nil; end;
        if self.detalhes_carpintaria ~= nil then self.detalhes_carpintaria:destroy(); self.detalhes_carpintaria = nil; end;
        if self.modbejeweled ~= nil then self.modbejeweled:destroy(); self.modbejeweled = nil; end;
        if self.label156 ~= nil then self.label156:destroy(); self.label156 = nil; end;
        if self.rectangle295 ~= nil then self.rectangle295:destroy(); self.rectangle295 = nil; end;
        if self.rectangle285 ~= nil then self.rectangle285:destroy(); self.rectangle285 = nil; end;
        if self.textEditor25 ~= nil then self.textEditor25:destroy(); self.textEditor25 = nil; end;
        if self.image27 ~= nil then self.image27:destroy(); self.image27 = nil; end;
        if self.layout2 ~= nil then self.layout2:destroy(); self.layout2 = nil; end;
        if self.rec_culinaria ~= nil then self.rec_culinaria:destroy(); self.rec_culinaria = nil; end;
        if self.dataLink68 ~= nil then self.dataLink68:destroy(); self.dataLink68 = nil; end;
        if self.button16 ~= nil then self.button16:destroy(); self.button16 = nil; end;
        if self.richEdit1 ~= nil then self.richEdit1:destroy(); self.richEdit1 = nil; end;
        if self.apdivina ~= nil then self.apdivina:destroy(); self.apdivina = nil; end;
        if self.aba_aura_magia ~= nil then self.aba_aura_magia:destroy(); self.aba_aura_magia = nil; end;
        if self.textEditor14 ~= nil then self.textEditor14:destroy(); self.textEditor14 = nil; end;
        if self.detalheEquipamento ~= nil then self.detalheEquipamento:destroy(); self.detalheEquipamento = nil; end;
        if self.label127 ~= nil then self.label127:destroy(); self.label127 = nil; end;
        if self.label206 ~= nil then self.label206:destroy(); self.label206 = nil; end;
        if self.label81 ~= nil then self.label81:destroy(); self.label81 = nil; end;
        if self.textEditor44 ~= nil then self.textEditor44:destroy(); self.textEditor44 = nil; end;
        if self.rectangle8 ~= nil then self.rectangle8:destroy(); self.rectangle8 = nil; end;
        if self.edit15 ~= nil then self.edit15:destroy(); self.edit15 = nil; end;
        if self.dataLink66 ~= nil then self.dataLink66:destroy(); self.dataLink66 = nil; end;
        if self.chk_raca_insectoide ~= nil then self.chk_raca_insectoide:destroy(); self.chk_raca_insectoide = nil; end;
        if self.dataLink74 ~= nil then self.dataLink74:destroy(); self.dataLink74 = nil; end;
        if self.xpbejeweled ~= nil then self.xpbejeweled:destroy(); self.xpbejeweled = nil; end;
        if self.label28 ~= nil then self.label28:destroy(); self.label28 = nil; end;
        if self.textEditor3 ~= nil then self.textEditor3:destroy(); self.textEditor3 = nil; end;
        if self.edit57 ~= nil then self.edit57:destroy(); self.edit57 = nil; end;
        if self.dataLink24 ~= nil then self.dataLink24:destroy(); self.dataLink24 = nil; end;
        if self.rectangle213 ~= nil then self.rectangle213:destroy(); self.rectangle213 = nil; end;
        if self.rectangle141 ~= nil then self.rectangle141:destroy(); self.rectangle141 = nil; end;
        if self.rectangle260 ~= nil then self.rectangle260:destroy(); self.rectangle260 = nil; end;
        if self.label100 ~= nil then self.label100:destroy(); self.label100 = nil; end;
        if self.label132 ~= nil then self.label132:destroy(); self.label132 = nil; end;
        if self.scrollBox1 ~= nil then self.scrollBox1:destroy(); self.scrollBox1 = nil; end;
        if self.label221 ~= nil then self.label221:destroy(); self.label221 = nil; end;
        if self.rectangle2 ~= nil then self.rectangle2:destroy(); self.rectangle2 = nil; end;
        if self.label50 ~= nil then self.label50:destroy(); self.label50 = nil; end;
        if self.label195 ~= nil then self.label195:destroy(); self.label195 = nil; end;
        if self.label231 ~= nil then self.label231:destroy(); self.label231 = nil; end;
        if self.tmrFiltroVinculo_1 ~= nil then self.tmrFiltroVinculo_1:destroy(); self.tmrFiltroVinculo_1 = nil; end;
        if self.btn_armadireitaequip ~= nil then self.btn_armadireitaequip:destroy(); self.btn_armadireitaequip = nil; end;
        if self.rectangle55 ~= nil then self.rectangle55:destroy(); self.rectangle55 = nil; end;
        if self.btnNovoTexto ~= nil then self.btnNovoTexto:destroy(); self.btnNovoTexto = nil; end;
        if self.label146 ~= nil then self.label146:destroy(); self.label146 = nil; end;
        if self.dataLink15 ~= nil then self.dataLink15:destroy(); self.dataLink15 = nil; end;
        if self.detalhes_criacao_animal ~= nil then self.detalhes_criacao_animal:destroy(); self.detalhes_criacao_animal = nil; end;
        if self.rec_pesca ~= nil then self.rec_pesca:destroy(); self.rec_pesca = nil; end;
        if self.label267 ~= nil then self.label267:destroy(); self.label267 = nil; end;
        if self.listavinculo_1 ~= nil then self.listavinculo_1:destroy(); self.listavinculo_1 = nil; end;
        if self.rectangle219 ~= nil then self.rectangle219:destroy(); self.rectangle219 = nil; end;
        if self.label210 ~= nil then self.label210:destroy(); self.label210 = nil; end;
        if self.rectangle27 ~= nil then self.rectangle27:destroy(); self.rectangle27 = nil; end;
        if self.rectangle17 ~= nil then self.rectangle17:destroy(); self.rectangle17 = nil; end;
        if self.label77 ~= nil then self.label77:destroy(); self.label77 = nil; end;
        if self.chk_perna ~= nil then self.chk_perna:destroy(); self.chk_perna = nil; end;
        if self.scrollBox15 ~= nil then self.scrollBox15:destroy(); self.scrollBox15 = nil; end;
        if self.edit78 ~= nil then self.edit78:destroy(); self.edit78 = nil; end;
        if self.tagsVinculo_1 ~= nil then self.tagsVinculo_1:destroy(); self.tagsVinculo_1 = nil; end;
        if self.rectangle168 ~= nil then self.rectangle168:destroy(); self.rectangle168 = nil; end;
        if self.rectangle190 ~= nil then self.rectangle190:destroy(); self.rectangle190 = nil; end;
        if self.label169 ~= nil then self.label169:destroy(); self.label169 = nil; end;
        if self.rectangle249 ~= nil then self.rectangle249:destroy(); self.rectangle249 = nil; end;
        if self.label248 ~= nil then self.label248:destroy(); self.label248 = nil; end;
        if self.xprhour ~= nil then self.xprhour:destroy(); self.xprhour = nil; end;
        if self.edit114 ~= nil then self.edit114:destroy(); self.edit114 = nil; end;
        if self.edit92 ~= nil then self.edit92:destroy(); self.edit92 = nil; end;
        if self.lista_equipamentos ~= nil then self.lista_equipamentos:destroy(); self.lista_equipamentos = nil; end;
        if self.d6 ~= nil then self.d6:destroy(); self.d6 = nil; end;
        if self.rectangle97 ~= nil then self.rectangle97:destroy(); self.rectangle97 = nil; end;
        if self.rectangle87 ~= nil then self.rectangle87:destroy(); self.rectangle87 = nil; end;
        if self.rectangle19 ~= nil then self.rectangle19:destroy(); self.rectangle19 = nil; end;
        if self.label97 ~= nil then self.label97:destroy(); self.label97 = nil; end;
        if self.chk_cabeca ~= nil then self.chk_cabeca:destroy(); self.chk_cabeca = nil; end;
        if self.image30 ~= nil then self.image30:destroy(); self.image30 = nil; end;
        if self.rectangle166 ~= nil then self.rectangle166:destroy(); self.rectangle166 = nil; end;
        if self.rectangle174 ~= nil then self.rectangle174:destroy(); self.rectangle174 = nil; end;
        if self.label163 ~= nil then self.label163:destroy(); self.label163 = nil; end;
        if self.rectangle247 ~= nil then self.rectangle247:destroy(); self.rectangle247 = nil; end;
        if self.label242 ~= nil then self.label242:destroy(); self.label242 = nil; end;
        if self.rectangle277 ~= nil then self.rectangle277:destroy(); self.rectangle277 = nil; end;
        if self.rectangle185 ~= nil then self.rectangle185:destroy(); self.rectangle185 = nil; end;
        if self.rectangle124 ~= nil then self.rectangle124:destroy(); self.rectangle124 = nil; end;
        if self.rectangle205 ~= nil then self.rectangle205:destroy(); self.rectangle205 = nil; end;
        if self.rectangle89 ~= nil then self.rectangle89:destroy(); self.rectangle89 = nil; end;
        if self.edit25 ~= nil then self.edit25:destroy(); self.edit25 = nil; end;
        if self.dataLink30 ~= nil then self.dataLink30:destroy(); self.dataLink30 = nil; end;
        if self.texto ~= nil then self.texto:destroy(); self.texto = nil; end;
        if self.lista_aura_magia ~= nil then self.lista_aura_magia:destroy(); self.lista_aura_magia = nil; end;
        if self.rectangle153 ~= nil then self.rectangle153:destroy(); self.rectangle153 = nil; end;
        if self.rectangle30 ~= nil then self.rectangle30:destroy(); self.rectangle30 = nil; end;
        if self.retangulo_aura ~= nil then self.retangulo_aura:destroy(); self.retangulo_aura = nil; end;
        if self.aba_skills ~= nil then self.aba_skills:destroy(); self.aba_skills = nil; end;
        if self.edit63 ~= nil then self.edit63:destroy(); self.edit63 = nil; end;
        if self.rectangle105 ~= nil then self.rectangle105:destroy(); self.rectangle105 = nil; end;
        if self.rectangle115 ~= nil then self.rectangle115:destroy(); self.rectangle115 = nil; end;
        if self.d10 ~= nil then self.d10:destroy(); self.d10 = nil; end;
        if self.label176 ~= nil then self.label176:destroy(); self.label176 = nil; end;
        if self.rectangle224 ~= nil then self.rectangle224:destroy(); self.rectangle224 = nil; end;
        if self.rectangle252 ~= nil then self.rectangle252:destroy(); self.rectangle252 = nil; end;
        if self.label275 ~= nil then self.label275:destroy(); self.label275 = nil; end;
        if self.aba_vinculos ~= nil then self.aba_vinculos:destroy(); self.aba_vinculos = nil; end;
        if self.comboBox34 ~= nil then self.comboBox34:destroy(); self.comboBox34 = nil; end;
        if self.comboBox22 ~= nil then self.comboBox22:destroy(); self.comboBox22 = nil; end;
        if self.edit5 ~= nil then self.edit5:destroy(); self.edit5 = nil; end;
        if self.edit104 ~= nil then self.edit104:destroy(); self.edit104 = nil; end;
        if self.edit69 ~= nil then self.edit69:destroy(); self.edit69 = nil; end;
        if self.dataLink2 ~= nil then self.dataLink2:destroy(); self.dataLink2 = nil; end;
        if self.image2 ~= nil then self.image2:destroy(); self.image2 = nil; end;
        if self.image15 ~= nil then self.image15:destroy(); self.image15 = nil; end;
        if self.rectangle258 ~= nil then self.rectangle258:destroy(); self.rectangle258 = nil; end;
        if self.label43 ~= nil then self.label43:destroy(); self.label43 = nil; end;
        if self.label178 ~= nil then self.label178:destroy(); self.label178 = nil; end;
        if self.btn_ombroequip ~= nil then self.btn_ombroequip:destroy(); self.btn_ombroequip = nil; end;
        if self.label30 ~= nil then self.label30:destroy(); self.label30 = nil; end;
        if self.edit39 ~= nil then self.edit39:destroy(); self.edit39 = nil; end;
        if self.comboBox28 ~= nil then self.comboBox28:destroy(); self.comboBox28 = nil; end;
        if self.apelemental ~= nil then self.apelemental:destroy(); self.apelemental = nil; end;
        if self.rectangle286 ~= nil then self.rectangle286:destroy(); self.rectangle286 = nil; end;
        if self.edtFiltroCategorias ~= nil then self.edtFiltroCategorias:destroy(); self.edtFiltroCategorias = nil; end;
        if self.rectangle298 ~= nil then self.rectangle298:destroy(); self.rectangle298 = nil; end;
        if self.textEditor20 ~= nil then self.textEditor20:destroy(); self.textEditor20 = nil; end;
        if self.image24 ~= nil then self.image24:destroy(); self.image24 = nil; end;
        if self.button4 ~= nil then self.button4:destroy(); self.button4 = nil; end;
        if self.dataLink46 ~= nil then self.dataLink46:destroy(); self.dataLink46 = nil; end;
        if self.dataLink58 ~= nil then self.dataLink58:destroy(); self.dataLink58 = nil; end;
        if self.image8 ~= nil then self.image8:destroy(); self.image8 = nil; end;
        if self.label49 ~= nil then self.label49:destroy(); self.label49 = nil; end;
        if self.edit18 ~= nil then self.edit18:destroy(); self.edit18 = nil; end;
        if self.button13 ~= nil then self.button13:destroy(); self.button13 = nil; end;
        if self.edit37 ~= nil then self.edit37:destroy(); self.edit37 = nil; end;
        if self.rectangle130 ~= nil then self.rectangle130:destroy(); self.rectangle130 = nil; end;
        if self.rectangle233 ~= nil then self.rectangle233:destroy(); self.rectangle233 = nil; end;
        if self.textEditor11 ~= nil then self.textEditor11:destroy(); self.textEditor11 = nil; end;
        if self.btnNovaVinculo_1 ~= nil then self.btnNovaVinculo_1:destroy(); self.btnNovaVinculo_1 = nil; end;
        if self.label19 ~= nil then self.label19:destroy(); self.label19 = nil; end;
        if self.explicacao_att ~= nil then self.explicacao_att:destroy(); self.explicacao_att = nil; end;
        if self.label124 ~= nil then self.label124:destroy(); self.label124 = nil; end;
        if self.label5 ~= nil then self.label5:destroy(); self.label5 = nil; end;
        if self.detalhes_mineracao ~= nil then self.detalhes_mineracao:destroy(); self.detalhes_mineracao = nil; end;
        if self.label205 ~= nil then self.label205:destroy(); self.label205 = nil; end;
        if self.detalhes_culinaria ~= nil then self.detalhes_culinaria:destroy(); self.detalhes_culinaria = nil; end;
        if self.rectangle45 ~= nil then self.rectangle45:destroy(); self.rectangle45 = nil; end;
        if self.edit12 ~= nil then self.edit12:destroy(); self.edit12 = nil; end;
        if self.dataLink61 ~= nil then self.dataLink61:destroy(); self.dataLink61 = nil; end;
        if self.dataLink71 ~= nil then self.dataLink71:destroy(); self.dataLink71 = nil; end;
        if self.edit87 ~= nil then self.edit87:destroy(); self.edit87 = nil; end;
        if self.richEdit6 ~= nil then self.richEdit6:destroy(); self.richEdit6 = nil; end;
        if self.label17 ~= nil then self.label17:destroy(); self.label17 = nil; end;
        if self.label27 ~= nil then self.label27:destroy(); self.label27 = nil; end;
        if self.edit54 ~= nil then self.edit54:destroy(); self.edit54 = nil; end;
        if self.dataLink27 ~= nil then self.dataLink27:destroy(); self.dataLink27 = nil; end;
        if self.rectangle216 ~= nil then self.rectangle216:destroy(); self.rectangle216 = nil; end;
        if self.tabela_atributos ~= nil then self.tabela_atributos:destroy(); self.tabela_atributos = nil; end;
        if self.label131 ~= nil then self.label131:destroy(); self.label131 = nil; end;
        if self.scrollBox4 ~= nil then self.scrollBox4:destroy(); self.scrollBox4 = nil; end;
        if self.detalheSkill ~= nil then self.detalheSkill:destroy(); self.detalheSkill = nil; end;
        if self.rectangle7 ~= nil then self.rectangle7:destroy(); self.rectangle7 = nil; end;
        if self.label55 ~= nil then self.label55:destroy(); self.label55 = nil; end;
        if self.label190 ~= nil then self.label190:destroy(); self.label190 = nil; end;
        if self.label232 ~= nil then self.label232:destroy(); self.label232 = nil; end;
        if self.combo_raca ~= nil then self.combo_raca:destroy(); self.combo_raca = nil; end;
        if self.rectangle50 ~= nil then self.rectangle50:destroy(); self.rectangle50 = nil; end;
        if self.apdemoniaca ~= nil then self.apdemoniaca:destroy(); self.apdemoniaca = nil; end;
        if self.dataLink82 ~= nil then self.dataLink82:destroy(); self.dataLink82 = nil; end;
        if self.textEditor8 ~= nil then self.textEditor8:destroy(); self.textEditor8 = nil; end;
        if self.edtFiltroEquipamentos ~= nil then self.edtFiltroEquipamentos:destroy(); self.edtFiltroEquipamentos = nil; end;
        if self.rectangle28 ~= nil then self.rectangle28:destroy(); self.rectangle28 = nil; end;
        if self.rectangle146 ~= nil then self.rectangle146:destroy(); self.rectangle146 = nil; end;
        if self.label74 ~= nil then self.label74:destroy(); self.label74 = nil; end;
        if self.textEditor34 ~= nil then self.textEditor34:destroy(); self.textEditor34 = nil; end;
        if self.afauras ~= nil then self.afauras:destroy(); self.afauras = nil; end;
        if self.label238 ~= nil then self.label238:destroy(); self.label238 = nil; end;
        if self.chk_raca_anao ~= nil then self.chk_raca_anao:destroy(); self.chk_raca_anao = nil; end;
        if self.rectangle267 ~= nil then self.rectangle267:destroy(); self.rectangle267 = nil; end;
        if self.rectangle195 ~= nil then self.rectangle195:destroy(); self.rectangle195 = nil; end;
        if self.edit113 ~= nil then self.edit113:destroy(); self.edit113 = nil; end;
        if self.label141 ~= nil then self.label141:destroy(); self.label141 = nil; end;
        if self.label260 ~= nil then self.label260:destroy(); self.label260 = nil; end;
        if self.d5 ~= nil then self.d5:destroy(); self.d5 = nil; end;
        if self.label217 ~= nil then self.label217:destroy(); self.label217 = nil; end;
        if self.rectangle84 ~= nil then self.rectangle84:destroy(); self.rectangle84 = nil; end;
        if self.label90 ~= nil then self.label90:destroy(); self.label90 = nil; end;
        if self.chk_raca_elfo ~= nil then self.chk_raca_elfo:destroy(); self.chk_raca_elfo = nil; end;
        if self.edit73 ~= nil then self.edit73:destroy(); self.edit73 = nil; end;
        if self.edit43 ~= nil then self.edit43:destroy(); self.edit43 = nil; end;
        if self.nometexto ~= nil then self.nometexto:destroy(); self.nometexto = nil; end;
        if self.ficha ~= nil then self.ficha:destroy(); self.ficha = nil; end;
        if self.rectangle161 ~= nil then self.rectangle161:destroy(); self.rectangle161 = nil; end;
        if self.rectangle171 ~= nil then self.rectangle171:destroy(); self.rectangle171 = nil; end;
        if self.label160 ~= nil then self.label160:destroy(); self.label160 = nil; end;
        if self.label116 ~= nil then self.label116:destroy(); self.label116 = nil; end;
        if self.rectangle240 ~= nil then self.rectangle240:destroy(); self.rectangle240 = nil; end;
        if self.label241 ~= nil then self.label241:destroy(); self.label241 = nil; end;
        if self.detalhes_pesca ~= nil then self.detalhes_pesca:destroy(); self.detalhes_pesca = nil; end;
        if self.edit99 ~= nil then self.edit99:destroy(); self.edit99 = nil; end;
        if self.label251 ~= nil then self.label251:destroy(); self.label251 = nil; end;
        if self.apmental ~= nil then self.apmental:destroy(); self.apmental = nil; end;
        if self.afinidadesaura ~= nil then self.afinidadesaura:destroy(); self.afinidadesaura = nil; end;
        if self.comboBox10 ~= nil then self.comboBox10:destroy(); self.comboBox10 = nil; end;
        if self.rectangle75 ~= nil then self.rectangle75:destroy(); self.rectangle75 = nil; end;
        if self.rectangle272 ~= nil then self.rectangle272:destroy(); self.rectangle272 = nil; end;
        if self.rectangle127 ~= nil then self.rectangle127:destroy(); self.rectangle127 = nil; end;
        if self.comboBox5 ~= nil then self.comboBox5:destroy(); self.comboBox5 = nil; end;
        if self.btn_botaequip ~= nil then self.btn_botaequip:destroy(); self.btn_botaequip = nil; end;
        if self.edit20 ~= nil then self.edit20:destroy(); self.edit20 = nil; end;
        if self.dataLink35 ~= nil then self.dataLink35:destroy(); self.dataLink35 = nil; end;
        if self.rectangle206 ~= nil then self.rectangle206:destroy(); self.rectangle206 = nil; end;
        if self.rectangle150 ~= nil then self.rectangle150:destroy(); self.rectangle150 = nil; end;
        if self.rectangle33 ~= nil then self.rectangle33:destroy(); self.rectangle33 = nil; end;
        if self.tabela_mods_fabricacao ~= nil then self.tabela_mods_fabricacao:destroy(); self.tabela_mods_fabricacao = nil; end;
        if self.label63 ~= nil then self.label63:destroy(); self.label63 = nil; end;
        if self.label184 ~= nil then self.label184:destroy(); self.label184 = nil; end;
        if self.edit66 ~= nil then self.edit66:destroy(); self.edit66 = nil; end;
        if self.modsudoku ~= nil then self.modsudoku:destroy(); self.modsudoku = nil; end;
        if self.rectangle108 ~= nil then self.rectangle108:destroy(); self.rectangle108 = nil; end;
        if self.rectangle229 ~= nil then self.rectangle229:destroy(); self.rectangle229 = nil; end;
        if self.rectangle182 ~= nil then self.rectangle182:destroy(); self.rectangle182 = nil; end;
        if self.label175 ~= nil then self.label175:destroy(); self.label175 = nil; end;
        if self.chk_raca_merfolk ~= nil then self.chk_raca_merfolk:destroy(); self.chk_raca_merfolk = nil; end;
        if self.label276 ~= nil then self.label276:destroy(); self.label276 = nil; end;
        if self.comboBox37 ~= nil then self.comboBox37:destroy(); self.comboBox37 = nil; end;
        if self.comboBox27 ~= nil then self.comboBox27:destroy(); self.comboBox27 = nil; end;
        if self.rectangle39 ~= nil then self.rectangle39:destroy(); self.rectangle39 = nil; end;
        if self.edit101 ~= nil then self.edit101:destroy(); self.edit101 = nil; end;
        if self.button9 ~= nil then self.button9:destroy(); self.button9 = nil; end;
        if self.image10 ~= nil then self.image10:destroy(); self.image10 = nil; end;
        if self.dataLink1 ~= nil then self.dataLink1:destroy(); self.dataLink1 = nil; end;
        if self.rectangle102 ~= nil then self.rectangle102:destroy(); self.rectangle102 = nil; end;
        if self.rectangle223 ~= nil then self.rectangle223:destroy(); self.rectangle223 = nil; end;
        if self.label46 ~= nil then self.label46:destroy(); self.label46 = nil; end;
        if self.rectangle69 ~= nil then self.rectangle69:destroy(); self.rectangle69 = nil; end;
        if self.chk_costas ~= nil then self.chk_costas:destroy(); self.chk_costas = nil; end;
        if self.textEditor23 ~= nil then self.textEditor23:destroy(); self.textEditor23 = nil; end;
        if self.image21 ~= nil then self.image21:destroy(); self.image21 = nil; end;
        if self.button7 ~= nil then self.button7:destroy(); self.button7 = nil; end;
        if self.dataLink45 ~= nil then self.dataLink45:destroy(); self.dataLink45 = nil; end;
        if self.dataLink55 ~= nil then self.dataLink55:destroy(); self.dataLink55 = nil; end;
        if self.image5 ~= nil then self.image5:destroy(); self.image5 = nil; end;
        if self.rectangle48 ~= nil then self.rectangle48:destroy(); self.rectangle48 = nil; end;
        if self.rectangle67 ~= nil then self.rectangle67:destroy(); self.rectangle67 = nil; end;
        if self.label37 ~= nil then self.label37:destroy(); self.label37 = nil; end;
        if self.edit88 ~= nil then self.edit88:destroy(); self.edit88 = nil; end;
        if self.edit30 ~= nil then self.edit30:destroy(); self.edit30 = nil; end;
        if self.rectangle135 ~= nil then self.rectangle135:destroy(); self.rectangle135 = nil; end;
        if self.rectangle236 ~= nil then self.rectangle236:destroy(); self.rectangle236 = nil; end;
        if self.label152 ~= nil then self.label152:destroy(); self.label152 = nil; end;
        if self.modptiles ~= nil then self.modptiles:destroy(); self.modptiles = nil; end;
        if self.rectangle281 ~= nil then self.rectangle281:destroy(); self.rectangle281 = nil; end;
        if self.rectangle291 ~= nil then self.rectangle291:destroy(); self.rectangle291 = nil; end;
        if self.label121 ~= nil then self.label121:destroy(); self.label121 = nil; end;
        if self.label200 ~= nil then self.label200:destroy(); self.label200 = nil; end;
        if self.chk_raca_stonelith ~= nil then self.chk_raca_stonelith:destroy(); self.chk_raca_stonelith = nil; end;
        if self.rectangle42 ~= nil then self.rectangle42:destroy(); self.rectangle42 = nil; end;
        if self.dataLink72 ~= nil then self.dataLink72:destroy(); self.dataLink72 = nil; end;
        if self.edit82 ~= nil then self.edit82:destroy(); self.edit82 = nil; end;
        if self.richEdit5 ~= nil then self.richEdit5:destroy(); self.richEdit5 = nil; end;
        if self.rectangle238 ~= nil then self.rectangle238:destroy(); self.rectangle238 = nil; end;
        if self.xp2048 ~= nil then self.xp2048:destroy(); self.xp2048 = nil; end;
        if self.label158 ~= nil then self.label158:destroy(); self.label158 = nil; end;
        if self.textEditor18 ~= nil then self.textEditor18:destroy(); self.textEditor18 = nil; end;
        if self.label10 ~= nil then self.label10:destroy(); self.label10 = nil; end;
        if self.label22 ~= nil then self.label22:destroy(); self.label22 = nil; end;
        if self.btn_pescocoequip ~= nil then self.btn_pescocoequip:destroy(); self.btn_pescocoequip = nil; end;
        if self.edit59 ~= nil then self.edit59:destroy(); self.edit59 = nil; end;
        if self.label85 ~= nil then self.label85:destroy(); self.label85 = nil; end;
        if self.afmagias ~= nil then self.afmagias:destroy(); self.afmagias = nil; end;
        if self.textEditor40 ~= nil then self.textEditor40:destroy(); self.textEditor40 = nil; end;
        if self.rectangle4 ~= nil then self.rectangle4:destroy(); self.rectangle4 = nil; end;
        if self.label56 ~= nil then self.label56:destroy(); self.label56 = nil; end;
        if self.label193 ~= nil then self.label193:destroy(); self.label193 = nil; end;
        if self.dataLink78 ~= nil then self.dataLink78:destroy(); self.dataLink78 = nil; end;
        if self.dataLink81 ~= nil then self.dataLink81:destroy(); self.dataLink81 = nil; end;
        if self.textEditor7 ~= nil then self.textEditor7:destroy(); self.textEditor7 = nil; end;
        if self.edit53 ~= nil then self.edit53:destroy(); self.edit53 = nil; end;
        if self.dataLink20 ~= nil then self.dataLink20:destroy(); self.dataLink20 = nil; end;
        if self.edtFiltroSkills ~= nil then self.edtFiltroSkills:destroy(); self.edtFiltroSkills = nil; end;
        if self.listaequipamento ~= nil then self.listaequipamento:destroy(); self.listaequipamento = nil; end;
        if self.textEditor31 ~= nil then self.textEditor31:destroy(); self.textEditor31 = nil; end;
        if self.rectangle145 ~= nil then self.rectangle145:destroy(); self.rectangle145 = nil; end;
        if self.label79 ~= nil then self.label79:destroy(); self.label79 = nil; end;
        if self.label104 ~= nil then self.label104:destroy(); self.label104 = nil; end;
        if self.label136 ~= nil then self.label136:destroy(); self.label136 = nil; end;
        if self.label225 ~= nil then self.label225:destroy(); self.label225 = nil; end;
        if self.detalhes_agricultura ~= nil then self.detalhes_agricultura:destroy(); self.detalhes_agricultura = nil; end;
        if self.label235 ~= nil then self.label235:destroy(); self.label235 = nil; end;
        if self.rectangle264 ~= nil then self.rectangle264:destroy(); self.rectangle264 = nil; end;
        if self.rectangle59 ~= nil then self.rectangle59:destroy(); self.rectangle59 = nil; end;
        if self.label142 ~= nil then self.label142:destroy(); self.label142 = nil; end;
        if self.dataLink11 ~= nil then self.dataLink11:destroy(); self.dataLink11 = nil; end;
        if self.apespiritual ~= nil then self.apespiritual:destroy(); self.apespiritual = nil; end;
        if self.label263 ~= nil then self.label263:destroy(); self.label263 = nil; end;
        if self.btn_costasequip ~= nil then self.btn_costasequip:destroy(); self.btn_costasequip = nil; end;
        if self.rectangle99 ~= nil then self.rectangle99:destroy(); self.rectangle99 = nil; end;
        if self.rectangle23 ~= nil then self.rectangle23:destroy(); self.rectangle23 = nil; end;
        if self.rectangle13 ~= nil then self.rectangle13:destroy(); self.rectangle13 = nil; end;
        if self.label73 ~= nil then self.label73:destroy(); self.label73 = nil; end;
        if self.label214 ~= nil then self.label214:destroy(); self.label214 = nil; end;
        if self.detalhes_alquimia ~= nil then self.detalhes_alquimia:destroy(); self.detalhes_alquimia = nil; end;
        if self.edit74 ~= nil then self.edit74:destroy(); self.edit74 = nil; end;
        if self.edit46 ~= nil then self.edit46:destroy(); self.edit46 = nil; end;
        if self.scrollBox11 ~= nil then self.scrollBox11:destroy(); self.scrollBox11 = nil; end;
        if self.rectangle172 ~= nil then self.rectangle172:destroy(); self.rectangle172 = nil; end;
        if self.label165 ~= nil then self.label165:destroy(); self.label165 = nil; end;
        if self.label111 ~= nil then self.label111:destroy(); self.label111 = nil; end;
        if self.label244 ~= nil then self.label244:destroy(); self.label244 = nil; end;
        if self.label256 ~= nil then self.label256:destroy(); self.label256 = nil; end;
        if self.rectangle271 ~= nil then self.rectangle271:destroy(); self.rectangle271 = nil; end;
        if self.edit96 ~= nil then self.edit96:destroy(); self.edit96 = nil; end;
        if self.xpsudoku ~= nil then self.xpsudoku:destroy(); self.xpsudoku = nil; end;
        if self.comboBox17 ~= nil then self.comboBox17:destroy(); self.comboBox17 = nil; end;
        if self.rectangle70 ~= nil then self.rectangle70:destroy(); self.rectangle70 = nil; end;
        if self.rectangle93 ~= nil then self.rectangle93:destroy(); self.rectangle93 = nil; end;
        if self.rectangle83 ~= nil then self.rectangle83:destroy(); self.rectangle83 = nil; end;
        if self.edit23 ~= nil then self.edit23:destroy(); self.edit23 = nil; end;
        if self.dataLink36 ~= nil then self.dataLink36:destroy(); self.dataLink36 = nil; end;
        if self.edit48 ~= nil then self.edit48:destroy(); self.edit48 = nil; end;
        if self.rectangle36 ~= nil then self.rectangle36:destroy(); self.rectangle36 = nil; end;
        if self.rectangle178 ~= nil then self.rectangle178:destroy(); self.rectangle178 = nil; end;
        if self.label66 ~= nil then self.label66:destroy(); self.label66 = nil; end;
        if self.label181 ~= nil then self.label181:destroy(); self.label181 = nil; end;
        if self.label258 ~= nil then self.label258:destroy(); self.label258 = nil; end;
        if self.apclarevidencia ~= nil then self.apclarevidencia:destroy(); self.apclarevidencia = nil; end;
        if self.rectangle181 ~= nil then self.rectangle181:destroy(); self.rectangle181 = nil; end;
        if self.rectangle120 ~= nil then self.rectangle120:destroy(); self.rectangle120 = nil; end;
        if self.rectangle201 ~= nil then self.rectangle201:destroy(); self.rectangle201 = nil; end;
        if self.edit29 ~= nil then self.edit29:destroy(); self.edit29 = nil; end;
        if self.rectangle157 ~= nil then self.rectangle157:destroy(); self.rectangle157 = nil; end;
        if self.rec_criacao_animal ~= nil then self.rec_criacao_animal:destroy(); self.rec_criacao_animal = nil; end;
        if self.label68 ~= nil then self.label68:destroy(); self.label68 = nil; end;
        if self.image13 ~= nil then self.image13:destroy(); self.image13 = nil; end;
        if self.dataLink4 ~= nil then self.dataLink4:destroy(); self.dataLink4 = nil; end;
        if self.apreforcomental ~= nil then self.apreforcomental:destroy(); self.apreforcomental = nil; end;
        if self.rectangle101 ~= nil then self.rectangle101:destroy(); self.rectangle101 = nil; end;
        if self.rectangle111 ~= nil then self.rectangle111:destroy(); self.rectangle111 = nil; end;
        if self.d14 ~= nil then self.d14:destroy(); self.d14 = nil; end;
        if self.label172 ~= nil then self.label172:destroy(); self.label172 = nil; end;
        if self.rectangle220 ~= nil then self.rectangle220:destroy(); self.rectangle220 = nil; end;
        if self.rectangle256 ~= nil then self.rectangle256:destroy(); self.rectangle256 = nil; end;
        if self.label271 ~= nil then self.label271:destroy(); self.label271 = nil; end;
        if self.comboBox30 ~= nil then self.comboBox30:destroy(); self.comboBox30 = nil; end;
        if self.apreforcofisico ~= nil then self.apreforcofisico:destroy(); self.apreforcofisico = nil; end;
        if self.button2 ~= nil then self.button2:destroy(); self.button2 = nil; end;
        if self.dataLink40 ~= nil then self.dataLink40:destroy(); self.dataLink40 = nil; end;
        if self.dataLink52 ~= nil then self.dataLink52:destroy(); self.dataLink52 = nil; end;
        if self.image6 ~= nil then self.image6:destroy(); self.image6 = nil; end;
        if self.rectangle60 ~= nil then self.rectangle60:destroy(); self.rectangle60 = nil; end;
        if self.label34 ~= nil then self.label34:destroy(); self.label34 = nil; end;
        if self.detalhe_vinculo_1 ~= nil then self.detalhe_vinculo_1:destroy(); self.detalhe_vinculo_1 = nil; end;
        if self.tmrFiltroTextos ~= nil then self.tmrFiltroTextos:destroy(); self.tmrFiltroTextos = nil; end;
        if self.rectangle136 ~= nil then self.rectangle136:destroy(); self.rectangle136 = nil; end;
        if self.rectangle235 ~= nil then self.rectangle235:destroy(); self.rectangle235 = nil; end;
        if self.label155 ~= nil then self.label155:destroy(); self.label155 = nil; end;
        if self.rectangle294 ~= nil then self.rectangle294:destroy(); self.rectangle294 = nil; end;
        if self.rectangle282 ~= nil then self.rectangle282:destroy(); self.rectangle282 = nil; end;
        if self.textEditor24 ~= nil then self.textEditor24:destroy(); self.textEditor24 = nil; end;
        if self.label3 ~= nil then self.label3:destroy(); self.label3 = nil; end;
        if self.image28 ~= nil then self.image28:destroy(); self.image28 = nil; end;
        if self.condicoescorpo ~= nil then self.condicoescorpo:destroy(); self.condicoescorpo = nil; end;
        if self.layout1 ~= nil then self.layout1:destroy(); self.layout1 = nil; end;
        if self.afinidadesmagia ~= nil then self.afinidadesmagia:destroy(); self.afinidadesmagia = nil; end;
        if self.button17 ~= nil then self.button17:destroy(); self.button17 = nil; end;
        if self.rectangle300 ~= nil then self.rectangle300:destroy(); self.rectangle300 = nil; end;
        if self.edit81 ~= nil then self.edit81:destroy(); self.edit81 = nil; end;
        if self.textEditor15 ~= nil then self.textEditor15:destroy(); self.textEditor15 = nil; end;
        if self.rectangle288 ~= nil then self.rectangle288:destroy(); self.rectangle288 = nil; end;
        if self.label21 ~= nil then self.label21:destroy(); self.label21 = nil; end;
        if self.label80 ~= nil then self.label80:destroy(); self.label80 = nil; end;
        if self.rectangle9 ~= nil then self.rectangle9:destroy(); self.rectangle9 = nil; end;
        if self.edit16 ~= nil then self.edit16:destroy(); self.edit16 = nil; end;
        if self.dataLink65 ~= nil then self.dataLink65:destroy(); self.dataLink65 = nil; end;
        if self.dataLink75 ~= nil then self.dataLink75:destroy(); self.dataLink75 = nil; end;
        if self.textEditor2 ~= nil then self.textEditor2:destroy(); self.textEditor2 = nil; end;
        if self.edit50 ~= nil then self.edit50:destroy(); self.edit50 = nil; end;
        if self.dataLink23 ~= nil then self.dataLink23:destroy(); self.dataLink23 = nil; end;
        if self.rectangle212 ~= nil then self.rectangle212:destroy(); self.rectangle212 = nil; end;
        if self.xpbnaval ~= nil then self.xpbnaval:destroy(); self.xpbnaval = nil; end;
        if self.textEditor32 ~= nil then self.textEditor32:destroy(); self.textEditor32 = nil; end;
        if self.rectangle140 ~= nil then self.rectangle140:destroy(); self.rectangle140 = nil; end;
        if self.rectangle261 ~= nil then self.rectangle261:destroy(); self.rectangle261 = nil; end;
        if self.label101 ~= nil then self.label101:destroy(); self.label101 = nil; end;
        if self.label135 ~= nil then self.label135:destroy(); self.label135 = nil; end;
        if self.label220 ~= nil then self.label220:destroy(); self.label220 = nil; end;
        if self.label236 ~= nil then self.label236:destroy(); self.label236 = nil; end;
        if self.rectangle3 ~= nil then self.rectangle3:destroy(); self.rectangle3 = nil; end;
        if self.label51 ~= nil then self.label51:destroy(); self.label51 = nil; end;
        if self.label194 ~= nil then self.label194:destroy(); self.label194 = nil; end;
        if self.xpcmagico ~= nil then self.xpcmagico:destroy(); self.xpcmagico = nil; end;
        if self.inventario ~= nil then self.inventario:destroy(); self.inventario = nil; end;
        if self.label281 ~= nil then self.label281:destroy(); self.label281 = nil; end;
        if self.rectangle54 ~= nil then self.rectangle54:destroy(); self.rectangle54 = nil; end;
        if self.modmmaze ~= nil then self.modmmaze:destroy(); self.modmmaze = nil; end;
        if self.label147 ~= nil then self.label147:destroy(); self.label147 = nil; end;
        if self.dataLink16 ~= nil then self.dataLink16:destroy(); self.dataLink16 = nil; end;
        if self.rec_alquimia ~= nil then self.rec_alquimia:destroy(); self.rec_alquimia = nil; end;
        if self.label266 ~= nil then self.label266:destroy(); self.label266 = nil; end;
        if self.btn_maodireitaequip ~= nil then self.btn_maodireitaequip:destroy(); self.btn_maodireitaequip = nil; end;
        if self.rectangle218 ~= nil then self.rectangle218:destroy(); self.rectangle218 = nil; end;
        if self.label211 ~= nil then self.label211:destroy(); self.label211 = nil; end;
        if self.rectangle24 ~= nil then self.rectangle24:destroy(); self.rectangle24 = nil; end;
        if self.rectangle16 ~= nil then self.rectangle16:destroy(); self.rectangle16 = nil; end;
        if self.label70 ~= nil then self.label70:destroy(); self.label70 = nil; end;
        if self.textEditor38 ~= nil then self.textEditor38:destroy(); self.textEditor38 = nil; end;
        if self.scrollBox16 ~= nil then self.scrollBox16:destroy(); self.scrollBox16 = nil; end;
        if self.edit79 ~= nil then self.edit79:destroy(); self.edit79 = nil; end;
        if self.edit45 ~= nil then self.edit45:destroy(); self.edit45 = nil; end;
        if self.rectangle191 ~= nil then self.rectangle191:destroy(); self.rectangle191 = nil; end;
        if self.xpgenius ~= nil then self.xpgenius:destroy(); self.xpgenius = nil; end;
        if self.edit93 ~= nil then self.edit93:destroy(); self.edit93 = nil; end;
        if self.dataLink18 ~= nil then self.dataLink18:destroy(); self.dataLink18 = nil; end;
        if self.rectangle73 ~= nil then self.rectangle73:destroy(); self.rectangle73 = nil; end;
        if self.rectangle96 ~= nil then self.rectangle96:destroy(); self.rectangle96 = nil; end;
        if self.rectangle80 ~= nil then self.rectangle80:destroy(); self.rectangle80 = nil; end;
        if self.rectangle18 ~= nil then self.rectangle18:destroy(); self.rectangle18 = nil; end;
        if self.label94 ~= nil then self.label94:destroy(); self.label94 = nil; end;
        if self.equipamentos_equipados ~= nil then self.equipamentos_equipados:destroy(); self.equipamentos_equipados = nil; end;
        if self.rectangle165 ~= nil then self.rectangle165:destroy(); self.rectangle165 = nil; end;
        if self.rectangle175 ~= nil then self.rectangle175:destroy(); self.rectangle175 = nil; end;
        if self.label65 ~= nil then self.label65:destroy(); self.label65 = nil; end;
        if self.label182 ~= nil then self.label182:destroy(); self.label182 = nil; end;
        if self.rectangle244 ~= nil then self.rectangle244:destroy(); self.rectangle244 = nil; end;
        if self.rectangle276 ~= nil then self.rectangle276:destroy(); self.rectangle276 = nil; end;
        if self.rectangle184 ~= nil then self.rectangle184:destroy(); self.rectangle184 = nil; end;
        if self.rectangle79 ~= nil then self.rectangle79:destroy(); self.rectangle79 = nil; end;
        if self.aba_classe ~= nil then self.aba_classe:destroy(); self.aba_classe = nil; end;
        if self.rectangle123 ~= nil then self.rectangle123:destroy(); self.rectangle123 = nil; end;
        if self.comboBox1 ~= nil then self.comboBox1:destroy(); self.comboBox1 = nil; end;
        if self.rectangle202 ~= nil then self.rectangle202:destroy(); self.rectangle202 = nil; end;
        if self.edit24 ~= nil then self.edit24:destroy(); self.edit24 = nil; end;
        if self.dataLink31 ~= nil then self.dataLink31:destroy(); self.dataLink31 = nil; end;
        if self.rectangle154 ~= nil then self.rectangle154:destroy(); self.rectangle154 = nil; end;
        if self.label188 ~= nil then self.label188:destroy(); self.label188 = nil; end;
        if self.listaskills ~= nil then self.listaskills:destroy(); self.listaskills = nil; end;
        if self.edit62 ~= nil then self.edit62:destroy(); self.edit62 = nil; end;
        if self.rectangle104 ~= nil then self.rectangle104:destroy(); self.rectangle104 = nil; end;
        if self.rectangle116 ~= nil then self.rectangle116:destroy(); self.rectangle116 = nil; end;
        if self.d11 ~= nil then self.d11:destroy(); self.d11 = nil; end;
        if self.label171 ~= nil then self.label171:destroy(); self.label171 = nil; end;
        if self.btn_pernaequip ~= nil then self.btn_pernaequip:destroy(); self.btn_pernaequip = nil; end;
        if self.rectangle225 ~= nil then self.rectangle225:destroy(); self.rectangle225 = nil; end;
        if self.chk_raca_humano ~= nil then self.chk_raca_humano:destroy(); self.chk_raca_humano = nil; end;
        if self.rectangle251 ~= nil then self.rectangle251:destroy(); self.rectangle251 = nil; end;
        if self.label272 ~= nil then self.label272:destroy(); self.label272 = nil; end;
        if self.modmahjong ~= nil then self.modmahjong:destroy(); self.modmahjong = nil; end;
        if self.comboBox33 ~= nil then self.comboBox33:destroy(); self.comboBox33 = nil; end;
        if self.comboBox23 ~= nil then self.comboBox23:destroy(); self.comboBox23 = nil; end;
        if self.textEditor29 ~= nil then self.textEditor29:destroy(); self.textEditor29 = nil; end;
        if self.xpmmaze ~= nil then self.xpmmaze:destroy(); self.xpmmaze = nil; end;
        if self.edit4 ~= nil then self.edit4:destroy(); self.edit4 = nil; end;
        if self.edit105 ~= nil then self.edit105:destroy(); self.edit105 = nil; end;
        if self.edit68 ~= nil then self.edit68:destroy(); self.edit68 = nil; end;
        if self.image14 ~= nil then self.image14:destroy(); self.image14 = nil; end;
        if self.image3 ~= nil then self.image3:destroy(); self.image3 = nil; end;
        if self.rectangle118 ~= nil then self.rectangle118:destroy(); self.rectangle118 = nil; end;
        if self.label42 ~= nil then self.label42:destroy(); self.label42 = nil; end;
        if self.label278 ~= nil then self.label278:destroy(); self.label278 = nil; end;
        if self.label31 ~= nil then self.label31:destroy(); self.label31 = nil; end;
        if self.detalhes_alfaiataria ~= nil then self.detalhes_alfaiataria:destroy(); self.detalhes_alfaiataria = nil; end;
        if self.bntNovacategoria ~= nil then self.bntNovacategoria:destroy(); self.bntNovacategoria = nil; end;
        if self.comboBox29 ~= nil then self.comboBox29:destroy(); self.comboBox29 = nil; end;
        if self.rectangle297 ~= nil then self.rectangle297:destroy(); self.rectangle297 = nil; end;
        if self.rectangle287 ~= nil then self.rectangle287:destroy(); self.rectangle287 = nil; end;
        if self.textEditor27 ~= nil then self.textEditor27:destroy(); self.textEditor27 = nil; end;
        if self.image25 ~= nil then self.image25:destroy(); self.image25 = nil; end;
        if self.chk_torso ~= nil then self.chk_torso:destroy(); self.chk_torso = nil; end;
        if self.dataLink59 ~= nil then self.dataLink59:destroy(); self.dataLink59 = nil; end;
        if self.btn_equipar_acao ~= nil then self.btn_equipar_acao:destroy(); self.btn_equipar_acao = nil; end;
        if self.image9 ~= nil then self.image9:destroy(); self.image9 = nil; end;
        if self.label48 ~= nil then self.label48:destroy(); self.label48 = nil; end;
        if self.edit19 ~= nil then self.edit19:destroy(); self.edit19 = nil; end;
        if self.button10 ~= nil then self.button10:destroy(); self.button10 = nil; end;
        if self.apemissao ~= nil then self.apemissao:destroy(); self.apemissao = nil; end;
        if self.edit34 ~= nil then self.edit34:destroy(); self.edit34 = nil; end;
        if self.rectangle131 ~= nil then self.rectangle131:destroy(); self.rectangle131 = nil; end;
        if self.rectangle232 ~= nil then self.rectangle232:destroy(); self.rectangle232 = nil; end;
        if self.textEditor12 ~= nil then self.textEditor12:destroy(); self.textEditor12 = nil; end;
        if self.btnNovaVinculo_2 ~= nil then self.btnNovaVinculo_2:destroy(); self.btnNovaVinculo_2 = nil; end;
        if self.label125 ~= nil then self.label125:destroy(); self.label125 = nil; end;
        if self.label204 ~= nil then self.label204:destroy(); self.label204 = nil; end;
        if self.label4 ~= nil then self.label4:destroy(); self.label4 = nil; end;
        if self.label83 ~= nil then self.label83:destroy(); self.label83 = nil; end;
        if self.rectangle46 ~= nil then self.rectangle46:destroy(); self.rectangle46 = nil; end;
        if self.label199 ~= nil then self.label199:destroy(); self.label199 = nil; end;
        if self.edit13 ~= nil then self.edit13:destroy(); self.edit13 = nil; end;
        if self.dataLink60 ~= nil then self.dataLink60:destroy(); self.dataLink60 = nil; end;
        if self.dataLink76 ~= nil then self.dataLink76:destroy(); self.dataLink76 = nil; end;
        if self.edit86 ~= nil then self.edit86:destroy(); self.edit86 = nil; end;
        if self.label14 ~= nil then self.label14:destroy(); self.label14 = nil; end;
        if self.label26 ~= nil then self.label26:destroy(); self.label26 = nil; end;
        if self.textEditor1 ~= nil then self.textEditor1:destroy(); self.textEditor1 = nil; end;
        if self.edit55 ~= nil then self.edit55:destroy(); self.edit55 = nil; end;
        if self.dataLink26 ~= nil then self.dataLink26:destroy(); self.dataLink26 = nil; end;
        if self.rectangle215 ~= nil then self.rectangle215:destroy(); self.rectangle215 = nil; end;
        if self.label102 ~= nil then self.label102:destroy(); self.label102 = nil; end;
        if self.label130 ~= nil then self.label130:destroy(); self.label130 = nil; end;
        if self.scrollBox7 ~= nil then self.scrollBox7:destroy(); self.scrollBox7 = nil; end;
        if self.label223 ~= nil then self.label223:destroy(); self.label223 = nil; end;
        if self.label52 ~= nil then self.label52:destroy(); self.label52 = nil; end;
        if self.label197 ~= nil then self.label197:destroy(); self.label197 = nil; end;
        if self.edtFiltro_Aura_Magia ~= nil then self.edtFiltro_Aura_Magia:destroy(); self.edtFiltro_Aura_Magia = nil; end;
        if self.label233 ~= nil then self.label233:destroy(); self.label233 = nil; end;
        if self.combo_racas_gerais ~= nil then self.combo_racas_gerais:destroy(); self.combo_racas_gerais = nil; end;
        if self.rectangle53 ~= nil then self.rectangle53:destroy(); self.rectangle53 = nil; end;
        if self.label148 ~= nil then self.label148:destroy(); self.label148 = nil; end;
        if self.label269 ~= nil then self.label269:destroy(); self.label269 = nil; end;
        if self.rectangle29 ~= nil then self.rectangle29:destroy(); self.rectangle29 = nil; end;
        if self.rectangle15 ~= nil then self.rectangle15:destroy(); self.rectangle15 = nil; end;
        if self.label75 ~= nil then self.label75:destroy(); self.label75 = nil; end;
        if self.textEditor35 ~= nil then self.textEditor35:destroy(); self.textEditor35 = nil; end;
        if self.label239 ~= nil then self.label239:destroy(); self.label239 = nil; end;
        if self.rectangle196 ~= nil then self.rectangle196:destroy(); self.rectangle196 = nil; end;
        if self.edit112 ~= nil then self.edit112:destroy(); self.edit112 = nil; end;
        if self.tipo_de_energia ~= nil then self.tipo_de_energia:destroy(); self.tipo_de_energia = nil; end;
        if self.edit90 ~= nil then self.edit90:destroy(); self.edit90 = nil; end;
        if self.xpspuzzle ~= nil then self.xpspuzzle:destroy(); self.xpspuzzle = nil; end;
        if self.comboBox19 ~= nil then self.comboBox19:destroy(); self.comboBox19 = nil; end;
        if self.d4 ~= nil then self.d4:destroy(); self.d4 = nil; end;
        if self.chk_acessorio1 ~= nil then self.chk_acessorio1:destroy(); self.chk_acessorio1 = nil; end;
        if self.rectangle95 ~= nil then self.rectangle95:destroy(); self.rectangle95 = nil; end;
        if self.rectangle85 ~= nil then self.rectangle85:destroy(); self.rectangle85 = nil; end;
        if self.label218 ~= nil then self.label218:destroy(); self.label218 = nil; end;
        if self.label91 ~= nil then self.label91:destroy(); self.label91 = nil; end;
        if self.mod2048 ~= nil then self.mod2048:destroy(); self.mod2048 = nil; end;
        if self.edit70 ~= nil then self.edit70:destroy(); self.edit70 = nil; end;
        if self.edit42 ~= nil then self.edit42:destroy(); self.edit42 = nil; end;
        if self.rectangle160 ~= nil then self.rectangle160:destroy(); self.rectangle160 = nil; end;
        if self.rectangle176 ~= nil then self.rectangle176:destroy(); self.rectangle176 = nil; end;
        if self.label161 ~= nil then self.label161:destroy(); self.label161 = nil; end;
        if self.label115 ~= nil then self.label115:destroy(); self.label115 = nil; end;
        if self.aptransmutacao ~= nil then self.aptransmutacao:destroy(); self.aptransmutacao = nil; end;
        if self.rectangle241 ~= nil then self.rectangle241:destroy(); self.rectangle241 = nil; end;
        if self.label240 ~= nil then self.label240:destroy(); self.label240 = nil; end;
        if self.label252 ~= nil then self.label252:destroy(); self.label252 = nil; end;
        if self.rectangle275 ~= nil then self.rectangle275:destroy(); self.rectangle275 = nil; end;
        if self.comboBox13 ~= nil then self.comboBox13:destroy(); self.comboBox13 = nil; end;
        if self.rectangle74 ~= nil then self.rectangle74:destroy(); self.rectangle74 = nil; end;
        if self.rectangle126 ~= nil then self.rectangle126:destroy(); self.rectangle126 = nil; end;
        if self.comboBox6 ~= nil then self.comboBox6:destroy(); self.comboBox6 = nil; end;
        if self.rectangle207 ~= nil then self.rectangle207:destroy(); self.rectangle207 = nil; end;
        if self.edit27 ~= nil then self.edit27:destroy(); self.edit27 = nil; end;
        if self.dataLink32 ~= nil then self.dataLink32:destroy(); self.dataLink32 = nil; end;
        if self.rectangle151 ~= nil then self.rectangle151:destroy(); self.rectangle151 = nil; end;
        if self.rectangle32 ~= nil then self.rectangle32:destroy(); self.rectangle32 = nil; end;
        if self.label62 ~= nil then self.label62:destroy(); self.label62 = nil; end;
        if self.edit9 ~= nil then self.edit9:destroy(); self.edit9 = nil; end;
        if self.label185 ~= nil then self.label185:destroy(); self.label185 = nil; end;
        if self.edit65 ~= nil then self.edit65:destroy(); self.edit65 = nil; end;
        if self.edit108 ~= nil then self.edit108:destroy(); self.edit108 = nil; end;
        if self.image19 ~= nil then self.image19:destroy(); self.image19 = nil; end;
        if self.label174 ~= nil then self.label174:destroy(); self.label174 = nil; end;
        if self.label277 ~= nil then self.label277:destroy(); self.label277 = nil; end;
        if self.comboBox8 ~= nil then self.comboBox8:destroy(); self.comboBox8 = nil; end;
        if self.dataLink38 ~= nil then self.dataLink38:destroy(); self.dataLink38 = nil; end;
        if self.comboBox36 ~= nil then self.comboBox36:destroy(); self.comboBox36 = nil; end;
        if self.comboBox24 ~= nil then self.comboBox24:destroy(); self.comboBox24 = nil; end;
        if self.xpmahjong ~= nil then self.xpmahjong:destroy(); self.xpmahjong = nil; end;
        if self.rectangle38 ~= nil then self.rectangle38:destroy(); self.rectangle38 = nil; end;
        if self.edit3 ~= nil then self.edit3:destroy(); self.edit3 = nil; end;
        if self.rec_alfaiataria ~= nil then self.rec_alfaiataria:destroy(); self.rec_alfaiataria = nil; end;
        if self.button8 ~= nil then self.button8:destroy(); self.button8 = nil; end;
        if self.edit102 ~= nil then self.edit102:destroy(); self.edit102 = nil; end;
        if self.image17 ~= nil then self.image17:destroy(); self.image17 = nil; end;
        if self.chk_ombro ~= nil then self.chk_ombro:destroy(); self.chk_ombro = nil; end;
        if self.label45 ~= nil then self.label45:destroy(); self.label45 = nil; end;
        if self.label128 ~= nil then self.label128:destroy(); self.label128 = nil; end;
        if self.textEditor22 ~= nil then self.textEditor22:destroy(); self.textEditor22 = nil; end;
        if self.label9 ~= nil then self.label9:destroy(); self.label9 = nil; end;
        if self.image22 ~= nil then self.image22:destroy(); self.image22 = nil; end;
        if self.btnNovoEquipamento ~= nil then self.btnNovoEquipamento:destroy(); self.btnNovoEquipamento = nil; end;
        if self.button6 ~= nil then self.button6:destroy(); self.button6 = nil; end;
        if self.dataLink44 ~= nil then self.dataLink44:destroy(); self.dataLink44 = nil; end;
        if self.dataLink56 ~= nil then self.dataLink56:destroy(); self.dataLink56 = nil; end;
        if self.label209 ~= nil then self.label209:destroy(); self.label209 = nil; end;
        if self.rectangle49 ~= nil then self.rectangle49:destroy(); self.rectangle49 = nil; end;
        if self.apinvocacao ~= nil then self.apinvocacao:destroy(); self.apinvocacao = nil; end;
        if self.aba_inventario ~= nil then self.aba_inventario:destroy(); self.aba_inventario = nil; end;
        if self.modlout ~= nil then self.modlout:destroy(); self.modlout = nil; end;
        if self.rectangle64 ~= nil then self.rectangle64:destroy(); self.rectangle64 = nil; end;
        if self.edit31 ~= nil then self.edit31:destroy(); self.edit31 = nil; end;
        if self.rec_insetocultura ~= nil then self.rec_insetocultura:destroy(); self.rec_insetocultura = nil; end;
        if self.rectangle132 ~= nil then self.rectangle132:destroy(); self.rectangle132 = nil; end;
        if self.label151 ~= nil then self.label151:destroy(); self.label151 = nil; end;
        if self.rectangle231 ~= nil then self.rectangle231:destroy(); self.rectangle231 = nil; end;
        if self.rectangle290 ~= nil then self.rectangle290:destroy(); self.rectangle290 = nil; end;
        if self.label122 ~= nil then self.label122:destroy(); self.label122 = nil; end;
        if self.label203 ~= nil then self.label203:destroy(); self.label203 = nil; end;
        if self.label7 ~= nil then self.label7:destroy(); self.label7 = nil; end;
        if self.rectangle43 ~= nil then self.rectangle43:destroy(); self.rectangle43 = nil; end;
        if self.modbnaval ~= nil then self.modbnaval:destroy(); self.modbnaval = nil; end;
        if self.edit10 ~= nil then self.edit10:destroy(); self.edit10 = nil; end;
        if self.dataLink63 ~= nil then self.dataLink63:destroy(); self.dataLink63 = nil; end;
        if self.dataLink73 ~= nil then self.dataLink73:destroy(); self.dataLink73 = nil; end;
        if self.edit85 ~= nil then self.edit85:destroy(); self.edit85 = nil; end;
        if self.richEdit4 ~= nil then self.richEdit4:destroy(); self.richEdit4 = nil; end;
        if self.rectangle138 ~= nil then self.rectangle138:destroy(); self.rectangle138 = nil; end;
        if self.tags_Aura_Magia ~= nil then self.tags_Aura_Magia:destroy(); self.tags_Aura_Magia = nil; end;
        if self.textEditor19 ~= nil then self.textEditor19:destroy(); self.textEditor19 = nil; end;
        if self.xpptiles ~= nil then self.xpptiles:destroy(); self.xpptiles = nil; end;
        if self.label11 ~= nil then self.label11:destroy(); self.label11 = nil; end;
        if self.label25 ~= nil then self.label25:destroy(); self.label25 = nil; end;
        if self.retangulo_magia ~= nil then self.retangulo_magia:destroy(); self.retangulo_magia = nil; end;
        if self.dataLink29 ~= nil then self.dataLink29:destroy(); self.dataLink29 = nil; end;
        if self.label84 ~= nil then self.label84:destroy(); self.label84 = nil; end;
        if self.rec_pesquisa ~= nil then self.rec_pesquisa:destroy(); self.rec_pesquisa = nil; end;
        if self.chk_maoesquerda ~= nil then self.chk_maoesquerda:destroy(); self.chk_maoesquerda = nil; end;
        if self.tmrFiltroCategorias ~= nil then self.tmrFiltroCategorias:destroy(); self.tmrFiltroCategorias = nil; end;
        if self.btn_acessorio2equip ~= nil then self.btn_acessorio2equip:destroy(); self.btn_acessorio2equip = nil; end;
        if self.textEditor43 ~= nil then self.textEditor43:destroy(); self.textEditor43 = nil; end;
        if self.rectangle5 ~= nil then self.rectangle5:destroy(); self.rectangle5 = nil; end;
        if self.label57 ~= nil then self.label57:destroy(); self.label57 = nil; end;
        if self.label192 ~= nil then self.label192:destroy(); self.label192 = nil; end;
        if self.dataLink79 ~= nil then self.dataLink79:destroy(); self.dataLink79 = nil; end;
        if self.tipo_de_arquivo ~= nil then self.tipo_de_arquivo:destroy(); self.tipo_de_arquivo = nil; end;
        if self.dataLink80 ~= nil then self.dataLink80:destroy(); self.dataLink80 = nil; end;
        if self.textEditor6 ~= nil then self.textEditor6:destroy(); self.textEditor6 = nil; end;
        if self.d9 ~= nil then self.d9:destroy(); self.d9 = nil; end;
        if self.textEditor36 ~= nil then self.textEditor36:destroy(); self.textEditor36 = nil; end;
        if self.rectangle144 ~= nil then self.rectangle144:destroy(); self.rectangle144 = nil; end;
        if self.rectangle265 ~= nil then self.rectangle265:destroy(); self.rectangle265 = nil; end;
        if self.label105 ~= nil then self.label105:destroy(); self.label105 = nil; end;
        if self.label139 ~= nil then self.label139:destroy(); self.label139 = nil; end;
        if self.label224 ~= nil then self.label224:destroy(); self.label224 = nil; end;
        if self.scrollBox18 ~= nil then self.scrollBox18:destroy(); self.scrollBox18 = nil; end;
        if self.edit_nome ~= nil then self.edit_nome:destroy(); self.edit_nome = nil; end;
        if self.label_magia ~= nil then self.label_magia:destroy(); self.label_magia = nil; end;
        if self.rectangle58 ~= nil then self.rectangle58:destroy(); self.rectangle58 = nil; end;
        if self.edit111 ~= nil then self.edit111:destroy(); self.edit111 = nil; end;
        if self.modmastermind ~= nil then self.modmastermind:destroy(); self.modmastermind = nil; end;
        if self.xpqcabeca ~= nil then self.xpqcabeca:destroy(); self.xpqcabeca = nil; end;
        if self.label143 ~= nil then self.label143:destroy(); self.label143 = nil; end;
        if self.dataLink12 ~= nil then self.dataLink12:destroy(); self.dataLink12 = nil; end;
        if self.label262 ~= nil then self.label262:destroy(); self.label262 = nil; end;
        if self.xppman ~= nil then self.xppman:destroy(); self.xppman = nil; end;
        if self.d3 ~= nil then self.d3:destroy(); self.d3 = nil; end;
        if self.chk_acessorio2 ~= nil then self.chk_acessorio2:destroy(); self.chk_acessorio2 = nil; end;
        if self.rectangle98 ~= nil then self.rectangle98:destroy(); self.rectangle98 = nil; end;
        if self.rectangle20 ~= nil then self.rectangle20:destroy(); self.rectangle20 = nil; end;
        if self.rectangle12 ~= nil then self.rectangle12:destroy(); self.rectangle12 = nil; end;
        if self.label92 ~= nil then self.label92:destroy(); self.label92 = nil; end;
        if self.detalhes_insetocultura ~= nil then self.detalhes_insetocultura:destroy(); self.detalhes_insetocultura = nil; end;
        if self.label215 ~= nil then self.label215:destroy(); self.label215 = nil; end;
        if self.edit75 ~= nil then self.edit75:destroy(); self.edit75 = nil; end;
        if self.edit41 ~= nil then self.edit41:destroy(); self.edit41 = nil; end;
        if self.scrollBox12 ~= nil then self.scrollBox12:destroy(); self.scrollBox12 = nil; end;
        if self.rectangle163 ~= nil then self.rectangle163:destroy(); self.rectangle163 = nil; end;
        if self.rectangle173 ~= nil then self.rectangle173:destroy(); self.rectangle173 = nil; end;
        if self.label166 ~= nil then self.label166:destroy(); self.label166 = nil; end;
        if self.label110 ~= nil then self.label110:destroy(); self.label110 = nil; end;
        if self.rectangle242 ~= nil then self.rectangle242:destroy(); self.rectangle242 = nil; end;
        if self.label247 ~= nil then self.label247:destroy(); self.label247 = nil; end;
        if self.label257 ~= nil then self.label257:destroy(); self.label257 = nil; end;
        if self.edit97 ~= nil then self.edit97:destroy(); self.edit97 = nil; end;
        if self.rectangle270 ~= nil then self.rectangle270:destroy(); self.rectangle270 = nil; end;
        if self.xppaciencia ~= nil then self.xppaciencia:destroy(); self.xppaciencia = nil; end;
        if self.comboBox16 ~= nil then self.comboBox16:destroy(); self.comboBox16 = nil; end;
        if self.rectangle77 ~= nil then self.rectangle77:destroy(); self.rectangle77 = nil; end;
        if self.tmrFiltroEquipamentos ~= nil then self.tmrFiltroEquipamentos:destroy(); self.tmrFiltroEquipamentos = nil; end;
        if self.rectangle129 ~= nil then self.rectangle129:destroy(); self.rectangle129 = nil; end;
        if self.rectangle92 ~= nil then self.rectangle92:destroy(); self.rectangle92 = nil; end;
        if self.rectangle208 ~= nil then self.rectangle208:destroy(); self.rectangle208 = nil; end;
        if self.edit22 ~= nil then self.edit22:destroy(); self.edit22 = nil; end;
        if self.label98 ~= nil then self.label98:destroy(); self.label98 = nil; end;
        if self.dataLink37 ~= nil then self.dataLink37:destroy(); self.dataLink37 = nil; end;
        if self.rectangle35 ~= nil then self.rectangle35:destroy(); self.rectangle35 = nil; end;
        if self.rectangle179 ~= nil then self.rectangle179:destroy(); self.rectangle179 = nil; end;
        if self.label61 ~= nil then self.label61:destroy(); self.label61 = nil; end;
        if self.label186 ~= nil then self.label186:destroy(); self.label186 = nil; end;
        if self.label259 ~= nil then self.label259:destroy(); self.label259 = nil; end;
        if self.rectangle180 ~= nil then self.rectangle180:destroy(); self.rectangle180 = nil; end;
        if self.edit28 ~= nil then self.edit28:destroy(); self.edit28 = nil; end;
        if self.titulo_aura_magia ~= nil then self.titulo_aura_magia:destroy(); self.titulo_aura_magia = nil; end;
        if self.rectangle158 ~= nil then self.rectangle158:destroy(); self.rectangle158 = nil; end;
        if self.dataLink49 ~= nil then self.dataLink49:destroy(); self.dataLink49 = nil; end;
        if self.image12 ~= nil then self.image12:destroy(); self.image12 = nil; end;
        if self.dataLink7 ~= nil then self.dataLink7:destroy(); self.dataLink7 = nil; end;
        if self.rectangle100 ~= nil then self.rectangle100:destroy(); self.rectangle100 = nil; end;
        if self.rectangle112 ~= nil then self.rectangle112:destroy(); self.rectangle112 = nil; end;
        if self.rectangle221 ~= nil then self.rectangle221:destroy(); self.rectangle221 = nil; end;
        if self.rectangle255 ~= nil then self.rectangle255:destroy(); self.rectangle255 = nil; end;
        if self.tags_equip ~= nil then self.tags_equip:destroy(); self.tags_equip = nil; end;
        if self.button1 ~= nil then self.button1:destroy(); self.button1 = nil; end;
        if self.dataLink43 ~= nil then self.dataLink43:destroy(); self.dataLink43 = nil; end;
        if self.dataLink9 ~= nil then self.dataLink9:destroy(); self.dataLink9 = nil; end;
        if self.image7 ~= nil then self.image7:destroy(); self.image7 = nil; end;
        if self.dataLink53 ~= nil then self.dataLink53:destroy(); self.dataLink53 = nil; end;
        if self.scrollBox20 ~= nil then self.scrollBox20:destroy(); self.scrollBox20 = nil; end;
        if self.rectangle61 ~= nil then self.rectangle61:destroy(); self.rectangle61 = nil; end;
        if self.label35 ~= nil then self.label35:destroy(); self.label35 = nil; end;
        if self.detalhe_vinculo_2 ~= nil then self.detalhe_vinculo_2:destroy(); self.detalhe_vinculo_2 = nil; end;
        if self.edit32 ~= nil then self.edit32:destroy(); self.edit32 = nil; end;
        if self.rectangle137 ~= nil then self.rectangle137:destroy(); self.rectangle137 = nil; end;
        if self.rectangle234 ~= nil then self.rectangle234:destroy(); self.rectangle234 = nil; end;
        if self.label154 ~= nil then self.label154:destroy(); self.label154 = nil; end;
        if self.modpman ~= nil then self.modpman:destroy(); self.modpman = nil; end;
        if self.chk_raca_alto_humano ~= nil then self.chk_raca_alto_humano:destroy(); self.chk_raca_alto_humano = nil; end;
        if self.rectangle283 ~= nil then self.rectangle283:destroy(); self.rectangle283 = nil; end;
        if self.rectangle293 ~= nil then self.rectangle293:destroy(); self.rectangle293 = nil; end;
        if self.label2 ~= nil then self.label2:destroy(); self.label2 = nil; end;
        if self.label89 ~= nil then self.label89:destroy(); self.label89 = nil; end;
        if self.image29 ~= nil then self.image29:destroy(); self.image29 = nil; end;
        if self.rectangle40 ~= nil then self.rectangle40:destroy(); self.rectangle40 = nil; end;
        if self.button14 ~= nil then self.button14:destroy(); self.button14 = nil; end;
        if self.edit80 ~= nil then self.edit80:destroy(); self.edit80 = nil; end;
        if self.richEdit3 ~= nil then self.richEdit3:destroy(); self.richEdit3 = nil; end;
        if self.textEditor16 ~= nil then self.textEditor16:destroy(); self.textEditor16 = nil; end;
        if self.aptitudeaura ~= nil then self.aptitudeaura:destroy(); self.aptitudeaura = nil; end;
        if self.label12 ~= nil then self.label12:destroy(); self.label12 = nil; end;
        if self.label20 ~= nil then self.label20:destroy(); self.label20 = nil; end;
        if self.rectangle289 ~= nil then self.rectangle289:destroy(); self.rectangle289 = nil; end;
        if self.label87 ~= nil then self.label87:destroy(); self.label87 = nil; end;
        if self.chk_maodireita ~= nil then self.chk_maodireita:destroy(); self.chk_maodireita = nil; end;
        if self.rectangle149 ~= nil then self.rectangle149:destroy(); self.rectangle149 = nil; end;
        if self.rectangle268 ~= nil then self.rectangle268:destroy(); self.rectangle268 = nil; end;
        if self.label108 ~= nil then self.label108:destroy(); self.label108 = nil; end;
        if self.label229 ~= nil then self.label229:destroy(); self.label229 = nil; end;
        if self.scrollBox9 ~= nil then self.scrollBox9:destroy(); self.scrollBox9 = nil; end;
        if self.label58 ~= nil then self.label58:destroy(); self.label58 = nil; end;
        if self.edit17 ~= nil then self.edit17:destroy(); self.edit17 = nil; end;
        if self.dataLink64 ~= nil then self.dataLink64:destroy(); self.dataLink64 = nil; end;
        if self.tmrFiltroSkills ~= nil then self.tmrFiltroSkills:destroy(); self.tmrFiltroSkills = nil; end;
        if self.textEditor5 ~= nil then self.textEditor5:destroy(); self.textEditor5 = nil; end;
        if self.edit51 ~= nil then self.edit51:destroy(); self.edit51 = nil; end;
        if self.dataLink22 ~= nil then self.dataLink22:destroy(); self.dataLink22 = nil; end;
        if self.rectangle211 ~= nil then self.rectangle211:destroy(); self.rectangle211 = nil; end;
        if self.xplout ~= nil then self.xplout:destroy(); self.xplout = nil; end;
        if self.textEditor33 ~= nil then self.textEditor33:destroy(); self.textEditor33 = nil; end;
        if self.rectangle143 ~= nil then self.rectangle143:destroy(); self.rectangle143 = nil; end;
        if self.rectangle262 ~= nil then self.rectangle262:destroy(); self.rectangle262 = nil; end;
        if self.label106 ~= nil then self.label106:destroy(); self.label106 = nil; end;
        if self.label134 ~= nil then self.label134:destroy(); self.label134 = nil; end;
        if self.scrollBox3 ~= nil then self.scrollBox3:destroy(); self.scrollBox3 = nil; end;
        if self.label227 ~= nil then self.label227:destroy(); self.label227 = nil; end;
        if self.label237 ~= nil then self.label237:destroy(); self.label237 = nil; end;
        if self.modspuzzle ~= nil then self.modspuzzle:destroy(); self.modspuzzle = nil; end;
        if self.label280 ~= nil then self.label280:destroy(); self.label280 = nil; end;
        if self.rectangle198 ~= nil then self.rectangle198:destroy(); self.rectangle198 = nil; end;
        if self.rectangle57 ~= nil then self.rectangle57:destroy(); self.rectangle57 = nil; end;
        if self.label144 ~= nil then self.label144:destroy(); self.label144 = nil; end;
        if self.dataLink17 ~= nil then self.dataLink17:destroy(); self.dataLink17 = nil; end;
        if self.label265 ~= nil then self.label265:destroy(); self.label265 = nil; end;
        if self.label212 ~= nil then self.label212:destroy(); self.label212 = nil; end;
        if self.rectangle25 ~= nil then self.rectangle25:destroy(); self.rectangle25 = nil; end;
        if self.rectangle11 ~= nil then self.rectangle11:destroy(); self.rectangle11 = nil; end;
        if self.label71 ~= nil then self.label71:destroy(); self.label71 = nil; end;
        if self.btn_cabecaequip ~= nil then self.btn_cabecaequip:destroy(); self.btn_cabecaequip = nil; end;
        if self.textEditor39 ~= nil then self.textEditor39:destroy(); self.textEditor39 = nil; end;
        if self.edit76 ~= nil then self.edit76:destroy(); self.edit76 = nil; end;
        if self.edit44 ~= nil then self.edit44:destroy(); self.edit44 = nil; end;
        if self.scrollBox17 ~= nil then self.scrollBox17:destroy(); self.scrollBox17 = nil; end;
        if self.detalhes_joalheria ~= nil then self.detalhes_joalheria:destroy(); self.detalhes_joalheria = nil; end;
        if self.textoinventario ~= nil then self.textoinventario:destroy(); self.textoinventario = nil; end;
        if self.rectangle192 ~= nil then self.rectangle192:destroy(); self.rectangle192 = nil; end;
        if self.label113 ~= nil then self.label113:destroy(); self.label113 = nil; end;
        if self.label254 ~= nil then self.label254:destroy(); self.label254 = nil; end;
        if self.edit94 ~= nil then self.edit94:destroy(); self.edit94 = nil; end;
        if self.dataLink19 ~= nil then self.dataLink19:destroy(); self.dataLink19 = nil; end;
        if self.comboBox15 ~= nil then self.comboBox15:destroy(); self.comboBox15 = nil; end;
        if self.rectangle72 ~= nil then self.rectangle72:destroy(); self.rectangle72 = nil; end;
        if self.rectangle91 ~= nil then self.rectangle91:destroy(); self.rectangle91 = nil; end;
        if self.rectangle81 ~= nil then self.rectangle81:destroy(); self.rectangle81 = nil; end;
        if self.label95 ~= nil then self.label95:destroy(); self.label95 = nil; end;
        if self.image32 ~= nil then self.image32:destroy(); self.image32 = nil; end;
        if self.edtFiltroVinculo_2 ~= nil then self.edtFiltroVinculo_2:destroy(); self.edtFiltroVinculo_2 = nil; end;
        if self.rectangle164 ~= nil then self.rectangle164:destroy(); self.rectangle164 = nil; end;
        if self.rectangle245 ~= nil then self.rectangle245:destroy(); self.rectangle245 = nil; end;
        if self.label64 ~= nil then self.label64:destroy(); self.label64 = nil; end;
        if self.label119 ~= nil then self.label119:destroy(); self.label119 = nil; end;
        if self.label183 ~= nil then self.label183:destroy(); self.label183 = nil; end;
        if self.detalhes_forja ~= nil then self.detalhes_forja:destroy(); self.detalhes_forja = nil; end;
        if self.btnNovaSkill ~= nil then self.btnNovaSkill:destroy(); self.btnNovaSkill = nil; end;
        if self.cores_afinidades ~= nil then self.cores_afinidades:destroy(); self.cores_afinidades = nil; end;
        if self.rectangle279 ~= nil then self.rectangle279:destroy(); self.rectangle279 = nil; end;
        if self.rectangle187 ~= nil then self.rectangle187:destroy(); self.rectangle187 = nil; end;
        if self.rectangle78 ~= nil then self.rectangle78:destroy(); self.rectangle78 = nil; end;
        if self.rectangle122 ~= nil then self.rectangle122:destroy(); self.rectangle122 = nil; end;
        if self.comboBox2 ~= nil then self.comboBox2:destroy(); self.comboBox2 = nil; end;
        if self.btn_cintoequip ~= nil then self.btn_cintoequip:destroy(); self.btn_cintoequip = nil; end;
        if self.btn_armaesquerdaequip ~= nil then self.btn_armaesquerdaequip:destroy(); self.btn_armaesquerdaequip = nil; end;
        if self.rectangle203 ~= nil then self.rectangle203:destroy(); self.rectangle203 = nil; end;
        if self.rectangle155 ~= nil then self.rectangle155:destroy(); self.rectangle155 = nil; end;
        if self.modqcabeca ~= nil then self.modqcabeca:destroy(); self.modqcabeca = nil; end;
        if self.xpmastermind ~= nil then self.xpmastermind:destroy(); self.xpmastermind = nil; end;
        if self.label189 ~= nil then self.label189:destroy(); self.label189 = nil; end;
        if self.edit61 ~= nil then self.edit61:destroy(); self.edit61 = nil; end;
        if self.rectangle107 ~= nil then self.rectangle107:destroy(); self.rectangle107 = nil; end;
        if self.rectangle117 ~= nil then self.rectangle117:destroy(); self.rectangle117 = nil; end;
        if self.rectangle189 ~= nil then self.rectangle189:destroy(); self.rectangle189 = nil; end;
        if self.label170 ~= nil then self.label170:destroy(); self.label170 = nil; end;
        if self.d12 ~= nil then self.d12:destroy(); self.d12 = nil; end;
        if self.rectangle226 ~= nil then self.rectangle226:destroy(); self.rectangle226 = nil; end;
        if self.label38 ~= nil then self.label38:destroy(); self.label38 = nil; end;
        if self.rectangle250 ~= nil then self.rectangle250:destroy(); self.rectangle250 = nil; end;
        if self.label273 ~= nil then self.label273:destroy(); self.label273 = nil; end;
        if self.approducao ~= nil then self.approducao:destroy(); self.approducao = nil; end;
        if self.comboBox20 ~= nil then self.comboBox20:destroy(); self.comboBox20 = nil; end;
        if self.comboBox32 ~= nil then self.comboBox32:destroy(); self.comboBox32 = nil; end;
        if self.textEditor28 ~= nil then self.textEditor28:destroy(); self.textEditor28 = nil; end;
        if self.edtFiltroTextos ~= nil then self.edtFiltroTextos:destroy(); self.edtFiltroTextos = nil; end;
        if self.edit7 ~= nil then self.edit7:destroy(); self.edit7 = nil; end;
        if self.edit106 ~= nil then self.edit106:destroy(); self.edit106 = nil; end;
        if self.dataLink50 ~= nil then self.dataLink50:destroy(); self.dataLink50 = nil; end;
        if self.rectangle119 ~= nil then self.rectangle119:destroy(); self.rectangle119 = nil; end;
        if self.label41 ~= nil then self.label41:destroy(); self.label41 = nil; end;
        if self.label279 ~= nil then self.label279:destroy(); self.label279 = nil; end;
        if self.rectangle62 ~= nil then self.rectangle62:destroy(); self.rectangle62 = nil; end;
        if self.label32 ~= nil then self.label32:destroy(); self.label32 = nil; end;
        if self.label157 ~= nil then self.label157:destroy(); self.label157 = nil; end;
        if self.rectangle296 ~= nil then self.rectangle296:destroy(); self.rectangle296 = nil; end;
        if self.rectangle284 ~= nil then self.rectangle284:destroy(); self.rectangle284 = nil; end;
        if self.textEditor26 ~= nil then self.textEditor26:destroy(); self.textEditor26 = nil; end;
        if self.image26 ~= nil then self.image26:destroy(); self.image26 = nil; end;
        if self.dataLink69 ~= nil then self.dataLink69:destroy(); self.dataLink69 = nil; end;
        if self.button11 ~= nil then self.button11:destroy(); self.button11 = nil; end;
        if self.apmanipulacao ~= nil then self.apmanipulacao:destroy(); self.apmanipulacao = nil; end;
        if self.edit35 ~= nil then self.edit35:destroy(); self.edit35 = nil; end;
        if self.textEditor13 ~= nil then self.textEditor13:destroy(); self.textEditor13 = nil; end;
        if self.chk_cinto ~= nil then self.chk_cinto:destroy(); self.chk_cinto = nil; end;
        if self.label126 ~= nil then self.label126:destroy(); self.label126 = nil; end;
        if self.label207 ~= nil then self.label207:destroy(); self.label207 = nil; end;
        if self.label82 ~= nil then self.label82:destroy(); self.label82 = nil; end;
        if self.rectangle47 ~= nil then self.rectangle47:destroy(); self.rectangle47 = nil; end;
        if self.textEditor45 ~= nil then self.textEditor45:destroy(); self.textEditor45 = nil; end;
        if self.label198 ~= nil then self.label198:destroy(); self.label198 = nil; end;
        if self.edit14 ~= nil then self.edit14:destroy(); self.edit14 = nil; end;
        if self.dataLink67 ~= nil then self.dataLink67:destroy(); self.dataLink67 = nil; end;
        if self.dataLink77 ~= nil then self.dataLink77:destroy(); self.dataLink77 = nil; end;
        if self.richEdit8 ~= nil then self.richEdit8:destroy(); self.richEdit8 = nil; end;
        if self.label15 ~= nil then self.label15:destroy(); self.label15 = nil; end;
        if self.label29 ~= nil then self.label29:destroy(); self.label29 = nil; end;
        if self.edit56 ~= nil then self.edit56:destroy(); self.edit56 = nil; end;
        if self.dataLink25 ~= nil then self.dataLink25:destroy(); self.dataLink25 = nil; end;
        if self.rectangle214 ~= nil then self.rectangle214:destroy(); self.rectangle214 = nil; end;
        if self.xpjcobrinha ~= nil then self.xpjcobrinha:destroy(); self.xpjcobrinha = nil; end;
        if self.label103 ~= nil then self.label103:destroy(); self.label103 = nil; end;
        if self.label133 ~= nil then self.label133:destroy(); self.label133 = nil; end;
        if self.scrollBox6 ~= nil then self.scrollBox6:destroy(); self.scrollBox6 = nil; end;
        if self.label222 ~= nil then self.label222:destroy(); self.label222 = nil; end;
        if self.rectangle1 ~= nil then self.rectangle1:destroy(); self.rectangle1 = nil; end;
        if self.label53 ~= nil then self.label53:destroy(); self.label53 = nil; end;
        if self.label196 ~= nil then self.label196:destroy(); self.label196 = nil; end;
        if self.label230 ~= nil then self.label230:destroy(); self.label230 = nil; end;
        if self.chk_raca_reptideo ~= nil then self.chk_raca_reptideo:destroy(); self.chk_raca_reptideo = nil; end;
        if self.tmrFiltroVinculo_2 ~= nil then self.tmrFiltroVinculo_2:destroy(); self.tmrFiltroVinculo_2 = nil; end;
        if self.rectangle52 ~= nil then self.rectangle52:destroy(); self.rectangle52 = nil; end;
        if self.detalhes_pesquisa ~= nil then self.detalhes_pesquisa:destroy(); self.detalhes_pesquisa = nil; end;
        if self.label149 ~= nil then self.label149:destroy(); self.label149 = nil; end;
        if self.dataLink14 ~= nil then self.dataLink14:destroy(); self.dataLink14 = nil; end;
        if self.btn_maoesquerdaequip ~= nil then self.btn_maoesquerdaequip:destroy(); self.btn_maoesquerdaequip = nil; end;
        if self.btn_mod_fabricacao ~= nil then self.btn_mod_fabricacao:destroy(); self.btn_mod_fabricacao = nil; end;
        if self.label268 ~= nil then self.label268:destroy(); self.label268 = nil; end;
        if self.rectangle26 ~= nil then self.rectangle26:destroy(); self.rectangle26 = nil; end;
        if self.rectangle14 ~= nil then self.rectangle14:destroy(); self.rectangle14 = nil; end;
        if self.label76 ~= nil then self.label76:destroy(); self.label76 = nil; end;
        if self.chk_armadireita ~= nil then self.chk_armadireita:destroy(); self.chk_armadireita = nil; end;
        if self.scrollBox14 ~= nil then self.scrollBox14:destroy(); self.scrollBox14 = nil; end;
        if self.tagsVinculo_2 ~= nil then self.tagsVinculo_2:destroy(); self.tagsVinculo_2 = nil; end;
        if self.rectangle169 ~= nil then self.rectangle169:destroy(); self.rectangle169 = nil; end;
        if self.rectangle197 ~= nil then self.rectangle197:destroy(); self.rectangle197 = nil; end;
        if self.label168 ~= nil then self.label168:destroy(); self.label168 = nil; end;
        if self.rectangle248 ~= nil then self.rectangle248:destroy(); self.rectangle248 = nil; end;
        if self.label249 ~= nil then self.label249:destroy(); self.label249 = nil; end;
        if self.edit115 ~= nil then self.edit115:destroy(); self.edit115 = nil; end;
        if self.chk_raca_werebeast ~= nil then self.chk_raca_werebeast:destroy(); self.chk_raca_werebeast = nil; end;
        if self.edit91 ~= nil then self.edit91:destroy(); self.edit91 = nil; end;
        if self.comboBox18 ~= nil then self.comboBox18:destroy(); self.comboBox18 = nil; end;
        if self.d7 ~= nil then self.d7:destroy(); self.d7 = nil; end;
        if self.rectangle94 ~= nil then self.rectangle94:destroy(); self.rectangle94 = nil; end;
        if self.rectangle86 ~= nil then self.rectangle86:destroy(); self.rectangle86 = nil; end;
        if self.label219 ~= nil then self.label219:destroy(); self.label219 = nil; end;
        if self.label96 ~= nil then self.label96:destroy(); self.label96 = nil; end;
        if self.edit71 ~= nil then self.edit71:destroy(); self.edit71 = nil; end;
        if self.rec_mineracao ~= nil then self.rec_mineracao:destroy(); self.rec_mineracao = nil; end;
        if self.image31 ~= nil then self.image31:destroy(); self.image31 = nil; end;
        if self.edtFiltroVinculo_1 ~= nil then self.edtFiltroVinculo_1:destroy(); self.edtFiltroVinculo_1 = nil; end;
        if self.rectangle167 ~= nil then self.rectangle167:destroy(); self.rectangle167 = nil; end;
        if self.rectangle177 ~= nil then self.rectangle177:destroy(); self.rectangle177 = nil; end;
        if self.label162 ~= nil then self.label162:destroy(); self.label162 = nil; end;
        if self.label114 ~= nil then self.label114:destroy(); self.label114 = nil; end;
        if self.rectangle246 ~= nil then self.rectangle246:destroy(); self.rectangle246 = nil; end;
        if self.label243 ~= nil then self.label243:destroy(); self.label243 = nil; end;
        if self.label253 ~= nil then self.label253:destroy(); self.label253 = nil; end;
        if self.rectangle274 ~= nil then self.rectangle274:destroy(); self.rectangle274 = nil; end;
        if self.comboBox12 ~= nil then self.comboBox12:destroy(); self.comboBox12 = nil; end;
        if self.rectangle125 ~= nil then self.rectangle125:destroy(); self.rectangle125 = nil; end;
        if self.comboBox7 ~= nil then self.comboBox7:destroy(); self.comboBox7 = nil; end;
        if self.rectangle88 ~= nil then self.rectangle88:destroy(); self.rectangle88 = nil; end;
        if self.edit26 ~= nil then self.edit26:destroy(); self.edit26 = nil; end;
        if self.dataLink33 ~= nil then self.dataLink33:destroy(); self.dataLink33 = nil; end;
        if self.rectangle204 ~= nil then self.rectangle204:destroy(); self.rectangle204 = nil; end;
        if self.rectangle152 ~= nil then self.rectangle152:destroy(); self.rectangle152 = nil; end;
        if self.rectangle31 ~= nil then self.rectangle31:destroy(); self.rectangle31 = nil; end;
        if self.edit8 ~= nil then self.edit8:destroy(); self.edit8 = nil; end;
        if self.edit109 ~= nil then self.edit109:destroy(); self.edit109 = nil; end;
        if self.edit64 ~= nil then self.edit64:destroy(); self.edit64 = nil; end;
        if self.image18 ~= nil then self.image18:destroy(); self.image18 = nil; end;
        if self.xpjogosdisponivel ~= nil then self.xpjogosdisponivel:destroy(); self.xpjogosdisponivel = nil; end;
        if self.apconjuracao ~= nil then self.apconjuracao:destroy(); self.apconjuracao = nil; end;
        if self.rectangle114 ~= nil then self.rectangle114:destroy(); self.rectangle114 = nil; end;
        if self.rectangle253 ~= nil then self.rectangle253:destroy(); self.rectangle253 = nil; end;
        if self.label177 ~= nil then self.label177:destroy(); self.label177 = nil; end;
        if self.detalhes_ecomorfia ~= nil then self.detalhes_ecomorfia:destroy(); self.detalhes_ecomorfia = nil; end;
        if self.label274 ~= nil then self.label274:destroy(); self.label274 = nil; end;
        if self.comboBox9 ~= nil then self.comboBox9:destroy(); self.comboBox9 = nil; end;
        if self.dataLink39 ~= nil then self.dataLink39:destroy(); self.dataLink39 = nil; end;
        if self.comboBox35 ~= nil then self.comboBox35:destroy(); self.comboBox35 = nil; end;
        if self.comboBox25 ~= nil then self.comboBox25:destroy(); self.comboBox25 = nil; end;
        if self.edit2 ~= nil then self.edit2:destroy(); self.edit2 = nil; end;
        if self.edit103 ~= nil then self.edit103:destroy(); self.edit103 = nil; end;
        if self.image16 ~= nil then self.image16:destroy(); self.image16 = nil; end;
        if self.dataLink3 ~= nil then self.dataLink3:destroy(); self.dataLink3 = nil; end;
        if self.rectangle259 ~= nil then self.rectangle259:destroy(); self.rectangle259 = nil; end;
        if self.label44 ~= nil then self.label44:destroy(); self.label44 = nil; end;
        if self.aba_perfil ~= nil then self.aba_perfil:destroy(); self.aba_perfil = nil; end;
        if self.label179 ~= nil then self.label179:destroy(); self.label179 = nil; end;
        if self.edit38 ~= nil then self.edit38:destroy(); self.edit38 = nil; end;
        if self.rectangle299 ~= nil then self.rectangle299:destroy(); self.rectangle299 = nil; end;
        if self.label129 ~= nil then self.label129:destroy(); self.label129 = nil; end;
        if self.textEditor21 ~= nil then self.textEditor21:destroy(); self.textEditor21 = nil; end;
        if self.label8 ~= nil then self.label8:destroy(); self.label8 = nil; end;
        if self.image23 ~= nil then self.image23:destroy(); self.image23 = nil; end;
        if self.label208 ~= nil then self.label208:destroy(); self.label208 = nil; end;
        if self.button5 ~= nil then self.button5:destroy(); self.button5 = nil; end;
        if self.dataLink47 ~= nil then self.dataLink47:destroy(); self.dataLink47 = nil; end;
        if self.dataLink57 ~= nil then self.dataLink57:destroy(); self.dataLink57 = nil; end;
        if self.chk_raca_broteli ~= nil then self.chk_raca_broteli:destroy(); self.chk_raca_broteli = nil; end;
        if self.xptetrix ~= nil then self.xptetrix:destroy(); self.xptetrix = nil; end;
        if self.modcmagico ~= nil then self.modcmagico:destroy(); self.modcmagico = nil; end;
        if self.rectangle65 ~= nil then self.rectangle65:destroy(); self.rectangle65 = nil; end;
        if self.button12 ~= nil then self.button12:destroy(); self.button12 = nil; end;
        if self.edit36 ~= nil then self.edit36:destroy(); self.edit36 = nil; end;
        if self.rectangle133 ~= nil then self.rectangle133:destroy(); self.rectangle133 = nil; end;
        if self.rectangle230 ~= nil then self.rectangle230:destroy(); self.rectangle230 = nil; end;
        if self.label150 ~= nil then self.label150:destroy(); self.label150 = nil; end;
        if self.textEditor10 ~= nil then self.textEditor10:destroy(); self.textEditor10 = nil; end;
        if self.label18 ~= nil then self.label18:destroy(); self.label18 = nil; end;
        if self.label123 ~= nil then self.label123:destroy(); self.label123 = nil; end;
        if self.label202 ~= nil then self.label202:destroy(); self.label202 = nil; end;
        if self.label6 ~= nil then self.label6:destroy(); self.label6 = nil; end;
        if self.rec_ecomorfia ~= nil then self.rec_ecomorfia:destroy(); self.rec_ecomorfia = nil; end;
        if self.rectangle44 ~= nil then self.rectangle44:destroy(); self.rectangle44 = nil; end;
        if self.edit11 ~= nil then self.edit11:destroy(); self.edit11 = nil; end;
        if self.dataLink62 ~= nil then self.dataLink62:destroy(); self.dataLink62 = nil; end;
        if self.dataLink70 ~= nil then self.dataLink70:destroy(); self.dataLink70 = nil; end;
        if self.aba_raca ~= nil then self.aba_raca:destroy(); self.aba_raca = nil; end;
        if self.edit84 ~= nil then self.edit84:destroy(); self.edit84 = nil; end;
        if self.richEdit7 ~= nil then self.richEdit7:destroy(); self.richEdit7 = nil; end;
        if self.rectangle139 ~= nil then self.rectangle139:destroy(); self.rectangle139 = nil; end;
        if self.label16 ~= nil then self.label16:destroy(); self.label16 = nil; end;
        if self.label24 ~= nil then self.label24:destroy(); self.label24 = nil; end;
        if self.aba_minigames ~= nil then self.aba_minigames:destroy(); self.aba_minigames = nil; end;
        if self.dataLink28 ~= nil then self.dataLink28:destroy(); self.dataLink28 = nil; end;
        if self.rectangle217 ~= nil then self.rectangle217:destroy(); self.rectangle217 = nil; end;
        if self.textEditor42 ~= nil then self.textEditor42:destroy(); self.textEditor42 = nil; end;
        if self.scrollBox5 ~= nil then self.scrollBox5:destroy(); self.scrollBox5 = nil; end;
        if self.rectangle6 ~= nil then self.rectangle6:destroy(); self.rectangle6 = nil; end;
        if self.label54 ~= nil then self.label54:destroy(); self.label54 = nil; end;
        if self.label191 ~= nil then self.label191:destroy(); self.label191 = nil; end;
        if self.btn_acessorio1equip ~= nil then self.btn_acessorio1equip:destroy(); self.btn_acessorio1equip = nil; end;
        if self.rectangle51 ~= nil then self.rectangle51:destroy(); self.rectangle51 = nil; end;
        if self.textEditor9 ~= nil then self.textEditor9:destroy(); self.textEditor9 = nil; end;
        if self.d8 ~= nil then self.d8:destroy(); self.d8 = nil; end;
        if self.textEditor37 ~= nil then self.textEditor37:destroy(); self.textEditor37 = nil; end;
        if self.rectangle147 ~= nil then self.rectangle147:destroy(); self.rectangle147 = nil; end;
        if self.chk_raca_aveano ~= nil then self.chk_raca_aveano:destroy(); self.chk_raca_aveano = nil; end;
        if self.rectangle266 ~= nil then self.rectangle266:destroy(); self.rectangle266 = nil; end;
        if self.label138 ~= nil then self.label138:destroy(); self.label138 = nil; end;
        if self.scrollBox19 ~= nil then self.scrollBox19:destroy(); self.scrollBox19 = nil; end;
        if self.rectangle194 ~= nil then self.rectangle194:destroy(); self.rectangle194 = nil; end;
        if self.edit110 ~= nil then self.edit110:destroy(); self.edit110 = nil; end;
        if self.label140 ~= nil then self.label140:destroy(); self.label140 = nil; end;
        if self.dataLink13 ~= nil then self.dataLink13:destroy(); self.dataLink13 = nil; end;
        if self.chk_raca_wixili ~= nil then self.chk_raca_wixili:destroy(); self.chk_raca_wixili = nil; end;
        if self.label261 ~= nil then self.label261:destroy(); self.label261 = nil; end;
        if self.d2 ~= nil then self.d2:destroy(); self.d2 = nil; end;
        if self.modjcobrinha ~= nil then self.modjcobrinha:destroy(); self.modjcobrinha = nil; end;
        if self.label216 ~= nil then self.label216:destroy(); self.label216 = nil; end;
        if self.rectangle21 ~= nil then self.rectangle21:destroy(); self.rectangle21 = nil; end;
        if self.scrollBox13 ~= nil then self.scrollBox13:destroy(); self.scrollBox13 = nil; end;
        if self.label93 ~= nil then self.label93:destroy(); self.label93 = nil; end;
        if self.edit72 ~= nil then self.edit72:destroy(); self.edit72 = nil; end;
        if self.edit40 ~= nil then self.edit40:destroy(); self.edit40 = nil; end;
        if self.chk_armaesquerda ~= nil then self.chk_armaesquerda:destroy(); self.chk_armaesquerda = nil; end;
        if self.vezesjogadas ~= nil then self.vezesjogadas:destroy(); self.vezesjogadas = nil; end;
        if self.rectangle162 ~= nil then self.rectangle162:destroy(); self.rectangle162 = nil; end;
        if self.rectangle170 ~= nil then self.rectangle170:destroy(); self.rectangle170 = nil; end;
        if self.label167 ~= nil then self.label167:destroy(); self.label167 = nil; end;
        if self.label117 ~= nil then self.label117:destroy(); self.label117 = nil; end;
        if self.rectangle243 ~= nil then self.rectangle243:destroy(); self.rectangle243 = nil; end;
        if self.rec_forja ~= nil then self.rec_forja:destroy(); self.rec_forja = nil; end;
        if self.btn_torsoequip ~= nil then self.btn_torsoequip:destroy(); self.btn_torsoequip = nil; end;
        if self.edit98 ~= nil then self.edit98:destroy(); self.edit98 = nil; end;
        if self.btn_desequipar_acao ~= nil then self.btn_desequipar_acao:destroy(); self.btn_desequipar_acao = nil; end;
        if self.label246 ~= nil then self.label246:destroy(); self.label246 = nil; end;
        if self.label250 ~= nil then self.label250:destroy(); self.label250 = nil; end;
        if self.comboBox11 ~= nil then self.comboBox11:destroy(); self.comboBox11 = nil; end;
        if self.rectangle76 ~= nil then self.rectangle76:destroy(); self.rectangle76 = nil; end;
        if self.rectangle273 ~= nil then self.rectangle273:destroy(); self.rectangle273 = nil; end;
        if self.rectangle128 ~= nil then self.rectangle128:destroy(); self.rectangle128 = nil; end;
        if self.comboBox4 ~= nil then self.comboBox4:destroy(); self.comboBox4 = nil; end;
        if self.btnNova_Aura_Magia ~= nil then self.btnNova_Aura_Magia:destroy(); self.btnNova_Aura_Magia = nil; end;
        if self.edit21 ~= nil then self.edit21:destroy(); self.edit21 = nil; end;
        if self.dataLink34 ~= nil then self.dataLink34:destroy(); self.dataLink34 = nil; end;
        if self.label99 ~= nil then self.label99:destroy(); self.label99 = nil; end;
        if self.detalhe_aura_magia ~= nil then self.detalhe_aura_magia:destroy(); self.detalhe_aura_magia = nil; end;
        if self.rectangle209 ~= nil then self.rectangle209:destroy(); self.rectangle209 = nil; end;
        if self.listatextos ~= nil then self.listatextos:destroy(); self.listatextos = nil; end;
        if self.rectangle34 ~= nil then self.rectangle34:destroy(); self.rectangle34 = nil; end;
        if self.label60 ~= nil then self.label60:destroy(); self.label60 = nil; end;
        if self.label187 ~= nil then self.label187:destroy(); self.label187 = nil; end;
        if self.edit67 ~= nil then self.edit67:destroy(); self.edit67 = nil; end;
        if self.descricao ~= nil then self.descricao:destroy(); self.descricao = nil; end;
        if self.rectangle109 ~= nil then self.rectangle109:destroy(); self.rectangle109 = nil; end;
        if self.rectangle228 ~= nil then self.rectangle228:destroy(); self.rectangle228 = nil; end;
        if self.rectangle183 ~= nil then self.rectangle183:destroy(); self.rectangle183 = nil; end;
        if self.explicacao_raca ~= nil then self.explicacao_raca:destroy(); self.explicacao_raca = nil; end;
        if self.comboBox38 ~= nil then self.comboBox38:destroy(); self.comboBox38 = nil; end;
        if self.comboBox26 ~= nil then self.comboBox26:destroy(); self.comboBox26 = nil; end;
        if self.rectangle159 ~= nil then self.rectangle159:destroy(); self.rectangle159 = nil; end;
        if self.edit1 ~= nil then self.edit1:destroy(); self.edit1 = nil; end;
        if self.dataLink48 ~= nil then self.dataLink48:destroy(); self.dataLink48 = nil; end;
        if self.image11 ~= nil then self.image11:destroy(); self.image11 = nil; end;
        if self.dataLink6 ~= nil then self.dataLink6:destroy(); self.dataLink6 = nil; end;
        if self.edit100 ~= nil then self.edit100:destroy(); self.edit100 = nil; end;
        if self.rectangle103 ~= nil then self.rectangle103:destroy(); self.rectangle103 = nil; end;
        if self.rectangle113 ~= nil then self.rectangle113:destroy(); self.rectangle113 = nil; end;
        if self.label47 ~= nil then self.label47:destroy(); self.label47 = nil; end;
        if self.rectangle222 ~= nil then self.rectangle222:destroy(); self.rectangle222 = nil; end;
        if self.rectangle68 ~= nil then self.rectangle68:destroy(); self.rectangle68 = nil; end;
        if self.rectangle254 ~= nil then self.rectangle254:destroy(); self.rectangle254 = nil; end;
        if self.listacategoria ~= nil then self.listacategoria:destroy(); self.listacategoria = nil; end;
        if self.chk_pescoco ~= nil then self.chk_pescoco:destroy(); self.chk_pescoco = nil; end;
        if self.image20 ~= nil then self.image20:destroy(); self.image20 = nil; end;
        if self.dataLink42 ~= nil then self.dataLink42:destroy(); self.dataLink42 = nil; end;
        if self.dataLink54 ~= nil then self.dataLink54:destroy(); self.dataLink54 = nil; end;
        if self.dataLink8 ~= nil then self.dataLink8:destroy(); self.dataLink8 = nil; end;
        if self.image4 ~= nil then self.image4:destroy(); self.image4 = nil; end;
        if self.rectangle66 ~= nil then self.rectangle66:destroy(); self.rectangle66 = nil; end;
        if self.label36 ~= nil then self.label36:destroy(); self.label36 = nil; end;
        if self.edit89 ~= nil then self.edit89:destroy(); self.edit89 = nil; end;
        if self.edit33 ~= nil then self.edit33:destroy(); self.edit33 = nil; end;
        if self.rectangle134 ~= nil then self.rectangle134:destroy(); self.rectangle134 = nil; end;
        if self.rectangle237 ~= nil then self.rectangle237:destroy(); self.rectangle237 = nil; end;
        if self.label153 ~= nil then self.label153:destroy(); self.label153 = nil; end;
        if self.rectangle292 ~= nil then self.rectangle292:destroy(); self.rectangle292 = nil; end;
        if self.rectangle280 ~= nil then self.rectangle280:destroy(); self.rectangle280 = nil; end;
        if self.label120 ~= nil then self.label120:destroy(); self.label120 = nil; end;
        if self.label201 ~= nil then self.label201:destroy(); self.label201 = nil; end;
        if self.label1 ~= nil then self.label1:destroy(); self.label1 = nil; end;
        if self.label88 ~= nil then self.label88:destroy(); self.label88 = nil; end;
        if self.modtetrix ~= nil then self.modtetrix:destroy(); self.modtetrix = nil; end;
        if self.rectangle41 ~= nil then self.rectangle41:destroy(); self.rectangle41 = nil; end;
        if self.button15 ~= nil then self.button15:destroy(); self.button15 = nil; end;
        if self.edit83 ~= nil then self.edit83:destroy(); self.edit83 = nil; end;
        if self.richEdit2 ~= nil then self.richEdit2:destroy(); self.richEdit2 = nil; end;
        if self.rectangle239 ~= nil then self.rectangle239:destroy(); self.rectangle239 = nil; end;
        if self.xptdh ~= nil then self.xptdh:destroy(); self.xptdh = nil; end;
        if self.rec_carpintaria ~= nil then self.rec_carpintaria:destroy(); self.rec_carpintaria = nil; end;
        if self.textEditor17 ~= nil then self.textEditor17:destroy(); self.textEditor17 = nil; end;
        if self.label159 ~= nil then self.label159:destroy(); self.label159 = nil; end;
        if self.label13 ~= nil then self.label13:destroy(); self.label13 = nil; end;
        if self.label23 ~= nil then self.label23:destroy(); self.label23 = nil; end;
        if self.edit58 ~= nil then self.edit58:destroy(); self.edit58 = nil; end;
        if self.label86 ~= nil then self.label86:destroy(); self.label86 = nil; end;
        if self.rectangle148 ~= nil then self.rectangle148:destroy(); self.rectangle148 = nil; end;
        if self.rectangle269 ~= nil then self.rectangle269:destroy(); self.rectangle269 = nil; end;
        if self.label109 ~= nil then self.label109:destroy(); self.label109 = nil; end;
        if self.label228 ~= nil then self.label228:destroy(); self.label228 = nil; end;
        if self.scrollBox8 ~= nil then self.scrollBox8:destroy(); self.scrollBox8 = nil; end;
        if self.textEditor41 ~= nil then self.textEditor41:destroy(); self.textEditor41 = nil; end;
        if self.label59 ~= nil then self.label59:destroy(); self.label59 = nil; end;
        if self.botaocondicao ~= nil then self.botaocondicao:destroy(); self.botaocondicao = nil; end;
        if self.textEditor4 ~= nil then self.textEditor4:destroy(); self.textEditor4 = nil; end;
        if self.edit52 ~= nil then self.edit52:destroy(); self.edit52 = nil; end;
        if self.dataLink21 ~= nil then self.dataLink21:destroy(); self.dataLink21 = nil; end;
        if self.rectangle210 ~= nil then self.rectangle210:destroy(); self.rectangle210 = nil; end;
        if self.textEditor30 ~= nil then self.textEditor30:destroy(); self.textEditor30 = nil; end;
        if self.rectangle142 ~= nil then self.rectangle142:destroy(); self.rectangle142 = nil; end;
        if self.label78 ~= nil then self.label78:destroy(); self.label78 = nil; end;
        if self.label107 ~= nil then self.label107:destroy(); self.label107 = nil; end;
        if self.label137 ~= nil then self.label137:destroy(); self.label137 = nil; end;
        if self.scrollBox2 ~= nil then self.scrollBox2:destroy(); self.scrollBox2 = nil; end;
        if self.tmrFiltro_Aura_Magia ~= nil then self.tmrFiltro_Aura_Magia:destroy(); self.tmrFiltro_Aura_Magia = nil; end;
        if self.label226 ~= nil then self.label226:destroy(); self.label226 = nil; end;
        if self.label234 ~= nil then self.label234:destroy(); self.label234 = nil; end;
        if self.rectangle263 ~= nil then self.rectangle263:destroy(); self.rectangle263 = nil; end;
        if self.modcminado ~= nil then self.modcminado:destroy(); self.modcminado = nil; end;
        if self.rectangle199 ~= nil then self.rectangle199:destroy(); self.rectangle199 = nil; end;
        if self.rectangle56 ~= nil then self.rectangle56:destroy(); self.rectangle56 = nil; end;
        if self.modpaciencia ~= nil then self.modpaciencia:destroy(); self.modpaciencia = nil; end;
        if self.label145 ~= nil then self.label145:destroy(); self.label145 = nil; end;
        if self.dataLink10 ~= nil then self.dataLink10:destroy(); self.dataLink10 = nil; end;
        if self.tagsSkill ~= nil then self.tagsSkill:destroy(); self.tagsSkill = nil; end;
        if self.label264 ~= nil then self.label264:destroy(); self.label264 = nil; end;
        if self.listavinculo_2 ~= nil then self.listavinculo_2:destroy(); self.listavinculo_2 = nil; end;
        if self.d1 ~= nil then self.d1:destroy(); self.d1 = nil; end;
        if self.label213 ~= nil then self.label213:destroy(); self.label213 = nil; end;
        if self.rectangle22 ~= nil then self.rectangle22:destroy(); self.rectangle22 = nil; end;
        if self.rectangle10 ~= nil then self.rectangle10:destroy(); self.rectangle10 = nil; end;
        if self.label72 ~= nil then self.label72:destroy(); self.label72 = nil; end;
        self:_oldLFMDestroy();
    end;

    obj:endUpdate();

    return obj;
end;

function newfrmPickMeUp()
    local retObj = nil;
    __o_rrpgObjs.beginObjectsLoading();

    __o_Utils.tryFinally(
      function()
        retObj = constructNew_frmPickMeUp();
      end,
      function()
        __o_rrpgObjs.endObjectsLoading();
      end);

    assert(retObj ~= nil);
    return retObj;
end;

local _frmPickMeUp = {
    newEditor = newfrmPickMeUp, 
    new = newfrmPickMeUp, 
    name = "frmPickMeUp", 
    dataType = "Pick_Me_Up_Geral", 
    formType = "sheetTemplate", 
    formComponentName = "form", 
    cacheMode = "none", 
    title = "Pick Me Up", 
    description=""};

frmPickMeUp = _frmPickMeUp;
Firecast.registrarForm(_frmPickMeUp);
Firecast.registrarDataType(_frmPickMeUp);

return _frmPickMeUp;
