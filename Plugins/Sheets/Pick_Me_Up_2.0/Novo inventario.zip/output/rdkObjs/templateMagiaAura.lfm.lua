require("firecast.lua");
local __o_rrpgObjs = require("rrpgObjs.lua");
require("rrpgGUI.lua");
require("rrpgDialogs.lua");
require("rrpgLFM.lua");
require("ndb.lua");
require("locale.lua");
local __o_Utils = require("utils.lua");

local function constructNew_template_Aura_Magia()
    local obj = GUI.fromHandle(_obj_newObject("form"));
    local self = obj;
    local sheet = nil;

    rawset(obj, "_oldSetNodeObjectFunction", obj.setNodeObject);

    function obj:setNodeObject(nodeObject)
        sheet = nodeObject;
        self.sheet = nodeObject;
        self:_oldSetNodeObjectFunction(nodeObject);
    end;

    function obj:setNodeDatabase(nodeObject)
        self:setNodeObject(nodeObject);
    end;

    _gui_assignInitialParentForForm(obj.handle);
    obj:beginUpdate();
    obj:setName("template_Aura_Magia");
    obj:setHeight(140);
    obj.grid.role = "col";
    obj.grid.width = 6;
    obj.grid["cnt-gutter"] = 0;

    obj.indicador_cor_Aura_Magia = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.indicador_cor_Aura_Magia:setParent(obj);
    obj.indicador_cor_Aura_Magia:setName("indicador_cor_Aura_Magia");
    obj.indicador_cor_Aura_Magia:setColor("#150e16");
    obj.indicador_cor_Aura_Magia:setStrokeSize(1);
    obj.indicador_cor_Aura_Magia:setStrokeColor("white");
    obj.indicador_cor_Aura_Magia:setCornerType("round");
    obj.indicador_cor_Aura_Magia:setXradius(5);
    obj.indicador_cor_Aura_Magia:setYradius(5);
    obj.indicador_cor_Aura_Magia.grid.role = "col";
    obj.indicador_cor_Aura_Magia.grid.width = 12;
    obj.indicador_cor_Aura_Magia:setHeight(140);

    obj.dataLink1 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink1:setParent(obj.indicador_cor_Aura_Magia);
    obj.dataLink1:setField("cor_Aura_Magia");
    obj.dataLink1:setName("dataLink1");

    obj.img_Aura_Magia = GUI.fromHandle(_obj_newObject("image"));
    obj.img_Aura_Magia:setParent(obj.indicador_cor_Aura_Magia);
    obj.img_Aura_Magia:setName("img_Aura_Magia");
    obj.img_Aura_Magia:setField("imagem_Aura_Magia");
    obj.img_Aura_Magia.grid.role = "col";
    obj.img_Aura_Magia.grid.width = 12;
    obj.img_Aura_Magia:setHeight(134);
    obj.img_Aura_Magia:setStyle("proportional");
    obj.img_Aura_Magia:setEditable(true);
    obj.img_Aura_Magia.animate = true;
    obj.img_Aura_Magia:setMargins({top=3,left=3,right=3,bottom=3});

    obj.dataLink2 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink2:setParent(obj.img_Aura_Magia);
    obj.dataLink2:setField("imagem_Aura_Magia");
    obj.dataLink2:setDefaultValue("https://blob.firecast.com.br/blobs/ONIDFJIW_4313555/aura_magia.png");
    obj.dataLink2:setName("dataLink2");

    obj.label1 = GUI.fromHandle(_obj_newObject("label"));
    obj.label1:setParent(obj.img_Aura_Magia);
    obj.label1.grid.role = "col";
    obj.label1.grid.width = 8;
    obj.label1:setName("label1");

    obj.cbxInvisivel = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.cbxInvisivel:setParent(obj.img_Aura_Magia);
    obj.cbxInvisivel:setName("cbxInvisivel");
    obj.cbxInvisivel.grid.role = "col";
    obj.cbxInvisivel.grid.width = 2;
    obj.cbxInvisivel:setImageChecked("invisivel.png");
    obj.cbxInvisivel:setImageUnchecked("visivel.png");
    obj.cbxInvisivel:setAutoChange(false);
    obj.cbxInvisivel:setHeight(21);
    obj.cbxInvisivel:setMargins({top=3});

    obj.btnExcluir = GUI.fromHandle(_obj_newObject("button"));
    obj.btnExcluir:setParent(obj.img_Aura_Magia);
    obj.btnExcluir:setName("btnExcluir");
    obj.btnExcluir:setText("✖");
    obj.btnExcluir.grid.role = "col";
    obj.btnExcluir.grid.width = 2;
    obj.btnExcluir:setFontSize(6);
    obj.btnExcluir:setHeight(21);
    obj.btnExcluir:setMargins({top=3,right=3});

    obj.rectangle1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle1:setParent(obj.img_Aura_Magia);
    obj.rectangle1:setHeight(20);
    obj.rectangle1:setColor("black");
    obj.rectangle1:setCornerType("round");
    obj.rectangle1.grid.role = "col";
    obj.rectangle1.grid.width = 12;
    obj.rectangle1:setStrokeSize(1);
    obj.rectangle1:setStrokeColor("white");
    obj.rectangle1:setXradius(5);
    obj.rectangle1:setYradius(5);
    obj.rectangle1:setMargins({top=90,right=2,left=2});
    obj.rectangle1:setName("rectangle1");

    obj.edit1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit1:setParent(obj.rectangle1);
    obj.edit1:setField("nome_Aura_Magia");
    obj.edit1.grid.role = "col";
    obj.edit1.grid.width = 12;
    obj.edit1:setTransparent(true);
    obj.edit1:setFontSize(15);
    obj.edit1:setHeight(21);
    obj.edit1:setVertTextAlign("center");
    obj.edit1:setHorzTextAlign("center");
    obj.edit1:setFontFamily("Wishes Script Caps Display");
    obj.edit1:setName("edit1");


      function self:alternarVisibilidade()
        if self.cbxInvisivel.checked then
          NDB.setPermission(sheet, "group", "jogadores", "read", nil);
          NDB.setPermission(sheet, "group", "espectadores", "read", nil);
        else
          NDB.setPermission(sheet, "group", "jogadores", "read", "deny");
          NDB.setPermission(sheet, "group", "espectadores", "read", "deny");
        end;
      end; 

      self.btnExcluir.onClick = function (_)
        local node = sheet
        if  self.observer ~= nil then
            self.observer.enabled = false
            self.observer = nil
        end
        if node ~= nil then
            NDB.deleteNode(node)
        end
      end;

      function self:atualizarCbxInvisivel()          
        if sheet == nil then return end
        if self.cbxInvisivel == nil then return end
        self.cbxInvisivel.checked = NDB.getPermission(sheet, "group", "espectadores", "read") == "deny" or
                                    NDB.getPermission(sheet, "group", "jogadores", "read") == "deny"
        self.cbxInvisivel.enabled = NDB.testPermission(sheet, "writePermissions");
      end;
    


    obj._e_event0 = obj:addEventListener("onScopeNodeChanged",
        function ()
            if self.observer ~= nil then   
                      self.observer.enabled = false;
                      self.observer = nil;
                  end;
            
                  if sheet ~= nil then   
                    local obsOk, obsOrErr = pcall(function() return NDB.newObserver(sheet) end)
                    if obsOk and obsOrErr ~= nil then
                        self.observer = obsOrErr
            
                        self.observer.onPermissionListChanged = function(node)
                            if sheet ~= nil then
                                pcall(function() self:atualizarCbxInvisivel() end)
                            end
                        end;
            
                        self.observer.onFinalPermissionsCouldBeChanged = function(node)
                            if sheet ~= nil then
                                pcall(function() self:atualizarCbxInvisivel() end)
                            end
                        end;
                    end
            
                    pcall(function() self:atualizarCbxInvisivel() end)
                  end;
        end);

    obj._e_event1 = obj.dataLink1:addEventListener("onChange",
        function (field, oldValue, newValue)
            local cor = sheet.cor_Aura_Magia or "#ffffff"
                            self.indicador_cor_Aura_Magia.color = cor
        end);

    obj._e_event2 = obj.dataLink2:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet == nil then return end
                                    pcall(function()
                                        if sheet.imagem_Aura_Magia == nil then 
                                            sheet.imagem_Aura_Magia = "https://blob.firecast.com.br/blobs/ONIDFJIW_4313555/aura_magia.png"
                                        end
                                    end)
        end);

    obj._e_event3 = obj.cbxInvisivel:addEventListener("onClick",
        function (event)
            self:alternarVisibilidade();
        end);

    function obj:_releaseEvents()
        __o_rrpgObjs.removeEventListenerById(self._e_event3);
        __o_rrpgObjs.removeEventListenerById(self._e_event2);
        __o_rrpgObjs.removeEventListenerById(self._e_event1);
        __o_rrpgObjs.removeEventListenerById(self._e_event0);
    end;

    obj._oldLFMDestroy = obj.destroy;

    function obj:destroy() 
        self:_releaseEvents();

        if (self.handle ~= 0) and (self.setNodeDatabase ~= nil) then
          self:setNodeDatabase(nil);
        end;

        if self.dataLink2 ~= nil then self.dataLink2:destroy(); self.dataLink2 = nil; end;
        if self.cbxInvisivel ~= nil then self.cbxInvisivel:destroy(); self.cbxInvisivel = nil; end;
        if self.dataLink1 ~= nil then self.dataLink1:destroy(); self.dataLink1 = nil; end;
        if self.rectangle1 ~= nil then self.rectangle1:destroy(); self.rectangle1 = nil; end;
        if self.edit1 ~= nil then self.edit1:destroy(); self.edit1 = nil; end;
        if self.indicador_cor_Aura_Magia ~= nil then self.indicador_cor_Aura_Magia:destroy(); self.indicador_cor_Aura_Magia = nil; end;
        if self.img_Aura_Magia ~= nil then self.img_Aura_Magia:destroy(); self.img_Aura_Magia = nil; end;
        if self.label1 ~= nil then self.label1:destroy(); self.label1 = nil; end;
        if self.btnExcluir ~= nil then self.btnExcluir:destroy(); self.btnExcluir = nil; end;
        self:_oldLFMDestroy();
    end;

    obj:endUpdate();

    return obj;
end;

function newtemplate_Aura_Magia()
    local retObj = nil;
    __o_rrpgObjs.beginObjectsLoading();

    __o_Utils.tryFinally(
      function()
        retObj = constructNew_template_Aura_Magia();
      end,
      function()
        __o_rrpgObjs.endObjectsLoading();
      end);

    assert(retObj ~= nil);
    return retObj;
end;

local _template_Aura_Magia = {
    newEditor = newtemplate_Aura_Magia, 
    new = newtemplate_Aura_Magia, 
    name = "template_Aura_Magia", 
    dataType = "", 
    formType = "undefined", 
    formComponentName = "form", 
    cacheMode = "none", 
    title = "", 
    description=""};

template_Aura_Magia = _template_Aura_Magia;
Firecast.registrarForm(_template_Aura_Magia);

return _template_Aura_Magia;
