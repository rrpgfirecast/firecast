require("firecast.lua");
local __o_rrpgObjs = require("rrpgObjs.lua");
require("rrpgGUI.lua");
require("rrpgDialogs.lua");
require("rrpgLFM.lua");
require("ndb.lua");
require("locale.lua");
local __o_Utils = require("utils.lua");

local function constructNew_templateSkills()
    local obj = GUI.fromHandle(_obj_newObject("form"));
    local self = obj;
    local sheet = nil;

    rawset(obj, "_oldSetNodeObjectFunction", obj.setNodeObject);

    function obj:setNodeObject(nodeObject)
        sheet = nodeObject;
        self.sheet = nodeObject;
        self:_oldSetNodeObjectFunction(nodeObject);
    end;

    function obj:setNodeDatabase(nodeObject)
        self:setNodeObject(nodeObject);
    end;

    _gui_assignInitialParentForForm(obj.handle);
    obj:beginUpdate();
    obj:setName("templateSkills");
    obj:setHeight(140);
    obj.grid.role = "col";
    obj.grid.width = 4;
    obj.grid["cnt-gutter"] = 0;

    obj.indicador_maetria = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.indicador_maetria:setParent(obj);
    obj.indicador_maetria:setName("indicador_maetria");
    obj.indicador_maetria:setColor("#150e16");
    obj.indicador_maetria:setStrokeSize(1);
    obj.indicador_maetria:setStrokeColor("white");
    obj.indicador_maetria:setCornerType("round");
    obj.indicador_maetria:setXradius(5);
    obj.indicador_maetria:setYradius(5);
    obj.indicador_maetria.grid.role = "col";
    obj.indicador_maetria.grid.width = 12;
    obj.indicador_maetria:setHeight(140);

    obj.dataLink1 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink1:setParent(obj.indicador_maetria);
    obj.dataLink1:setField("maestriaSkill");
    obj.dataLink1:setName("dataLink1");

    obj.imgSkill = GUI.fromHandle(_obj_newObject("image"));
    obj.imgSkill:setParent(obj.indicador_maetria);
    obj.imgSkill:setName("imgSkill");
    obj.imgSkill:setField("imagemSkill");
    obj.imgSkill.grid.role = "col";
    obj.imgSkill.grid.width = 12;
    obj.imgSkill:setHeight(134);
    obj.imgSkill:setStyle("proportional");
    obj.imgSkill:setEditable(true);
    obj.imgSkill.animate = true;
    obj.imgSkill:setMargins({top=3,left=3,right=3,bottom=3});

    obj.dataLink2 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink2:setParent(obj.imgSkill);
    obj.dataLink2:setField("imagemSkill");
    obj.dataLink2:setDefaultValue("https://blob.firecast.com.br/blobs/AARNJUKH_4341169/69d1f3310884980d000ee1a3.png");
    obj.dataLink2:setName("dataLink2");

    obj.rectangle1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle1:setParent(obj.imgSkill);
    obj.rectangle1:setHeight(20);
    obj.rectangle1:setColor("black");
    obj.rectangle1:setCornerType("round");
    obj.rectangle1.grid.role = "col";
    obj.rectangle1.grid.width = 8;
    obj.rectangle1:setStrokeSize(1);
    obj.rectangle1:setStrokeColor("white");
    obj.rectangle1:setXradius(5);
    obj.rectangle1:setYradius(5);
    obj.rectangle1:setMargins({top=3});
    obj.rectangle1:setName("rectangle1");

    obj.label1 = GUI.fromHandle(_obj_newObject("label"));
    obj.label1:setParent(obj.rectangle1);
    obj.label1:setField("maestriaSkill");
    obj.label1.grid.role = "col";
    obj.label1.grid.width = 12;
    obj.label1:setFontSize(10);
    obj.label1:setHeight(21);
    obj.label1:setVertTextAlign("center");
    obj.label1:setHorzTextAlign("center");
    obj.label1:setFontFamily("Cinzel");
    obj.label1:setName("label1");

    obj.cbxInvisivel = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.cbxInvisivel:setParent(obj.imgSkill);
    obj.cbxInvisivel:setName("cbxInvisivel");
    obj.cbxInvisivel.grid.role = "col";
    obj.cbxInvisivel.grid.width = 2;
    obj.cbxInvisivel:setImageChecked("invisivel.png");
    obj.cbxInvisivel:setImageUnchecked("visivel.png");
    obj.cbxInvisivel:setAutoChange(false);
    obj.cbxInvisivel:setHeight(21);
    obj.cbxInvisivel:setMargins({top=3});

    obj.btnExcluir = GUI.fromHandle(_obj_newObject("button"));
    obj.btnExcluir:setParent(obj.imgSkill);
    obj.btnExcluir:setName("btnExcluir");
    obj.btnExcluir:setText("✖");
    obj.btnExcluir.grid.role = "col";
    obj.btnExcluir.grid.width = 2;
    obj.btnExcluir:setFontSize(6);
    obj.btnExcluir:setHeight(21);
    obj.btnExcluir:setMargins({top=3,right=3});

    obj.rectangle2 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle2:setParent(obj.imgSkill);
    obj.rectangle2:setHeight(20);
    obj.rectangle2:setColor("black");
    obj.rectangle2:setCornerType("round");
    obj.rectangle2.grid.role = "col";
    obj.rectangle2.grid.width = 12;
    obj.rectangle2:setStrokeSize(1);
    obj.rectangle2:setStrokeColor("white");
    obj.rectangle2:setXradius(5);
    obj.rectangle2:setYradius(5);
    obj.rectangle2:setMargins({top=90,right=2,left=2});
    obj.rectangle2:setName("rectangle2");

    obj.edit1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit1:setParent(obj.rectangle2);
    obj.edit1:setField("nomeSkill");
    obj.edit1.grid.role = "col";
    obj.edit1.grid.width = 12;
    obj.edit1:setTransparent(true);
    obj.edit1:setFontSize(15);
    obj.edit1:setHeight(21);
    obj.edit1:setVertTextAlign("center");
    obj.edit1:setHorzTextAlign("center");
    obj.edit1:setFontFamily("Wishes Script Caps Display");
    obj.edit1:setName("edit1");


      function self:alternarVisibilidade()
        if self.cbxInvisivel.checked then
          NDB.setPermission(sheet, "group", "jogadores", "read", nil);
          NDB.setPermission(sheet, "group", "espectadores", "read", nil);
        else
          NDB.setPermission(sheet, "group", "jogadores", "read", "deny");
          NDB.setPermission(sheet, "group", "espectadores", "read", "deny");
        end;
      end; 

      self.btnExcluir.onClick = function (_)
        local node = sheet
        if  self.observer ~= nil then
            self.observer.enabled = false
            self.observer = nil
        end
        if node ~= nil then
            NDB.deleteNode(node)
        end
      end;

      function self:atualizarCbxInvisivel()          
        if sheet == nil then return end
        if self.cbxInvisivel == nil then return end
        self.cbxInvisivel.checked = NDB.getPermission(sheet, "group", "espectadores", "read") == "deny" or
                                    NDB.getPermission(sheet, "group", "jogadores", "read") == "deny"
        self.cbxInvisivel.enabled = NDB.testPermission(sheet, "writePermissions");
      end;
    


    obj._e_event0 = obj:addEventListener("onScopeNodeChanged",
        function ()
            if self.observer ~= nil then   
                      self.observer.enabled = false;
                      self.observer = nil;
                  end;
            
                  if sheet ~= nil then   
                    self.observer = NDB.newObserver(sheet);
            
                    self.observer.onPermissionListChanged = function(node)
                        if sheet ~= nil then
                            pcall(function() self:atualizarCbxInvisivel() end)
                        end
                    end;
            
                    self.observer.onFinalPermissionsCouldBeChanged = function(node)
                        if sheet ~= nil then
                            pcall(function() self:atualizarCbxInvisivel() end)
                        end
                    end;
            
                    pcall(function() self:atualizarCbxInvisivel() end)
                  end;
        end);

    obj._e_event1 = obj.dataLink1:addEventListener("onChange",
        function (field, oldValue, newValue)
            local maestria = sheet.maestriaSkill
                            if maestria == "Básica" then
                                self.indicador_maetria.color = "#4e4e4e"
                            elseif maestria == "Intermediária" then
                                self.indicador_maetria.color = "#00900c"
                            elseif maestria == "Avançada" then
                                self.indicador_maetria.color = "#0032b0"
                            elseif maestria == "Mestra" then
                                self.indicador_maetria.color = "#830285"
                            elseif maestria == "Suprema" then
                                self.indicador_maetria.color = "#ffd000"
                            else
                                self.indicador_maetria.color = "#ffffff"
                            end
        end);

    obj._e_event2 = obj.dataLink2:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet.imagemSkill == nil then 
                                    sheet.imagemSkill = "https://blob.firecast.com.br/blobs/AARNJUKH_4341169/69d1f3310884980d000ee1a3.png";
                                end;
        end);

    obj._e_event3 = obj.cbxInvisivel:addEventListener("onClick",
        function (event)
            self:alternarVisibilidade();
        end);

    function obj:_releaseEvents()
        __o_rrpgObjs.removeEventListenerById(self._e_event3);
        __o_rrpgObjs.removeEventListenerById(self._e_event2);
        __o_rrpgObjs.removeEventListenerById(self._e_event1);
        __o_rrpgObjs.removeEventListenerById(self._e_event0);
    end;

    obj._oldLFMDestroy = obj.destroy;

    function obj:destroy() 
        self:_releaseEvents();

        if (self.handle ~= 0) and (self.setNodeDatabase ~= nil) then
          self:setNodeDatabase(nil);
        end;

        if self.imgSkill ~= nil then self.imgSkill:destroy(); self.imgSkill = nil; end;
        if self.dataLink2 ~= nil then self.dataLink2:destroy(); self.dataLink2 = nil; end;
        if self.cbxInvisivel ~= nil then self.cbxInvisivel:destroy(); self.cbxInvisivel = nil; end;
        if self.dataLink1 ~= nil then self.dataLink1:destroy(); self.dataLink1 = nil; end;
        if self.rectangle1 ~= nil then self.rectangle1:destroy(); self.rectangle1 = nil; end;
        if self.edit1 ~= nil then self.edit1:destroy(); self.edit1 = nil; end;
        if self.btnExcluir ~= nil then self.btnExcluir:destroy(); self.btnExcluir = nil; end;
        if self.label1 ~= nil then self.label1:destroy(); self.label1 = nil; end;
        if self.indicador_maetria ~= nil then self.indicador_maetria:destroy(); self.indicador_maetria = nil; end;
        if self.rectangle2 ~= nil then self.rectangle2:destroy(); self.rectangle2 = nil; end;
        self:_oldLFMDestroy();
    end;

    obj:endUpdate();

    return obj;
end;

function newtemplateSkills()
    local retObj = nil;
    __o_rrpgObjs.beginObjectsLoading();

    __o_Utils.tryFinally(
      function()
        retObj = constructNew_templateSkills();
      end,
      function()
        __o_rrpgObjs.endObjectsLoading();
      end);

    assert(retObj ~= nil);
    return retObj;
end;

local _templateSkills = {
    newEditor = newtemplateSkills, 
    new = newtemplateSkills, 
    name = "templateSkills", 
    dataType = "", 
    formType = "undefined", 
    formComponentName = "form", 
    cacheMode = "none", 
    title = "", 
    description=""};

templateSkills = _templateSkills;
Firecast.registrarForm(_templateSkills);

return _templateSkills;
