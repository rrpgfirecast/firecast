require("firecast.lua");
local __o_rrpgObjs = require("rrpgObjs.lua");
require("rrpgGUI.lua");
require("rrpgDialogs.lua");
require("rrpgLFM.lua");
require("ndb.lua");
require("locale.lua");
local __o_Utils = require("utils.lua");

local function constructNew_templateEquipamentoItem()
    local obj = GUI.fromHandle(_obj_newObject("form"));
    local self = obj;
    local sheet = nil;

    rawset(obj, "_oldSetNodeObjectFunction", obj.setNodeObject);

    function obj:setNodeObject(nodeObject)
        sheet = nodeObject;
        self.sheet = nodeObject;
        self:_oldSetNodeObjectFunction(nodeObject);
    end;

    function obj:setNodeDatabase(nodeObject)
        self:setNodeObject(nodeObject);
    end;

    _gui_assignInitialParentForForm(obj.handle);
    obj:beginUpdate();
    obj:setName("templateEquipamentoItem");
    obj:setHeight(150);
    obj.grid.role = "col";
    obj.grid.width = 4;
    obj.grid["cnt-gutter"] = 0;

    obj.indicadorEquipado = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.indicadorEquipado:setParent(obj);
    obj.indicadorEquipado:setName("indicadorEquipado");
    obj.indicadorEquipado:setColor("#150e16");
    obj.indicadorEquipado:setStrokeSize(1);
    obj.indicadorEquipado:setStrokeColor("white");
    obj.indicadorEquipado:setCornerType("round");
    obj.indicadorEquipado:setXradius(5);
    obj.indicadorEquipado:setYradius(5);
    obj.indicadorEquipado.grid.role = "col";
    obj.indicadorEquipado.grid.width = 12;
    obj.indicadorEquipado:setHeight(150);

    obj.dataLink1 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink1:setParent(obj.indicadorEquipado);
    obj.dataLink1:setField("isEquipado");
    obj.dataLink1:setName("dataLink1");

    obj.imgEquipamento = GUI.fromHandle(_obj_newObject("image"));
    obj.imgEquipamento:setParent(obj.indicadorEquipado);
    obj.imgEquipamento:setName("imgEquipamento");
    obj.imgEquipamento:setField("imagemEquip");
    obj.imgEquipamento.grid.role = "col";
    obj.imgEquipamento.grid.width = 12;
    obj.imgEquipamento:setHeight(144);
    obj.imgEquipamento:setStyle("proportional");
    obj.imgEquipamento:setEditable(true);
    obj.imgEquipamento.animate = true;
    obj.imgEquipamento:setMargins({top=3,left=3,right=3,bottom=3});

    obj.dataLink2 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink2:setParent(obj.imgEquipamento);
    obj.dataLink2:setField("imagemEquip");
    obj.dataLink2:setDefaultValue("https://blob.firecast.com.br/blobs/QFIFTOKR_3447743/perspective-dice-random-icon-469x512-mm6xb.png");
    obj.dataLink2:setName("dataLink2");

    obj.rectangle1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle1:setParent(obj.imgEquipamento);
    obj.rectangle1:setHeight(20);
    obj.rectangle1:setColor("black");
    obj.rectangle1:setCornerType("round");
    obj.rectangle1.grid.role = "col";
    obj.rectangle1.grid.width = 4;
    obj.rectangle1:setStrokeSize(1);
    obj.rectangle1:setStrokeColor("white");
    obj.rectangle1:setXradius(5);
    obj.rectangle1:setYradius(5);
    obj.rectangle1:setMargins({top=3,left=3});
    obj.rectangle1:setName("rectangle1");

    obj.edit1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit1:setParent(obj.rectangle1);
    obj.edit1:setField("qtdEquip");
    obj.edit1.grid.role = "col";
    obj.edit1.grid.width = 12;
    obj.edit1:setTransparent(true);
    obj.edit1:setFontSize(15);
    obj.edit1:setHeight(21);
    obj.edit1:setVertTextAlign("center");
    obj.edit1:setHorzTextAlign("center");
    obj.edit1:setFontFamily("Wishes Script Caps Display");
    obj.edit1:setName("edit1");

    obj.rectangle2 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle2:setParent(obj.imgEquipamento);
    obj.rectangle2:setHeight(20);
    obj.rectangle2:setColor("black");
    obj.rectangle2:setCornerType("round");
    obj.rectangle2.grid.role = "col";
    obj.rectangle2.grid.width = 4;
    obj.rectangle2:setStrokeSize(1);
    obj.rectangle2:setStrokeColor("white");
    obj.rectangle2:setXradius(5);
    obj.rectangle2:setYradius(5);
    obj.rectangle2:setMargins({top=3});
    obj.rectangle2:setName("rectangle2");

    obj.label1 = GUI.fromHandle(_obj_newObject("label"));
    obj.label1:setParent(obj.rectangle2);
    obj.label1:setField("rankEquip");
    obj.label1.grid.role = "col";
    obj.label1.grid.width = 12;
    obj.label1:setFontSize(15);
    obj.label1:setHeight(21);
    obj.label1:setVertTextAlign("center");
    obj.label1:setHorzTextAlign("center");
    obj.label1:setFontFamily("Cinzel");
    obj.label1:setName("label1");

    obj.cbxInvisivel = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.cbxInvisivel:setParent(obj.imgEquipamento);
    obj.cbxInvisivel:setName("cbxInvisivel");
    obj.cbxInvisivel.grid.role = "col";
    obj.cbxInvisivel.grid.width = 2;
    obj.cbxInvisivel:setImageChecked("invisivel.png");
    obj.cbxInvisivel:setImageUnchecked("visivel.png");
    obj.cbxInvisivel:setAutoChange(false);
    obj.cbxInvisivel:setHeight(21);
    obj.cbxInvisivel:setMargins({top=3});

    obj.btnExcluir = GUI.fromHandle(_obj_newObject("button"));
    obj.btnExcluir:setParent(obj.imgEquipamento);
    obj.btnExcluir:setName("btnExcluir");
    obj.btnExcluir:setText("✖");
    obj.btnExcluir.grid.role = "col";
    obj.btnExcluir.grid.width = 2;
    obj.btnExcluir:setFontSize(6);
    obj.btnExcluir:setHeight(21);
    obj.btnExcluir:setMargins({top=3,right=3});

    obj.rectangle3 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle3:setParent(obj.imgEquipamento);
    obj.rectangle3:setHeight(20);
    obj.rectangle3:setColor("black");
    obj.rectangle3:setCornerType("round");
    obj.rectangle3.grid.role = "col";
    obj.rectangle3.grid.width = 12;
    obj.rectangle3:setStrokeSize(1);
    obj.rectangle3:setStrokeColor("white");
    obj.rectangle3:setXradius(5);
    obj.rectangle3:setYradius(5);
    obj.rectangle3:setMargins({top=100,right=2,left=2});
    obj.rectangle3:setName("rectangle3");

    obj.edit2 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit2:setParent(obj.rectangle3);
    obj.edit2:setField("nomeEquip");
    obj.edit2.grid.role = "col";
    obj.edit2.grid.width = 12;
    obj.edit2:setTransparent(true);
    obj.edit2:setFontSize(15);
    obj.edit2:setHeight(21);
    obj.edit2:setVertTextAlign("center");
    obj.edit2:setHorzTextAlign("center");
    obj.edit2:setFontFamily("Wishes Script Caps Display");
    obj.edit2:setName("edit2");


      function self:alternarVisibilidade()
        if self.cbxInvisivel.checked then
          NDB.setPermission(sheet, "group", "jogadores", "read", nil);
          NDB.setPermission(sheet, "group", "espectadores", "read", nil);
        else
          NDB.setPermission(sheet, "group", "jogadores", "read", "deny");
          NDB.setPermission(sheet, "group", "espectadores", "read", "deny");
        end;
      end; 

      self.btnExcluir.onClick = function (_)
        local node = sheet
        if  self.observer ~= nil then
            self.observer.enabled = false
            self.observer = nil
        end
        if node ~= nil then
            NDB.deleteNode(node)
        end
      end;

      function self:atualizarCbxInvisivel()          
        if sheet == nil then return end
        if self.cbxInvisivel == nil then return end
        self.cbxInvisivel.checked = NDB.getPermission(sheet, "group", "espectadores", "read") == "deny" or
                                    NDB.getPermission(sheet, "group", "jogadores", "read") == "deny"
        self.cbxInvisivel.enabled = NDB.testPermission(sheet, "writePermissions");
      end;
    


    obj._e_event0 = obj:addEventListener("onScopeNodeChanged",
        function ()
            if self.observer ~= nil then   
                      self.observer.enabled = false;
                      self.observer = nil;
                  end;
            
                  if sheet ~= nil then   
                    local obsOk, obsOrErr = pcall(function() return NDB.newObserver(sheet) end)
                    if obsOk and obsOrErr ~= nil then
                        self.observer = obsOrErr
            
                        self.observer.onPermissionListChanged = function(node)
                            if sheet ~= nil then
                                pcall(function() self:atualizarCbxInvisivel() end)
                            end
                        end;
            
                        self.observer.onFinalPermissionsCouldBeChanged = function(node)
                            if sheet ~= nil then
                                pcall(function() self:atualizarCbxInvisivel() end)
                            end
                        end;
                    end
            
                    pcall(function() self:atualizarCbxInvisivel() end)
                  end;
        end);

    obj._e_event1 = obj.dataLink1:addEventListener("onChange",
        function (field, oldValue, newValue)
            -- Agora o 'self.indicadorEquipado' vai existir!
                            if self.indicadorEquipado ~= nil then
                                if sheet.isEquipado == true then
                                self.indicadorEquipado.strokeColor = "red"
                                self.indicadorEquipado.strokeSize = 2
                                else
                                self.indicadorEquipado.strokeColor = "white"
                                self.indicadorEquipado.strokeSize = 1
                                end;
                            end;
        end);

    obj._e_event2 = obj.dataLink2:addEventListener("onChange",
        function (field, oldValue, newValue)
            if sheet == nil then return end
                                pcall(function()
                                    if sheet.imagemEquip == nil then 
                                        sheet.imagemEquip = "https://blob.firecast.com.br/blobs/QFIFTOKR_3447743/perspective-dice-random-icon-469x512-mm6xb.png"
                                    end
                                end)
        end);

    obj._e_event3 = obj.cbxInvisivel:addEventListener("onClick",
        function (event)
            self:alternarVisibilidade();
        end);

    function obj:_releaseEvents()
        __o_rrpgObjs.removeEventListenerById(self._e_event3);
        __o_rrpgObjs.removeEventListenerById(self._e_event2);
        __o_rrpgObjs.removeEventListenerById(self._e_event1);
        __o_rrpgObjs.removeEventListenerById(self._e_event0);
    end;

    obj._oldLFMDestroy = obj.destroy;

    function obj:destroy() 
        self:_releaseEvents();

        if (self.handle ~= 0) and (self.setNodeDatabase ~= nil) then
          self:setNodeDatabase(nil);
        end;

        if self.dataLink2 ~= nil then self.dataLink2:destroy(); self.dataLink2 = nil; end;
        if self.rectangle2 ~= nil then self.rectangle2:destroy(); self.rectangle2 = nil; end;
        if self.cbxInvisivel ~= nil then self.cbxInvisivel:destroy(); self.cbxInvisivel = nil; end;
        if self.edit2 ~= nil then self.edit2:destroy(); self.edit2 = nil; end;
        if self.dataLink1 ~= nil then self.dataLink1:destroy(); self.dataLink1 = nil; end;
        if self.rectangle1 ~= nil then self.rectangle1:destroy(); self.rectangle1 = nil; end;
        if self.rectangle3 ~= nil then self.rectangle3:destroy(); self.rectangle3 = nil; end;
        if self.edit1 ~= nil then self.edit1:destroy(); self.edit1 = nil; end;
        if self.btnExcluir ~= nil then self.btnExcluir:destroy(); self.btnExcluir = nil; end;
        if self.imgEquipamento ~= nil then self.imgEquipamento:destroy(); self.imgEquipamento = nil; end;
        if self.label1 ~= nil then self.label1:destroy(); self.label1 = nil; end;
        if self.indicadorEquipado ~= nil then self.indicadorEquipado:destroy(); self.indicadorEquipado = nil; end;
        self:_oldLFMDestroy();
    end;

    obj:endUpdate();

    return obj;
end;

function newtemplateEquipamentoItem()
    local retObj = nil;
    __o_rrpgObjs.beginObjectsLoading();

    __o_Utils.tryFinally(
      function()
        retObj = constructNew_templateEquipamentoItem();
      end,
      function()
        __o_rrpgObjs.endObjectsLoading();
      end);

    assert(retObj ~= nil);
    return retObj;
end;

local _templateEquipamentoItem = {
    newEditor = newtemplateEquipamentoItem, 
    new = newtemplateEquipamentoItem, 
    name = "templateEquipamentoItem", 
    dataType = "", 
    formType = "undefined", 
    formComponentName = "form", 
    cacheMode = "none", 
    title = "", 
    description=""};

templateEquipamentoItem = _templateEquipamentoItem;
Firecast.registrarForm(_templateEquipamentoItem);

return _templateEquipamentoItem;
