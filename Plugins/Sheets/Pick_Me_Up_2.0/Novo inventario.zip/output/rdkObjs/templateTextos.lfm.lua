require("firecast.lua");
local __o_rrpgObjs = require("rrpgObjs.lua");
require("rrpgGUI.lua");
require("rrpgDialogs.lua");
require("rrpgLFM.lua");
require("ndb.lua");
require("locale.lua");
local __o_Utils = require("utils.lua");

local function constructNew_templateTextos()
    local obj = GUI.fromHandle(_obj_newObject("form"));
    local self = obj;
    local sheet = nil;

    rawset(obj, "_oldSetNodeObjectFunction", obj.setNodeObject);

    function obj:setNodeObject(nodeObject)
        sheet = nodeObject;
        self.sheet = nodeObject;
        self:_oldSetNodeObjectFunction(nodeObject);
    end;

    function obj:setNodeDatabase(nodeObject)
        self:setNodeObject(nodeObject);
    end;

    _gui_assignInitialParentForForm(obj.handle);
    obj:beginUpdate();
    obj:setName("templateTextos");
    obj:setHeight(50);
    obj.grid.role = "col";
    obj.grid.width = 12;
    obj.grid["cnt-gutter"] = 0;

    obj.indicador_Texto = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.indicador_Texto:setParent(obj);
    obj.indicador_Texto:setName("indicador_Texto");
    obj.indicador_Texto:setColor("#150e16");
    obj.indicador_Texto:setStrokeSize(1);
    obj.indicador_Texto:setStrokeColor("white");
    obj.indicador_Texto:setCornerType("round");
    obj.indicador_Texto:setXradius(5);
    obj.indicador_Texto:setYradius(5);
    obj.indicador_Texto.grid.role = "col";
    obj.indicador_Texto.grid.width = 12;
    obj.indicador_Texto:setHeight(40);

    obj.dataLink1 = GUI.fromHandle(_obj_newObject("dataLink"));
    obj.dataLink1:setParent(obj.indicador_Texto);
    obj.dataLink1:setField("Texto");
    obj.dataLink1:setName("dataLink1");

    obj.edit1 = GUI.fromHandle(_obj_newObject("edit"));
    obj.edit1:setParent(obj.indicador_Texto);
    obj.edit1:setField("nome");
    obj.edit1.grid.role = "col";
    obj.edit1.grid.width = 10;
    obj.edit1:setTransparent(true);
    obj.edit1:setFontSize(15);
    obj.edit1:setHeight(21);
    obj.edit1:setVertTextAlign("center");
    obj.edit1:setHorzTextAlign("center");
    obj.edit1:setFontFamily("Wishes Script Caps Display");
    obj.edit1:setName("edit1");

    obj.rectangle1 = GUI.fromHandle(_obj_newObject("rectangle"));
    obj.rectangle1:setParent(obj.indicador_Texto);
    obj.rectangle1.grid.role = "col";
    obj.rectangle1.grid.width = 2;
    obj.rectangle1:setColor("none");
    obj.rectangle1:setHeight(40);
    obj.rectangle1:setName("rectangle1");

    obj.cbxInvisivel = GUI.fromHandle(_obj_newObject("imageCheckBox"));
    obj.cbxInvisivel:setParent(obj.rectangle1);
    obj.cbxInvisivel:setName("cbxInvisivel");
    obj.cbxInvisivel.grid.role = "col";
    obj.cbxInvisivel.grid.width = 12;
    obj.cbxInvisivel:setImageChecked("invisivel.png");
    obj.cbxInvisivel:setImageUnchecked("visivel.png");
    obj.cbxInvisivel:setAutoChange(false);
    obj.cbxInvisivel:setHeight(20);
    obj.cbxInvisivel:setMargins({top=3});

    obj.btnExcluir = GUI.fromHandle(_obj_newObject("button"));
    obj.btnExcluir:setParent(obj.rectangle1);
    obj.btnExcluir:setName("btnExcluir");
    obj.btnExcluir:setText("✖");
    obj.btnExcluir.grid.role = "col";
    obj.btnExcluir.grid.width = 12;
    obj.btnExcluir:setFontSize(6);
    obj.btnExcluir:setHeight(20);
    obj.btnExcluir:setMargins({top=3,right=3});


      function self:alternarVisibilidade()
        if self.cbxInvisivel.checked then
          NDB.setPermission(sheet, "group", "jogadores", "read", nil);
          NDB.setPermission(sheet, "group", "espectadores", "read", nil);
        else
          NDB.setPermission(sheet, "group", "jogadores", "read", "deny");
          NDB.setPermission(sheet, "group", "espectadores", "read", "deny");
        end;
      end; 

      self.btnExcluir.onClick = function (_)
        local node = sheet
        if  self.observer ~= nil then
            self.observer.enabled = false
            self.observer = nil
        end
        if node ~= nil then
            NDB.deleteNode(node)
        end
      end;

      function self:atualizarCbxInvisivel()          
        if sheet == nil then return end
        if self.cbxInvisivel == nil then return end
        self.cbxInvisivel.checked = NDB.getPermission(sheet, "group", "espectadores", "read") == "deny" or
                                    NDB.getPermission(sheet, "group", "jogadores", "read") == "deny"
        self.cbxInvisivel.enabled = NDB.testPermission(sheet, "writePermissions");
      end;
    


    obj._e_event0 = obj:addEventListener("onScopeNodeChanged",
        function ()
            if self.observer ~= nil then   
                      self.observer.enabled = false;
                      self.observer = nil;
                  end;
            
                  if sheet ~= nil then   
                    local obsOk, obsOrErr = pcall(function() return NDB.newObserver(sheet) end)
                    if obsOk and obsOrErr ~= nil then
                        self.observer = obsOrErr
            
                        self.observer.onPermissionListChanged = function(node)
                            if sheet ~= nil then
                                pcall(function() self:atualizarCbxInvisivel() end)
                            end
                        end;
            
                        self.observer.onFinalPermissionsCouldBeChanged = function(node)
                            if sheet ~= nil then
                                pcall(function() self:atualizarCbxInvisivel() end)
                            end
                        end;
                    end
            
                    pcall(function() self:atualizarCbxInvisivel() end)
                  end;
        end);

    obj._e_event1 = obj.dataLink1:addEventListener("onChange",
        function (field, oldValue, newValue)
            local cor = sheet.Texto
                          if cor ~= nil and cor ~= "" then
                              self.indicador_Texto.color = cor
                          else
                              self.indicador_Texto.color = "#150e16"
                          end
        end);

    obj._e_event2 = obj.cbxInvisivel:addEventListener("onClick",
        function (event)
            self:alternarVisibilidade();
        end);

    function obj:_releaseEvents()
        __o_rrpgObjs.removeEventListenerById(self._e_event2);
        __o_rrpgObjs.removeEventListenerById(self._e_event1);
        __o_rrpgObjs.removeEventListenerById(self._e_event0);
    end;

    obj._oldLFMDestroy = obj.destroy;

    function obj:destroy() 
        self:_releaseEvents();

        if (self.handle ~= 0) and (self.setNodeDatabase ~= nil) then
          self:setNodeDatabase(nil);
        end;

        if self.edit1 ~= nil then self.edit1:destroy(); self.edit1 = nil; end;
        if self.indicador_Texto ~= nil then self.indicador_Texto:destroy(); self.indicador_Texto = nil; end;
        if self.cbxInvisivel ~= nil then self.cbxInvisivel:destroy(); self.cbxInvisivel = nil; end;
        if self.btnExcluir ~= nil then self.btnExcluir:destroy(); self.btnExcluir = nil; end;
        if self.dataLink1 ~= nil then self.dataLink1:destroy(); self.dataLink1 = nil; end;
        if self.rectangle1 ~= nil then self.rectangle1:destroy(); self.rectangle1 = nil; end;
        self:_oldLFMDestroy();
    end;

    obj:endUpdate();

    return obj;
end;

function newtemplateTextos()
    local retObj = nil;
    __o_rrpgObjs.beginObjectsLoading();

    __o_Utils.tryFinally(
      function()
        retObj = constructNew_templateTextos();
      end,
      function()
        __o_rrpgObjs.endObjectsLoading();
      end);

    assert(retObj ~= nil);
    return retObj;
end;

local _templateTextos = {
    newEditor = newtemplateTextos, 
    new = newtemplateTextos, 
    name = "templateTextos", 
    dataType = "", 
    formType = "undefined", 
    formComponentName = "form", 
    cacheMode = "none", 
    title = "", 
    description=""};

templateTextos = _templateTextos;
Firecast.registrarForm(_templateTextos);

return _templateTextos;
